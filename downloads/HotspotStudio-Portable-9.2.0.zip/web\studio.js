(function () {
  'use strict';

  const $ = (selector, root) => (root || document).querySelector(selector);
  const $$ = (selector, root) => Array.from((root || document).querySelectorAll(selector));
  const icon = (name) => '<svg aria-hidden="true"><use href="#i-' + name + '"></use></svg>';
  const APP_BUILD = '9.2.0';
  const KEYS = {
    news: 'hotspot_news_v1',
    selected: 'hotspot_selection_v1',
    article: 'hotspot_article_v1',
    drafts: 'hotspot_drafts_v1',
    completed: 'hotspot_completed_v1',
    generating: 'hotspot_generating_v1',
    pendingBrowse: 'hotspot_pending_browse_v1',
    imported: 'hotspot_imported_topics_v1',
    edgeSeen: 'hotspot_edge_seen_v1',
    edgeSeenKeys: 'hotspot_edge_seen_keys_v1',
    materials: 'hotspot_materials_v1',
    edgeAutoDraft: 'hotspot_edge_auto_draft_v1',
    presenterImage: 'hotspot_presenter_image_v1',
    originalSubtitleText: 'hotspot_original_subtitle_text_v1',
    chineseSubtitleText: 'hotspot_chinese_subtitle_text_v1',
    videoQuality: 'hotspot_video_quality_v1',
    directorStyle: 'hotspot_director_style_v1',
    videoOutputMode: 'hotspot_video_output_mode_v1',
    subtitleSourceLanguage: 'hotspot_subtitle_source_language_v1',
    archiveSearchCache: 'hotspot_archive_search_cache_v1',
    railOrder: 'hotspot_section_rail_order_v1',
    episodes: 'hotspot_program_episodes_v1',
    novel: 'hotspot_original_novel_v1',
    novelMaterials: 'hotspot_novel_materials_v1',
    videoDownloads: 'hotspot_video_downloads_v1',
    videoDownloadMode: 'hotspot_video_download_mode_v1'
  };
  const MEDIA_DB_NAME = 'hotspot_studio_media_v1';
  const MEDIA_ORIGINAL_STORE = 'original_videos';
  const MEDIA_FINISHED_STORE = 'finished_videos';
  const FALLBACK_SECTIONS = [
    { id: 'general', name: '要闻', color: '#ed5b47', enabled: true },
    { id: 'society', name: '社会', color: '#d88a37', enabled: true },
    { id: 'finance', name: '财经', color: '#37936a', enabled: true },
    { id: 'tech', name: '科技', color: '#466fd3', enabled: true },
    { id: 'entertainment', name: '文娱', color: '#c95d92', enabled: true },
    { id: 'sports', name: '体育', color: '#319898', enabled: true },
    { id: 'world', name: '国际', color: '#7961c4', enabled: true },
    { id: 'military', name: '军事', color: '#717b61', enabled: true },
    { id: 'health', name: '健康', color: '#39a87b', enabled: true },
    { id: 'education', name: '教育', color: '#b6803f', enabled: true },
    { id: 'realestate', name: '房产', color: '#8e745b', enabled: true },
    { id: 'travel', name: '旅游', color: '#3c9ca4', enabled: true },
    { id: 'auto', name: '汽车', color: '#657687', enabled: true },
    { id: 'digital', name: '数码', color: '#597fc0', enabled: true },
    { id: 'game', name: '游戏', color: '#8f64ba', enabled: true },
    { id: 'tencent', name: '腾讯热闻', color: '#2f7fc4', enabled: true },
    { id: 'weibo', name: '微博热议', color: '#e15b56', enabled: true },
    { id: 'netease', name: '网易热闻', color: '#d9363e', enabled: true },
    { id: 'jinjiang', name: '晋江热文', color: '#a75c76', enabled: true },
    { id: 'fanqie', name: '番茄小说', color: '#ef604a', enabled: true },
    { id: 'zhihu', name: '知乎热文', color: '#356fbb', enabled: true },
    { id: 'world-trivia', name: '海外冷知识', color: '#5d8d84', enabled: true },
    { id: 'world-local', name: '海外地方新闻', color: '#647fa5', enabled: true },
    { id: 'qimao', name: '七猫小说', color: '#e69435', enabled: true }
  ];
  const PLATFORM_SECTIONS = {
    tencent: { name: '腾讯新闻网页', url: 'https://news.qq.com/', hint: '腾讯新闻网页内容' },
    weibo: { name: '微博热搜', url: 'https://s.weibo.com/top/summary', hint: '实时热搜话题与全网讨论' },
    netease: { name: '网易新闻', url: 'https://news.163.com/', hint: '最新资讯与深度报道' },
    jinjiang: { name: '晋江文学城', url: 'https://www.jjwxc.net/', hint: '公开作品与阅读趋势' },
    fanqie: { name: '番茄小说', url: 'https://fanqienovel.com/', hint: '热门小说与阅读话题' },
    qimao: { name: '七猫小说', url: 'https://www.qimao.com/', hint: '热门小说与阅读话题' },
    zhihu: { name: '知乎', url: 'https://www.zhihu.com/', hint: '热门问题与讨论文章' },
    toutiao: { name: '今日头条', url: 'https://www.toutiao.com/', hint: '资讯发布与创作后台' },
    qqlive: { name: '腾讯视频', url: 'https://v.qq.com/', hint: '影视内容与视频素材' },
    youku: { name: '优酷', url: 'https://www.youku.com/', hint: '影视内容与视频素材' },
    mgtv: { name: '芒果TV', url: 'https://www.mgtv.com/', hint: '影视内容与视频素材' },
    iqiyi: { name: '爱奇艺', url: 'https://www.iqiyi.com/', hint: '影视内容与视频素材' },
    bilibili: { name: '哔哩哔哩', url: 'https://www.bilibili.com/', hint: '视频内容与创作素材' },
    jianying: { name: '剪映', url: 'https://www.capcut.cn/', hint: '剪辑授权素材与导出成片' },
    'netease-music': { name: '网易云音乐', url: 'https://music.163.com/', hint: '音乐与电台内容' },
    baidu: { name: '百度', url: 'https://www.baidu.com/', hint: '全网公开信息与素材搜索' },
    sogou: { name: '搜狗', url: 'https://www.sogou.com/', hint: '全网公开信息与素材搜索' },
    sohu: { name: '搜狐', url: 'https://www.sohu.com/', hint: '新闻、视频与公开内容' },
    youtube: { name: 'YouTube', url: 'https://www.youtube.com/', hint: '海外公开视频与官方预告' },
    ted: { name: 'TED', url: 'https://www.ted.com/', hint: '公开演讲与思想内容' },
    archive: { name: 'Internet Archive', url: 'https://archive.org/', hint: '公开版权影像资料' },
    workbuddy: { name: 'Workbuddy', url: 'https://www.workbuddy.ai/', hint: '独立 AI 创作助手' }
  };
  const WORKBUDDY_URL = 'https://www.workbuddy.ai/';
  const WEB_ONLY_SOURCES = new Set([
    'weibo', 'netease', 'jinjiang', 'fanqie', 'qimao', 'zhihu',
    'baidu', 'sogou', 'sohu', 'youtube', 'ted', 'archive'
  ]);
  const DIRECTOR_STYLES = {
    zhang: {
      name: '张艺谋电影感', accent: '#b3261e', gold: '#d8b26b', ink: '#100d0b',
      font: '"SimSun", "Microsoft YaHei UI"', note: '红色、金色与墨黑为主，强调对称画面、宏大留白和由慢到快的剪辑节奏。'
    },
    chen: {
      name: '陈凯歌古典叙事', accent: '#a56b3f', gold: '#e0c08a', ink: '#171513',
      font: '"KaiTi", "Microsoft YaHei UI"', note: '暖褐色调、宽阔留白、缓慢推镜和文学化章节标题。'
    },
    wong: {
      name: '王家卫霓虹都市', accent: '#d62967', gold: '#38c8c3', ink: '#10101d',
      font: '"Microsoft YaHei UI"', note: '青绿与洋红霓虹、偏置构图、轻微拖影和都市情绪字幕。'
    },
    nolan: {
      name: '诺兰冷峻工业', accent: '#e2b454', gold: '#8ba0b8', ink: '#080c11',
      font: '"Microsoft YaHei UI"', note: '冷蓝黑白、硬朗信息条、短镜头交错和悬疑推进节奏。'
    },
    guofan: {
      name: '郭帆科幻工业', accent: '#4ac8d3', gold: '#e8874e', ink: '#071218',
      font: '"Microsoft YaHei UI"', note: '青橙对比、工业网格、HUD信息线和未来设备质感。'
    },
    wushan: {
      name: '乌尔善神话史诗', accent: '#b65a2c', gold: '#c8a766', ink: '#0f0b09',
      font: '"SimSun", "Microsoft YaHei UI"', note: '青铜、炭黑与熔金色调，强调史诗体量、火粒和仪式感。'
    },
    zhengwu: {
      name: '正午阳光现实主义', accent: '#5f8c71', gold: '#d4c9aa', ink: '#151a18',
      font: '"Microsoft YaHei UI"', note: '自然光、生活化色彩、克制字幕和人物关系叙事。'
    },
    caodun: {
      name: '曹盾古装剧集', accent: '#8b4d39', gold: '#c5a06d', ink: '#15100e',
      font: '"SimSun", "Microsoft YaHei UI"', note: '低饱和古铜色、长镜头节奏、礼仪空间和层次纵深。'
    },
    zhenglong: {
      name: '郑晓龙时代群像', accent: '#9b5b42', gold: '#cfb68c', ink: '#151311',
      font: '"Microsoft YaHei UI"', note: '时代纪实色彩、群像字幕、稳定构图和叙事信息密度。'
    },
    villeneuve: {
      name: '维伦纽瓦科幻留白', accent: '#d89b52', gold: '#b8c3ca', ink: '#11171c',
      font: '"Microsoft YaHei UI"', note: '灰雾、巨物尺度、大面积留白和克制缓慢的推进。'
    },
    cameron: {
      name: '卡梅隆工业奇观', accent: '#2f98b8', gold: '#e5904d', ink: '#07131b',
      font: '"Microsoft YaHei UI"', note: '深海蓝与机械橙、宏大场面和明确的速度变化。'
    },
    spielberg: {
      name: '斯皮尔伯格温暖冒险', accent: '#d58545', gold: '#f1d39b', ink: '#17202b',
      font: '"Microsoft YaHei UI"', note: '自然暖光、家庭情感、人物视线和冒险式推进。'
    },
    fincher: {
      name: '芬奇精密暗黑', accent: '#8fb194', gold: '#ced3c6', ink: '#090d0c',
      font: '"Microsoft YaHei UI"', note: '低饱和暗绿色、精确构图、冷峻信息字幕和短促悬念。'
    },
    scott: {
      name: '雷德利冷峻史诗', accent: '#b46b45', gold: '#b9b3a5', ink: '#0e1215',
      font: '"SimSun", "Microsoft YaHei UI"', note: '烟尘、钢铁、冷灰与宏大空间，强调压迫感和历史纵深。'
    },
    bong: {
      name: '奉俊昊阶层寓言', accent: '#d67c2f', gold: '#83a79f', ink: '#101514',
      font: '"Microsoft YaHei UI"', note: '冷暖对立、空间阶层、群体构图和黑色幽默式反差。'
    },
    park: {
      name: '朴赞郁对称欲望', accent: '#a72e4d', gold: '#d5b777', ink: '#100d13',
      font: '"SimSun", "Microsoft YaHei UI"', note: '严格对称、浓烈酒红与金色、欲望和危险并置。'
    },
    miller: {
      name: '米勒沙漠追速', accent: '#db611f', gold: '#e6bd69', ink: '#160e08',
      font: '"Microsoft YaHei UI"', note: '橙沙、重机械、中心追逐构图和高密度快速切换。'
    },
    ritchie: {
      name: '盖里奇多线快切', accent: '#d5a928', gold: '#d7d7d7', ink: '#0d0d0d',
      font: '"Microsoft YaHei UI"', note: '黑金高反差、人物名片、多线快切和节奏感强的标题。'
    },
    tarantino: {
      name: '塔伦蒂诺章回快切', accent: '#d7ac24', gold: '#f1d477', ink: '#110d08',
      font: '"SimSun", "Microsoft YaHei UI"', note: '高饱和黄红、章回体标题、突然推近和风格化停顿。'
    },
    anderson: {
      name: '安德森粉彩对称', accent: '#d87f8b', gold: '#b9cda3', ink: '#25343a',
      font: '"Microsoft YaHei UI"', note: '粉彩配色、严格居中、平面化布局和克制幽默。'
    },
    vince: {
      name: '吉里根冷静悬念', accent: '#c99939', gold: '#b8a882', ink: '#101713',
      font: '"Microsoft YaHei UI"', note: '荒漠黄褐、精确留白、章节提示和缓慢积累的悬念。'
    },
    moffat: {
      name: '莫法特高概念悬疑', accent: '#556fb4', gold: '#d6c481', ink: '#0b101c',
      font: '"Microsoft YaHei UI"', note: '冷蓝高反差、信息碎片、快速插叙和谜题式字幕。'
    },
    hwang: {
      name: '黄东赫阶层冲突', accent: '#b43b47', gold: '#7d9c74', ink: '#0d1210',
      font: '"Microsoft YaHei UI"', note: '红绿冲突、群像压迫、空间对比和强情绪转折。'
    },
    flanagan: {
      name: '弗拉纳根暗夜氛围', accent: '#5b709d', gold: '#b9c5c8', ink: '#05080e',
      font: '"SimSun", "Microsoft YaHei UI"', note: '深蓝黑色、缓慢推镜、黑暗留白和低压字幕。'
    },
    anime: {
      name: '通用动漫风', accent: '#4a9fd8', gold: '#ffd166', ink: '#18253a',
      font: '"Microsoft YaHei UI"', note: '明快高饱和色彩、清晰轮廓、青春人物感和轻快转场。'
    },
    miyazaki: {
      name: '宫崎骏自然幻想风', accent: '#5e9f62', gold: '#f0cf78', ink: '#21372c',
      font: '"KaiTi", "Microsoft YaHei UI"', note: '森林绿与天空蓝、自然光影、开阔草地、飞行感和温柔留白。'
    },
    shinkai: {
      name: '新海诚光影青春风', accent: '#3e8fc9', gold: '#f0b2c8', ink: '#10253b',
      font: '"Microsoft YaHei UI"', note: '通透天空、强烈逆光、城市夜景、云层与雨滴，适合青春情绪。'
    },
    kon: {
      name: '今敏梦境剪辑风', accent: '#d63f6f', gold: '#5fc4c2', ink: '#111326',
      font: '"Microsoft YaHei UI"', note: '现实与梦境交错、重复镜头、快速蒙太奇和红青对比。'
    },
    cel: {
      name: '日系赛璐璐复古风', accent: '#e05a4f', gold: '#f0d079', ink: '#1b2233',
      font: '"Microsoft YaHei UI"', note: '手绘赛璐璐质感、明确色块、复古动画字幕和稳定构图。'
    },
    guoman: {
      name: '国漫热血风', accent: '#e64c3c', gold: '#ffc454', ink: '#161b24',
      font: '"Microsoft YaHei UI"', note: '红金高能配色、强烈速度线、冲击字幕和热血战斗节奏。'
    },
    anime3d: {
      name: '三维动画电影风', accent: '#3a9bc0', gold: '#f1b45e', ink: '#142330',
      font: '"Microsoft YaHei UI"', note: '立体光照、柔和材质、明暗层次和适合大银幕的空间景深。'
    }
  };
  const VIDEO_MATERIAL_DEFAULTS = {
    'overseas-film': '海外电影 官方预告 高清',
    'overseas-tv': '海外电视剧 官方预告 片段',
    'overseas-variety': '海外综艺 官方片段',
    'overseas-talk': '海外脱口秀 官方片段',
    'overseas-anime': '海外动漫 官方预告 片段',
    anime: '动漫 番剧 动画电影 官方片段',
    variety: '综艺 脱口秀 真人秀 官方片段',
    documentary: '纪录片 官方完整片段',
    'public-domain': 'public domain film full movie',
    'domestic-variety': '国内综艺 官方片段',
    'domestic-talk': '脱口秀 官方片段'
  };
  const VIDEO_MATERIAL_SOURCES = {
    youtube: (query) => 'https://www.youtube.com/results?search_query=' + encodeURIComponent(query),
    bilibili: (query) => 'https://search.bilibili.com/all?keyword=' + encodeURIComponent(query),
    tencent: (query) => 'https://v.qq.com/x/search/?q=' + encodeURIComponent(query),
    youku: (query) => 'https://so.youku.com/search_video/q_' + encodeURIComponent(query),
    mgtv: (query) => 'https://so.mgtv.com/so?k=' + encodeURIComponent(query),
    iqiyi: (query) => 'https://so.iqiyi.com/so/q_' + encodeURIComponent(query),
    archive: (query) => 'https://archive.org/search?query=' + encodeURIComponent(query),
    ted: (query) => 'https://www.ted.com/search?q=' + encodeURIComponent(query),
    baidu: (query) => 'https://www.baidu.com/s?wd=' + encodeURIComponent(query),
    sogou: (query) => 'https://www.sogou.com/web?query=' + encodeURIComponent(query),
    sohu: (query) => 'https://search.sohu.com/?keyword=' + encodeURIComponent(query),
    anime: (query) => 'https://commons.wikimedia.org/w/index.php?search=' +
      encodeURIComponent(query + ' anime animation') + '&title=Special:MediaSearch&type=video',
    variety: (query) => 'https://www.baidu.com/sf/vsearch?pd=video&wd=' +
      encodeURIComponent(query + ' 综艺 脱口秀 官方片段')
  };
  const COUNTRY_VIDEO_LIBRARIES = {
    china: {
      name: '中国',
      items: [
        { title: '1905 电影网 · 中国经典电影', description: 'CCTV6 旗下官方电影平台，可查找经典国产电影、纪录片和电影频道节目。', source: '中国电影频道', url: (q) => 'https://www.1905.com/search/?q=' + encodeURIComponent(q) },
        { title: '央视网 · 经典影视搜索', description: '查找央视播出的经典电视剧、电影、纪录片和公开节目。', source: '央视网', url: (q) => 'https://search.cctv.com/search.php?qtext=' + encodeURIComponent(q) + '&type=video' },
        { title: '中国电影资料馆', description: '中国电影档案、修复影片和经典影片资料，可在官方平台查看馆藏与放映信息。', source: '中国电影资料馆', url: () => 'https://www.cfa.org.cn/' }
      ]
    },
    korea: {
      name: '韩国',
      items: [
        { title: '韩国电影资料馆 · 经典电影', description: '韩国官方电影档案馆，包含经典韩国电影、修复影片和影史资料。', source: 'KOFA', url: () => 'https://www.koreafilm.or.kr/' },
        { title: '韩国电影资料馆官方频道', description: '在官方 YouTube 频道搜索韩国经典电影、修复片段和导演访谈。', source: 'Korean Film Archive', url: (q) => 'https://www.youtube.com/@KoreanFilmArchive/search?query=' + encodeURIComponent(q) }
      ]
    },
    italy: {
      name: '意大利',
      items: [
        { title: 'Cinecittà Luce · 意大利影像档案', description: '意大利国家影像档案，包含历史新闻、纪录片和经典电影资料。', source: 'Cinecittà Luce', url: () => 'https://www.cinecittaluce.it/' },
        { title: 'RaiPlay · 意大利经典影视', description: '意大利广播电视台官方平台，可搜索电影、电视剧、纪录片和经典节目。', source: 'RaiPlay', url: (q) => 'https://www.raiplay.it/ricerca?q=' + encodeURIComponent(q) }
      ]
    },
    germany: {
      name: '德国',
      items: [
        { title: 'DEFA 电影资料库', description: '东德 DEFA 电影档案与经典德国电影研究资料。', source: 'DEFA Film Library', url: () => 'https://www.umass.edu/defa/' },
        { title: 'ARD Mediathek · 德国经典影视', description: '德国公共广播官方片库，搜索电影、电视剧、纪录片和历史文化节目。', source: 'ARD', url: (q) => 'https://www.ardmediathek.de/suche/' + encodeURIComponent(q) }
      ]
    },
    france: {
      name: '法国',
      items: [
        { title: 'INA · 法国音像档案', description: '法国国家音像档案，包含经典电视、电影资料和历史影像。', source: 'INA', url: (q) => 'https://www.ina.fr/recherche?q=' + encodeURIComponent(q) },
        { title: 'ARTE · 欧洲电影与纪录片', description: '欧洲公共文化频道官方片库，可查找电影、电视剧和纪录片。', source: 'ARTE', url: (q) => 'https://www.arte.tv/de/search/?q=' + encodeURIComponent(q) }
      ]
    },
    japan: {
      name: '日本',
      items: [
        { title: '日本国立电影资料馆', description: '日本官方电影档案机构，包含经典电影、修复资料和影史馆藏。', source: 'NFAJ', url: () => 'https://www.nfaj.go.jp/' },
        { title: 'NHK 档案', description: '日本公共广播历史节目、纪录片和文化影像资料。', source: 'NHK Archives', url: () => 'https://www.nhk.or.jp/archives/' }
      ]
    },
    anime: {
      name: '动漫',
      items: [
        { title: '哔哩哔哩 · 国创与动画', description: '搜索国创、日本番剧、动画电影和官方公开片段。', source: '哔哩哔哩', url: (q) => 'https://search.bilibili.com/all?keyword=' + encodeURIComponent(q + ' 动漫 番剧') },
        { title: '腾讯视频动漫 · 官方搜索', description: '腾讯视频动漫官方搜索，查找国漫、番剧、预告和花絮。', source: '腾讯视频', url: (q) => 'https://v.qq.com/x/search/?q=' + encodeURIComponent(q + ' 动漫') },
        { title: 'Ani-One Asia 官方频道', description: '东南亚正版动画官方频道，查找官方片段和多语言节目。', source: 'Ani-One Asia', url: (q) => 'https://www.youtube.com/@AniOneAsia/search?query=' + encodeURIComponent(q) },
        { title: 'Muse Asia 官方频道', description: '正版动画官方频道，查找动画预告、片段和节目信息。', source: 'Muse Asia', url: (q) => 'https://www.youtube.com/@MuseAsia/search?query=' + encodeURIComponent(q) },
        { title: 'Internet Archive · 动画资料', description: '搜索公开版权动画、老动画电影和动画历史资料。', source: 'Internet Archive', url: (q) => 'https://archive.org/search?query=' + encodeURIComponent(q + ' animation anime') }
      ]
    },
    variety: {
      name: '综艺',
      items: [
        { title: '芒果TV · 综艺官方片库', description: '搜索国内综艺、真人秀、晚会和公开节目片段。', source: '芒果TV', url: (q) => 'https://so.mgtv.com/so?k=' + encodeURIComponent(q + ' 综艺') },
        { title: '腾讯视频 · 综艺搜索', description: '搜索腾讯综艺、真人秀、访谈和官方片段。', source: '腾讯视频', url: (q) => 'https://v.qq.com/x/search/?q=' + encodeURIComponent(q + ' 综艺') },
        { title: '优酷 · 综艺搜索', description: '搜索优酷综艺、脱口秀、访谈和节目花絮。', source: '优酷', url: (q) => 'https://so.youku.com/search_video/q_' + encodeURIComponent(q + ' 综艺') },
        { title: '哔哩哔哩 · 综艺与脱口秀', description: '搜索公开节目片段、脱口秀、访谈和综艺剪辑素材。', source: '哔哩哔哩', url: (q) => 'https://search.bilibili.com/all?keyword=' + encodeURIComponent(q + ' 综艺 脱口秀') },
        { title: 'Internet Archive · 综艺节目资料', description: '搜索公开版权综艺、脱口秀、访谈和历史电视节目。', source: 'Internet Archive', url: (q) => 'https://archive.org/search?query=' + encodeURIComponent(q + ' variety show talk show') }
      ]
    },
    uk: {
      name: '英国',
      items: [
        { title: 'BFI Player · 英国经典电影', description: '英国电影协会官方平台，可查找免费和授权经典电影。', source: 'BFI', url: (q) => 'https://player.bfi.org.uk/search/free?q=' + encodeURIComponent(q) }
      ]
    },
    usa: {
      name: '美国',
      items: [
        { title: '美国国会图书馆 · 国家放映室', description: '美国公共版权和馆藏经典电影官方入口。', source: 'Library of Congress', url: (q) => 'https://www.loc.gov/collections/national-screening-room/?q=' + encodeURIComponent(q) },
        { title: 'Internet Archive · 公共版权电影', description: '查找美国公共版权老电影、纪录片和经典电视节目。', source: 'Internet Archive', url: (q) => 'https://archive.org/search?query=' + encodeURIComponent(q) }
      ]
    }
  };
  const COUNTRY_CLASSIC_TITLES = {
    china: {
      search: (query) => 'https://www.1905.com/search/?q=' + encodeURIComponent(query),
      titles: ['小城之春', '神女', '马路天使', '一江春水向东流', '西游记', '红楼梦', '三国演义', '水浒传']
    },
    korea: {
      search: (query) => 'https://www.youtube.com/@KoreanFilmArchive/search?query=' + encodeURIComponent(query),
      titles: ['下女', '误发弹', '春香传', '大长今']
    },
    italy: {
      search: (query) => 'https://www.raiplay.it/ricerca?q=' + encodeURIComponent(query),
      titles: ['偷自行车的人', '甜蜜的生活', '八部半', '大路']
    },
    germany: {
      search: (query) => 'https://www.ardmediathek.de/suche/' + encodeURIComponent(query),
      titles: ['大都会', 'M就是凶手', '蓝天使', '柏林苍穹下']
    },
    france: {
      search: (query) => 'https://www.ina.fr/recherche?q=' + encodeURIComponent(query),
      titles: ['天堂的孩子', '游戏规则', '四百击', '精疲力尽']
    },
    japan: {
      search: (query) => 'https://www.nfaj.go.jp/search/?q=' + encodeURIComponent(query),
      titles: ['东京物语', '七武士', '罗生门', '雨月物语']
    },
    anime: {
      search: (query) => 'https://search.bilibili.com/all?keyword=' + encodeURIComponent(query + ' 动画'),
      titles: ['大闹天宫', '哪吒闹海', '葫芦兄弟', '铁臂阿童木', '机动战士高达', '灌篮高手', '名侦探柯南', '海贼王']
    },
    variety: {
      search: (query) => 'https://search.bilibili.com/all?keyword=' + encodeURIComponent(query + ' 综艺'),
      titles: ['正大综艺', '快乐大本营', '天天向上', '王牌对王牌', '极限挑战', '奔跑吧', '脱口秀大会', '奇葩说']
    },
    uk: {
      search: (query) => 'https://player.bfi.org.uk/search/free?q=' + encodeURIComponent(query),
      titles: ['第三人', '相见恨晚', '阿拉伯的劳伦斯', '远方的声音']
    },
    usa: {
      search: (query) => 'https://www.loc.gov/search/?q=' + encodeURIComponent(query),
      titles: ['公民凯恩', '卡萨布兰卡', '雨中曲', '十二怒汉']
    }
  };
  const COUNTRY_SEARCH_HINTS = {
    china: 'China Chinese film 中国电影 经典电影',
    korea: 'South Korea Korean film 한국영화',
    italy: 'Italy Italian film cinema italiano',
    germany: 'Germany German film deutscher Film',
    france: 'France French film cinéma français',
    japan: 'Japan Japanese film 日本映画',
    anime: 'anime animation アニメ 动漫 番剧 动画电影',
    variety: 'variety show talk show 综艺 真人秀 脱口秀',
    uk: 'United Kingdom British film',
    usa: 'United States public domain film'
  };
  const ARTICLE_STYLE_PROMPTS = {
    cctv: '采用央视微新闻式写法：事实先行，背景和影响表述克制准确。',
    tencent: '采用腾讯新闻深度图文式写法：导语、分层小标题、背景梳理、影响和后续观察。',
    toutiao: '采用今日头条讨论稿写法：开头快速提出争议焦点，分点展开并给出讨论问题。',
    weibo: '采用微博话题解读写法：先给一句核心话题，再列事实要点和公众讨论焦点，语言简洁、段落短。',
    overseas: '采用海外观察写法：补充国际背景、不同地区视角和中外差异，标明信息边界。',
    character: '采用人物特写写法：从具体人物处境切入，再连接事件背景和公共议题。',
    data: '采用数据新闻写法：只解释可核验的数据、时间线和变化趋势，不编造数字。',
    zhihu: '采用知乎式问题讨论结构：先提出一个明确问题，再分点解释事实、争议和不同立场，避免把观点写成事实。',
    xiaohongshu: '采用轻量图文分享结构：开头一句抓住重点，正文短段落、分点表达，适度加入阅读提示，但不使用夸张虚假标题。'
  };
  const ARTICLE_TEMPLATE_PROMPTS = {
    news: '采用央视式新闻版式：事实导语、核心信息、影响与后续关注，段落清晰，图片贴近对应事实。',
    tencent: '采用腾讯新闻式深度版式：导语、分层小标题、信息梳理、影响分析、来源说明，适合中长篇阅读。',
    headline: '采用今日头条式讨论版式：冲突焦点前置、分段展开、观点与事实分开，结尾提出可讨论的问题。',
    weibo: '采用微博话题版式：开头用话题卡片突出事件，随后列出事实要点、讨论焦点和待核实边界，短段落、重点前置。',
    photo: '采用图片故事版式：每个小标题对应一个画面段落，图片说明包含人物、地点、时间和来源，正文不要重复罗列图片内容。',
    timeline: '采用事件时间线版式：按已知时间顺序组织事实，明确区分已确认信息、未确认信息和后续节点。',
    brief: '采用新闻速览卡片版式：先给三条核心要点，再按“发生了什么、为什么重要、接下来关注什么”展开。',
    interview: '采用问答解读版式：提出读者最关心的问题，以一问一答展开，每个回答只使用材料可支持的事实。',
    magazine: '采用新闻杂志特写版式：具体场景开头、人物与事件交织、分段留白、结尾回到公共议题，避免虚构场景。'
  };
  const ARTICLE_TEMPLATE_LABELS = {
    news: '央视新闻', tencent: '腾讯深度', headline: '头条话题', weibo: '微博话题',
    brief: '速览卡片', photo: '图片故事', timeline: '事件时间线', interview: '问答解读', magazine: '杂志特写'
  };
  const ARTICLE_MODE_PROMPTS = {
    micro: '生成权威微新闻，正文约300-700字，先交代核心事实，再补充影响与后续关注。',
    digest: '生成新闻快读，正文约450-800字：先用3条要点概括事件，再写“发生了什么、关键背景、为什么值得关注、接下来看什么”，段落短、信息密度高。',
    short: '生成短篇文章，正文约700-1200字，结构紧凑，只保留最重要的事实、背景和讨论点。',
    topic: '生成话题讨论文章，正文约800-1400字，先提出争议或关注焦点，再按事实、观点和边界展开。',
    feature: '生成深度图文，正文约1600-2600字，包含导语、事实梳理、背景、影响和后续观察。'
  };
  const ARTICLE_CONTENT_MODES = {
    fact: '事实快报：按“发生了什么—已知信息—仍待确认”的顺序写作，重点是准确。',
    discussion: '争议讨论：先提出核心分歧，再并列不同立场、事实依据和讨论边界。',
    impact: '影响分析：重点解释事件会影响哪些人、行业或公共生活，避免空泛判断。',
    timeline: '时间线复盘：按时间顺序还原事件节点，区分已确认信息与后续变化。',
    people: '人物视角：从受影响者、参与者或普通人的具体处境切入，再回到事件和背景。',
    qa: '问答拆解：列出读者最关心的5至7个问题，逐问逐答，不把推测写成事实。',
    deep: '背景解释：补充必要的社会、行业或国际背景，再解释这一事件为什么值得关注。',
    visual: '图文卡片：提炼关键事实，每段控制在80至140字，按“一个观点、一张配图、一句说明”组织，方便直接发布为图文卡片。'
  };
  const ARTICLE_CONTENT_MODE_LABELS = {
    fact: '事实快报', discussion: '争议讨论', impact: '影响分析', timeline: '时间线复盘',
    people: '人物视角', qa: '问答拆解', deep: '背景解释', visual: '图文卡片'
  };
  const ARTICLE_VARIATION_ANGLES = [
    '这次从最容易被忽略的细节切入，标题和小标题要与上一版明显不同。',
    '这次先写读者最关心的现实影响，再补事实和背景，避免重复上一版的段落顺序。',
    '这次以一个问题贯穿全文，通过连续追问推进事实，结尾给出待观察节点。',
    '这次采用短段落和清晰小节，每个小节只回答一个核心问题。',
    '这次从不同群体的感受和利益关系展开，但不得把个人观点写成公共事实。',
    '这次重点呈现事件变化过程，减少泛泛评论，增加信息边界说明。'
  ];
  function articleModeLabel(mode) {
    return mode === 'topic' ? '话题讨论' : mode === 'short' ? '短篇文章' :
      mode === 'digest' ? '新闻快读' :
      mode === 'feature' ? '深度文章' : '微新闻';
  }

  function articleContentModePrompt(mode) {
    return ARTICLE_CONTENT_MODES[mode] || ARTICLE_CONTENT_MODES.fact;
  }

  function nextArticleVariationPrompt() {
    const angle = ARTICLE_VARIATION_ANGLES[state.articleVariant % ARTICLE_VARIATION_ANGLES.length];
    state.articleVariant += 1;
    return angle + '请生成第 ' + state.articleVariant + ' 个独立版本，不能复用已有版本的标题、导语、小标题和段落顺序。';
  }

  function articleTemplateForContentMode(mode) {
    return {
      fact: 'brief', discussion: 'headline', impact: 'tencent', timeline: 'timeline',
      people: 'magazine', qa: 'interview', deep: 'tencent', visual: 'photo'
    }[mode] || 'news';
  }

  function renderArticleAnglePicker() {
    const grid = $('#articleAngleGrid');
    if (!grid) return;
    const selected = new Set(state.articleAngleModes);
    $$('[data-article-angle]', grid).forEach((button) => {
      const active = selected.has(button.dataset.articleAngle);
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
      button.disabled = state.articleBatchBusy ||
        (!active && state.articleAngleModes.length >= 4);
    });
    if ($('#generateAngleVariantsBtn')) {
      $('#generateAngleVariantsBtn').disabled = state.articleBatchBusy;
      $('#generateAngleVariantsBtn').textContent = state.articleBatchBusy
        ? '正在生成多个模板版本…'
        : '按所选模板生成多个版本';
    }
  }

  function novelLengthLabel(length) {
    return length === 'long' ? '长篇小说' : length === 'medium' ? '中篇小说' : '短篇小说';
  }

  const NOVEL_STYLE_PROMPTS = {
    oriental: '东方电影感叙事：重视色彩意象、留白、对称场景和情绪递进。',
    realism: '现实主义群像：生活细节真实，人物选择有社会背景和多面性。',
    suspense: '非线性悬疑：伏笔、信息差、章节反转和结尾回收。',
    urban: '都市情绪流：克制的对白、细腻心理和关系张力。',
    classic: '古典文学叙事：章回感、含蓄表达和清晰的人物命运线。',
    scifi: '硬科幻史诗：自洽技术设定、社会推演和宏大尺度。',
    myth: '神话冒险：仪式感、象征意象和多阶段考验。',
    overseas: '海外畅销小说风格：强钩子、短章节、高冲突和国际化背景。'
  };

  const state = {
    config: {
      refreshMinutes: 20,
      maxItemsPerSection: 20,
      sections: FALLBACK_SECTIONS,
      customFeeds: [],
      ai: { enabled: false, baseUrl: 'https://api.deepseek.com/v1', model: 'deepseek-chat', hasKey: false },
      imageAi: { enabled: false, baseUrl: 'https://api.openai.com/v1', model: 'gpt-image-1', hasKey: false }
    },
    news: [],
    imported: loadJson(KEYS.imported, []),
    edgeSeen: loadJson(KEYS.edgeSeen, []),
    edgeSeenKeys: loadJson(KEYS.edgeSeenKeys, []),
    edgeQueue: [],
    edgeInboxKnownIds: new Set(),
    edgeInboxInitialized: false,
    materials: loadJson(KEYS.materials, []),
    edgeAutoDraft: loadJson(KEYS.edgeAutoDraft, true),
    mode: 'loading',
    selected: loadJson(KEYS.selected, []),
    drafts: loadJson(KEYS.drafts, []),
    completed: loadJson(KEYS.completed, []),
    generating: loadJson(KEYS.generating, []),
    workFilter: 'all',
    workSort: 'newest',
    article: loadJson(KEYS.article, null),
    activeSection: 'all',
    railOrder: loadJson(KEYS.railOrder, []),
    heroIndex: 0,
    heroTimer: null,
    heroPaused: false,
    platformOpenGuard: {},
    feedSort: 'hot',
    search: '',
    limit: 9,
    health: null,
    edgeConnected: false,
    edgeExtensionVersion: '',
    codexReady: false,
    codexInstalled: false,
    codexLoggedIn: false,
    codexPath: '',
    apps: null,
    githubStatus: null,
    presenter: 'female',
    presenterImage: loadJson(KEYS.presenterImage, ''),
    episodes: loadJson(KEYS.episodes, []),
    novel: loadJson(KEYS.novel, null),
    novelMaterials: loadJson(KEYS.novelMaterials, []),
    novelPlan: null,
    novelEdgeSource: null,
    novelLength: 'short',
    novelNarrativeStyle: 'oriental',
    programMode: 'radio',
    currentEpisodeId: '',
    videoScript: '',
    videoEpisodeTitle: '',
    musicFile: null,
    musicName: '',
    neteaseAudioStream: null,
    localVideoClips: [],
    originalPublishSelected: [],
    originalPublishSelectionTouched: false,
    videoLibrarySelected: [],
    articleSourceSelected: [],
    novelMaterialSelected: [],
    videoBreakdown: null,
    pendingVideoSource: '',
    pendingVideoSourceAt: 0,
    pendingVideoSourceTimer: null,
    pendingWritingSourceTimer: null,
    autoStartAfterClipImport: false,
    neteaseWatchStart: 0,
    neteasePromptedAt: 0,
    ratio: '9:16',
    videoQuality: loadJson(KEYS.videoQuality, 'fhd'),
    speed: 'normal',
    videoComposition: 'precise',
    videoOutputMode: loadJson(KEYS.videoOutputMode, 'styled'),
    videoVisualStyle: 'cinematic',
    directorStyle: loadJson(KEYS.directorStyle, 'zhang'),
    clipAudioMode: 'original',
    originalSubtitleText: loadJson(KEYS.originalSubtitleText, ''),
    chineseSubtitleText: loadJson(KEYS.chineseSubtitleText, ''),
    subtitleSourceLanguage: loadJson(KEYS.subtitleSourceLanguage, 'en-US'),
    videoDuration: 30,
    videoBlob: null,
    videoUrl: '',
    videoWakeLock: null,
    originalLibrary: [],
    finishedVideos: [],
    mediaLibraryReady: false,
    serverOriginalsLoading: false,
    serverOriginalsLoaded: false,
    originalFolder: '',
    videoDownloadTasks: loadJson(KEYS.videoDownloads, []),
    videoDownloadMode: loadJson(KEYS.videoDownloadMode, 'parallel'),
    voiceoverBlob: null,
    voiceoverUrl: '',
    voiceoverText: '',
    voiceoverVoice: 'zh-CN-XiaoxiaoNeural',
    generatedVideoSeconds: 0,
    articleMode: 'micro',
    articleStyle: 'cctv',
    articleTemplate: 'news',
    articleContentMode: 'fact',
    articleAngleModes: ['fact', 'discussion'],
    articleBatchArticles: [],
    articleBatchBusy: false,
    articleInsertRange: null,
    articleReplaceImageNode: null,
    lastGeneratedImageKind: '',
    generatedImageBatch: null,
    articleVariant: 0,
    articleKind: 'article',
    writingSourceTarget: '',
    lastWritingSource: null,
    lastPlatformSource: '',
    pendingWritingSourceRead: '',
    browseFlow: {
      active: false,
      kind: '',
      sourceId: '',
      sourceName: '',
      target: '',
      startedAt: 0,
      resuming: false,
      handled: false,
      fallbackTimer: null
    },
    articleScope: 'single',
    articleFocusId: '',
    aiScope: 'single',
    aiMode: 'feature',
    aiKind: 'article',
    aiArticleType: 'feature',
    aiNovelLength: 'short',
    aiAttachments: [],
    inspirationMode: 'article',
    inspirationArticleType: 'feature',
    inspirationNovelLength: 'short',
    inspirationBusy: false,
    researchArticles: [],
    researchImages: [],
    selectedResearchSources: [],
    selectedResearchImages: [],
    recording: false,
    previewTimer: null,
    modalDrag: null,
    audioContext: null,
    lastFrameTime: 0,
    variant: 0
  };

  const imageCache = new Map();
  const articleImageAssetCache = new Map();
  const detailCache = new Map();

  function withTimeout(promise, timeoutMs, message) {
    let timer;
    const timeout = new Promise((resolve, reject) => {
      timer = setTimeout(() => reject(new Error(message || '操作超时')), timeoutMs);
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
  }

  function reportClientLog(kind, message, extra) {
    try {
      const payload = JSON.stringify({ kind, message: String(message || ''), extra: String(extra || ''), url: location.href });
      if (navigator.sendBeacon) navigator.sendBeacon('/api/client-log', payload);
      else fetch('/api/client-log', { method: 'POST', body: payload, keepalive: true });
    } catch (error) {
      // Diagnostics must never interrupt the editor.
    }
  }
  window.addEventListener('error', (event) => reportClientLog('error', event.message, (event.filename || '') + ':' + event.lineno + ':' + event.colno));
  window.addEventListener('unhandledrejection', (event) => reportClientLog('promise', event.reason && (event.reason.stack || event.reason.message) || event.reason));

  function loadJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function saveJson(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (error) { console.warn(error); }
  }

  function openMediaDb() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        reject(new Error('当前浏览器不支持本地素材库'));
        return;
      }
      const request = indexedDB.open(MEDIA_DB_NAME, 1);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(MEDIA_ORIGINAL_STORE)) {
          database.createObjectStore(MEDIA_ORIGINAL_STORE, { keyPath: 'id' });
        }
        if (!database.objectStoreNames.contains(MEDIA_FINISHED_STORE)) {
          database.createObjectStore(MEDIA_FINISHED_STORE, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('无法打开本地素材库'));
    });
  }

  async function mediaStorePut(storeName, value) {
    const database = await openMediaDb();
    try {
      await new Promise((resolve, reject) => {
        const transaction = database.transaction(storeName, 'readwrite');
        transaction.objectStore(storeName).put(value);
        transaction.oncomplete = resolve;
        transaction.onerror = () => reject(transaction.error || new Error('素材保存失败'));
      });
    } finally {
      database.close();
    }
  }

  async function mediaStoreAll(storeName) {
    const database = await openMediaDb();
    try {
      return await new Promise((resolve, reject) => {
        const transaction = database.transaction(storeName, 'readonly');
        const request = transaction.objectStore(storeName).getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error || new Error('素材读取失败'));
      });
    } finally {
      database.close();
    }
  }

  async function mediaStoreDelete(storeName, id) {
    const database = await openMediaDb();
    try {
      await new Promise((resolve, reject) => {
        const transaction = database.transaction(storeName, 'readwrite');
        transaction.objectStore(storeName).delete(id);
        transaction.oncomplete = resolve;
        transaction.onerror = () => reject(transaction.error || new Error('素材删除失败'));
      });
    } finally {
      database.close();
    }
  }

  function formatFileSize(bytes) {
    const size = Number(bytes) || 0;
    if (size >= 1024 * 1024) return (size / (1024 * 1024)).toFixed(1) + ' MB';
    if (size >= 1024) return Math.round(size / 1024) + ' KB';
    return size + ' B';
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function truncate(value, length) {
    const text = String(value || '').replace(/\s+/g, ' ').trim();
    return text.length > length ? text.slice(0, length).replace(/[，。；、\s]+$/, '') + '…' : text;
  }

  function unique(values) {
    return Array.from(new Set((values || []).filter(Boolean)));
  }

  function stripHtml(html) {
    const box = document.createElement('div');
    box.innerHTML = html || '';
    return (box.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function normalizeSourceText(value) {
    return String(value == null ? '' : value)
      .replace(/\u00a0/g, ' ')
      .replace(/\r\n?/g, '\n')
      .replace(/[ \t]+\n/g, '\n')
      .replace(/\n[ \t]+/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  function cleanGeneratedImageText(value) {
    return String(value || '')
      .replace(/【?图片位\s*\d*】?/gi, ' ')
      .replace(/[·•|｜\-—]?\s*配图\s*\d+/gi, ' ')
      .replace(/画面建议\s*[：:]?/gi, ' ')
      .replace(/图注\s*[：:]?/gi, ' ')
      .replace(/热点工坊/g, ' ')
      .replace(/自动生成的新闻配图/gi, ' ')
      .replace(/自动生成新闻图卡/gi, ' ')
      .replace(/正文配图/gi, ' ')
      .replace(/新闻图卡/gi, ' ')
      .replace(/自动生成新闻/gi, ' ')
      .replace(/\s{2,}/g, ' ')
      .replace(/^[\s·•|｜\-—]+|[\s·•|｜\-—]+$/g, '')
      .trim();
  }

  function collectJsonSourceText(value, output, depth) {
    if (depth > 5 || output.length >= 60000) return;
    if (typeof value === 'string') {
      const text = value.replace(/<[^>]+>/g, ' ').trim();
      if (text.length >= 2) output.push(text);
      return;
    }
    if (Array.isArray(value)) {
      value.slice(0, 80).forEach((item) => collectJsonSourceText(item, output, depth + 1));
      return;
    }
    if (!value || typeof value !== 'object') return;
    const preferred = ['title', 'text', 'content', 'body', 'summary', 'description', 'article', 'html'];
    preferred.forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        collectJsonSourceText(value[key], output, depth + 1);
      }
    });
    Object.keys(value).filter((key) => !preferred.includes(key)).slice(0, 40).forEach((key) => {
      collectJsonSourceText(value[key], output, depth + 1);
    });
  }

  async function readWritingDataSourceFile(file) {
    if (!file) throw new Error('没有选择文件');
    const extension = (String(file.name).match(/\.([^.]+)$/) || [])[1]?.toLowerCase() || '';
    const raw = await file.text();
    if (!raw.trim()) throw new Error('文件内容为空');
    const fallbackTitle = file.name.replace(/\.[^.]+$/, '') || '本地素材';
    if (extension === 'html' || extension === 'htm') {
      const doc = new DOMParser().parseFromString(raw, 'text/html');
      doc.querySelectorAll('script,style,nav,footer,aside,noscript').forEach((node) => node.remove());
      const content = doc.querySelector('article,main,[role="main"]') || doc.body;
      const heading = content?.querySelector('h1');
      const title = normalizeSourceText(doc.title || heading?.textContent || fallbackTitle);
      const text = normalizeSourceText(content?.textContent || doc.body?.textContent || '');
      return { title: title || fallbackTitle, text, html: content?.innerHTML || '', url: '' };
    }
    if (extension === 'json') {
      let parsed;
      try {
        parsed = JSON.parse(raw);
      } catch (error) {
        throw new Error('JSON 格式不正确，请检查文件内容');
      }
      const values = [];
      collectJsonSourceText(parsed, values, 0);
      const text = normalizeSourceText(unique(values).join('\n\n')).slice(0, 60000);
      const title = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
        ? normalizeSourceText(parsed.title || parsed.name || parsed.headline || fallbackTitle)
        : fallbackTitle;
      return { title: title || fallbackTitle, text, html: '', url: '' };
    }
    let text = raw;
    if (extension === 'md' || extension === 'markdown') {
      text = raw
        .replace(/```[\s\S]*?```/g, (block) => block.replace(/```[^\n]*\n?|```/g, ''))
        .replace(/!\[[^\]]*\]\([^)]+\)/g, '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/^#{1,6}\s+/gm, '')
        .replace(/^>\s?/gm, '')
        .replace(/[*_~`]/g, '');
    }
    const heading = text.match(/^\s*#?\s*([^\n]{2,100})/);
    return {
      title: normalizeSourceText(heading?.[1] || fallbackTitle),
      text: normalizeSourceText(text).slice(0, 60000),
      html: '',
      url: ''
    };
  }

  async function importLocalWritingDataSource(target, fileOrFiles) {
    const files = Array.isArray(fileOrFiles) ? fileOrFiles :
      (fileOrFiles ? [fileOrFiles] : []);
    if (!files.length) return;
    try {
      showLoading('正在读取本地数据源', '正在解析文件中的标题和正文。');
      const sources = [];
      for (const file of files) {
        const source = await readWritingDataSourceFile(file);
        if (source.text && source.text.replace(/\s/g, '').length >= 20) {
          sources.push(Object.assign({}, source, { fileName: file.name }));
        }
      }
      if (!sources.length) throw new Error('文件中没有足够的正文，至少需要 20 个有效文字');
      if (target === 'novel' && sources.length > 1) {
        const materials = sources.map((source, index) => ({
          id: 'novel_local_' + Date.now() + '_' + index,
          title: source.title || source.fileName,
          text: truncate(source.text, 12000),
          url: source.url || '',
          source: '本地文件 · ' + source.fileName,
          createdAt: new Date().toISOString()
        }));
        state.novelMaterials = materials.concat(state.novelMaterials).filter((material, index, all) =>
          all.findIndex((entry) => entry.title === material.title && entry.text === material.text) === index
        ).slice(0, 10);
        state.novelMaterialSelected = $('#novelMaterialUseMode') &&
          $('#novelMaterialUseMode').value === 'single'
          ? [materials[0].id]
          : materials.map((item) => item.id);
        saveJson(KEYS.novelMaterials, state.novelMaterials);
        renderNovelMaterials();
        const combinedText = sources.map((source) =>
          '《' + source.title + '》\n' + source.text).join('\n\n');
        $('#novelInspiration').value = [
          '参考以下多个素材进行原创小说再创作。只提炼高层结构、题材和社会背景。',
          novelTransformationPrompt(),
          truncate(combinedText, 9000)
        ].join('\n\n');
        showView('novel');
        hideLoading();
        showWritingSourceReadSuccess('novel', '已读取 ' + sources.length + ' 个小说素材',
          combinedText, '', '本地多文件素材');
        return;
      }
      const source = sources[0];
      hideLoading();
      applyWritingSource(target, source.title, source.text, source.url,
        '本地文件 · ' + source.fileName);
    } catch (error) {
      hideLoading();
      showToast('本地数据源读取失败', error.message, 'error');
    }
  }

  function camelize(value) {
    if (Array.isArray(value)) return value.map(camelize);
    if (!value || typeof value !== 'object') return value;
    const output = {};
    Object.keys(value).forEach((key) => {
      output[key.charAt(0).toLowerCase() + key.slice(1)] = camelize(value[key]);
    });
    return output;
  }

  async function api(path, options) {
    const settings = Object.assign({ headers: { 'Content-Type': 'application/json' } }, options || {});
    let response;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        response = await fetch(path, settings);
        break;
      } catch (error) {
        if (attempt >= 2) throw new Error('本地服务连接中断，请确认热点工坊仍在运行，然后刷新页面。');
        await new Promise((resolve) => setTimeout(resolve, 350 * (attempt + 1)));
      }
    }
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || '请求失败（' + response.status + '）');
    return camelize(data);
  }

  function sectionInfo(id) {
    return (state.config.sections || []).find((section) => section.id === id) || { id, name: '资讯', color: '#ed5b47' };
  }

  function normalizeItem(item) {
    const section = sectionInfo(item.section);
    const originalImage = item.imageOriginal != null
      ? item.imageOriginal
      : (item.image && !String(item.image).startsWith('data:') ? item.image : '');
    const gallery = unique([originalImage].concat(item.gallery || []).filter((url) => /^https?:\/\//i.test(url)));
    return Object.assign({}, item, {
      sectionName: item.sectionName || section.name,
      color: item.color || section.color,
      summary: item.summary || '打开来源查看更完整的信息。',
      imageOriginal: originalImage,
      gallery,
      image: originalImage
    });
  }

  function makeFallbackImage(item, color) {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 675;
    const ctx = canvas.getContext('2d');
    const gradient = ctx.createLinearGradient(0, 0, 1200, 675);
    gradient.addColorStop(0, '#17243a');
    gradient.addColorStop(.62, color);
    gradient.addColorStop(1, '#f18a64');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1200, 675);
    ctx.globalAlpha = .12;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    for (let x = 0; x < 1200; x += 72) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, 675); ctx.stroke();
    }
    for (let y = 0; y < 675; y += 72) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(1200, y); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#ff8a71';
    ctx.fillRect(70, 65, 72, 8);
    const generatedCard = /自动生成|正文配图|新闻图卡/.test(item.sectionName || '');
    if (!generatedCard) {
      ctx.fillStyle = '#fff';
      ctx.font = '700 28px "Microsoft YaHei UI"';
      ctx.fillText(item.sectionName || sectionInfo(item.section).name || '今日热点', 70, 120);
    }
    ctx.font = '800 55px "Microsoft YaHei UI"';
    const lines = wrapLines(ctx, cleanGeneratedImageText(item.title) ||
      '新闻图卡', 940, 3);
    lines.forEach((line, index) => ctx.fillText(line, 70, 300 + index * 76));
    if (!generatedCard) {
      ctx.fillStyle = 'rgba(255,255,255,.72)';
      ctx.font = '500 24px "Microsoft YaHei UI"';
      ctx.fillText('热点工坊 · 自动生成的新闻配图', 72, 600);
    }
    return canvas.toDataURL('image/jpeg', .82);
  }

  function mergeImported(remoteItems) {
    const imported = (state.imported || []).map((item) => normalizeItem(Object.assign({}, item, {
      imported: true,
      publishedLabel: item.publishedLabel || '已导入'
    })));
    const seen = new Set();
    return imported.concat(remoteItems || []).filter((item) => {
      const key = (item.url || '') + '|' + (item.title || '').replace(/\s/g, '');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function dateLabel() {
    const now = new Date();
    return now.getFullYear() + '年' + (now.getMonth() + 1) + '月' + now.getDate() + '日 · ' +
      new Intl.DateTimeFormat('zh-CN', { weekday: 'long' }).format(now);
  }

  function showView(name) {
    $$('.view').forEach((view) => view.classList.toggle('active', view.id === 'view-' + name));
    $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === name));
    $$('.channel-inner [data-view]').forEach((item) => item.classList.toggle('active', item.dataset.view === name));
    if (name === 'ai') renderAiView();
    if (name === 'inspiration') renderInspiration();
    if (name === 'programs') renderPrograms();
    if (name === 'novel') renderNovel();
    if (name === 'github') loadGitHubStatus();
    if (name === 'article') renderArticle();
    if (name === 'video') prepareVideoView();
    renderCreationSaveBar();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function showToast(title, message, type) {
    const kind = type || 'success';
    const node = document.createElement('div');
    node.className = 'toast ' + kind;
    node.innerHTML = '<span>' + icon(kind === 'error' ? 'close' : kind === 'info' ? 'spark' : 'check') + '</span><div><strong>' +
      escapeHtml(title) + '</strong>' + (message ? '<p>' + escapeHtml(message) + '</p>' : '') + '</div>';
    $('#toasts').appendChild(node);
    setTimeout(() => {
      node.style.opacity = '0';
      node.style.transform = 'translateY(7px)';
      setTimeout(() => node.remove(), 220);
    }, 3900);
  }

  function showLoading(title, text) {
    $('#loadingTitle').textContent = title || '正在处理';
    $('#loadingText').textContent = text || '请稍候…';
    $('#loading').hidden = false;
  }

  function hideLoading() {
    $('#loading').hidden = true;
  }

  function showModal(title, eyebrow, body, foot) {
    $('#modalTitle').textContent = title;
    $('#modalEyebrow').textContent = eyebrow || 'HOTSPOT STUDIO';
    $('#modalBody').innerHTML = body;
    $('#modalFoot').innerHTML = foot || '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>';
    const modal = $('#modalBackdrop .modal');
    if (modal) {
      modal.style.transform = '';
      modal.dataset.dragX = '0';
      modal.dataset.dragY = '0';
      modal.classList.remove('dragging');
    }
    const modalHead = $('#modalBackdrop .modal-head');
    if (modalHead) modalHead.title = '按住标题栏可拖动窗口';
    $('#modalBackdrop').hidden = false;
  }

  function closeModal() {
    const modal = $('#modalBackdrop .modal');
    if (modal) {
      modal.style.transform = '';
      modal.dataset.dragX = '0';
      modal.dataset.dragY = '0';
    }
    $('#modalBackdrop').hidden = true;
  }

  function setMode() {
    const status = $('#sourceStatus');
    status.classList.remove('live', 'demo');
    const label = $('span', status);
    if (state.mode === 'live') {
      status.classList.add('live');
      label.textContent = '实时资讯';
      $('#feedFreshness').textContent = '刚刚更新';
    } else if (state.mode === 'bridge') {
      status.classList.add('live');
      label.textContent = '公共新闻实时';
      $('#feedFreshness').textContent = 'Edge 公共新闻桥接';
    } else if (state.mode === 'demo') {
      status.classList.add('demo');
      label.textContent = '演示模式';
      $('#feedFreshness').textContent = '演示内容';
    } else if (state.mode === 'loading') {
      label.textContent = '正在采集';
      $('#feedFreshness').textContent = '正在更新';
    } else {
      status.classList.add('demo');
      label.textContent = '本地缓存';
      $('#feedFreshness').textContent = '缓存内容';
    }
  }

  function renderSkeletons() {
    $('#newsGrid').innerHTML = Array.from({ length: 5 }, () => '<div class="news-skeleton"></div>').join('');
  }

  async function loadConfig() {
    try {
      const config = await api('/api/config');
      state.config = Object.assign({}, state.config, config);
      if (!state.config.sections || !state.config.sections.length) state.config.sections = FALLBACK_SECTIONS;
      if (!state.config.customFeeds) state.config.customFeeds = [];
      if (!state.config.ai) state.config.ai = { enabled: false, baseUrl: '', model: '', hasKey: false };
      if (!state.config.imageAi) state.config.imageAi = { enabled: false, baseUrl: 'https://api.openai.com/v1', model: 'gpt-image-1', hasKey: false };
    } catch (error) {
      showToast('配置读取失败', error.message, 'error');
    }
  }

  async function loadHealth() {
    try {
      state.health = await api('/api/health');
      state.codexReady = Boolean(state.health.codexReady);
      state.codexInstalled = Boolean(state.health.codexInstalled);
      state.codexLoggedIn = Boolean(state.health.codexLoggedIn);
      state.codexPath = state.health.codexPath || '';
      if (state.health.dataDirectory) $('#dataPath').textContent = state.health.dataDirectory;
      const edgeCard = $('.edge-card');
      if (state.health.edgeReady) {
        edgeCard.classList.add('ready');
        $('#edgeStatus').textContent = '已接入 · Edge ' + (state.health.edgeVersion || '本机版本');
      } else {
        $('#edgeStatus').textContent = '未检测到 Microsoft Edge';
      }
    } catch (error) {
      console.warn(error);
    }
  }

  async function loadApps() {
    try {
      state.apps = await api('/api/apps');
      if (!state.apps.browsers || !state.apps.browsers.some((app) => app.id === state.config.preferredBrowserId)) {
        const edge = (state.apps.browsers || []).find((app) => app.id === 'edge');
        state.config.preferredBrowserId = edge ? edge.id : ((state.apps.browsers || [])[0] || {}).id || 'default';
      }
      if (!state.apps.videoPlayers || !state.apps.videoPlayers.some((app) => app.id === state.config.preferredVideoPlayerId)) {
        state.config.preferredVideoPlayerId = ((state.apps.videoPlayers || [])[0] || {}).id || 'video-default';
      }
    } catch (error) {
      state.apps = { browsers: [{ id: 'edge', name: 'Microsoft Edge' }, { id: 'default', name: '系统默认浏览器' }], videoPlayers: [{ id: 'video-default', name: '系统默认视频播放器' }] };
    }
    renderAppOptions();
  }

  async function loadEdgeStatus() {
    try {
      const result = await api('/api/edge-status');
      state.edgeConnected = Boolean(result.connected);
      state.edgeExtensionVersion = result.extensionVersion || '';
      const extensionOutdated = state.edgeConnected && state.edgeExtensionVersion &&
        state.edgeExtensionVersion !== '1.9.6';
      const banner = $('#edgeAutoBanner');
      if (!banner) return;
      banner.classList.toggle('connected', state.edgeConnected);
      banner.classList.toggle('outdated', extensionOutdated);
      $('#edgeAutoTitle').textContent = extensionOutdated
        ? 'Edge 扩展需要升级'
        : (state.edgeConnected ? 'Edge 自动读取已开启' : 'Edge 自动读取尚未连接');
      const lastSeenLabel = result.lastSeen ? new Date(Number(result.lastSeen)).toLocaleTimeString('zh-CN') : '刚刚';
      $('#edgeAutoHint').textContent = extensionOutdated
        ? '当前为旧版 ' + state.edgeExtensionVersion + '，点击“立即升级”后在扩展页点一次“重新加载”。'
        : state.edgeConnected
          ? '已连接扩展 ' + (state.edgeExtensionVersion || '') + '，公共新闻会自动进入首页。'
        : '安装一次采集扩展后，新闻页面和最近浏览内容会自动送入小程序。';
      $('#edgeAutoSetupBtn').textContent = extensionOutdated ? '立即升级' : state.edgeConnected ? '查看设置' : '3 步启用';
      if ($('#edgeStatus')) {
        $('#edgeStatus').textContent = '已接入 · Edge ' + (state.health && state.health.edgeVersion || '') +
          (state.edgeConnected ? ' · 扩展 ' + (state.edgeExtensionVersion || '已连接') : ' · 扩展未连接');
      }
    } catch (error) {
      state.edgeConnected = false;
    }
  }

  function openEdgeCaptureSetup() {
    showModal('启用 Edge 自动读取', 'EDGE AUTO CAPTURE',
      '<div class="publish-step"><span>01</span><div><strong>打开扩展目录</strong><p>点击下方“打开扩展目录”，保持窗口不要关闭。</p></div></div>' +
      '<div class="publish-step"><span>02</span><div><strong>加载或更新扩展</strong><p>在 Edge 打开 <code>edge://extensions</code>，开启开发人员模式；首次使用选择“加载解压缩的扩展”，已安装则点击扩展卡片上的“重新加载”。</p></div></div>' +
      '<div class="publish-step"><span>03</span><div><strong>开启自动采集</strong><p>点击 Edge 工具栏中的热点工坊扩展图标，打开“自动采集新闻页”。</p></div></div>' +
      '<div class="modal-note">' + icon('check') + '<p>新闻正文会等待你确认；最近浏览页只保存在本机，用于小说素材自动填入。不会读取 Edge 历史、密码或 Cookie。</p></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>稍后</button>' +
      '<button class="btn btn-secondary" type="button" id="modalOpenExtFolder">打开扩展目录</button>' +
      '<button class="btn btn-secondary" type="button" id="modalCheckEdge">重新检测</button>' +
      '<button class="btn btn-primary" type="button" id="modalOpenExtPage">打开扩展管理页</button>');
    $('#modalOpenExtFolder').addEventListener('click', async () => {
      try { await api('/api/open-extension', { method: 'POST', body: '{}' }); }
      catch (error) { showToast('打开失败', error.message, 'error'); }
    });
    $('#modalOpenExtPage').addEventListener('click', async () => {
      try {
        await api('/api/open-edge-extensions', { method: 'POST', body: '{}' });
        showToast('已打开扩展管理页', '请开启开发人员模式并加载解压缩扩展。', 'info');
      } catch (error) {
        showToast('打开失败', error.message, 'error');
      }
    });
    $('#modalCheckEdge').addEventListener('click', async () => {
      await loadEdgeStatus();
      showToast(state.edgeConnected ? 'Edge 扩展已连接' : '尚未检测到扩展',
        state.edgeConnected ? '自动读取已经开启。' : '请确认扩展已加载，并打开一次扩展开关。', state.edgeConnected ? 'success' : 'info');
    });
  }

  function renderAppOptions() {
    if (!state.apps) return;
    const browser = $('#preferredBrowser');
    const player = $('#preferredVideoPlayer');
    if (!browser || !player) return;
    browser.innerHTML = state.apps.browsers.map((app) => '<option value="' + escapeHtml(app.id) + '">' +
      escapeHtml(app.name) + '</option>').join('');
    player.innerHTML = state.apps.videoPlayers.map((app) => '<option value="' + escapeHtml(app.id) + '">' +
      escapeHtml(app.name) + '</option>').join('');
    browser.value = state.config.preferredBrowserId || 'default';
    player.value = state.config.preferredVideoPlayerId || 'video-default';
    $('#appDetectStatus').textContent = '已检测：' + state.apps.browsers.length + ' 个浏览器，' +
      state.apps.videoPlayers.length + ' 个视频应用。选择后会自动记住。';
  }

  async function fetchNews(force) {
    state.mode = 'loading';
    setMode();
    $('#refreshBtn').classList.add('spinning');
    const demo = new URLSearchParams(location.search).get('demo') === '1';
    if (force) showLoading('正在刷新热点', '正在读取最新资讯和新闻图片。');
    try {
      const data = await api('/api/news?section=all&force=' + (force ? '1' : '0') + (demo ? '&demo=1' : ''));
      state.news = mergeImported((data.items || []).map(normalizeItem));
      state.mode = data.mode || (data.demo ? 'demo' : 'live');
      state.selected = state.selected.filter((id) => state.news.some((item) => item.id === id));
      if (!state.selected.length && state.news.length) autoRecommend(false, false);
      saveJson(KEYS.news, { items: state.news, mode: state.mode, updatedAt: data.updatedAt });
      renderAll();
      autoGrabVisibleImages();
      if (state.mode === 'demo') showToast('当前为演示内容', data.message || '新闻源暂未连通，网络恢复后点击刷新。', 'info');
      else if (force) showToast('热点已更新', '已收录 ' + state.news.length + ' 条最新资讯。');
    } catch (error) {
      state.mode = 'error';
      if (!state.news.length) {
        $('#newsGrid').innerHTML = '<div class="empty-state"><span>' + icon('refresh') + '</span><h3>暂时没有读取到资讯</h3><p>' +
          escapeHtml(error.message) + '</p><button class="btn btn-secondary" type="button" data-refresh>重新加载</button></div>';
      }
      showToast('采集失败', error.message, 'error');
    } finally {
      setMode();
      hideLoading();
      $('#refreshBtn').classList.remove('spinning');
    }
  }

  function visibleNews() {
    const query = state.search.trim().toLowerCase();
    const filterFor = (items) => items.filter((item) => {
      const sectionMatch = state.activeSection === 'all' ||
        state.activeSection === 'hot' ||
        (state.activeSection === 'imported' ? item.imported : item.section === state.activeSection);
      const haystack = [item.title, item.summary, item.source, item.sectionName].join(' ').toLowerCase();
      return sectionMatch && (!query || haystack.includes(query));
    });
    const activeIsSection = !['all', 'hot', 'imported'].includes(state.activeSection);
    let result = filterFor(state.news);
    state.sectionFallback = false;
    if (!result.length && activeIsSection && state.news.length) {
      const searchOnly = state.news.filter((item) => {
        const haystack = [item.title, item.summary, item.source, item.sectionName].join(' ').toLowerCase();
        return !query || haystack.includes(query);
      });
      if (searchOnly.length) {
        result = searchOnly;
        state.sectionFallback = true;
      }
    }
    if (state.feedSort === 'latest') {
      result = result.slice().sort((a, b) => {
        const dateValue = (value) => {
          if (typeof value === 'number') return value;
          const match = String(value || '').match(/\/Date\((\d+)\)\//);
          return match ? Number(match[1]) : new Date(value || 0).getTime();
        };
        return dateValue(b.publishedAt) - dateValue(a.publishedAt);
      });
    } else if (state.feedSort === 'visual') {
      result = result.slice().sort((a, b) =>
        ((b.gallery || []).length + (b.imageOriginal ? 1 : 0)) -
        ((a.gallery || []).length + (a.imageOriginal ? 1 : 0)) ||
        (b.score || 0) - (a.score || 0));
    } else {
      result = result.slice().sort((a, b) => (b.score || 0) - (a.score || 0));
    }
    return result;
  }

  function selectedItems() {
    return state.selected.map((id) => state.news.find((item) => item.id === id)).filter(Boolean);
  }

  function autoRecommend(showMessage, refresh) {
    const pool = state.news.slice().sort((a, b) => (b.score || 0) - (a.score || 0));
    const chosen = [];
    const sections = new Set();
    pool.forEach((item) => {
      if (chosen.length >= 3 || sections.has(item.section)) return;
      chosen.push(item);
      sections.add(item.section);
    });
    if (chosen.length < 3) {
      pool.forEach((item) => {
        if (chosen.length < 3 && !chosen.some((picked) => picked.id === item.id)) chosen.push(item);
      });
    }
    state.selected = chosen.map((item) => item.id);
    saveJson(KEYS.selected, state.selected);
    if (refresh !== false) renderAll();
    if (showMessage) showToast('已推荐 3 条', '优先覆盖不同板块，并优先选择带图资讯。');
  }

  function ensureSources(minimum) {
    let items = selectedItems();
    if (items.length < minimum && state.news.length) {
      autoRecommend(false, false);
      items = selectedItems();
    }
    return items;
  }

  function toggleSelection(id) {
    const index = state.selected.indexOf(id);
    if (index >= 0) state.selected.splice(index, 1);
    else {
      if (state.selected.length >= 5) {
        showToast('最多选择 5 条', '建议聚焦 3 条核心资讯。', 'info');
        return;
      }
      state.selected.push(id);
    }
    saveJson(KEYS.selected, state.selected);
    renderNews();
    renderSelection();
    renderVideoSources();
  }

  function renderAll() {
    renderFilters();
    renderSectionRail();
    renderNews();
    renderSelection();
    renderHotList();
    renderDrafts();
    renderHero();
    renderAiView();
    renderArticle();
    renderVideoSources();
    updateCounts();
  }

  function renderFilters() {
    const tabs = $('#filterTabs');
    if (!tabs) return;
    const sections = state.config.sections.filter((section) => section.enabled);
    tabs.innerHTML =
      '<button class="filter-tab' + (state.activeSection === 'all' ? ' active' : '') + '" data-section="all">推荐</button>' +
      sections.map((section) => '<button class="filter-tab' + (state.activeSection === section.id ? ' active' : '') + '" data-section="' +
        escapeHtml(section.id) + '">' + escapeHtml(section.name) + '</button>').join('');
  }

  function renderSectionRail() {
    const container = $('#sectionRailList');
    if (!container) return;
    const platformSectionIds = new Set(['tencent', 'weibo', 'netease', 'jinjiang', 'fanqie', 'qimao', 'zhihu']);
    const sections = state.config.sections.filter((section) =>
      section.enabled && !platformSectionIds.has(section.id));
    const countFor = (id) => state.news.filter((item) => item.section === id).length;
    const episodeCount = (type) => state.episodes.filter((episode) => episode.type === type).length;
    const rows = [
      { id: 'all', name: '推荐', count: state.news.length, color: '#ef5b49', special: true },
      { id: 'hot', name: '热搜', count: state.news.filter((item) => (item.score || 0) >= 75).length, color: '#ef5b49', special: true },
      { id: 'imported', name: '我的导入', count: state.news.filter((item) => item.imported).length, color: '#4e74cc', imported: true },
      { id: 'tencent', name: '腾讯新闻网页', count: countFor('tencent'), color: '#2f7fc4', section: true, external: 'https://news.qq.com/' },
      { id: 'weibo', name: '微博热搜', count: countFor('weibo'), color: '#e15b56', section: true, external: 'https://s.weibo.com/top/summary' },
      { id: 'netease', name: '网易新闻', count: countFor('netease'), color: '#d9363e', section: true, external: 'https://news.163.com/' },
      { id: 'netease-music', name: '网易云音乐', count: '打开', color: '#d9363e', platform: 'https://music.163.com/' },
      { id: 'jinjiang', name: '晋江文学城', count: countFor('jinjiang'), color: '#a75c76', section: true, external: 'https://www.jjwxc.net/' },
      { id: 'fanqie', name: '番茄小说', count: countFor('fanqie'), color: '#ef604a', section: true, external: 'https://fanqienovel.com/' },
      { id: 'zhihu', name: '知乎', count: countFor('zhihu'), color: '#356fbb', section: true, external: 'https://www.zhihu.com/' },
      { id: 'radio', name: '热点电台', count: episodeCount('radio') || '新', color: '#3e806d', program: 'radio' },
      { id: 'story', name: '故事会', count: episodeCount('story') || '新', color: '#9d6d4e', program: 'story' },
      { id: 'novel', name: '原创小说', count: state.novel ? 1 : '新', color: '#8f4b69', view: 'novel' }
    ];
    if (!rows.some((row) => row.id === 'qimao')) {
      const zhihuIndex = rows.findIndex((row) => row.id === 'zhihu');
      rows.splice(zhihuIndex >= 0 ? zhihuIndex : rows.length, 0,
        { id: 'qimao', name: '七猫小说', count: countFor('qimao'), color: '#e69435', section: true, external: 'https://www.qimao.com/' });
    }
    sections.forEach((section) => rows.push({
      id: section.id,
      name: section.name,
      count: state.news.filter((item) => item.section === section.id).length,
      color: section.color,
      category: true
    }));
    if (Array.isArray(state.railOrder) && state.railOrder.length) {
      const order = new Map(state.railOrder.map((id, index) => [id, index]));
      const baseOrder = new Map(rows.map((row, index) => [row.id, index]));
      rows.sort((a, b) =>
        (order.has(a.id) ? order.get(a.id) : 10000 + baseOrder.get(a.id)) -
        (order.has(b.id) ? order.get(b.id) : 10000 + baseOrder.get(b.id)));
    }
    container.innerHTML = rows.map((row, index) =>
      (row.category && (!rows[index - 1] || !rows[index - 1].category) ? '<div class="rail-divider"></div>' : '') +
      '<button class="section-rail-item' + (state.activeSection === row.id ? ' active' : '') +
      (row.special ? ' special' : '') + (row.imported ? ' imported' : '') +
      (row.platform || row.external ? ' external' : '') +
      '" type="button" draggable="true" title="按住拖动可调整板块顺序" data-rail-id="' +
      escapeHtml(row.id) + '" ' + (row.platform
        ? 'data-open-platform="' + escapeHtml(row.platform) + '"'
        : (row.program ? 'data-open-program="' + escapeHtml(row.program) + '"' :
          (row.view ? 'data-view="' + escapeHtml(row.view) + '"' : 'data-section="' + escapeHtml(row.id) + '"'))) +
      (row.external ? ' data-platform-source="' + escapeHtml(row.external) + '"' : '') +
      ' style="--rail-color:' + escapeHtml(row.color) + '">' +
      '<span class="rail-drag-handle" aria-hidden="true">⋮⋮</span><i></i><span>' +
      escapeHtml(row.name) + '</span><b>' +
      escapeHtml(row.count === 0 ? '刷新' : (row.count == null ? '' : row.count)) + '</b></button>'
    ).join('');
  }

  function heroCandidates() {
    const filtered = visibleNews();
    const pool = filtered.length ? filtered : state.news;
    const seen = new Set();
    return pool.slice().sort((a, b) =>
      (b.score || 0) - (a.score || 0) ||
      new Date(b.publishedAt || 0).getTime() - new Date(a.publishedAt || 0).getTime()
    ).filter((item) => {
      const key = item.url || item.title;
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(0, 8);
  }

  function leadItem() {
    const items = heroCandidates();
    if (!items.length) return null;
    state.heroIndex = ((state.heroIndex % items.length) + items.length) % items.length;
    return items[state.heroIndex];
  }

  function advanceHero(direction) {
    const items = heroCandidates();
    if (items.length < 2) return;
    state.heroIndex = (state.heroIndex + direction + items.length) % items.length;
    renderHero(true);
  }

  function renderHero(animate) {
    const items = heroCandidates();
    const player = $('#heroPlayer');
    if (!player) return;
    if (!items.length) {
      $('#heroHeadline').textContent = '正在读取最新热点…';
      $('#heroSummary').textContent = '请稍候，程序会持续轮换最新、最热的内容。';
      $('#heroDate').textContent = dateLabel();
      $('#heroCounter').textContent = '0 / 0';
      $('#heroDots').innerHTML = '';
      const emptyCover = $('#heroCover');
      emptyCover.classList.add('no-image');
      emptyCover.innerHTML = '<span class="cover-placeholder">实时热点<br><small>等待内容</small></span>';
      return;
    }
    state.heroIndex = ((state.heroIndex % items.length) + items.length) % items.length;
    const item = items[state.heroIndex];
    player.dataset.heroId = item.id;
    if (!item) return;
    $('#heroHeadline').textContent = item.title;
    $('#heroSummary').textContent = item.summary;
    $('#heroDate').textContent = (item.publishedLabel || '最新') + ' · ' + (item.source || item.sectionName || '公开资讯');
    $('#heroCounter').textContent = (state.heroIndex + 1) + ' / ' + items.length;
    $('#heroDots').innerHTML = items.map((entry, index) =>
      '<i class="' + (index === state.heroIndex ? 'active' : '') + '" data-hero-index="' + index + '"></i>').join('');
    const cover = $('#heroCover');
    cover.classList.toggle('no-image', !item.image);
    cover.innerHTML = item.image
      ? '<img src="' + escapeHtml(item.image) + '" alt="" referrerpolicy="no-referrer" onerror="this.style.display=\'none\';this.parentElement.classList.add(\'no-image\')">' +
        '<span class="hero-cover-shade"></span><span class="hero-cover-tag">实时 ' + (state.heroIndex + 1) + ' / ' + items.length + '</span>' +
        '<span class="hero-cover-brand">热点工坊 <small>DAILY BRIEF</small></span>'
      : '<span class="cover-placeholder">' + escapeHtml(item.sectionName || '热点工坊') + '<br><small>HOT LIVE</small></span>' +
        '<span class="hero-cover-shade"></span><span class="hero-cover-tag">实时 ' + (state.heroIndex + 1) + ' / ' + items.length + '</span>';
    if (animate) {
      player.classList.remove('hero-switching');
      void player.offsetWidth;
      player.classList.add('hero-switching');
      window.clearTimeout(state.heroAnimationTimer);
      state.heroAnimationTimer = window.setTimeout(() => player.classList.remove('hero-switching'), 420);
    }
  }

  function renderAiAttachments() {
    const box = $('#aiAttachments');
    if (!box) return;
    box.innerHTML = state.aiAttachments.map((item) =>
      '<div class="ai-attachment"><img src="' + escapeHtml(item.url) + '" alt=""><span>' +
      escapeHtml(item.label || '创作图片') + '</span><button type="button" data-remove-ai-attachment="' +
      escapeHtml(item.id) + '" title="移除">×</button></div>').join('');
  }

  function addAiAttachments(items) {
    (items || []).forEach((item) => {
      if (!item || !item.url) return;
      state.aiAttachments.push({
        id: 'ai_attachment_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        url: item.url,
        label: item.label || '创作图片',
        kind: item.kind || 'image'
      });
    });
    state.aiAttachments = state.aiAttachments.slice(-10);
    renderAiAttachments();
  }

  async function addAiImageFiles(files) {
    const images = [];
    for (const file of Array.from(files || [])) {
      if (!/^image\//i.test(file.type)) continue;
      try {
        images.push({ url: await readImageFile(file), label: file.name, kind: 'image' });
      } catch (error) {}
    }
    addAiAttachments(images);
    if (images.length) showToast('图片素材已加入', 'AI 会结合图片和文字生成图文内容。');
  }

  async function captureVideoFrames(file, count) {
    const objectUrl = URL.createObjectURL(file);
    const video = document.createElement('video');
    video.muted = true;
    video.preload = 'metadata';
    video.src = objectUrl;
    try {
      await new Promise((resolve, reject) => {
        video.onloadedmetadata = resolve;
        video.onerror = () => reject(new Error('无法读取视频文件'));
        setTimeout(resolve, 5000);
      });
      const duration = Math.max(1, Number(video.duration) || 1);
      const total = Math.max(1, count || 4);
      const frames = [];
      const canvas = document.createElement('canvas');
      for (let index = 0; index < total; index += 1) {
        const time = Math.max(.1, Math.min(duration - .1, duration * ((index + .7) / (total + .4))));
        await new Promise((resolve) => {
          video.onseeked = resolve;
          try { video.currentTime = time; } catch (error) { resolve(); }
          setTimeout(resolve, 2200);
        });
        canvas.width = 960;
        canvas.height = Math.max(1, Math.round(960 * (video.videoHeight || 540) / Math.max(1, video.videoWidth || 960)));
        canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
        frames.push({ url: canvas.toDataURL('image/jpeg', .84), label: file.name + ' 画面 ' + (index + 1), kind: 'video-frame' });
      }
      return frames;
    } finally {
      video.removeAttribute('src');
      video.load();
      URL.revokeObjectURL(objectUrl);
    }
  }

  async function grabArticleForAi() {
    try {
      const current = await api('/api/edge-current');
      let item = current && current.item;
      if (!item || !item.text) {
        const inbox = await api('/api/edge-inbox');
        item = recentCapturedItem(inbox.items || [], state.lastPlatformSource);
      }
      if (!item || !item.text) throw new Error('请在 Edge 打开文章，或先右键抓取到热点工坊');
      $('#aiInstructions').value = [
        $('#aiInstructions').value.trim(),
        '抓取文章：' + (item.title || ''),
        truncate(item.text, 8000)
      ].filter(Boolean).join('\n\n');
      addAiAttachments((item.images || []).slice(0, 4).map((url, index) => ({
        url, label: (item.title || '文章图片') + ' ' + (index + 1), kind: 'article-image'
      })));
      showToast('文章和图片已加入 AI 素材', item.title || '当前文章');
    } catch (error) {
      showToast('抓取文章失败', error.message, 'info');
    }
  }

  function renderAiView() {
    if (!$('#aiModelBadge')) return;
    const ready = Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    const model = state.config.ai && state.config.ai.model || 'DeepSeek';
    const baseUrl = state.config.ai && state.config.ai.baseUrl || '';
    const badge = $('#aiModelBadge');
    badge.textContent = ready ? model : '未连接 AI';
    badge.classList.toggle('ready', ready);
    $('#aiOnlineDot').classList.toggle('ready', ready);
    $('#aiGreeting').textContent = ready ? 'AI 编辑已连接，可以开始写作' : '先连接 AI 服务';
    $('#aiConnectionHint').textContent = ready
      ? '会读取原文，并围绕当前范围生成可编辑文章'
      : '点击“配置 AI”，填写 API Key 并测试连接';
    if ($('#codexStatus')) {
      $('#codexStatus').textContent = state.codexReady
        ? '本机 Codex 已连接'
        : ready ? '使用已连接 AI' : '请先连接 AI';
      $('#codexStatus').classList.toggle('ready', state.codexReady);
      $('#codexWriteBtn').disabled = false;
      $('#codexWriteBtn').textContent = state.codexReady
        ? 'Codex 生成'
        : ready ? 'AI 生成' : '配置并生成';
    }
    $('#aiSideStatus').textContent = ready ? '已连接' : '待配置';
    $('#aiSideStatus').style.color = ready ? '#2f986a' : '#9ba0a5';
    $('#aiSideModel').textContent = model;
    $('#aiSideBase').textContent = baseUrl || '尚未填写接口地址';
    const context = state.aiScope === 'multi' ? selectedItems().slice(0, 4) : [selectedItems()[0] || leadItem()].filter(Boolean);
    $('#aiContextList').innerHTML = context.length
      ? context.map((item) => '<span class="ai-context-chip"><b>' + escapeHtml(item.sectionName) + '</b><span>' +
          escapeHtml(item.title) + '</span></span>').join('')
      : '<div class="ai-context-empty">当前没有热点素材，请先返回首页刷新或导入内容。</div>';
    $$('#aiScopeChoices button').forEach((button) => button.classList.toggle('active', button.dataset.aiScope === state.aiScope));
    $$('#aiKindChoices button').forEach((button) =>
      button.classList.toggle('active', button.dataset.aiKind === state.aiKind));
    $$('#aiModeChoices button').forEach((button) =>
      button.classList.toggle('active', button.dataset.aiMode === state.aiArticleType));
    $$('#aiNovelLengthChoices button').forEach((button) =>
      button.classList.toggle('active', button.dataset.aiNovelLength === state.aiNovelLength));
    $('#aiArticleOptions').hidden = state.aiKind !== 'article';
    $('#aiNovelOptions').hidden = state.aiKind !== 'novel';
    if ($('#aiArticleStyle')) $('#aiArticleStyle').value = state.aiArticleStyle || 'cctv';
    if ($('#aiRunBtn span')) {
      $('#aiRunBtn span').textContent = state.aiKind === 'novel'
        ? '生成原创小说'
        : '生成到图文编辑器';
    }
    renderAiAttachments();
  }

  async function runAiWriting() {
    if ((!state.config.ai.enabled || !state.config.ai.hasKey) && !state.codexReady) {
      showToast('AI 还没有连接', '请先填写 API Key 并完成连接测试。', 'info');
      openSettings();
      setTimeout(() => $('#aiEnabled').focus(), 250);
      return;
    }
    const items = state.aiScope === 'multi' ? multiEventItems() : ensureSources(1);
    const instructions = $('#aiInstructions').value.trim();
    const attachments = state.aiAttachments.slice();
    if (!items.length && !instructions && !attachments.length) {
      showToast('没有可写作的素材', '可以输入一句话、读取截图、抓取文章或上传视频。', 'info');
      return;
    }
    if (state.aiKind === 'novel') {
      const eventContext = items.map((item, index) =>
        '素材' + (index + 1) + '《' + item.title + '》：' + truncate(item.summary || item.detailText || '', 900)
      ).join('\n\n');
      const novelPrompt = [
        instructions || (state.aiScope === 'multi'
          ? '把这些独立事件作为社会背景，创作一部原创小说；事件之间不要强行写成因果。'
          : '把当前事件作为社会背景，创作一部原创小说。'),
        eventContext ? '可参考的公开素材（只提炼背景与职业细节，不得照抄）：\n' + eventContext : '',
        attachments.length ? '本次另有 ' + attachments.length + ' 张截图或视频画面，用作氛围和场景参考。' : ''
      ].filter(Boolean).join('\n\n');
      state.novelLength = state.aiNovelLength || 'short';
      $('#novelInspiration').value = novelPrompt;
      await generateOriginalNovel(false, {
        prompt: novelPrompt,
        length: state.novelLength,
        genre: '现实题材',
        engine: 'auto',
        images: attachments
      });
      showView('novel');
      return;
    }
    const articleType = ARTICLE_MODE_PROMPTS[state.aiArticleType] ? state.aiArticleType : 'feature';
    state.aiMode = articleType;
    state.articleStyle = state.aiArticleStyle || 'cctv';
    if ($('#articleStylePreset')) $('#articleStylePreset').value = state.articleStyle;
    state.article = null;
    await makeArticle(true, {
      scope: state.aiScope,
      mode: articleType,
      focusId: state.aiScope === 'single' ? (items[0]?.id || '') : '',
      instructions,
      customText: instructions,
      images: attachments.map((item) => item.url),
      imageLabels: attachments.map((item) => item.label)
    });
  }

  async function runCodexOneShot() {
    const prompt = $('#codexPrompt').value.trim();
    const kind = $('#codexOutputKind').value;
    const isArticle = kind === 'article';
    const novelLength = kind === 'long' ? 'long' : kind === 'medium' ? 'medium' : 'short';
    if (!prompt) {
      showToast('请输入一句创作要求', '例如：写一篇外卖骑手重返校园的短篇小说。', 'info');
      $('#codexPrompt').focus();
      return;
    }
    const aiReady = Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    if (!state.codexReady && !aiReady) {
      showToast('还没有可用的写作引擎', '请连接本机 Codex，或在设置中配置并测试 AI。', 'info');
      openSettings();
      return;
    }
    const engineLabel = aiReady ? 'AI' : 'Codex';
    const button = $('#codexWriteBtn');
    const taskId = beginGeneration(isArticle ? 'article' : 'novel', truncate(prompt, 36),
      isArticle ? engineLabel + ' 正在撰写图文' : engineLabel + ' 正在撰写' + novelLengthLabel(novelLength));
    button.disabled = true;
    showLoading(engineLabel + ' 正在创作',
      isArticle ? '正在直接撰写完整图文文章。' : '正在生成标题、人物、提纲、章节和正文。');
    try {
      const result = await requestStandaloneWriting(prompt, kind, 'auto');
      if (!result || !result.text) throw new Error(engineLabel + ' 没有返回内容');
      if (isArticle) {
        const parsed = aiTextToHtml(result.text);
        let html = parsed.html;
        const titleMatch = result.text.match(/^标题[：:]\s*(.+)$/m);
        const title = parsed.title || (titleMatch && titleMatch[1].trim()) || truncate(prompt, 26);
        html = '<p class="article-publish-meta"><span class="article-badge feature">' +
          (result.engine === 'codex' ? 'Codex' : 'AI') + ' 原创</span>一句话创作 · 发布前人工核验</p>' + html;
        state.article = {
          id: 'article_codex_' + Date.now(),
          title: truncate(title, 30),
          html,
          cover: '',
          sourceIds: [],
          tags: [result.engine === 'codex' ? 'Codex' : 'AI', '一句话创作'],
          articleMode: state.aiArticleType || 'feature',
          articleScope: 'single',
          status: 'editing',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        state.article.template = state.articleTemplate;
        state.article.html = applyArticleTemplateHtml(state.article.html, state.articleTemplate);
        saveJson(KEYS.article, state.article);
        renderArticle();
        showView('article');
      } else {
        const parsed = parseNovelAiOutput(result.text, truncate(prompt, 24));
        state.novelLength = novelLength;
        state.novel = {
          id: 'novel_codex_' + Date.now(),
          title: parsed.title || truncate(prompt, 24),
          html: novelTextToHtml(parsed.body),
          lengthType: state.novelLength,
          genre: $('#novelGenre') ? $('#novelGenre').value : '现实题材',
          prompt,
          storyBible: parsed.storyBible,
          visuals: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        saveJson(KEYS.novel, state.novel);
        renderNovel();
        showView('novel');
      }
      finishGeneration(taskId, kind === 'article' ? 'article' : 'novel',
        kind === 'article' ? state.article : state.novel);
      showToast((result.engine === 'codex' ? 'Codex' : 'AI') + ' 创作完成',
        '成品已进入编辑器，可以继续修改或发布。');
    } catch (error) {
      failGeneration(taskId, error.message);
      showToast(engineLabel + ' 创作失败', error.message, 'error');
    } finally {
      button.disabled = false;
      hideLoading();
    }
  }

  async function requestStandaloneWriting(prompt, kind, preference) {
    const aiReady = Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    let codexError = null;
    let aiError = null;
    const preferAiFirst = preference === 'ai' || (preference === 'auto' && aiReady);
    if (preferAiFirst && aiReady) {
      try {
        const result = await api('/api/ai', {
          method: 'POST',
          body: JSON.stringify({
            system: '你是严谨的原创中文作者，直接返回成品，不解释创作过程，不编造无法核实的事实。',
            prompt,
            temperature: .62
          })
        });
        if (result.ok && result.text) return { text: result.text, engine: 'ai' };
      } catch (error) {
        aiError = error;
      }
    }
    if (preference !== 'ai' && state.codexReady) {
      try {
        const result = await api('/api/codex-write', {
          method: 'POST',
          body: JSON.stringify({ prompt, kind })
        });
        if (result.ok && result.text) return { text: result.text, engine: 'codex' };
      } catch (error) {
        codexError = error;
      }
    }
    if (!preferAiFirst && preference !== 'codex' && aiReady) {
      try {
        const result = await api('/api/ai', {
          method: 'POST',
          body: JSON.stringify({
            system: '你是严谨的原创中文作者，直接返回成品，不解释创作过程，不编造无法核实的事实。',
            prompt,
            temperature: .62
          })
        });
        if (result.ok && result.text) return { text: result.text, engine: 'ai' };
      } catch (error) {
        aiError = error;
      }
    }
    if (aiError) throw aiError;
    if (codexError) throw codexError;
    throw new Error(preference === 'codex' ? '请先登录 Codex' : '请先配置 AI 或登录 Codex');
  }

  async function findFreeFigure(query) {
    try {
      const result = await api('/api/image-search?q=' + encodeURIComponent(query));
      const image = (result.items || [])[0];
      if (!image || !image.url) return '';
      return '<figure><img src="' + escapeHtml(image.url) + '" alt=""><figcaption>图片素材：' +
        escapeHtml(image.source || '免费图库') + ' · ' + escapeHtml(image.creator || '') +
        ' · ' + escapeHtml(image.license || '使用前请核对授权') + '</figcaption></figure>';
    } catch (error) {
      return '';
    }
  }

  function showArticleBatchResults(artifacts) {
    state.articleBatchArticles = artifacts.slice();
    showModal('多个阐述角度已生成', 'MULTI-TEMPLATE RESULTS',
      '<div class="article-batch-results">' +
        '<p class="import-hint">已按 ' + artifacts.length +
          ' 个模板分别生成，标题、结构、导语和段落顺序均不同。所有版本已暂存到草稿箱。</p>' +
        artifacts.map((artifact, index) => {
          const mode = artifact.payload && artifact.payload.contentMode || 'fact';
          return '<div class="article-batch-card"><span>' + String(index + 1).padStart(2, '0') + '</span><div><b>' +
            escapeHtml(ARTICLE_CONTENT_MODE_LABELS[mode] || '内容版本') + '</b><strong>' +
            escapeHtml(artifact.title) + '</strong><small>' +
            escapeHtml(truncate(stripHtml(artifact.payload && artifact.payload.html || ''), 120)) +
            '</small></div><button type="button" data-preview-batch-article="' + index + '">预览</button></div>';
        }).join('') +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>保留在草稿箱</button>' +
      '<button class="btn btn-primary" type="button" id="saveAllBatchArticlesBtn">全部保存成品</button>');
    $$('[data-preview-batch-article]').forEach((button) => {
      button.addEventListener('click', () => {
        const artifact = state.articleBatchArticles[Number(button.dataset.previewBatchArticle)];
        if (!artifact) return;
        showModal('模板版本预览', 'TEMPLATE VERSION PREVIEW',
          '<div class="artifact-preview-panel artifact-preview-page">' +
            '<div class="artifact-preview-head"><strong>发布前预览</strong><span>' +
              escapeHtml(ARTICLE_CONTENT_MODE_LABELS[artifact.payload.contentMode] || '内容版本') +
            '</span></div>' +
            '<div class="artifact-preview-body">' + buildArtifactPreview(artifact) + '</div>' +
          '</div>',
          '<button class="btn btn-secondary" type="button" id="backToBatchResultsBtn">返回版本列表</button>');
        $('#backToBatchResultsBtn').addEventListener('click', () => showArticleBatchResults(artifacts));
      });
    });
    $('#saveAllBatchArticlesBtn').addEventListener('click', () => {
      const ids = new Set(artifacts.map((artifact) => artifact.id));
      state.drafts = state.drafts.filter((item) => !ids.has(item.id));
      saveJson(KEYS.drafts, state.drafts);
      artifacts.forEach((artifact) => saveWorkToLibrary(artifact, 'completed'));
      closeModal();
      showToast('全部版本已保存', '已放入作品中心的“已完成”。');
    });
  }

  async function runArticleAngleVariants() {
    const prompt = $('#articleQuickPrompt').value.trim();
    if (!prompt) {
      showToast('请先输入写作内容或读取素材', '多模板生成会使用同样的素材，但分别采用不同阐述角度。', 'info');
      $('#articleQuickPrompt').focus();
      return;
    }
    const modes = state.articleAngleModes.filter((mode) => ARTICLE_CONTENT_MODES[mode]);
    if (modes.length < 2) {
      showToast('请至少选择两个模板', '建议选择“事实快报 + 争议讨论”或“影响分析 + 人物视角”。', 'info');
      return;
    }
    if (state.articleBatchBusy) return;
    const aiReady = state.codexReady ||
      Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    if (!aiReady) {
      showToast('多模板生成需要 AI', '请先连接 Codex，或在设置中填写可用的 AI 服务。', 'info');
      openSettings();
      return;
    }
    state.articleBatchBusy = true;
    renderArticleAnglePicker();
    const artifacts = [];
    const usedTitles = new Set();
    try {
      for (let index = 0; index < modes.length; index += 1) {
        const mode = modes[index];
        const modeLabel = ARTICLE_CONTENT_MODE_LABELS[mode] || '内容版本';
        const template = articleTemplateForContentMode(mode);
        const taskId = beginGeneration('article', modeLabel + ' · ' + truncate(prompt, 28),
          '正在生成第 ' + (index + 1) + ' / ' + modes.length + ' 个角度版本');
        showLoading('正在生成多个模板版本', '正在生成“' + modeLabel + '”版本，结构与其它版本保持明显差异。');
        try {
          const variationPrompt = nextArticleVariationPrompt();
          const enhanced = [
            prompt,
            '本次必须使用独立的内容阐述模板：' + articleContentModePrompt(mode),
            '本版本版式：' + ARTICLE_TEMPLATE_PROMPTS[template],
            '本次版本差异化要求：' + variationPrompt,
            ARTICLE_MODE_PROMPTS[mode === 'visual' ? 'short' : 'digest'],
            '第一行输出“标题：……”，正文必须完整。',
            '不得复用其它模板版本的标题、导语、小标题、开头方式和段落顺序。'
          ].join('\n\n');
          const result = await requestStandaloneWriting(enhanced, 'article', 'auto');
          const parsed = aiTextToHtml(result.text);
          const titleMatch = result.text.match(/^标题[：:]\s*(.+)$/m);
          let title = truncate(parsed.title || (titleMatch && titleMatch[1].trim()) || modeLabel, 30);
          const titleKey = title.replace(/\s/g, '');
          if (usedTitles.has(titleKey)) title = truncate(title + '｜' + modeLabel, 30);
          usedTitles.add(title.replace(/\s/g, ''));
          const figure = mode === 'visual'
            ? (await Promise.all([
                findFreeFigure(title + ' 新闻现场'),
                findFreeFigure(title + ' 人物'),
                findFreeFigure(title + ' 背景')
              ])).filter(Boolean).join('')
            : await findFreeFigure(title);
          const html = applyArticleTemplateHtml(
            '<p class="article-publish-meta"><span class="article-badge feature">' +
              escapeHtml(modeLabel) + '模板</span>同一素材 · 不同阐述角度 · 发布前核验</p>' +
            parsed.html + figure,
            template
          );
          const article = {
            id: 'article_angle_' + Date.now() + '_' + index,
            title,
            html,
            cover: '',
            sourceIds: state.selected.slice(0, 4),
            tags: ['多模板生成', modeLabel],
            style: $('#articleStylePreset') ? $('#articleStylePreset').value : state.articleStyle,
            contentMode: mode,
            template,
            articleMode: mode === 'visual' ? 'short' : 'digest',
            articleScope: 'single',
            status: 'editing',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          const artifact = buildWorkArtifact('article', article, taskId);
          artifacts.push(artifact);
          saveWorkToLibrary(artifact, 'draft');
        } catch (error) {
          failGeneration(taskId, error.message);
        } finally {
          state.generating = state.generating.filter((item) => item.id !== taskId);
          saveJson(KEYS.generating, state.generating);
          renderDrafts();
        }
      }
      if (!artifacts.length) throw new Error('所有模板版本均生成失败，请检查 AI 连接后重试');
      state.article = JSON.parse(JSON.stringify(artifacts[0].payload));
      state.articleContentMode = state.article.contentMode;
      state.articleTemplate = state.article.template;
      saveJson(KEYS.article, state.article);
      renderArticle();
      showView('article');
      showArticleBatchResults(artifacts);
    } catch (error) {
      showToast('多模板生成失败', error.message, 'error');
    } finally {
      state.articleBatchBusy = false;
      renderArticleAnglePicker();
      hideLoading();
    }
  }

  function openArticleMultiTemplateDialog(initialPrompt) {
    let selected = new Set(state.articleAngleModes.length ? state.articleAngleModes : ['fact', 'discussion']);
    const promptDefault = String(initialPrompt || $('#articleQuickPrompt').value || '').trim();
    showModal('选择多个阐述角度', 'MULTI-TEMPLATE WRITER',
      '<div class="article-template-dialog">' +
        '<p class="import-hint">同一份素材可以同时生成多个版本。请选择 2–4 个模板，每版都会更换标题、开头、小标题和段落顺序。</p>' +
        '<label>本次写作内容或素材要求<textarea id="multiTemplatePrompt" placeholder="输入新闻主题、讨论要求，或先关闭窗口读取软件文本和文章素材">' +
          escapeHtml(promptDefault) + '</textarea></label>' +
        '<div class="article-angle-head"><strong>选择阐述角度</strong><span id="multiTemplateCount">已选 ' +
          selected.size + ' 个，最多 4 个</span></div>' +
        '<div class="article-angle-grid" id="multiTemplateGrid">' +
          Object.keys(ARTICLE_CONTENT_MODES).map((mode) =>
            '<button type="button" data-dialog-angle="' + mode + '" class="' +
              (selected.has(mode) ? 'active' : '') + '">' +
              escapeHtml(ARTICLE_CONTENT_MODE_LABELS[mode]) + '</button>').join('') +
        '</div>' +
        '<div class="modal-note"><p>生成会使用当前已连接的 Codex 或 AI。生成完成后，每个版本都会先放入草稿箱，可逐篇预览。</p></div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-primary" type="button" id="confirmMultiTemplateBtn">生成所选模板版本</button>');
    const render = () => {
      $$('[data-dialog-angle]').forEach((button) => {
        const active = selected.has(button.dataset.dialogAngle);
        button.classList.toggle('active', active);
        button.disabled = !active && selected.size >= 4;
      });
      $('#multiTemplateCount').textContent = '已选 ' + selected.size + ' 个，最多 4 个';
    };
    $$('[data-dialog-angle]').forEach((button) => {
      button.addEventListener('click', () => {
        const mode = button.dataset.dialogAngle;
        if (selected.has(mode)) selected.delete(mode);
        else if (selected.size < 4) selected.add(mode);
        else {
          showToast('最多选择 4 个模板', '先取消一个模板，再选择新的角度。', 'info');
          return;
        }
        render();
      });
    });
    $('#confirmMultiTemplateBtn').addEventListener('click', () => {
      if (selected.size < 2) {
        showToast('请至少选择两个模板', '多模板生成需要至少两个不同的阐述角度。', 'info');
        return;
      }
      const prompt = $('#multiTemplatePrompt').value.trim();
      if (!prompt) {
        showToast('请填写写作内容', '也可以先关闭窗口，读取文章或软件素材后再次打开。', 'info');
        $('#multiTemplatePrompt').focus();
        return;
      }
      state.articleAngleModes = Array.from(selected);
      $('#articleQuickPrompt').value = prompt;
      renderArticleAnglePicker();
      closeModal();
      setTimeout(runArticleAngleVariants, 80);
    });
    render();
  }

  function openAiMultiTemplateDialog() {
    const items = state.aiScope === 'multi'
      ? selectedItems().slice(0, 4)
      : [selectedItems()[0] || leadItem()].filter(Boolean);
    const instructions = $('#aiInstructions') ? $('#aiInstructions').value.trim() : '';
    const context = items.map((item, index) =>
      '事件' + (index + 1) + '：' + item.title + '\n公开摘要：' + truncate(item.summary || item.detailText || '', 900)
    ).join('\n\n');
    openArticleMultiTemplateDialog([
      context ? '请围绕以下同一组热点生成多个阐述角度不同的版本：\n' + context : '',
      instructions ? '用户的写作要求：' + instructions : '写作要求：事实准确、结构清晰，重要判断标明信息边界。',
      '每个版本必须完整，不得只输出目录或提纲。'
    ].filter(Boolean).join('\n\n'));
  }

  async function runArticleQuickWrite(mode) {
    const prompt = $('#articleQuickPrompt').value.trim();
    if (!prompt) {
      showToast('请输入一句写作要求', null, 'info');
      $('#articleQuickPrompt').focus();
      return;
    }
    const style = $('#articleStylePreset').value;
    const contentMode = $('#articleContentMode') ? $('#articleContentMode').value : state.articleContentMode;
    const templateId = $('#articleLayoutPreset') ? $('#articleLayoutPreset').value : 'news';
    state.articleTemplate = ARTICLE_TEMPLATE_PROMPTS[templateId] ? templateId : 'news';
    const articleMode = ARTICLE_MODE_PROMPTS[mode] ? mode : 'feature';
    state.articleStyle = style;
    state.articleContentMode = ARTICLE_CONTENT_MODES[contentMode] ? contentMode : 'fact';
    const variationPrompt = nextArticleVariationPrompt();
    const button = $('#articleQuickWriteBtn');
    const taskId = beginGeneration('article', truncate(prompt, 36),
      articleMode === 'micro' ? '正在生成微新闻图文' : '正在生成完整图文');
    button.disabled = true;
    showLoading('正在撰写' + articleModeLabel(articleMode),
      '正在尝试 Codex 或已配置的 AI，并准备配图。');
    try {
      const enhanced = prompt + '\n写作风格：' + (ARTICLE_STYLE_PROMPTS[style] || ARTICLE_STYLE_PROMPTS.cctv) +
        '\n图文版式：' + ARTICLE_TEMPLATE_PROMPTS[state.articleTemplate] +
        '\n内容模式：' + articleContentModePrompt(state.articleContentMode) +
        '\n本次版本要求：' + variationPrompt +
        '\n' + ARTICLE_MODE_PROMPTS[articleMode] +
        '\n第一行输出“标题：……”，使用小标题和清晰段落。';
      const result = await requestStandaloneWriting(enhanced, 'article', 'auto');
      const parsed = aiTextToHtml(result.text);
      const titleMatch = result.text.match(/^标题[：:]\s*(.+)$/m);
      const title = parsed.title || (titleMatch && titleMatch[1].trim()) || truncate(prompt, 26);
      const visualSubject = truncate(title || prompt, 50);
      const figure = state.articleContentMode === 'visual'
        ? (await Promise.all([
            findFreeFigure(visualSubject + ' 新闻现场'),
            findFreeFigure(visualSubject + ' 人物'),
            findFreeFigure(visualSubject + ' 背景')
          ])).filter(Boolean).join('')
        : await findFreeFigure(visualSubject);
      const html = applyArticleTemplateHtml('<p class="article-publish-meta"><span class="article-badge feature">' +
        (result.engine === 'codex' ? 'Codex' : 'AI') + ' 直写</span>一句话创作 · 发布前人工核验</p>' +
        parsed.html + figure, state.articleTemplate);
      state.article = {
        id: 'article_quick_' + Date.now(),
        title: truncate(title, 30),
        html,
        cover: '',
        sourceIds: [],
        tags: [articleModeLabel(articleMode), style],
        style,
        contentMode: state.articleContentMode,
        template: state.articleTemplate,
        articleMode,
        articleScope: 'single',
        status: 'editing',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      saveJson(KEYS.article, state.article);
      renderArticle();
      showView('article');
      finishGeneration(taskId, 'article', state.article);
      showToast('图文已生成', result.engine === 'codex' ? '由本机 Codex 完成。' : '由已配置 AI 完成。');
    } catch (error) {
      failGeneration(taskId, error.message);
      showToast('图文生成失败', error.message, 'error');
    } finally {
      button.disabled = false;
      hideLoading();
    }
  }

  function defaultNovelChapterCount(length) {
    return length === 'long' ? 30 : length === 'medium' ? 12 : 5;
  }

  function resizeNovelChapterPlan(chapters, count) {
    const target = Math.max(3, Math.min(80, Number(count) || 5));
    const next = (chapters || []).slice(0, target);
    while (next.length < target) {
      next.push({
        title: '第' + (next.length + 1) + '章 待定',
        summary: '等待根据整体提纲细化本章核心事件'
      });
    }
    return next;
  }

  function parseNovelPlanningExtras(raw) {
    const titleBlock = takeNovelSection(raw, '书名候选');
    const namingBlock = takeNovelSection(raw, '人物命名方案');
    const titles = (titleBlock || '').split(/\r?\n/)
      .map((line) => cleanNovelListLine(line).split(/[｜|]/)[0].trim())
      .filter((line) => line.length >= 2 && line.length <= 40);
    const nameSchemes = (namingBlock || '').split(/\r?\n/)
      .map((line) => cleanNovelListLine(line))
      .filter(Boolean)
      .map((line, index) => {
        const parts = line.split(/[｜|]/);
        const label = (parts.shift() || ('命名方案 ' + (index + 1))).trim();
        const names = parts.join('｜')
          .split(/[、，,；;]/)
          .map((name) => name.replace(/^.*?[：:]/, '').trim())
          .filter((name) => name.length >= 1 && name.length <= 20);
        return { label, names };
      })
      .filter((scheme) => scheme.names.length);
    return { titles: unique(titles), nameSchemes };
  }

  function selectedNovelReferenceMaterials(limit) {
    const mode = $('#novelMaterialUseMode') ? $('#novelMaterialUseMode').value : 'multiple';
    const selected = state.novelMaterials.filter((material) =>
      state.novelMaterialSelected.includes(material.id));
    const source = selected.length
      ? selected
      : state.novelMaterials.slice();
    return (mode === 'single' ? source.slice(0, 1) : source).slice(0, limit || 6);
  }

  function novelTransformationPrompt() {
    const scope = $('#novelTransformScope') ? $('#novelTransformScope').value : 'full';
    const replaceNames = !$('#novelReplaceNames') || $('#novelReplaceNames').checked;
    const replaceBackground = !$('#novelReplaceBackground') || $('#novelReplaceBackground').checked;
    const replaceRelations = !$('#novelReplaceRelations') || $('#novelReplaceRelations').checked;
    return [
      '参考素材使用方式：' +
        ($('#novelMaterialUseMode') && $('#novelMaterialUseMode').value === 'single'
          ? '只使用一个素材，提炼高层主题和叙事节奏。'
          : '综合多个素材的共性，重新组合背景、冲突和人物。'),
      scope === 'full'
        ? '再创作幅度：全面更换时代、国家或地区、城市、职业、家族结构和社会规则。'
        : scope === 'era'
          ? '再创作幅度：保留题材方向，但更换时代和地点。'
          : '再创作幅度：更换职业、家族和人物社会关系。',
      replaceNames ? '所有人物姓名、昵称、家族名、组织名和专有名词必须重新命名，不得沿用素材。' : '',
      replaceBackground ? '所有背景、地名、机构、事件和独特设定必须重新设计，不得复制素材。' : '',
      replaceRelations ? '人物关系、核心冲突、转折和结局必须重新设计，不得按原素材情节顺序改写。' : '',
      '只能参考高层结构、节奏和题材特征；不得逐句改写、拼接或高度模仿任何现有作品。'
    ].filter(Boolean).join('\n');
  }

  async function startNovelPlanningWorkflow(options) {
    const settings = options || {};
    const aiReady = Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    const engine = settings.engine || ($('#novelEngine') ? $('#novelEngine').value : 'auto');
    if ((engine === 'ai' && !aiReady) || (engine === 'codex' && !state.codexReady) ||
        (engine === 'auto' && !aiReady && !state.codexReady)) {
      showToast('小说规划需要 AI', '请连接本机 Codex，或在设置中配置 AI。', 'info');
      openSettings();
      return;
    }
    const prompt = String(settings.prompt || $('#novelQuickPrompt').value || $('#novelInspiration').value || '').trim();
    if (!prompt && !selectedItems().length && !state.novelMaterials.length) {
      showToast('请先填写小说要求或读取素材', '可以写题材、人物、冲突和想要的结局。', 'info');
      $('#novelQuickPrompt').focus();
      return;
    }
    const mode = settings.length || state.novelLength || 'short';
    const genre = settings.genre || $('#novelGenre').value || '现实题材';
    const narrativeStyle = settings.narrativeStyle ||
      ($('#novelNarrativeStyle') ? $('#novelNarrativeStyle').value : 'oriental');
    const defaultChapterCount = defaultNovelChapterCount(mode);
    const taskId = beginGeneration('novel', truncate(prompt || '小说故事档案', 36),
      '正在读取海内外素材并生成待确认故事档案');
    showLoading('正在整理国内外素材', '先检索 Edge、国内外公开资料和图片，再生成小说名、简介与人物档案。');
    try {
      if (settings.images && settings.images.length) {
        const extraImages = settings.images.filter((image) => image && image.url).map((image, index) => ({
          title: image.label || ('创作素材 ' + (index + 1)),
          thumbnail: image.url,
          url: image.url,
          source: 'AI 工作台素材',
          creator: '',
          license: '请核对素材授权'
        }));
        state.researchImages = extraImages.concat(state.researchImages || []).slice(0, 20);
        state.selectedResearchImages = state.researchImages.slice(0, 4).map((image, index) => index);
      }
      await collectNovelResearch(prompt, genre, false);
      const selectedContext = selectedItems().slice(0, 4).map((item) =>
        item.title + '。' + item.summary).join('\n');
      const researchContext = state.researchArticles
        .filter((item) => state.selectedResearchSources.includes(item.id))
        .slice(0, 10)
        .map((item, index) => '资料' + (index + 1) + '（' + (item.region || '公开') + '）：' +
          item.title + '\n来源：' + (item.source || '公开网页') + '\n摘要：' + truncate(item.summary || '', 700))
        .join('\n\n');
      const referenceMaterials = selectedNovelReferenceMaterials(6);
      const materialContext = referenceMaterials.map((material, index) =>
        '素材' + (index + 1) + '《' + material.title + '》：' + truncate(material.text, 1400)).join('\n\n');
      showLoading('正在生成小说故事档案', '只生成书名候选、故事概要、简介、人物和章节结构，不写正文。');
      const planningPrompt = [
        '你是原创小说策划编辑。必须创造全新人物、地点和情节，不得复制、逐字改写或高度模仿现有作品。',
        novelTransformationPrompt(),
        '只完成小说策划档案，禁止输出任何章节正文。',
        '小说类型：' + genre,
        '叙事风格：' + (NOVEL_STYLE_PROMPTS[narrativeStyle] || NOVEL_STYLE_PROMPTS.oriental),
        '篇幅：' + novelLengthLabel(mode) + '，默认计划 ' + defaultChapterCount + ' 章。',
        '人物形象必须从故事主题、时代、地域、职业、阶层和人物处境推导，形成差异化视觉设计。' +
          '外貌不能只写“好看、英俊、漂亮”，必须写出年龄感、发型、面部或体态特征、常穿服饰、材质颜色、随身物件和一个可反复识别的标志性细节；不同人物不得同质化。',
        '情节可以借鉴热门小说常见的宏观节奏：强开篇钩子、明确欲望、持续阻力、关系张力、阶段升级、关键反转、情绪释放和结局回收。' +
          '只参考这些通用叙事规律和题材爽点，不得复用任何具体作品的人物、事件链、独特设定、标志性台词或原句。',
        '严格按以下标签输出：',
        '【书名候选】\n每行一个候选书名，共5个，使用“书名｜一句风格说明”格式。',
        '【作品资料】\n标题：最终推荐书名\n一句话简介：...\n小说简介：250-400字完整故事简介',
        '【人物命名方案】\n方案1｜角色1姓名、角色2姓名、角色3姓名、角色4姓名\n方案2｜另一组姓名...\n方案3｜另一组姓名...',
        '【人物档案】\n姓名｜年龄身份与职业｜贴题外貌穿搭与标志性细节｜性格与说话方式｜核心欲望与弱点｜与其他人物关系\n至少5人',
        '【故事提纲】\n阶段名｜目标与阻力｜关系变化｜阶段爽点或反转｜本阶段结尾钩子',
        '【章节目录】\n第1章 章名｜本章核心事件\n共' + defaultChapterCount + '章',
        '用户要求与故事方向：\n' + truncate(prompt + '\n' + selectedContext, 6000),
        materialContext ? '参考素材（只提炼背景，不照搬）：\n' + materialContext : '',
        researchContext ? '国内外公开资料（只作为社会背景与职业细节）：\n' + researchContext : ''
      ].filter(Boolean).join('\n\n');
      const result = await requestStandaloneWriting(planningPrompt, mode, engine);
      const parsed = parseNovelAiOutput(result.text, '未命名原创小说');
      const extras = parseNovelPlanningExtras(result.text);
      const bible = parsed.storyBible || {};
      const plan = {
        title: parsed.title || extras.titles[0] || '未命名原创小说',
        titleOptions: extras.titles.length ? extras.titles : [parsed.title || '未命名原创小说'],
        synopsis: bible.synopsis || truncate(parsed.body, 300),
        characters: bible.characters || [],
        nameSchemes: extras.nameSchemes || [],
        outline: bible.outline || [],
        chapters: resizeNovelChapterPlan(bible.chapters || [], defaultChapterCount),
        chapterCount: defaultChapterCount,
        firstChapterWords: mode === 'long' ? 2800 : mode === 'medium' ? 2200 : 1800,
        genre,
        mode,
        narrativeStyle,
        engine,
        prompt,
        sources: state.researchArticles.filter((item) => state.selectedResearchSources.includes(item.id)).slice(0, 10),
        visuals: state.selectedResearchImages.map((index) => state.researchImages[index]).filter(Boolean).slice(0, 4),
        researchCount: state.researchArticles.length,
        createdAt: new Date().toISOString()
      };
      state.novelPlan = plan;
      state.generating = state.generating.filter((item) => item.id !== taskId);
      saveJson(KEYS.generating, state.generating);
      renderDrafts();
      hideLoading();
      showNovelPlanConfirmation(plan);
    } catch (error) {
      failGeneration(taskId, error.message);
      showToast('小说档案生成失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  function showNovelPlanConfirmation(plan) {
    showModal('确认小说故事档案', 'STEP 1 OF 2 · CONFIRM PLAN',
      '<div class="novel-plan-confirm">' +
        '<div class="post-browse-source"><strong>' + escapeHtml(plan.title) + '</strong><small>已读取 ' +
          plan.researchCount + ' 条国内外资料 · 尚未生成正文</small></div>' +
        '<label>选择小说名（可手动修改）<input id="novelPlanTitleInput" maxlength="40" value="' +
          escapeHtml(plan.title) + '"></label>' +
        '<div class="novel-title-options">' + plan.titleOptions.map((title, index) =>
          '<button type="button" data-plan-title="' + index + '">' + escapeHtml(title) + '</button>').join('') + '</div>' +
        '<label>小说简介<textarea id="novelPlanSynopsis">' + escapeHtml(plan.synopsis || '') + '</textarea></label>' +
        (plan.nameSchemes.length
          ? '<div><strong class="novel-plan-section-title">人物命名方案（可选，也可逐人修改）</strong><div class="novel-name-schemes">' +
            plan.nameSchemes.map((scheme, index) => '<button type="button" data-name-scheme="' + index + '">' +
              escapeHtml(scheme.label) + '：' + escapeHtml(scheme.names.join('、')) + '</button>').join('') + '</div></div>'
          : '') +
        '<div class="novel-plan-character-editor"><strong>人物介绍</strong>' +
          (plan.characters.length ? plan.characters.map((character, index) =>
            '<div class="novel-plan-character"><input data-plan-character-name="' + index + '" value="' +
              escapeHtml(character.name || ('人物' + (index + 1))) + '"><span><b>' +
              escapeHtml(character.role || '主要人物') + '</b><small>' +
              escapeHtml(character.description || character.role || '') + '</small></span></div>').join('')
            : '<p class="field-hint">AI 暂未识别人物，可以在确认前重新生成档案。</p>') +
        '</div>' +
        '<div class="novel-plan-numbers">' +
          '<label>全书章节数<input id="novelPlanChapterCount" type="number" min="3" max="80" value="' +
            plan.chapterCount + '"></label>' +
          '<label>第一章目标字数<input id="novelPlanFirstWords" type="number" min="500" max="5000" step="100" value="' +
            plan.firstChapterWords + '"></label>' +
        '</div>' +
        '<div class="novel-plan-readonly"><strong>故事提纲</strong><p>' +
          escapeHtml(plan.outline.map((item) => item.title + '：' + item.summary).join('；') || '待生成') +
        '</p><strong>章节目录</strong><p>' +
          escapeHtml(plan.chapters.slice(0, 12).map((chapter) => chapter.title).join(' / ')) +
          (plan.chapters.length > 12 ? ' …' : '') + '</p></div>' +
        '<div class="modal-note"><p>请先确认小说名、简介、人物名称、章节数和第一章字数。确认后才会开始写第一章。</p></div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>暂不创作</button>' +
      '<button class="btn btn-secondary" type="button" id="regenerateNovelPlanBtn">重新生成档案</button>' +
      '<button class="btn btn-primary" type="button" id="confirmNovelPlanBtn">确认并创作第一章</button>');
    $$('[data-plan-title]').forEach((button) => {
      button.addEventListener('click', () => {
        const title = plan.titleOptions[Number(button.dataset.planTitle)];
        if (title) $('#novelPlanTitleInput').value = title;
      });
    });
    $$('[data-name-scheme]').forEach((button) => {
      button.addEventListener('click', () => {
        const scheme = plan.nameSchemes[Number(button.dataset.nameScheme)];
        if (!scheme) return;
        $$('[data-plan-character-name]').forEach((input, index) => {
          if (scheme.names[index]) input.value = scheme.names[index];
        });
      });
    });
    $('#regenerateNovelPlanBtn').addEventListener('click', () => {
      closeModal();
      startNovelPlanningWorkflow({
        prompt: plan.prompt, length: plan.mode, genre: plan.genre,
        narrativeStyle: plan.narrativeStyle, engine: plan.engine
      });
    });
    $('#confirmNovelPlanBtn').addEventListener('click', () => {
      const title = $('#novelPlanTitleInput').value.trim();
      if (!title) {
        showToast('请确认小说名', null, 'info');
        $('#novelPlanTitleInput').focus();
        return;
      }
      const chapterCount = Math.max(3, Math.min(80,
        Number($('#novelPlanChapterCount').value) || plan.chapterCount));
      const firstChapterWords = Math.max(500, Math.min(5000,
        Number($('#novelPlanFirstWords').value) || plan.firstChapterWords));
      const characters = plan.characters.map((character, index) => Object.assign({}, character, {
        name: ($('[data-plan-character-name="' + index + '"]')?.value || character.name || '').trim()
      }));
      const updated = Object.assign({}, plan, {
        title,
        synopsis: $('#novelPlanSynopsis').value.trim(),
        characters,
        chapters: resizeNovelChapterPlan(plan.chapters, chapterCount),
        chapterCount,
        firstChapterWords
      });
      state.novelPlan = updated;
      closeModal();
      generateFirstChapterFromNovelPlan(updated);
    });
  }

  async function generateFirstChapterFromNovelPlan(plan) {
    const taskId = beginGeneration('novel', plan.title || '原创小说第一章',
      '正在创作第一章');
    showLoading('正在创作第一章', '已使用确认后的小说名、人物、章节数和字数要求。');
    try {
      const chapterTitle = plan.chapters[0]?.title || '第一章';
      const prompt = [
        '根据下面已经确认的小说档案，只创作第一章，不得提前写后续章节。',
        novelTransformationPrompt(),
        '小说名：' + plan.title,
        '小说简介：' + plan.synopsis,
        '类型与风格：' + plan.genre + '；' +
          (NOVEL_STYLE_PROMPTS[plan.narrativeStyle] || NOVEL_STYLE_PROMPTS.oriental),
        '全书计划章节数：' + plan.chapterCount + '章。',
        '第一章目标字数：约' + plan.firstChapterWords + '字，允许上下浮动10%。',
        '第一章名称：' + chapterTitle,
        '人物档案：\n' + plan.characters.map((character) =>
          character.name + '｜' + (character.identity || character.role || '') + '｜' +
          (character.appearance || '') + '｜' + (character.personality || '') + '｜' +
          (character.motivation || '') + '｜' + (character.relationship || '') + '｜' +
          (character.description || '')).join('\n'),
        '故事提纲：\n' + plan.outline.map((item) => item.title + '｜' + item.summary).join('\n'),
        '章节目录：\n' + plan.chapters.map((chapter) => chapter.title + '｜' + chapter.summary).join('\n'),
        '人物出场时必须自然带出已确认的外貌、穿搭和标志性细节，后续行为要符合其身份、欲望和弱点。' +
          '第一章要有热门小说式的快速钩子、清晰目标、关系张力和章末悬念，但不得照搬任何具体作品桥段。',
        '必须原创，不得复制参考作品。只输出第一章标题和完整正文，不要输出提纲、人物表或后续章节。'
      ].join('\n\n');
      const result = await requestStandaloneWriting(prompt, plan.mode, plan.engine);
      const parsed = parseNovelAiOutput(result.text, chapterTitle);
      const bodyText = parsed.body || result.text;
      const figures = novelFiguresFromResearch(plan.visuals);
      state.novelLength = plan.mode;
      state.novel = {
        id: 'novel_staged_' + Date.now(),
        title: plan.title,
        html: addFiguresToNovelHtml(novelTextToHtml(bodyText), figures),
        lengthType: plan.mode,
        genre: plan.genre,
        narrativeStyle: plan.narrativeStyle,
        prompt: plan.prompt,
        storyBible: {
          synopsis: plan.synopsis,
          characters: plan.characters,
          outline: plan.outline,
          chapters: plan.chapters,
          targetChapterCount: plan.chapterCount,
          targetWordsPerChapter: plan.firstChapterWords
        },
        visuals: plan.visuals,
        sources: plan.sources,
        stagedCreation: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      saveJson(KEYS.novel, state.novel);
      renderNovel();
      showView('novel');
      finishGeneration(taskId, 'novel', state.novel);
      showToast('第一章已生成', '小说名、人物、章节数和字数已按你的确认设置保存。');
    } catch (error) {
      failGeneration(taskId, error.message);
      showToast('第一章生成失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  async function runNovelQuickWrite() {
    return startNovelPlanningWorkflow();
    const prompt = $('#novelQuickPrompt').value.trim() || $('#novelInspiration').value.trim();
    if (!prompt) {
      showToast('请输入一句小说要求', null, 'info');
      $('#novelQuickPrompt').focus();
      return;
    }
    const style = $('#novelNarrativeStyle').value;
    const engine = $('#novelEngine').value;
    const mode = state.novelLength;
    const genre = $('#novelGenre').value;
    $('#novelInspiration').value = prompt;
    const button = $('#novelQuickWriteBtn');
    const taskId = beginGeneration('novel', truncate(prompt, 36),
      '正在生成' + novelLengthLabel(mode));
    button.disabled = true;
    showLoading('正在读取素材并创作', '正在补充国内外背景，然后生成人物、提纲、章节与正文。');
    try {
      if (engine !== 'codex' && !(engine === 'auto' && state.codexReady)) {
        await collectNovelResearch(prompt, genre, false);
      }
      const materialText = state.novelMaterials.slice(0, 4).map((item) =>
        '《' + item.title + '》：' + truncate(item.text, 700)).join('\n');
      const researchText = state.researchArticles.slice(0, 5).map((item) =>
        item.title + '：' + truncate(item.summary || '', 400)).join('\n');
      const enhanced = [
        prompt,
        '小说类型：' + genre,
        '叙事风格：' + (NOVEL_STYLE_PROMPTS[style] || NOVEL_STYLE_PROMPTS.oriental),
        mode === 'long'
          ? '篇幅要求：长篇小说开篇，先输出作品资料、至少6人的人物档案、故事提纲、至少8章目录，再写第一章约2500字。'
          : mode === 'medium'
            ? '篇幅要求：中篇小说开篇，先输出作品资料、至少5人的人物档案、故事提纲、8-15章目录，再写第一章约2000字。'
            : '篇幅要求：完整短篇小说，正文约3000-4500字，分为3-5章，人物、冲突、转折和结局完整。',
        '必须使用全新人物、地点和情节，不得复刻现有作品。',
        materialText ? '背景参考（只提炼社会和职业细节）：\n' + materialText : '',
        researchText ? '公开资料（只作背景，不照搬）：\n' + researchText : ''
      ].filter(Boolean).join('\n\n');
      const result = await requestStandaloneWriting(enhanced, mode, engine);
      showLoading('正在整理小说结构', '正在拆分书名、人物、提纲和章节。');
      const parsed = parseNovelAiOutput(result.text, truncate(prompt, 24));
      const images = state.selectedResearchImages.map((index) => state.researchImages[index]).filter(Boolean);
      const figures = novelFiguresFromResearch(images);
      state.novel = {
        id: 'novel_quick_' + Date.now(),
        title: parsed.title || truncate(prompt, 24),
        html: addFiguresToNovelHtml(novelTextToHtml(parsed.body), figures),
        lengthType: mode,
        genre,
        narrativeStyle: style,
        prompt,
        storyBible: parsed.storyBible,
        visuals: images.slice(0, 4),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      saveJson(KEYS.novel, state.novel);
      renderNovel();
      showView('novel');
      finishGeneration(taskId, 'novel', state.novel);
      showToast('小说已生成', result.engine === 'codex' ? '由本机 Codex 完成。' : '由已配置 AI 完成。');
    } catch (error) {
      failGeneration(taskId, error.message);
      showToast('小说生成失败', error.message, 'error');
    } finally {
      button.disabled = false;
      hideLoading();
    }
  }

  function showWritingSourceReadSuccess(target, title, text, url, source) {
    const cleanText = normalizeSourceText(text);
    const typeLabel = target === 'novel' ? '小说素材' : '图文素材';
    const previewText = cleanText.length > 8000
      ? cleanText.slice(0, 8000) + '\n\n……已省略后续内容，生成时会读取完整素材。'
      : cleanText;
    const generateFoot = target === 'novel'
      ? '<button class="btn btn-primary" type="button" id="readSourceGenerateNovelBtn">生成并预览小说成品</button>'
      : '<button class="btn btn-secondary" type="button" id="readSourceGenerateMicroBtn">生成并预览新闻快读</button>' +
        '<button class="btn btn-secondary" type="button" id="readSourceGenerateVisualBtn">生成并预览图文卡片</button>' +
        '<button class="btn btn-primary" type="button" id="readSourceGenerateArticleBtn">生成并预览完整图文</button>';
    showModal('素材读取成功', 'SOURCE READY',
      '<div class="source-read-success">' +
        '<div class="post-browse-source"><strong>' + escapeHtml(title || '当前素材') + '</strong><small>' +
          escapeHtml(source || '软件素材') + ' · ' + cleanText.replace(/\s/g, '').length + ' 字</small></div>' +
        '<div class="source-read-checks">' +
          '<span>已读取标题</span><span>已读取正文</span><span>可用于' + typeLabel + '创作</span>' +
        '</div>' +
        '<p class="import-hint">下一步可先检查原文，也可以直接生成。成品生成后会先打开预览，并让你选择保存为已完成或放入草稿箱。</p>' +
        '<div class="read-source-preview" id="readSourcePreviewPanel" hidden>' +
          '<div class="artifact-preview-head"><strong>已读取素材预览</strong><span>' +
            escapeHtml(source || '软件素材') + '</span></div>' +
          '<div class="read-source-preview-body">' + escapeHtml(previewText) + '</div>' +
        '</div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>继续编辑</button>' +
      '<button class="btn btn-secondary" type="button" id="previewReadSourceBtn">预览素材</button>' +
      generateFoot);
    $('#previewReadSourceBtn').addEventListener('click', () => {
      const panel = $('#readSourcePreviewPanel');
      panel.hidden = !panel.hidden;
      $('#previewReadSourceBtn').textContent = panel.hidden ? '预览素材' : '收起素材';
      if (!panel.hidden) panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
    if (target === 'novel') {
      $('#readSourceGenerateNovelBtn').addEventListener('click', () => {
        closeModal();
        showView('novel');
        runNovelQuickWrite();
      });
    } else {
      $('#readSourceGenerateMicroBtn').addEventListener('click', () => {
        closeModal();
        showView('article');
        runArticleQuickWrite('digest');
      });
      $('#readSourceGenerateVisualBtn').addEventListener('click', () => {
        closeModal();
        showView('article');
        if ($('#articleContentMode')) $('#articleContentMode').value = 'visual';
        state.articleContentMode = 'visual';
        if ($('#articleLayoutPreset')) $('#articleLayoutPreset').value = 'photo';
        selectArticleTemplate('photo');
        runArticleQuickWrite('short');
      });
      $('#readSourceGenerateArticleBtn').addEventListener('click', () => {
        closeModal();
        showView('article');
        runArticleQuickWrite('feature');
      });
    }
  }

  function applyWritingSource(target, title, text, url, source) {
    const cleanText = normalizeSourceText(text);
    if (cleanText.length < 20) throw new Error('当前页面没有足够的可读文字');
    if (target === 'article') {
      $('#articleQuickPrompt').value = [
        '请根据下面选择的软件素材写一篇原创图文，提炼事实、背景、影响和讨论焦点。',
        '素材标题：' + title,
        '素材来源：' + source,
        '素材内容：' + truncate(cleanText, 6000)
      ].join('\n');
      showView('article');
      showToast('图文素材已读取', title + '。请选择写作风格后点击直接写作。');
    } else {
      const material = {
        id: 'novel_write_source_' + Date.now(),
        title: title || '软件当前内容',
        text: truncate(cleanText, 12000),
        url: url || '',
        source: source || '软件内容',
        createdAt: new Date().toISOString()
      };
      state.novelMaterials.unshift(material);
      state.novelMaterials = state.novelMaterials.slice(0, 10);
      state.novelMaterialSelected = $('#novelMaterialUseMode') &&
        $('#novelMaterialUseMode').value === 'single'
        ? [material.id]
        : unique(state.novelMaterialSelected.concat(material.id)).slice(-10);
      saveJson(KEYS.novelMaterials, state.novelMaterials);
      renderNovelMaterials();
      $('#novelInspiration').value = [
        '参考下面选择的软件素材进行全新原创小说创作，只提炼背景、人物关系和社会细节。',
        '素材标题：' + title,
        '素材来源：' + source,
        '素材内容：' + truncate(cleanText, 6000)
      ].join('\n');
      if (!$('#novelQuickPrompt').value.trim()) $('#novelQuickPrompt').value = title;
      showView('novel');
      showToast('小说素材已读取', '已加入素材库并填入提示词，点击直接创作即可。');
    }
    state.lastWritingSource = {
      target,
      title: title || '当前素材',
      text: cleanText,
      url: url || '',
      source: source || '软件内容',
      readAt: new Date().toISOString()
    };
    showWritingSourceReadSuccess(target, title, cleanText, url, source);
    return state.lastWritingSource;
  }

  function showPostBrowseActions(title, source, target) {
    const last = state.lastWritingSource;
    if (!last) return;
    showWritingSourceReadSuccess(target || last.target || state.writingSourceTarget || 'article',
      title || last.title, last.text, last.url, source || last.source);
  }

  function captureTime(item) {
    const raw = String(item && item.capturedAt || '');
    const dotNet = raw.match(/^\/Date\((\d+)(?:[+-]\d+)?\)\/$/);
    const time = dotNet ? Number(dotNet[1]) : new Date(raw).getTime();
    return Number.isFinite(time) ? time : 0;
  }

  function recentCapturedItem(items, platform) {
    const domains = {
      jinjiang: ['jjwxc.net'], fanqie: ['fanqienovel.com'], qimao: ['qimao.com'],
      zhihu: ['zhihu.com'], tencent: ['qq.com'], netease: ['163.com'],
      weibo: ['weibo.com'], bilibili: ['bilibili.com'], toutiao: ['toutiao.com']
    };
    const allowed = domains[platform] || [];
    const now = Date.now();
    return (items || []).find((item) => {
      if (!item || !item.text) return false;
      const capturedAt = captureTime(item);
      if (capturedAt && now - capturedAt > 15 * 60 * 1000) return false;
      if (!allowed.length) return true;
      return allowed.some((domain) => String(item.url || '').includes(domain));
    }) || null;
  }

  async function readWritingSource(target, silent) {
    try {
      let item = null;
      const platform = state.browseFlow.sourceId || state.lastPlatformSource || '';
      try {
        const current = await api('/api/edge-current');
        item = current && current.item;
      } catch (error) {}
      if (!item || !item.text) {
        const inbox = await api('/api/edge-inbox');
        item = recentCapturedItem(inbox.items || [], platform);
      }
      if (!item || !item.text) {
        if (platform && platform !== 'edge') {
          const native = await api('/api/read-platform?platform=' + encodeURIComponent(platform));
          if (native && native.ok && native.text) {
            item = {
              id: 'native_' + platform + '_' + Date.now(),
              title: native.title || platform,
              text: native.text,
              url: native.url || '',
              site: native.site || platform
            };
          }
        }
      }
      if (!item || !item.text) throw new Error('没有读取到软件当前页面，请先在软件中打开文章或小说');
      markEdgeSeen(item.id, item);
      applyWritingSource(target, item.title || '当前素材', item.text, item.url || '',
        item.site || hostName(item.url) || 'Edge 网页');
      return true;
    } catch (error) {
      if (!silent) showToast('读取素材失败', error.message, 'info');
      return false;
    }
  }

  function openSoftwareTextSourceDialog(target) {
    state.writingSourceTarget = target;
    const isNovel = target === 'novel';
    const options = isNovel
      ? [
          ['edge', 'Edge 当前网页'], ['jinjiang', '晋江文学城'], ['fanqie', '番茄小说'],
          ['qimao', '七猫小说'], ['zhihu', '知乎'], ['bilibili', '哔哩哔哩']
        ]
      : [
          ['edge', 'Edge 当前网页'], ['toutiao', '今日头条'], ['tencent', '腾讯新闻'],
          ['weibo', '微博'], ['netease', '网易新闻'], ['sohu', '搜狐'],
          ['baidu', '百度'], ['sogou', '搜狗'], ['zhihu', '知乎'], ['bilibili', '哔哩哔哩']
        ];
    showModal('软件文本数据源', 'SOFTWARE TEXT SOURCE',
      '<div class="software-text-source-dialog">' +
        '<p class="import-hint">先在软件或网页中打开要参考的文章、章节或讨论内容，再读取网页、剪贴板，或把正文粘贴到下方。' +
          (isNovel ? '小说素材只用于提炼题材、人物关系和叙事结构，生成结果必须原创。' : '') + '</p>' +
        '<label>素材软件<select id="softwareWritingPlatform">' +
          options.map(([id, name]) => '<option value="' + id + '">' + name + '</option>').join('') +
        '</select></label>' +
        '<button class="btn btn-secondary btn-block" type="button" id="openSoftwareTextDataSourceBtn">打开所选软件或网站</button>' +
        '<div class="software-text-read-actions">' +
          '<button type="button" id="readSoftwareTextEdgeBtn">读取 Edge 当前页</button>' +
          '<button type="button" id="readSoftwareTextClipboardBtn">读取剪贴板正文</button>' +
        '</div>' +
        '<label>素材标题<input id="softwareWritingTitle" maxlength="160" placeholder="文章名、小说名或事件标题"></label>' +
        '<label>素材链接（可选）<input id="softwareWritingUrl" type="url" placeholder="https://..."></label>' +
        '<label>读取到的正文<textarea id="softwareWritingText" placeholder="从软件复制正文后点“读取剪贴板正文”，也可以直接粘贴到这里"></textarea></label>' +
        '<div class="software-text-source-tip" id="softwareTextSourceStatus">正文至少需要 20 个字。读取成功后可预览素材，再生成并预览成品。</div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-primary" type="button" id="confirmSoftwareTextSourceBtn">确认读取并进入下一步</button>');
    const platformSelect = $('#softwareWritingPlatform');
    const setStatus = (message) => {
      const status = $('#softwareTextSourceStatus');
      if (status) status.textContent = message;
    };
    $('#openSoftwareTextDataSourceBtn').addEventListener('click', async () => {
      const platform = platformSelect.value;
      const sourceName = platformSelect.options[platformSelect.selectedIndex].textContent.trim();
      const platformInfo = PLATFORM_SECTIONS[platform];
      if (!platformInfo) {
        setStatus('这个软件暂时没有可用入口，请选择其他软件。');
        return;
      }
      state.lastPlatformSource = platform;
      scheduleWritingReturnFlow(target, sourceName, platform);
      setStatus('正在打开 ' + sourceName + '。找到内容后复制正文，再回到这里读取。');
      await openWritingDestination(target, platform, platformInfo.url);
    });
    $('#readSoftwareTextEdgeBtn').addEventListener('click', async () => {
      const platform = platformSelect.value;
      state.lastPlatformSource = platform;
      closeModal();
      const loaded = await readWritingSource(target, false);
      if (!loaded) {
        showToast('没有读取到当前网页', '请先在 Edge 或软件中打开正文，也可重新打开“软件文本数据源”并读取剪贴板。', 'info');
      }
    });
    $('#readSoftwareTextClipboardBtn').addEventListener('click', async () => {
      try {
        const text = normalizeSourceText(await navigator.clipboard.readText());
        if (text.length < 20) throw new Error('剪贴板中没有足够正文');
        $('#softwareWritingText').value = text;
        if (!$('#softwareWritingTitle').value.trim()) {
          const firstLine = text.split(/\n/).map((line) => line.trim()).find((line) => line.length >= 4);
          $('#softwareWritingTitle').value = truncate(firstLine || '软件素材', 100);
        }
        setStatus('已从剪贴板读取 ' + text.replace(/\s/g, '').length + ' 字。可以检查正文后确认读取。');
        showToast('剪贴板正文已读取', '请确认标题和正文，再进入下一步。');
      } catch (error) {
        setStatus('无法自动读取剪贴板。请在软件中选中正文并复制，或直接粘贴到下方文本框。');
        $('#softwareWritingText').focus();
      }
    });
    $('#confirmSoftwareTextSourceBtn').addEventListener('click', () => {
      const title = $('#softwareWritingTitle').value.trim() ||
        truncate($('#softwareWritingText').value.trim().split(/\n/)[0] || '软件素材', 100);
      const text = normalizeSourceText($('#softwareWritingText').value);
      const url = $('#softwareWritingUrl').value.trim();
      const sourceName = platformSelect.options[platformSelect.selectedIndex].textContent.trim();
      if (text.length < 20) {
        setStatus('正文太短，请至少提供 20 个有效文字。');
        $('#softwareWritingText').focus();
        return;
      }
      try {
        closeModal();
        applyWritingSource(target, title, text, url,
          sourceName === 'Edge 当前网页' ? 'Edge 网页 · ' + (hostName(url) || title) : sourceName);
      } catch (error) {
        showToast('读取软件文本失败', error.message, 'error');
      }
    });
  }

  function openWritingSourcePicker(target) {
    state.writingSourceTarget = target;
    const sources = [
      ['edge', 'Edge 当前页'], ['jinjiang', '晋江文学城'], ['fanqie', '番茄小说'], ['qimao', '七猫小说'],
      ['zhihu', '知乎'], ['tencent', '腾讯新闻'], ['netease', '网易新闻'],
      ['weibo', '微博'], ['bilibili', '哔哩哔哩'], ['toutiao', '今日头条'],
      ['baidu', '百度'], ['sogou', '搜狗'], ['sohu', '搜狐'],
      ['netease-music', '网易云音乐'], ['youtube', 'YouTube'], ['ted', 'TED'], ['archive', 'Internet Archive']
    ];
    showModal('选择图文或小说素材软件', 'WRITING SOURCE',
      '<div class="writing-source-picker">' +
        '<p class="import-hint">选择软件并进入内容页后返回小程序，程序会自动读取当前可访问的文字和标题。只用于提炼背景与结构，创作结果必须原创。</p>' +
        '<div class="writing-source-grid">' + sources.map(([id, name]) => {
          const platform = PLATFORM_SECTIONS[id];
          return WEB_ONLY_SOURCES.has(id) && platform
            ? '<a href="' + escapeHtml(platform.url) + '" data-direct-web="1" data-writing-source="' + id + '">' + name + '</a>'
            : '<button type="button" data-writing-source="' + id + '">' + name + '</button>';
        }).join('') + '</div>' +
        '<div class="writing-source-local"><button type="button" id="writingSourceSoftwareText">软件文本数据源</button><button type="button" id="writingSourceLocal">导入本地文件</button><button type="button" id="writingSourceRefresh">读取当前素材</button></div>' +
        '<input id="writingSourceFile" type="file" accept=".txt,.md,.markdown,.html,.htm,.json,.csv,.xml,text/plain,text/html,application/json,text/csv,text/xml" hidden>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>');
    $$('[data-writing-source]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        const id = button.dataset.writingSource;
        state.writingSourceTarget = target;
        if (id === 'edge') {
          closeModal();
          await readWritingSource(target, false);
          return;
        }
        state.pendingWritingSourceRead = target;
        scheduleWritingReturnFlow(target, button.textContent.trim(), id);
        if (button.dataset.directWeb === '1') {
          setTimeout(closeModal, 80);
          showToast('已打开 ' + button.textContent.trim() + ' 官方网页', '选择内容后返回热点工坊，程序会继续读取。', 'info');
          return;
        }
        closeModal();
        showToast('正在打开 ' + button.textContent.trim(), '进入软件后选择内容；返回小程序时会自动衔接下一步。', 'info');
        launchBrowseSource(id, button.textContent.trim(), 'writing', target);
      });
    });
    $('#writingSourceSoftwareText').addEventListener('click', () => {
      closeModal();
      openSoftwareTextSourceDialog(target);
    });
    $('#writingSourceLocal').addEventListener('click', () => $('#writingSourceFile').click());
    $('#writingSourceRefresh').addEventListener('click', async () => {
      closeModal();
      await readWritingSource(target, false);
    });
    $('#writingSourceFile').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      try {
        const source = await readWritingDataSourceFile(file);
        closeModal();
        applyWritingSource(target, source.title, source.text, source.url, '本地文件 · ' + file.name);
      } catch (error) {
        showToast('文件读取失败', error.message, 'error');
      }
    });
  }

  function renderInspiration() {
    if (!$('#inspirationAiState')) return;
    const ready = Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    $('#inspirationAiState').textContent = ready ? 'AI 已就绪 · ' + (state.config.ai.model || '') : 'AI 尚未连接';
    $('#inspirationAiState').classList.toggle('ready', ready);
    $$('#inspirationKindSwitch button').forEach((button) =>
      button.classList.toggle('active', button.dataset.outputKind === state.inspirationMode));
    $$('#inspirationOutputMode button').forEach((button) =>
      button.classList.toggle('active', button.dataset.outputMode === state.inspirationArticleType));
    $$('#inspirationNovelLength button').forEach((button) =>
      button.classList.toggle('active', button.dataset.inspirationNovelLength === state.inspirationNovelLength));
    $('#inspirationArticleTypeRow').hidden = state.inspirationMode !== 'article';
    $('#inspirationNovelLengthRow').hidden = state.inspirationMode !== 'novel';
    if ($('#inspirationArticleStyle')) $('#inspirationArticleStyle').value = state.articleStyle || 'cctv';
    if ($('#inspirationLayoutPreset')) $('#inspirationLayoutPreset').value =
      ARTICLE_TEMPLATE_PROMPTS[state.articleTemplate] ? state.articleTemplate : 'news';
    if ($('.inspiration-layout-select')) $('.inspiration-layout-select').hidden = state.inspirationMode !== 'article';
    if ($('.inspiration-style-select')) $('.inspiration-style-select').hidden = state.inspirationMode !== 'article';
    $('#researchStatus').textContent = state.researchArticles.length
      ? '已找到 ' + state.researchArticles.length + ' 条信息、' + state.researchImages.length + ' 张图片'
      : '尚未检索';
    $('#researchSources').innerHTML = state.researchArticles.length
      ? state.researchArticles.map((item) =>
          '<label class="research-source"><input type="checkbox" data-research-source="' + escapeHtml(item.id) + '"' +
          (state.selectedResearchSources.includes(item.id) ? ' checked' : '') + '><div><strong>' +
          escapeHtml(item.title) + '</strong><small><span class="region' + (item.region === '海外' ? ' overseas' : '') + '">' +
          escapeHtml(item.region || '国内') + '</span>' + escapeHtml(item.source || '公开网页') + '</small></div></label>'
        ).join('')
      : '<div class="research-empty">输入标题后点击“先搜索素材”<br>会同时检索国内和海外公开信息</div>';
    $('#researchImages').innerHTML = state.researchImages.length
      ? state.researchImages.map((image, index) =>
          '<button class="research-image-choice' + (state.selectedResearchImages.includes(index) ? ' selected' : '') +
          '" type="button" data-research-image="' + index + '"><img src="' +
          escapeHtml(image.thumbnail || image.url) + '" alt=""><span>' + escapeHtml(image.source || '免费图库') +
          '</span></button>'
        ).join('')
      : '<div class="research-empty">检索后显示可用图片<br>使用前请查看授权</div>';
  }

  function researchQueryText() {
    return ($('#inspirationTitle').value.trim() + ' ' + $('#inspirationPrompt').value.trim()).trim();
  }

  async function runResearch(showResult) {
    const query = researchQueryText();
    if (!query) {
      showToast('请先输入标题或创作提示词', null, 'info');
      $('#inspirationTitle').focus();
      return false;
    }
    showLoading('正在检索国内外资料', '正在搜索公开报道、背景信息和免费图片素材。');
    try {
      const result = await api('/api/research', {
        method: 'POST',
        body: JSON.stringify({ query })
      });
      state.researchArticles = result.articles || [];
      state.researchImages = result.images || [];
      state.selectedResearchSources = state.researchArticles.slice(0, 8).map((item) => item.id);
      state.selectedResearchImages = state.researchImages.slice(0, 4).map((item, index) => index);
      renderInspiration();
      if (showResult) showToast(result.articles.length ? '资料检索完成' : '暂未检索到外部资料',
        result.message || '可以继续根据你的提示词原创写作。', 'info');
      return true;
    } catch (error) {
      showToast('联网检索失败', error.message, 'error');
      return false;
    } finally {
      hideLoading();
    }
  }

  function materializeResearchSources(items) {
    const selected = items.filter((item) => state.selectedResearchSources.includes(item.id));
    const ids = [];
    selected.forEach((item) => {
      const id = 'research_' + item.id;
      ids.push(id);
      if (state.news.some((entry) => entry.id === id)) return;
      state.imported.unshift({
        id,
        title: item.title,
        summary: item.summary || '联网检索到的公开资料。',
        detailText: item.summary || '',
        url: item.url,
        image: item.image || '',
        imageOriginal: item.image || '',
        gallery: item.image ? [item.image] : [],
        source: item.source || item.region || '公开网页',
        section: 'general',
        sectionName: '参考资料',
        publishedAt: item.publishedAt || new Date().toISOString(),
        publishedLabel: item.region || '联网检索',
        score: 90,
        rank: 0,
        tag: '研究素材',
        imported: true
      });
    });
    saveJson(KEYS.imported, state.imported.slice(0, 100));
    const remote = state.news.filter((item) => !item.imported);
    state.news = mergeImported(remote);
    return ids;
  }

  async function createFromInspiration() {
    if (state.inspirationBusy) return;
    const aiReady = state.codexReady ||
      Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    if (!aiReady) {
      showToast('主题创作需要 AI', '请先连接本机 Codex，或在设置中完成 AI 连接。', 'info');
      openSettings();
      return;
    }
    let titleHint = $('#inspirationTitle').value.trim();
    let prompt = $('#inspirationPrompt').value.trim();
    if (!titleHint && !prompt) {
      const hot = leadItem();
      titleHint = hot ? truncate(hot.title, 36) : '今日值得关注的公共议题';
      prompt = hot
        ? '围绕“' + hot.title + '”写一篇通俗的深度图文，先讲清公开事实，再分析背景、现实影响、争议和后续观察。证据来自公开报道，不写空话，不编造数字和引语。'
        : '写一篇通俗的深度图文，选择当前值得关注的公共议题，讲清事实、背景、现实影响和争议，不写空话。';
      $('#inspirationTitle').value = titleHint;
      $('#inspirationPrompt').value = prompt;
      showToast('已自动使用当前主题', '可以继续生成，也可以先修改标题或提示词。', 'info');
    }
    state.inspirationBusy = true;
    $('#researchOnlyBtn').disabled = true;
    $('#researchCreateBtn').disabled = true;
    $('#researchCreateBtn').textContent = '正在联网研究…';
    if (!state.researchArticles.length) await runResearch(false);
    const selected = state.researchArticles.filter((item) => state.selectedResearchSources.includes(item.id));
    if (!selected.length && !prompt) {
      showToast('请选择至少一条资料，或填写自己的创作提示词', null, 'info');
      return;
    }
    const mode = state.inspirationMode;
    const articleType = state.inspirationArticleType || 'feature';
    const novelLength = state.inspirationNovelLength || 'short';
    const generationInstruction = mode === 'article'
      ? ARTICLE_MODE_PROMPTS[articleType] + '\n' +
        (ARTICLE_STYLE_PROMPTS[state.articleStyle] || ARTICLE_STYLE_PROMPTS.cctv) + '\n' +
        articleContentModePrompt(state.articleContentMode) + '\n' +
        nextArticleVariationPrompt()
      : novelLength === 'long'
        ? '创作一部长篇小说，先输出书名、简介、人物档案、故事提纲和不少于8章的目录，再写第一章约2500字。'
        : novelLength === 'medium'
          ? '创作一部中篇小说，先输出书名、简介、人物档案、故事提纲和8-15章目录，再写第一章约2000字。'
          : '创作一篇结构完整的短篇小说，正文约2500-4500字，有完整人物、冲突、转折和结局。';
    const researchText = selected.map((item, index) =>
      '资料' + (index + 1) + '（' + (item.region || '公开') + '）：' + item.title +
      '\n来源：' + (item.source || '公开网页') + '\n摘要：' + (item.summary || '') +
      '\n链接：' + (item.url || '')
    ).join('\n\n');
    const taskId = beginGeneration(mode === 'article' ? 'article' : 'novel', titleHint || truncate(prompt, 36),
      mode === 'article' ? '正在联网研究并撰写图文' : '正在构建原创小说');
    showLoading(mode === 'article' ? '正在研究并撰写' + articleModeLabel(articleType) : '正在构建' + novelLengthLabel(novelLength),
      '正在筛选国内与海外资料并重新组织为原创内容。');
    try {
      const result = await requestStandaloneWriting([
        '你是严谨的原创中文作者。只使用给定资料中的可核验事实，不编造；不使用原句、原人物名或独特设定。',
        generationInstruction,
        '创作标题或主题：' + titleHint,
        '用户创作要求：' + (prompt || '无额外要求'),
        '资料只作为事实线索和背景。文章写作必须重新组织语言；小说创作必须创造全新人物、设定和情节，不得抄袭或高度模仿。',
        '第一行输出“标题：……”，之后输出正文；不要解释创作过程。',
        '公开资料：\n' + researchText
      ].join('\n\n'), mode === 'article' ? 'article' : novelLength, 'auto');
      if (!result || !result.text) throw new Error('AI 没有返回内容');
      let bodyText = result.text.trim();
      let parsedTitle = titleHint || '主题创作';
      const titleMatch = bodyText.match(/^标题[：:]\s*(.+)$/m);
      if (titleMatch) {
        parsedTitle = titleMatch[1].trim();
        bodyText = bodyText.replace(/^标题[：:].+\r?\n?/m, '');
      }
      bodyText = bodyText.replace(/^#+\s+/, '');
      const sourceIds = materializeResearchSources(state.researchArticles);
      const selectedImages = state.selectedResearchImages.map((index) => state.researchImages[index]).filter(Boolean);
      const figures = selectedImages.slice(0, 3).map((image) =>
        '<figure><img src="' + escapeHtml(image.url) + '" alt="' + escapeHtml(image.title || '') +
        '"><figcaption>图片素材：' + escapeHtml(image.source || '免费图库') + ' · ' +
        escapeHtml(image.creator || '') + ' · ' + escapeHtml(image.license || '请查看授权') + '</figcaption></figure>'
      ).join('');
      if (mode === 'article') {
        state.article = {
          id: 'article_' + Date.now(),
          title: truncate(parsedTitle, 30),
          html: '<p class="article-publish-meta"><span class="article-badge ' +
            (articleType === 'feature' || articleType === 'topic' ? 'feature' : '') + '">' +
            escapeHtml(articleModeLabel(articleType)) + ' · 联网原创</span>根据公开资料重新组织 · 请人工核验</p>' +
            novelTextToHtml(bodyText) + figures +
            '<p><small>参考来源：' + selected.map((item) => escapeHtml(item.source || '公开网页')).join('、') + '</small></p>',
          cover: selectedImages[0] ? selectedImages[0].url : '',
          sourceIds,
          tags: ['主题创作', '联网研究', articleModeLabel(articleType)],
          style: state.articleStyle,
            contentMode: state.articleContentMode,
          articleMode: articleType,
          articleScope: 'single',
          status: 'editing',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        saveJson(KEYS.article, state.article);
        renderArticle();
        showView('article');
      } else {
        state.novel = {
          id: 'novel_' + Date.now(),
          title: parsedTitle,
          html: novelTextToHtml(bodyText) + figures,
          lengthType: novelLength,
          genre: $('#novelGenre') ? $('#novelGenre').value : '现实题材',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        saveJson(KEYS.novel, state.novel);
        state.novelLength = novelLength;
        renderNovel();
        showView('novel');
      }
      if (mode === 'article' && state.article) {
        state.article.template = state.articleTemplate;
        state.article.html = applyArticleTemplateHtml(state.article.html, state.articleTemplate);
        saveJson(KEYS.article, state.article);
      }
      finishGeneration(taskId, mode === 'article' ? 'article' : 'novel',
        mode === 'article' ? state.article : state.novel);
      showView(mode === 'article' ? 'article' : 'novel');
      showToast('原创内容已生成',
        (mode === 'article' ? articleModeLabel(articleType) : novelLengthLabel(novelLength)) +
        '已进入编辑器，并附上检索来源，请继续修改和核验。');
    } catch (error) {
      showToast('创作失败', error.message, 'error');
    } finally {
      state.inspirationBusy = false;
      $('#researchOnlyBtn').disabled = false;
      $('#researchCreateBtn').disabled = false;
      $('#researchCreateBtn').textContent = '联网研究并创作';
      hideLoading();
    }
  }

  function renderPlatformBar() {
    const bar = $('#sectionPlatformBar');
    if (!bar) return;
    const platform = PLATFORM_SECTIONS[state.activeSection];
    bar.hidden = !platform;
    if (!platform) return;
    $('#sectionPlatformTitle').textContent = platform.name + ' · 实时内容';
    $('#sectionPlatformHint').textContent = state.sectionFallback
      ? platform.hint + '；专属内容更新中，先显示全网实时热点'
      : platform.hint + '；当前显示 ' + visibleNews().length + ' 条可选题';
    $('#sectionOpenSourceBtn').dataset.sourceUrl = platform.url;
    const clientId = state.activeSection === 'tencent' ? 'qqlive' : '';
    const clientButton = $('#sectionOpenClientBtn');
    clientButton.hidden = !clientId;
    if (clientId) {
      clientButton.setAttribute('role', 'button');
      clientButton.removeAttribute('href');
      clientButton.textContent = '打开腾讯视频客户端';
    }
  }

  async function openPlatformContent(sectionId) {
    const platform = PLATFORM_SECTIONS[sectionId];
    if (!platform) return;
    if (WEB_ONLY_SOURCES.has(sectionId)) {
      openWebDestination(platform.url);
      return;
    }
    const now = Date.now();
    if (now - (state.platformOpenGuard[sectionId] || 0) < 1200) return;
    state.platformOpenGuard[sectionId] = now;
    try {
      const result = await api('/api/open-platform', {
        method: 'POST',
        body: JSON.stringify({ platform: sectionId, url: platform.url })
      });
      const method = String(result.method || '');
      const desktop = method.startsWith('desktop') || method === 'existing-window';
      showToast(method === 'existing-window' ? '已切换到已打开的软件' :
        method === 'web-fallback' ? '客户端未显示，已改用网页' :
          desktop ? '已打开对应软件' : '已打开官方网页',
      desktop ? '优先复用现有窗口；返回小程序后仍保留当前板块内容。' :
        method === 'web-fallback' ? '已尝试启动客户端但未检测到可见窗口，已用 Edge 打开官方页面。' :
          '当前电脑未检测到对应客户端，已使用 Edge 打开。', desktop ? 'success' : 'info');
    } catch (error) {
      showToast('打开平台失败', error.message, 'error');
    }
  }

  function browseSourceUrl(sourceId) {
    const platform = PLATFORM_SECTIONS[sourceId];
    return platform && platform.url || '';
  }

  function openWebDestination(url) {
    if (!/^https?:\/\//i.test(url)) return false;
    window.location.assign(url);
    return false;
  }

  async function launchBrowseSource(sourceId, sourceName, kind, target) {
    state.lastPlatformSource = sourceId || '';
    state.platformOpenGuard[sourceId] = 0;
    const url = browseSourceUrl(sourceId);
    if (WEB_ONLY_SOURCES.has(sourceId) && url) {
      openWebDestination(url);
      showToast('已打开 ' + sourceName + ' 官方网页', '在网页中选择内容后返回热点工坊，程序会继续读取。', 'info');
      return;
    }
    try {
      if (sourceId === 'netease-music') {
        await openNeteaseWatch();
        return;
      }
      if (!url) throw new Error('没有配置这个素材入口');
      const result = await api('/api/open-platform', {
        method: 'POST',
        body: JSON.stringify({ platform: sourceId, url })
      });
      const method = String(result && result.method || '');
      if (method === 'web' || method === 'web-fallback') {
        showToast('已切换到官方网页', sourceName + ' 客户端未显示窗口，正在用网页继续打开。', 'info');
        setTimeout(() => {
          if (url) window.location.assign(url);
        }, 700);
      }
    } catch (error) {
      const flow = state.browseFlow;
      if (flow && flow.sourceId === sourceId && flow.kind === kind && flow.target === target) {
        flow.active = false;
        flow.resuming = false;
        clearTimeout(flow.fallbackTimer);
      }
      if (url && /^https?:\/\//i.test(url)) {
        showToast('客户端未能打开，正在改用官方网页', sourceName + ' · ' + error.message, 'info');
        setTimeout(() => window.location.assign(url), 650);
      } else {
        showToast('打开 ' + (sourceName || '素材软件') + ' 失败', error.message, 'error');
      }
    }
  }

  function armBrowseFallback(flow) {
    persistBrowseFlow(flow);
    clearTimeout(flow.fallbackTimer);
    flow.fallbackTimer = setTimeout(() => {
      if (state.browseFlow !== flow || !flow.active || flow.resuming || flow.handled) return;
      if (!document.hasFocus() || document.hidden) return;
      resumeBrowseFlow(true);
    }, 18000);
  }

  function resetBrowseFlow(flow) {
    if (!flow) return;
    clearTimeout(flow.fallbackTimer);
    flow.active = false;
    flow.resuming = false;
    flow.handled = true;
    try { localStorage.removeItem(KEYS.pendingBrowse); } catch (error) {}
  }

  function persistBrowseFlow(flow) {
    if (!flow || !flow.active) return;
    saveJson(KEYS.pendingBrowse, {
      active: true,
      kind: flow.kind,
      sourceId: flow.sourceId,
      sourceName: flow.sourceName,
      target: flow.target,
      startedAt: flow.startedAt,
      resuming: false,
      handled: false
    });
  }

  function restoreBrowseFlow() {
    const saved = loadJson(KEYS.pendingBrowse, null);
    if (!saved || !saved.active || Date.now() - Number(saved.startedAt || 0) > 2 * 60 * 1000) {
      try { localStorage.removeItem(KEYS.pendingBrowse); } catch (error) {}
      return;
    }
    Object.assign(state.browseFlow, saved, { resuming: false, handled: false });
    state.pendingVideoSource = saved.kind === 'video' ? saved.sourceName : '';
    state.pendingWritingSourceRead = saved.kind === 'writing' ? saved.target : '';
  }

  function showBrowseReadFallback(target, sourceName) {
    showModal('切回后暂未读到素材内容', 'READ AGAIN',
      '<p class="topic-summary">已从 ' + escapeHtml(sourceName || '素材软件') +
      ' 返回。有的客户端不向网页接口提供正文，此时可重新读取，或先导入从客户端导出的文件。</p>' +
      '<div class="modal-note"><p>不会重复弹出确认窗口；这一次选择后会直接进入对应编辑器。</p></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>稍后处理</button>' +
      '<button class="btn btn-secondary" type="button" id="browseChangeSource">更换素材软件</button>' +
      '<button class="btn btn-secondary" type="button" id="browseImportText">导入本地素材</button>' +
      '<button class="btn btn-primary" type="button" id="browseReadAgain">重新读取当前内容</button>');
    $('#browseChangeSource').addEventListener('click', () => {
      closeModal();
      openWritingSourcePicker(target);
    });
    $('#browseImportText').addEventListener('click', () => {
      closeModal();
      openWritingSourcePicker(target);
      setTimeout(() => {
        const input = $('#writingSourceFile');
        if (input) input.click();
      }, 160);
    });
    $('#browseReadAgain').addEventListener('click', async () => {
      closeModal();
      await readWritingSource(target, false);
    });
  }

  async function resumeBrowseFlow(fromFallback) {
    const flow = state.browseFlow;
    if (!flow.active || flow.resuming || flow.handled) return;
    if (!document.hasFocus() && !fromFallback) return;
    flow.resuming = true;
    clearTimeout(flow.fallbackTimer);
    await new Promise((resolve) => setTimeout(resolve, flow.kind === 'writing' ? 1200 : 900));
    try {
      if (flow.kind === 'writing') {
        let read = false;
        for (let attempt = 0; attempt < 3 && !read; attempt += 1) {
          read = await readWritingSource(flow.target, true);
          if (!read) await new Promise((resolve) => setTimeout(resolve, 850));
        }
        if (!read) showBrowseReadFallback(flow.target, flow.sourceName);
      } else {
        await readCurrentMediaWindow();
      }
    } finally {
      resetBrowseFlow(flow);
    }
  }

  function triggerBrowseResume(delay) {
    const flow = state.browseFlow;
    if (!flow.active || flow.resuming || flow.handled) return;
    clearTimeout(flow.resumeTimer);
    flow.resumeTimer = setTimeout(() => {
      if (document.hasFocus() && !document.hidden) resumeBrowseFlow(false);
    }, Math.max(250, delay || 700));
  }

  function selectSection(sectionId, sourceUrl) {
    state.activeSection = sectionId;
    state.heroIndex = 0;
    state.search = '';
    if ($('#searchInput')) $('#searchInput').value = '';
    if ($('#headerSearch')) $('#headerSearch').value = '';
    state.limit = 18;
    renderFilters();
    renderSectionRail();
    renderNews();
    renderHero();
    showView('home');
    const exactCount = state.news.filter((item) => item.section === sectionId).length;
    if (!exactCount && state.mode !== 'loading') {
      showToast('正在读取最新内容', ((PLATFORM_SECTIONS[sectionId] || {}).name || '当前板块') + ' 正在更新。', 'info');
      fetchNews(true);
    }
    autoGrabVisibleImages();
  }

  function renderNews() {
    const grid = $('#newsGrid');
    let items = visibleNews();
    if (!items.length && state.news.length && state.activeSection === 'hot') {
      items = state.news.slice().sort((a, b) => (b.score || 0) - (a.score || 0));
      state.sectionFallback = true;
    }
    if (!items.length && state.news.length && !['all', 'hot', 'imported'].includes(state.activeSection)) {
      items = state.news.slice().sort((a, b) => (b.score || 0) - (a.score || 0));
      state.sectionFallback = true;
    }
    renderPlatformBar();
    if (!items.length) {
      $('#feedResultCount').textContent = '0 条内容';
      const platform = PLATFORM_SECTIONS[state.activeSection];
      grid.innerHTML = '<div class="empty-state"><span>' + icon(platform ? 'refresh' : 'wand') + '</span><h3>' +
        (platform ? '正在等待最新内容' : '没有匹配的资讯') + '</h3><p>' +
        (platform ? '可以刷新当前平台，或先打开原站浏览。' : '换个频道或清空搜索试试。') + '</p>' +
        '<button class="btn btn-secondary" type="button" data-refresh>刷新最新</button></div>';
      $('#moreBtn').hidden = true;
      return;
    }
    $('#feedResultCount').textContent = state.sectionFallback
      ? '该板块更新中 · 先看 ' + items.length + ' 条全网热点'
      : items.length + ' 条内容';
    $$('#feedSortControls [data-feed-sort]').forEach((button) =>
      button.classList.toggle('active', button.dataset.feedSort === state.feedSort));
    const shown = items.slice(0, state.limit);
    grid.innerHTML = shown.map((item) => {
      const selected = state.selected.includes(item.id);
      return '<article class="news-card' + (selected ? ' selected' : '') + '" data-news-id="' + escapeHtml(item.id) + '">' +
        '<div class="news-copy">' +
          '<div class="news-meta"><span>' + escapeHtml(item.sectionName) + '</span><span>' + escapeHtml(item.publishedLabel) +
          '</span>' + (item.demo ? '<span class="demo">示例</span>' : '') +
          (item.imported ? '<span class="demo imported-tag">已导入</span>' : '') +
          ((item.gallery || []).length > 0 ? '<span class="demo imported-tag">' + item.gallery.length + ' 图</span>' : '') + '</div>' +
          '<h3>' + escapeHtml(item.title) + '</h3>' +
          '<p>' + escapeHtml(item.summary) + '</p>' +
          '<div class="news-read-meta"><span>' + escapeHtml(item.source) + '</span><span>' + Math.round(item.score || 70) +
          ' 热度</span><button class="discuss-btn" type="button" data-quick-video="' + escapeHtml(item.id) + '">原片剪辑</button>' +
          '<button class="discuss-btn" type="button" data-open-topic="' + escapeHtml(item.id) + '">看讨论</button></div>' +
        '</div>' +
        '<div class="news-photo' + (item.image ? '' : ' no-image') + '">' +
          (item.image ? '<img src="' + escapeHtml(item.image) + '" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display=\'none\';this.parentElement.classList.add(\'no-image\')">' : '') +
          '<button class="news-select" type="button" data-select-only="' + escapeHtml(item.id) + '" aria-label="选择素材">' + icon('check') + '</button>' +
        '</div>' +
      '</article>';
    }).join('');
    $('#moreBtn').hidden = items.length <= state.limit;
  }

  async function autoGrabVisibleImages() {
    const targets = visibleNews()
      .filter((item) => !item.demo && !item.imageOriginal && !item._imageGrabTried && item.url && /^https?:\/\//i.test(item.url))
      .slice(0, 12);
    if (!targets.length) return;
    targets.forEach((item) => { item._imageGrabTried = true; });
    let cursor = 0;
    let changed = false;
    async function worker() {
      while (cursor < targets.length) {
        const item = targets[cursor++];
        try {
          const result = await api('/api/extract?url=' + encodeURIComponent(item.url));
          if (result.ok && (result.image || (result.images || []).length)) {
            item.imageOriginal = result.image || result.images[0] || '';
            item.image = item.imageOriginal;
            item.gallery = unique((item.gallery || []).concat(result.images || []).concat(result.image ? [result.image] : []));
            if (result.text && !item.detailText) item.detailText = result.text;
            changed = true;
          }
        } catch (error) {
          // Keep a text-only card when the publisher blocks server-side reading.
        }
      }
    }
    await Promise.all(Array.from({ length: 3 }, worker));
    if (changed) {
      renderNews();
      renderHero();
      renderSectionRail();
    }
  }

  function renderSelection() {
    const count = selectedItems().length;
    $('#selectionSummary').innerHTML = '<b>' + count + '</b><span>条已选</span><button type="button" id="autoSelectBtn">智能推荐</button>';
    const button = $('#autoSelectBtn');
    if (button) button.addEventListener('click', () => autoRecommend(true));
  }

  function renderHotList() {
    const items = state.news.slice().sort((a, b) => (b.score || 0) - (a.score || 0)).slice(0, 8);
    $('#hotList').innerHTML = items.map((item, index) =>
      '<div class="hot-item" data-hot-id="' + escapeHtml(item.id) + '"><span>' + (index + 1) + '</span><div><strong>' +
      escapeHtml(item.title) + '</strong><small>' + escapeHtml(item.source) + ' · ' + escapeHtml(item.publishedLabel) +
      (item.imported ? '<span class="imported-tag">已导入</span>' : '') + '</small><span class="hot-discuss">打开讨论与创作</span></div></div>'
    ).join('');
  }

  function updateCounts() {
    if ($('#draftCountLabel')) {
      $('#draftCountLabel').textContent = state.generating.filter((item) => item.status !== 'failed').length +
        ' 进行中 · ' + state.completed.length + ' 已完成 · ' + state.drafts.length + ' 草稿';
    }
  }

  function workTypeLabel(type) {
    return type === 'novel' ? '原创小说' : type === 'video' ? '短视频' : '图文文章';
  }

  function buildWorkArtifact(type, payload, taskId) {
    const object = payload || {};
    const title = object.title || (type === 'novel' ? '未命名原创小说' : type === 'video' ? '未命名短视频' : '未命名图文');
    const summary = type === 'novel'
      ? truncate(stripHtml(object.html || ''), 120)
      : type === 'video'
        ? truncate(state.videoBreakdown && state.videoBreakdown.summary || state.videoEpisodeTitle || '', 120)
        : truncate(stripHtml(object.html || ''), 120);
    const payloadCopy = type === 'video'
      ? Object.assign({}, object)
      : JSON.parse(JSON.stringify(object || {}));
    return {
      id: 'work_' + (taskId || Date.now()) + '_' + Math.random().toString(36).slice(2, 7),
      type,
      title,
      summary,
      cover: object.cover || (type === 'novel' && object.visuals && object.visuals[0] && object.visuals[0].url) || '',
      payload: payloadCopy,
      status: 'waiting',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  function beginGeneration(type, title, detail) {
    const id = 'task_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    state.generating.unshift({
      id,
      type,
      title: title || (type === 'novel' ? '正在生成原创小说' : type === 'video' ? '正在剪辑短视频' : '正在生成图文'),
      detail: detail || '正在读取素材并生成内容',
      status: 'running',
      startedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    state.generating = state.generating.slice(0, 30);
    saveJson(KEYS.generating, state.generating);
    renderDrafts();
    return id;
  }

  function failGeneration(taskId, message) {
    const task = state.generating.find((item) => item.id === taskId);
    if (!task) return;
    task.status = 'failed';
    task.detail = truncate(message || '生成失败，可重新发起', 180);
    task.endedAt = new Date().toISOString();
    task.updatedAt = new Date().toISOString();
    saveJson(KEYS.generating, state.generating);
    renderDrafts();
  }

  function generationTimeoutMs(task) {
    if (task && task.type === 'video') return 25 * 60 * 1000;
    if (task && task.type === 'novel') return 8 * 60 * 1000;
    return 4 * 60 * 1000;
  }

  function expireGenerationTasks(allRunning, refresh) {
    const now = Date.now();
    let changed = false;
    state.generating.forEach((task) => {
      if (!task || task.status !== 'running') return;
      const startedAt = new Date(task.startedAt || task.createdAt || 0).getTime();
      const age = Number.isFinite(startedAt) ? now - startedAt : Number.MAX_SAFE_INTEGER;
      if (!allRunning && age <= generationTimeoutMs(task)) return;
      task.status = 'failed';
      task.detail = allRunning
        ? '应用已重新启动，上一轮任务已中断，请重新生成'
        : '生成超过时限，已自动停止。请缩短篇幅或重新生成';
      task.endedAt = new Date().toISOString();
      task.updatedAt = task.endedAt;
      changed = true;
    });
    if (changed) {
      saveJson(KEYS.generating, state.generating);
      if (refresh) renderDrafts();
    }
    return changed;
  }

  function saveWorkToLibrary(artifact, destination) {
    const item = Object.assign({}, artifact, {
      status: destination === 'completed' ? 'completed' : 'draft',
      savedAt: destination === 'completed' ? new Date().toISOString() : '',
      updatedAt: new Date().toISOString()
    });
    if (destination === 'completed') {
      state.completed = [item].concat(state.completed.filter((entry) =>
        entry.id !== item.id && !(entry.type === item.type && entry.title === item.title)));
      state.completed = state.completed.slice(0, 100);
      saveJson(KEYS.completed, state.completed);
    } else {
      state.drafts = [item].concat(state.drafts.filter((entry) =>
        entry.id !== item.id && !(entry.type === item.type && entry.title === item.title)));
      state.drafts = state.drafts.slice(0, 100);
      saveJson(KEYS.drafts, state.drafts);
    }
    renderDrafts();
  }

  function sanitizeArtifactHtml(html) {
    const box = document.createElement('div');
    box.innerHTML = html || '';
    box.querySelectorAll('script,style,iframe,object,embed,link,meta').forEach((node) => node.remove());
    box.querySelectorAll('*').forEach((node) => {
      Array.from(node.attributes).forEach((attribute) => {
        if (/^on/i.test(attribute.name) || /^javascript:/i.test(attribute.value || ''))
          node.removeAttribute(attribute.name);
      });
    });
    return box.innerHTML;
  }

  function buildArtifactPreview(artifact) {
    const payload = artifact.payload || {};
    if (artifact.type === 'video') {
      let videoUrl = payload.videoUrl || '';
      if (!videoUrl && payload.videoBlob) videoUrl = URL.createObjectURL(payload.videoBlob);
      return videoUrl
        ? '<div class="artifact-video-preview"><video controls playsinline preload="metadata" src="' +
          escapeHtml(videoUrl) + '"></video></div>'
        : '<div class="artifact-preview-empty">视频文件未保留，只能查看标题和剪辑信息。</div>';
    }
    const html = sanitizeArtifactHtml(payload.html || '');
    const cover = payload.cover || payload.image || '';
    const summary = artifact.type === 'novel'
      ? (payload.synopsis || payload.summary || '')
      : (payload.summary || '');
    return '<article class="artifact-text-preview">' +
      (cover ? '<img class="artifact-preview-cover" src="' + escapeHtml(cover) + '" alt="">' : '') +
      '<h1>' + escapeHtml(payload.title || artifact.title || '未命名成品') + '</h1>' +
      (summary ? '<p class="artifact-preview-summary">' + escapeHtml(summary) + '</p>' : '') +
      '<div class="artifact-preview-content">' + html + '</div></article>';
  }

  function previewCurrentWork(type) {
    if (type === 'novel') {
      persistNovel();
      if (!state.novel || !stripHtml(state.novel.html || '').trim()) {
        showToast('还没有小说成品', '请先读取素材并点击“生成原创小说”。', 'info');
        return;
      }
    } else {
      persistArticle();
      if (!state.article || !stripHtml(state.article.html || '').trim()) {
        showToast('还没有图文成品', '请先读取素材并生成微新闻或完整图文。', 'info');
        return;
      }
    }
    const artifact = buildWorkArtifact(type, type === 'novel' ? state.novel : state.article,
      'preview_current_' + Date.now());
    showModal(type === 'novel' ? '小说成品预览' : '图文成品预览', 'FINAL PREVIEW',
      '<div class="artifact-preview-panel artifact-preview-page">' +
        '<div class="artifact-preview-head"><strong>发布前预览</strong><span>' +
          escapeHtml(workTypeLabel(type)) + ' · 图片、小标题与正文排版</span></div>' +
        '<div class="artifact-preview-body">' + buildArtifactPreview(artifact) + '</div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>返回编辑</button>' +
      '<button class="btn btn-secondary" type="button" id="previewCurrentToDraft">放入草稿箱</button>' +
      '<button class="btn btn-primary" type="button" id="previewCurrentToCompleted">保存成品</button>');
    $('#previewCurrentToDraft').addEventListener('click', () => {
      saveWorkToLibrary(artifact, 'draft');
      closeModal();
      showToast('已放入草稿箱');
    });
    $('#previewCurrentToCompleted').addEventListener('click', () => {
      saveWorkToLibrary(artifact, 'completed');
      closeModal();
      showToast('成品已保存', '已放入作品中心的“已完成”。');
    });
  }

  function offerSaveDecision(taskId, artifact) {
    state.generating = state.generating.filter((item) => item.id !== taskId);
    saveJson(KEYS.generating, state.generating);
    renderDrafts();
    showModal('成品已经生成', 'SAVE OR DRAFT',
      '<div class="post-browse-source"><strong>' + escapeHtml(artifact.title) + '</strong><small>' +
      escapeHtml(workTypeLabel(artifact.type)) + ' · 请选择成品去向</small></div>' +
      '<div class="publish-step"><span>01</span><div><strong>保存成品</strong><p>进入“已完成”，以后可以从作品中心直接打开、下载或继续发布。</p></div></div>' +
      '<div class="publish-step"><span>02</span><div><strong>暂不保存</strong><p>自动放入草稿箱；草稿可以随时打开、继续编辑或删除。</p></div></div>' +
      '<div class="artifact-preview-panel" id="artifactPreviewPanel" hidden>' +
        '<div class="artifact-preview-head"><strong>成品预览</strong><span>' +
        escapeHtml(workTypeLabel(artifact.type)) + '</span></div>' +
        '<div class="artifact-preview-body">' + buildArtifactPreview(artifact) + '</div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" id="previewGeneratedArtifact">预览成品</button>' +
      (artifact.type === 'article'
        ? '<button class="btn btn-secondary" type="button" id="generateImagesFromPreviewBtn">一键生成配图</button>'
        : '') +
      '<button class="btn btn-secondary" type="button" id="saveWorkAsDraft">暂不保存 · 放草稿箱</button>' +
      '<button class="btn btn-primary" type="button" id="saveWorkCompleted">保存成品</button>');
    $('#previewGeneratedArtifact').addEventListener('click', () => {
      const panel = $('#artifactPreviewPanel');
      panel.hidden = !panel.hidden;
      $('#previewGeneratedArtifact').textContent = panel.hidden ? '预览成品' : '收起预览';
      if (!panel.hidden) panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
    if ($('#generateImagesFromPreviewBtn')) {
      $('#generateImagesFromPreviewBtn').addEventListener('click', async () => {
        state.article = JSON.parse(JSON.stringify(artifact.payload || {}));
        state.articleMode = state.article.articleMode || state.articleMode;
        state.articleContentMode = state.article.contentMode || state.articleContentMode || 'fact';
        state.articleTemplate = state.article.template || state.articleTemplate || 'news';
        saveJson(KEYS.article, state.article);
        closeModal();
        renderArticle();
        showView('article');
        await generateArticleImagesOneClick();
      });
    }
    $('#saveWorkCompleted').addEventListener('click', () => {
      saveWorkToLibrary(artifact, 'completed');
      closeModal();
      showToast('成品已保存', '已放入首页作品中心的“已完成”。');
      if (artifact.type === 'video' && state.videoBlob) setTimeout(downloadVideo, 220);
    });
    $('#saveWorkAsDraft').addEventListener('click', () => {
      saveWorkToLibrary(artifact, 'draft');
      closeModal();
      showToast('已放入草稿箱', '可在作品中心继续编辑或删除。');
    });
  }

  function finishGeneration(taskId, type, payload) {
    const artifact = buildWorkArtifact(type, payload, taskId);
    offerSaveDecision(taskId, artifact);
    return artifact;
  }

  function workItemsForFilter(filter) {
    let items = filter === 'running' ? state.generating.slice()
      : filter === 'completed' ? state.completed.slice()
        : filter === 'drafts' ? state.drafts.slice()
          : state.generating.filter((item) => item.status !== 'failed').concat(state.completed, state.drafts);
    const timestamp = (item) => {
      const value = new Date(item.updatedAt || item.savedAt || item.createdAt || 0).getTime();
      return Number.isFinite(value) ? value : 0;
    };
    items.sort((first, second) => {
      if (state.workSort === 'oldest') return timestamp(first) - timestamp(second);
      if (state.workSort === 'name') return String(first.title || '').localeCompare(String(second.title || ''), 'zh-CN');
      if (state.workSort === 'type') return String(first.type || '').localeCompare(String(second.type || '')) ||
        timestamp(second) - timestamp(first);
      return timestamp(second) - timestamp(first);
    });
    return items;
  }

  function formatWorkElapsed(milliseconds) {
    const total = Math.max(0, Math.floor(Number(milliseconds || 0) / 1000));
    const minutes = Math.floor(total / 60);
    const seconds = total % 60;
    return String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
  }

  function tickWorkElapsed() {
    expireGenerationTasks(false, true);
    $$('[data-work-elapsed]').forEach((node) => {
      const start = new Date(node.dataset.workElapsed).getTime();
      const end = node.dataset.workEnded ? new Date(node.dataset.workEnded).getTime() : Date.now();
      if (Number.isFinite(start) && Number.isFinite(end)) node.textContent = formatWorkElapsed(end - start);
    });
  }

  function workCardHtml(item, source) {
    const running = source === 'generating';
    const statusLabel = running
      ? (item.status === 'failed' ? '生成未完成' : '进行中')
      : source === 'completed' ? '已完成' : '草稿';
    const statusClass = running ? 'running' : source === 'completed' ? 'completed' : 'draft';
    const typeLabel = workTypeLabel(item.type);
    const cover = item.cover ? '<img src="' + escapeHtml(item.cover) + '" alt="">' :
      running ? '<span class="draft-spinner"></span>' : escapeHtml(typeLabel.slice(0, 1));
    const elapsed = running
      ? ' · 已等待 <b class="work-elapsed" data-work-elapsed="' + escapeHtml(item.startedAt || item.createdAt || new Date().toISOString()) +
        '"' + (item.endedAt ? ' data-work-ended="' + escapeHtml(item.endedAt) + '"' : '') + '>' +
        formatWorkElapsed((item.endedAt ? new Date(item.endedAt) : new Date()) -
          new Date(item.startedAt || item.createdAt || Date.now())) + '</b>'
      : '';
    return '<div class="draft-card ' + statusClass + '"' +
      (running ? '' : ' data-work-source="' + escapeHtml(source) + '" data-work-id="' + escapeHtml(item.id) + '"') + '>' +
      '<span class="draft-cover">' + cover + '</span>' +
      '<div class="draft-copy"><strong>' + escapeHtml(item.title || '未命名成品') + '</strong>' +
      '<span class="draft-status ' + statusClass + '">' + escapeHtml(typeLabel + ' · ' + statusLabel) + elapsed + '</span>' +
      '<small>' + escapeHtml(running ? (item.detail || '正在生成') :
        new Date(item.updatedAt || item.createdAt || Date.now()).toLocaleString('zh-CN',
          { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })) + '</small></div>' +
      (!running
        ? (source === 'completed' && ['article', 'novel'].includes(item.type)
          ? '<button class="workbuddy-edit-btn" type="button" data-workbuddy-finished="' +
            escapeHtml(item.id) + '" data-workbuddy-source="' + escapeHtml(source) +
            '" title="用 Workbuddy 修改">WB</button>'
          : '') +
          '<button class="draft-delete" type="button" data-delete-work="' + escapeHtml(item.id) +
          '" data-work-source="' + escapeHtml(source) + '" title="删除">' + icon('trash') + '</button>'
        : item.status === 'failed'
          ? '<button class="draft-delete" type="button" data-delete-generation="' + escapeHtml(item.id) +
            '" title="移除失败任务">' + icon('trash') + '</button>'
          : '') +
      '</div>';
  }

  function deleteGenerationTask(id) {
    state.generating = state.generating.filter((item) => item.id !== id);
    saveJson(KEYS.generating, state.generating);
    renderDrafts();
    showToast('未完成任务已移除');
  }

  function preserveArticleFigures(originalHtml, revisedHtml) {
    const originalBox = document.createElement('div');
    originalBox.innerHTML = originalHtml || '';
    const figures = $$('figure', originalBox);
    if (!figures.length) return revisedHtml || '';
    const revisedBox = document.createElement('div');
    revisedBox.innerHTML = revisedHtml || '';
    revisedBox.querySelectorAll('figure,img').forEach((node) => node.remove());
    const anchors = $$('p, h2, h3', revisedBox).filter((node) =>
      String(node.textContent || '').trim().length >= 12);
    figures.forEach((figure, index) => {
      if (anchors.length) {
        const position = Math.min(anchors.length - 1,
          Math.floor((index + 1) * anchors.length / (figures.length + 1)));
        anchors[position].insertAdjacentElement('afterend', figure.cloneNode(true));
      } else {
        revisedBox.appendChild(figure.cloneNode(true));
      }
    });
    return revisedBox.innerHTML;
  }

  function artifactRevisionPrompt(item, instruction) {
    const payload = item.payload || {};
    const plain = stripHtml(payload.html || '');
    const figures = $$('figure', (() => {
      const box = document.createElement('div');
      box.innerHTML = payload.html || '';
      return box;
    })()).map((figure, index) =>
      '[图片' + (index + 1) + '：' + (figure.querySelector('figcaption')?.textContent || '文章配图') + ']');
    return [
      '你正在修改一份已经保存的' + workTypeLabel(item.type) + '成品。',
      '作品标题：' + (item.title || payload.title || '未命名成品'),
      figures.length ? '原文包含图片：' + figures.join('、') + '。图片由热点工坊保留，不需要在文字中重复输出图片标签。' : '',
      instruction ? '本次修改要求：' + instruction : '本次先读取成品，等待进一步修改。',
      '请保留可核验事实和原文有效信息，不编造数据、引语或事件；输出完整修改后的作品。',
      '第一行输出“标题：……”，随后输出完整正文。',
      '原始正文：\n' + truncate(plain, 14000)
    ].filter(Boolean).join('\n\n');
  }

  async function runFinishedArtifactAiRevision(item, instruction, preference) {
    if (!item || !item.payload) return;
    const type = item.type === 'novel' ? 'novel' : 'article';
    const taskId = beginGeneration(type, 'AI 修改 · ' + (item.title || '成品'),
      '正在生成新的修改版本');
    showLoading('正在修改成品', '正在保留原作品并生成新的修订版本。');
    try {
      const prompt = artifactRevisionPrompt(item, instruction);
      const novelKind = type === 'novel' ? (item.payload.lengthType || 'short') : 'article';
      const result = await requestStandaloneWriting(prompt, novelKind, preference);
      if (type === 'article') {
        const parsed = aiTextToHtml(result.text);
        const titleMatch = result.text.match(/^标题[：:]\s*(.+)$/m);
        const title = truncate(parsed.title || (titleMatch && titleMatch[1].trim()) ||
          item.payload.title || 'AI 修改版', 30);
        const merged = preserveArticleFigures(item.payload.html || '', parsed.html);
        state.article = Object.assign({}, JSON.parse(JSON.stringify(item.payload)), {
          id: 'article_ai_revision_' + Date.now(),
          title,
          html: merged,
          sourceWorkId: item.id,
          revisionInstruction: instruction,
          revisionEngine: result.engine,
          status: 'editing',
          updatedAt: new Date().toISOString()
        });
        state.article.html = applyArticleTemplateHtml(
          state.article.html, state.article.template || state.articleTemplate);
        saveJson(KEYS.article, state.article);
        renderArticle();
        showView('article');
        finishGeneration(taskId, 'article', state.article);
      } else {
        const parsed = parseNovelAiOutput(result.text, item.payload.title || 'AI 修改版');
        state.novel = Object.assign({}, JSON.parse(JSON.stringify(item.payload)), {
          id: 'novel_ai_revision_' + Date.now(),
          title: parsed.title || item.payload.title || 'AI 修改版',
          html: novelTextToHtml(parsed.body || result.text),
          storyBible: parsed.storyBible || item.payload.storyBible || {},
          sourceWorkId: item.id,
          revisionInstruction: instruction,
          revisionEngine: result.engine,
          updatedAt: new Date().toISOString()
        });
        saveJson(KEYS.novel, state.novel);
        renderNovel();
        showView('novel');
        finishGeneration(taskId, 'novel', state.novel);
      }
    } catch (error) {
      failGeneration(taskId, error.message);
      showToast('AI 修改失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  function openWorkbuddyFinishedDialog(item) {
    if (!item || !item.payload) return;
    showModal('AI 修改成品', 'FINISHED WORK · AI REVISION',
      '<div class="workbuddy-revision-dialog">' +
        '<div class="post-browse-source"><strong>' + escapeHtml(item.title || '未命名成品') + '</strong><small>' +
          escapeHtml(workTypeLabel(item.type)) + ' · 已从成品库读取</small></div>' +
        '<p class="import-hint">可以直接打开 Workbuddy 继续处理，也可以填写修改要求后把完整成品交给 Workbuddy。原成品不会被覆盖。</p>' +
        '<label>修改要求<textarea id="workbuddyRevisionInstruction" placeholder="例如：标题更吸引人；增加现实影响分析；压缩到1200字；重排段落和图片位置；改成腾讯新闻风格。"></textarea></label>' +
        '<label>修改方式<select id="artifactRevisionEngine">' +
          '<option value="auto">自动选择（Codex / 已连接 AI）</option>' +
          '<option value="codex">优先使用本机 Codex</option>' +
          '<option value="ai">使用已配置 AI</option>' +
          '<option value="workbuddy">Workbuddy 客户端或网页版</option>' +
        '</select></label>' +
        '<div class="workbuddy-revision-chips">' +
          '<button type="button" data-workbuddy-revision="标题更吸引人，但不得夸大或虚构。">优化标题</button>' +
          '<button type="button" data-workbuddy-revision="增加现实影响分析和不同群体视角，保留事实边界。">增强分析</button>' +
          '<button type="button" data-workbuddy-revision="压缩篇幅，删除重复表达，保留核心事实和图片。">精简文章</button>' +
          '<button type="button" data-workbuddy-revision="调整段落顺序、小标题和图片位置，使版面更适合今日头条。">重排图文</button>' +
        '</div>' +
        '<label>追加到成品正文前的修改说明<input id="workbuddyPrefixInstruction" placeholder="可选：例如补充一段新的讨论，再交给 Workbuddy"></label>' +
        '<div class="modal-note"><p>选择多个 AI 方式时，Workbuddy 客户端优先；无法启动时会在 Edge 打开网页版。修改结果从剪贴板导回后生成新版本。</p></div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-secondary" type="button" id="openFinishedInWorkbuddy">不修改，直接打开</button>' +
      '<button class="btn btn-primary" type="button" id="reviseFinishedInWorkbuddy">按所选 AI 修改</button>');
    $$('[data-workbuddy-revision]').forEach((button) => {
      button.addEventListener('click', () => {
        const textarea = $('#workbuddyRevisionInstruction');
        textarea.value = [textarea.value.trim(), button.dataset.workbuddyRevision].filter(Boolean).join('；');
        textarea.focus();
      });
    });
    const openForItem = (instruction) => {
      const prefix = $('#workbuddyPrefixInstruction').value.trim();
      const finalInstruction = [prefix, instruction].filter(Boolean).join('；');
      closeModal();
      openWorkbuddyBridge(true, artifactRevisionPrompt(item, finalInstruction), 'finished-revision', item);
    };
    $('#openFinishedInWorkbuddy').addEventListener('click', () => openForItem(''));
    $('#reviseFinishedInWorkbuddy').addEventListener('click', () => {
      const instruction = $('#workbuddyRevisionInstruction').value.trim();
      if (!instruction) {
        showToast('请填写修改要求', '例如：优化标题、增加分析、精简篇幅或重排图片。', 'info');
        $('#workbuddyRevisionInstruction').focus();
        return;
      }
      const engine = $('#artifactRevisionEngine').value;
      if (engine === 'workbuddy') {
        openForItem(instruction);
      } else {
        const prefix = $('#workbuddyPrefixInstruction').value.trim();
        closeModal();
        runFinishedArtifactAiRevision(item, [prefix, instruction].filter(Boolean).join('；'), engine);
      }
    });
  }

  function openWorkbuddyFinishedPicker() {
    const items = state.completed.filter((item) => ['article', 'novel'].includes(item.type));
    if (!items.length) {
      showToast('成品库为空', '请先保存一篇图文或小说成品。', 'info');
      return;
    }
    showModal('从成品库选择', 'FINISHED WORK LIBRARY',
      '<div class="workbuddy-finished-list">' + items.map((item) =>
        '<button type="button" data-workbuddy-pick="' + escapeHtml(item.id) + '"><strong>' +
          escapeHtml(item.title) + '</strong><small>' + escapeHtml(workTypeLabel(item.type)) +
          ' · ' + escapeHtml(stripHtml(item.payload && item.payload.html || '').slice(0, 80)) +
        '</small></button>').join('') + '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>');
    $$('[data-workbuddy-pick]').forEach((button) => {
      button.addEventListener('click', () => {
        const item = items.find((entry) => entry.id === button.dataset.workbuddyPick);
        openWorkbuddyFinishedDialog(item);
      });
    });
  }

  function openCurrentArticleAiModifyDialog() {
    persistArticle();
    if (!state.article || !stripHtml(state.article.html || '').trim()) {
      showToast('还没有图文成品', '请先生成或打开一篇图文文章。', 'info');
      return;
    }
    openWorkbuddyFinishedDialog({
      id: 'current_article_' + (state.article.id || Date.now()),
      type: 'article',
      title: state.article.title || $('#articleTitle').value.trim() || '当前图文',
      payload: JSON.parse(JSON.stringify(state.article))
    });
  }

  function normalizeWorkLibraries() {
    expireGenerationTasks(true, false);
    const normalize = (item, fallbackType) => {
      if (item && item.type && item.payload) return item;
      const type = item && item.lengthType ? 'novel' : fallbackType;
      return {
        id: item && item.id || ('work_legacy_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6)),
        type,
        title: item && item.title || (type === 'novel' ? '旧版原创小说' : '旧版图文'),
        summary: item && truncate(stripHtml(item.html || ''), 120) || '',
        cover: item && item.cover || '',
        payload: Object.assign({}, item || {}),
        status: 'draft',
        createdAt: item && item.createdAt || new Date().toISOString(),
        updatedAt: item && item.updatedAt || new Date().toISOString()
      };
    };
    state.drafts = (state.drafts || []).map((item) => normalize(item, 'article'));
    state.completed = (state.completed || []).map((item) => normalize(item, 'article'));
    if (state.article) {
      const known = state.completed.concat(state.drafts).some((item) =>
        item.type === 'article' && item.payload && item.payload.id === state.article.id);
      if (!known) state.drafts.unshift(normalize(state.article, 'article'));
    }
    if (state.novel) {
      const known = state.completed.concat(state.drafts).some((item) =>
        item.type === 'novel' && item.payload && item.payload.id === state.novel.id);
      if (!known) state.drafts.unshift(normalize(state.novel, 'novel'));
    }
    saveJson(KEYS.drafts, state.drafts);
    saveJson(KEYS.completed, state.completed);
  }

  function renderDrafts() {
    const grid = $('#draftGrid');
    if (!grid) return;
    updateCounts();
    if ($('#workSort')) $('#workSort').value = state.workSort;
    $$('#workTabs [data-work-filter]').forEach((button) =>
      button.classList.toggle('active', button.dataset.workFilter === state.workFilter));
    const items = workItemsForFilter(state.workFilter);
    const sourceFor = (item) => state.generating.includes(item) ? 'generating' :
      state.completed.includes(item) ? 'completed' : 'drafts';
    grid.innerHTML = items.length
      ? items.slice(0, 5).map((item) => workCardHtml(item, sourceFor(item))).join('')
      : '<div class="empty-draft">生成任务会先显示为“进行中”，成品生成后可选择保存或放入草稿箱</div>';
  }

  function currentCreativeArtifact() {
    if ($('#view-article').classList.contains('active') && state.article) {
      return { type: 'article', title: state.article.title || '未命名图文', payload: state.article };
    }
    if ($('#view-novel').classList.contains('active') && state.novel) {
      return { type: 'novel', title: state.novel.title || '未命名小说', payload: state.novel };
    }
    if ($('#view-video').classList.contains('active') && state.videoBlob) {
      return {
        type: 'video',
        title: state.videoEpisodeTitle || $('#clipPrompt').value.trim() || '未命名短视频',
        payload: {
          title: state.videoEpisodeTitle || $('#clipPrompt').value.trim() || '未命名短视频',
          videoBlob: state.videoBlob,
          videoUrl: state.videoUrl,
          duration: state.generatedVideoSeconds || state.videoDuration,
          cover: ''
        }
      };
    }
    return null;
  }

  function renderCreationSaveBar() {
    const bar = $('#creationSaveBar');
    if (!bar) return;
    const current = currentCreativeArtifact();
    bar.hidden = !current;
    if (!current) return;
    $('#creationSaveType').textContent = workTypeLabel(current.type) + ' · 作品保存';
    $('#creationSaveTitle').textContent = current.title;
  }

  function saveCurrentCreative(destination) {
    const current = currentCreativeArtifact();
    if (!current) {
      showToast('当前没有可保存成品', '请先生成图文、小说或视频。', 'info');
      return;
    }
    if (current.type === 'article') persistArticle();
    if (current.type === 'novel') persistNovel();
    const artifact = buildWorkArtifact(current.type, current.payload, 'manual_' + current.type + '_' + Date.now());
    saveWorkToLibrary(artifact, destination);
    showToast(destination === 'completed' ? '成品已保存' : '已放入草稿箱',
      destination === 'completed' ? '已进入作品中心的“已完成”。' : '可在作品中心继续编辑或删除。');
    if (current.type === 'video' && destination === 'completed' && state.videoBlob) setTimeout(downloadVideo, 180);
  }

  function openWorkItem(source, id) {
    const list = source === 'completed' ? state.completed : state.drafts;
    const item = list.find((entry) => entry.id === id);
    if (!item) return;
    closeModal();
    if (item.type === 'article' && item.payload) {
      state.article = JSON.parse(JSON.stringify(item.payload));
      state.articleMode = state.article.articleMode || state.articleMode;
      state.articleScope = state.article.articleScope || state.articleScope;
      saveJson(KEYS.article, state.article);
      renderArticle();
      showView('article');
      return;
    }
    if (item.type === 'novel' && item.payload) {
      state.novel = JSON.parse(JSON.stringify(item.payload));
      saveJson(KEYS.novel, state.novel);
      renderNovel();
      showView('novel');
      return;
    }
    if (item.type === 'video') {
      if (item.payload && item.payload.videoBlob && item.payload.videoUrl) {
        showView('video');
        state.videoBlob = item.payload.videoBlob;
        state.videoUrl = item.payload.videoUrl;
        $('#videoResult').src = state.videoUrl;
        $('#videoResult').hidden = false;
        $('#downloadVideoBtn').hidden = false;
        $('#emptyVideo').hidden = true;
        $('#videoState').textContent = '成品视频';
        $('#downloadVideoBtn').disabled = false;
        showVideoTextEditor();
      } else {
        showToast('视频文件未保留', '重新生成后才能再次下载；成品标题和剪辑信息仍保留在此列表。', 'info');
      }
    }
  }

  function deleteWorkItem(source, id) {
    if (source === 'drafts') {
      state.drafts = state.drafts.filter((item) => item.id !== id);
      saveJson(KEYS.drafts, state.drafts);
    } else if (source === 'completed') {
      state.completed = state.completed.filter((item) => item.id !== id);
      saveJson(KEYS.completed, state.completed);
    }
    renderDrafts();
    showToast('已删除', source === 'drafts' ? '草稿已从草稿箱删除。' : '成品已从已完成列表删除。');
  }

  function openWorkCenter() {
    const renderList = (filter) => {
      const items = workItemsForFilter(filter);
      const sourceFor = (item) => state.generating.includes(item) ? 'generating' :
        state.completed.includes(item) ? 'completed' : 'drafts';
      $('#workCenterTabs').innerHTML = [
        ['all', '全部'], ['running', '进行中'], ['completed', '已完成'], ['drafts', '草稿箱']
      ].map(([id, name]) => '<button type="button" class="' + (id === filter ? 'active' : '') +
        '" data-work-center-filter="' + id + '">' + name + '</button>').join('');
      $('#workCenterList').innerHTML = items.length
        ? items.map((item) => workCardHtml(item, sourceFor(item))).join('')
        : '<div class="empty-draft">这个分类还没有作品</div>';
      $$('#workCenterTabs [data-work-center-filter]').forEach((button) => {
        button.addEventListener('click', () => renderList(button.dataset.workCenterFilter));
      });
    };
    showModal('作品中心', 'FINISHED & DRAFTS',
      '<div class="work-center-toolbar"><div class="work-tabs" id="workCenterTabs"></div>' +
      '<select id="workCenterSort"><option value="newest">最新生成在前</option><option value="oldest">最早生成在前</option>' +
      '<option value="name">按名称排序</option><option value="type">按作品类型</option></select></div>' +
      '<div class="workbuddy-library-bar"><div><strong>Workbuddy 修改成品</strong><span>从“已完成”选择作品，决定是否填写修改要求</span></div>' +
      '<button class="btn btn-secondary" type="button" id="workCenterWorkbuddyBtn">选择成品并打开 Workbuddy</button></div>' +
      '<div class="work-center-list" id="workCenterList"></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>');
    $('#workCenterSort').value = state.workSort;
    $('#workCenterSort').addEventListener('change', (event) => {
      state.workSort = event.target.value;
      renderDrafts();
      renderList(state.workFilter);
    });
    $('#workCenterWorkbuddyBtn').addEventListener('click', openWorkbuddyFinishedPicker);
    renderList(state.workFilter);
  }

  function analysisFor(item, index) {
    const pools = {
      general: ['目前公开信息仍在持续更新。后续值得关注的是权威渠道是否发布进一步说明，以及事件对相关群体和公共服务的实际影响。'],
      society: ['这条消息与公众日常生活联系紧密。除事件本身外，具体执行方式、服务覆盖范围以及不同群体的实际感受，都是后续观察重点。'],
      finance: ['对普通读者而言，单一市场数据不足以代表长期趋势。更值得留意的是相关变化如何传导到企业经营、就业、消费和居民预期。'],
      tech: ['技术进展最终要回到真实应用场景中检验。稳定性、使用成本、数据安全和对普通用户的实际价值，是判断其影响的重要维度。'],
      world: ['国际信息往往牵涉多个利益相关方。后续政策表态、市场反应和区域合作动向，将决定事件影响的广度和持续时间。'],
      sports: ['赛事结果之外，训练体系、公共服务和大众参与同样值得关注。相关消息也反映出体育消费与城市公共空间的新变化。'],
      entertainment: ['文化内容的热度既来自作品本身，也来自观众的体验和讨论。判断其长期影响，还要看内容质量与产业生态是否持续改善。'],
      auto: ['汽车消费正在从关注单一参数转向重视安全、体验、补能和服务。相关变化将影响企业产品策略与消费者的长期使用成本。']
    };
    const list = pools[item.section] || pools.general;
    return list[index % list.length];
  }

  function firstSentence(text) {
    const clean = String(text || '').replace(/\s+/g, ' ').trim();
    const match = clean.match(/^.*?[。！？!?](?:\s|$)/);
    return truncate(match ? match[0] : clean, 120);
  }

  function splitFactSentences(text) {
    return String(text || '')
      .replace(/\r/g, '')
      .split(/(?<=[。！？!?])\s*/)
      .map((sentence) => sentence.replace(/\s+/g, ' ').trim())
      .filter((sentence) => sentence.length >= 16 && sentence.length <= 220)
      .filter((sentence) => !/^(责任编辑|编辑|来源|原标题|点击|扫描|更多精彩|免责声明)[：:]/.test(sentence));
  }

  function titleGrams(title) {
    const clean = String(title || '').replace(/[^\w\u4e00-\u9fa5]/g, '');
    const grams = new Set();
    for (let i = 0; i < clean.length - 1; i += 1) grams.add(clean.slice(i, i + 2));
    return Array.from(grams);
  }

  function relevantFacts(item, limit) {
    const text = item.detailText || item.summary || '';
    const sentences = splitFactSentences(text);
    const grams = titleGrams(item.title);
    const ranked = sentences.map((sentence, index) => {
      const score = grams.reduce((sum, gram) => sum + (sentence.includes(gram) ? 1 : 0), 0) +
        (/\d/.test(sentence) ? 1.5 : 0) + Math.max(0, 1 - index * .08);
      return { sentence, index, score };
    }).sort((a, b) => b.score - a.score || a.index - b.index);
    const chosen = [];
    ranked.forEach((entry) => {
      if (chosen.length < (limit || 4) && !chosen.some((itemSentence) => itemSentence === entry.sentence)) {
        chosen.push(entry.sentence);
      }
    });
    if (!chosen.length) chosen.push(firstSentence(item.summary));
    return chosen;
  }

  function factParagraphs(item, limit) {
    const facts = relevantFacts(item, limit || 3);
    return facts.map((sentence, index) =>
      '<p>' + (index === 0 ? '<strong>据' + escapeHtml(item.source || '公开报道') + '消息：</strong>' : '') +
      escapeHtml(sentence) + '</p>').join('');
  }

  function galleryFigures(item, limit) {
    const images = (item.gallery || []).filter((url) => url && url !== item.imageOriginal).slice(0, limit || 2);
    return images.map((url, index) =>
      '<figure><img src="' + escapeHtml(url) + '" alt="' + escapeHtml(item.title) +
      '"><figcaption>原文补充图片 ' + (index + 2) + ' / 来源：' + escapeHtml(item.source || '公开资讯') +
      '（发布前请确认授权）</figcaption></figure>').join('');
  }

  function impactFor(item) {
    const impacts = {
      general: '这类信息的影响通常不会只停留在事件本身。公众接下来更关心的是权威说明是否清晰、相关安排能否落实，以及信息变化会不会改变日常生活。',
      society: '对普通人而言，最直接的观察点是公共服务的可及性、办理流程是否清楚，以及不同年龄和不同地区的人群是否都能获得同等便利。',
      finance: '经济信息的影响会通过企业预期、就业机会、消费选择和家庭支出逐步传导。短期市场反应值得观察，但不宜据此判断长期走势。',
      tech: '技术变化最终会落到产品价格、使用门槛、数据安全和工作方式上。真正有意义的影响，需要在实际应用一段时间后才能看清。',
      world: '国际变化可能通过贸易、能源、物流和人员往来等渠道产生传导。不同行业受到的直接影响和间接影响，需要结合后续信息判断。',
      sports: '体育热点的影响不只体现在成绩上，也会带动赛事组织、城市服务、青少年培训和大众健身等更长期的变化。',
      entertainment: '文化内容会影响观众的消费选择，也会反过来影响创作方向。判断其价值，需要同时看内容质量、市场反馈和版权保护。',
      auto: '汽车消息会直接影响消费者的购买决策，也会传导到补能设施、售后服务和产业链供应。安全、质量与长期成本仍是核心。'
    };
    return impacts[item.section] || impacts.general;
  }

  async function enrichTopics(items) {
    const candidates = items.filter((item) => item.url && /^https?:\/\//i.test(item.url) && !item.detailText).slice(0, 4);
    await Promise.all(candidates.map(async (item) => {
      if (detailCache.has(item.url)) {
        const cached = detailCache.get(item.url);
        item.detailText = cached.text || '';
        if (!item.image && cached.image) item.image = cached.image;
        return;
      }
      try {
        const response = await api('/api/extract?url=' + encodeURIComponent(item.url));
        if (response.ok && response.text) {
          detailCache.set(item.url, { text: response.text, image: response.image || '' });
          item.detailText = response.text;
          item.detailCount = splitFactSentences(response.text).length;
          item.gallery = unique((item.gallery || []).concat(response.images || []).concat(response.image ? [response.image] : []));
          if (!item.imageOriginal && response.image) {
            item.image = response.image;
            item.imageOriginal = response.image;
          }
        }
      } catch (error) {
        console.warn('Article enrichment failed', item.url, error);
      }
    }));
    return items;
  }

  function aiTextToHtml(text) {
    const lines = String(text || '').trim().split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    let title = '';
    let html = '';
    lines.forEach((line) => {
      if (!title && /^标题[：:]/.test(line)) {
        title = line.replace(/^标题[：:]\s*/, '');
        return;
      }
      if (/^【.+】$/.test(line) || /^[一二三四五六七八九十\d]+[、.．]/.test(line)) {
        html += '<h2>' + escapeHtml(line.replace(/^[一二三四五六七八九十\d]+[、.．]\s*/, '')) + '</h2>';
      } else {
        html += '<p>' + escapeHtml(line) + '</p>';
      }
    });
    return { title, html };
  }

  function applyArticleTemplateHtml(html, templateId) {
    const safeTemplate = ARTICLE_TEMPLATE_PROMPTS[templateId] ? templateId : 'news';
    const box = document.createElement('div');
    box.innerHTML = html || '';
    const onlyChild = box.children.length === 1 ? box.firstElementChild : null;
    const inner = onlyChild && onlyChild.classList.contains('article-template')
      ? onlyChild.innerHTML
      : box.innerHTML;
    return '<div class="article-template article-template-' + safeTemplate + '">' + inner + '</div>';
  }

  function renderArticleTemplateStrip() {
    const strip = $('#articleTemplateStrip');
    if (!strip) return;
    strip.innerHTML = '<span>图文模板</span>' + Object.keys(ARTICLE_TEMPLATE_LABELS).map((id) =>
      '<button type="button" class="' + (state.articleTemplate === id ? 'active' : '') +
      '" data-article-template-preset="' + id + '">' + ARTICLE_TEMPLATE_LABELS[id] + '</button>').join('');
  }

  function selectArticleTemplate(templateId) {
    state.articleTemplate = ARTICLE_TEMPLATE_PROMPTS[templateId] ? templateId : 'news';
    if ($('#articleLayoutPreset')) $('#articleLayoutPreset').value = state.articleTemplate;
    renderArticleTemplateStrip();
    if (!state.article) return;
    state.article.template = state.articleTemplate;
    state.article.html = applyArticleTemplateHtml(state.article.html, state.articleTemplate);
    state.article.updatedAt = new Date().toISOString();
    saveJson(KEYS.article, state.article);
    renderArticle();
  }

  async function buildAiArticle(items, mode, scope, fallback, instructions, images, imageLabels) {
    if (!state.config.ai || !state.config.ai.enabled || !state.config.ai.hasKey) return fallback;
    const styleId = $('#articleStylePreset') ? $('#articleStylePreset').value : state.articleStyle;
    state.articleStyle = styleId || 'cctv';
    const contentModeId = $('#articleContentMode') ? $('#articleContentMode').value : state.articleContentMode;
    state.articleContentMode = ARTICLE_CONTENT_MODES[contentModeId] ? contentModeId : 'fact';
    const variationPrompt = nextArticleVariationPrompt();
    const templateId = $('#articleLayoutPreset') ? $('#articleLayoutPreset').value : state.articleTemplate || 'news';
    state.articleTemplate = templateId;
    const material = items.map((item, index) =>
      '【' + (index + 1) + '】' + item.title + '\n来源：' + item.source + '\n摘要：' + item.summary +
      '\n原文信息：' + truncate(item.detailText || item.summary, 2200)
    ).join('\n\n');
    const prompt = [
      scope === 'multi'
        ? '围绕以下多个独立热点写一篇可直接进入人工审核的中文讨论稿，分别陈述每个事件，再总结共同关注点，不得虚构事件之间的因果关系。'
        : '只讨论一个主事件，根据以下同一事件的公开信息写一篇可直接进入人工审核的中文新闻稿。',
      scope === 'multi'
        ? '每个事件必须有独立小标题和事实说明，最后再进行分析比较；不能把不同事件写成同一件事。'
        : '文章必须围绕第一条材料中的单一事件展开；后续材料只能用于补充事实、回应或背景，不得把无关热点拼接进文章。',
      ARTICLE_MODE_PROMPTS[mode] || ARTICLE_MODE_PROMPTS.feature,
      '写作风格：' + (ARTICLE_STYLE_PROMPTS[state.articleStyle] || ARTICLE_STYLE_PROMPTS.cctv),
      '内容模式：' + articleContentModePrompt(state.articleContentMode),
      '本次版本要求：' + variationPrompt,
      '图文版式：' + (ARTICLE_TEMPLATE_PROMPTS[state.articleTemplate] || ARTICLE_TEMPLATE_PROMPTS.news),
      '必须遵守：不编造人物、数字、时间、引语和因果关系；只使用材料中能支持的信息；对不确定内容使用“从公开信息看”“仍需等待进一步说明”等限定语；保留来源名称。',
      scope === 'multi'
        ? '结构：标题不超过30个汉字；导语；【事件概览】；用“事件一、事件二”等小标题分别写清事实；【共同关注】；【差异与边界】；【接下来关注什么】；【资料说明】。'
        : '结构：标题不超过30个汉字；导语；【新闻事实】；【信息梳理】；【影响与关注】；【接下来观察什么】；【资料说明】。',
      '输出格式：第一行“标题：...”，之后使用【小标题】和自然段，不要输出Markdown表格，不要写“作为AI”。',
      instructions ? '本次额外写作要求：' + instructions : '',
      (images || []).length ? '用户提供了 ' + images.length + ' 张截图或视频画面，请结合图中可见信息和文字要求写作；不得虚构图片中无法确认的事实。' : '',
      '公开材料：\n' + material
    ].filter(Boolean).join('\n\n');
    try {
      showLoading('正在进行深度写作', '正在基于原文信息重组事实、背景和影响，请稍候。');
      const result = await api('/api/ai', {
        method: 'POST',
        body: JSON.stringify({
          system: '你是严谨的中文新闻编辑，坚持事实优先、来源可核、表达克制，不扩写不存在的事实。',
          prompt,
          images: images || [],
          imageLabels: imageLabels || [],
          temperature: .58
        })
      });
      if (!result.ok || !result.text) return fallback;
      const parsed = aiTextToHtml(result.text);
      if (!parsed.html || stripHtml(parsed.html).length < 350) return fallback;
      const contentBox = document.createElement('div');
      contentBox.innerHTML = parsed.html;
      const firstParagraph = contentBox.querySelector('p');
      const figures = items.filter((item) => item.image).map((item) =>
        '<figure><img src="' + escapeHtml(item.image) + '" alt="' + escapeHtml(item.title) +
        '"><figcaption>新闻图片 / 来源：' + escapeHtml(item.source || '公开资讯') +
        '（发布前请确认授权）</figcaption></figure>');
      if (firstParagraph && figures[0]) firstParagraph.insertAdjacentHTML('afterend', figures[0]);
      figures.slice(1).forEach((figure) => contentBox.insertAdjacentHTML('beforeend', figure));
      const body = '<p class="article-publish-meta"><span class="article-badge ' +
        (mode === 'feature' || mode === 'topic' ? 'feature' : '') + '">' +
        (scope === 'multi' ? '多事件 · ' : '') + escapeHtml(articleModeLabel(mode)) +
        '</span>综合公开消息 · AI辅助整理 · 发布前人工核验</p>' + contentBox.innerHTML +
        '<p><small>资料来源：' + items.map((item) => escapeHtml(item.source || '公开资讯')).join('、') +
        '。本文根据公开材料辅助整理，不代表来源媒体观点。</small></p>';
      return Object.assign({}, fallback, {
        title: truncate(parsed.title || fallback.title, 30),
        html: applyArticleTemplateHtml(body, templateId),
        template: templateId,
        contentMode: state.articleContentMode,
        aiGenerated: true
      });
    } catch (error) {
      console.warn('AI article generation failed', error);
      return fallback;
    } finally {
      hideLoading();
    }
  }

  function isSameEvent(first, second) {
    if (!first || !second || first.id === second.id) return false;
    const firstGrams = titleGrams(first.title);
    const secondTitle = String(second.title || '').replace(/[^\w\u4e00-\u9fa5]/g, '');
    const matches = firstGrams.reduce((sum, gram) => sum + (secondTitle.includes(gram) ? 1 : 0), 0);
    return matches >= 3 || (firstGrams.length > 0 && matches / firstGrams.length >= .32);
  }

  function articleItemsFor(focusId) {
    const chosen = focusId
      ? state.news.find((item) => item.id === focusId)
      : selectedItems()[0] || visibleNews()[0] || state.news[0];
    if (!chosen) return [];
    const sameEventCoverage = state.news.filter((item) => item.id !== chosen.id && isSameEvent(chosen, item));
    return [chosen].concat(sameEventCoverage).slice(0, 4);
  }

  function multiEventItems() {
    let items = selectedItems().slice(0, 4);
    if (items.length < 2) {
      state.news.slice().sort((a, b) => (b.score || 0) - (a.score || 0)).forEach((item) => {
        if (items.length < 3 && !items.some((entry) => entry.id === item.id)) items.push(item);
      });
      state.selected = items.map((item) => item.id);
      saveJson(KEYS.selected, state.selected);
    }
    return items;
  }

  function referenceText(items) {
    return items.map((item) => item.url && /^https?:\/\//i.test(item.url)
      ? '<a href="' + escapeHtml(item.url) + '" target="_blank" rel="noreferrer">' + escapeHtml(item.source || '来源') + '</a>'
      : escapeHtml(item.source || '手动导入内容')).join(' · ');
  }

  function buildMicroArticle(focusId, mode) {
    const articleType = mode === 'short' ? 'short' : 'micro';
    const items = articleItemsFor(focusId);
    if (!items.length) {
      showToast('还没有可用素材', '请等资讯加载完成后再试。', 'info');
      return null;
    }
    const main = items[0];
    const related = items.slice(1);
    const titles = articleType === 'short'
      ? [
          '短文章｜' + truncate(main.title, 19),
          '今日解读｜' + truncate(main.title, 18),
          '核心关注｜' + truncate(main.title, 18)
        ]
      : [
          '微新闻｜' + truncate(main.title, 20),
          '今日关注｜' + truncate(main.title, 19),
          '权威速览｜' + truncate(main.title, 19)
        ];
    const title = truncate(titles[state.variant % titles.length], 30);
    state.variant += 1;
    const lead = firstSentence(main.summary);
    let html = '<p class="article-publish-meta"><span class="article-badge">' +
      escapeHtml(articleModeLabel(articleType)) + '</span>综合公开消息 · ' +
      escapeHtml(main.source || '热点工坊') + ' · ' + escapeHtml(main.publishedLabel || '今日') + '</p>';
    html += '<p class="article-lead">' + escapeHtml(lead) + '</p>';
    html += '<p>这条消息受到关注，不只因为事件本身，也因为它涉及公众对相关进展和实际影响的持续关心。</p>';
    if (main.image) {
      html += '<figure><img src="' + escapeHtml(main.image) + '" alt="' + escapeHtml(main.title) +
        '"><figcaption>资料图 / 图片素材来源：' + escapeHtml(main.source || '公开资讯') +
        '（发布前请确认授权）</figcaption></figure>';
    }
    html += '<h2>【新闻事实】</h2>';
    html += factParagraphs(main, 4);
    html += galleryFigures(main, 2);
    html += '<p><strong>信息来源：</strong>' + escapeHtml(main.source || '公开资讯') +
      '。目前公开报道主要围绕上述事实展开，具体时间、数据和后续安排，应以权威渠道最终发布的信息为准。</p>';
    html += '<h2>【为何受到关注】</h2>';
    html += '<p>' + escapeHtml(analysisFor(main, 0)) + '</p>';
    html += '<p>' + escapeHtml(impactFor(main)) + '</p>';
    if (related.length) {
      html += '<h2>【今日延伸快讯】</h2>';
      related.forEach((item, index) => {
        html += '<h3>' + String(index + 2).padStart(2, '0') + '｜' + escapeHtml(truncate(item.title, 34)) + '</h3>';
        html += factParagraphs(item, item.detailText ? 2 : 1);
        if (item.image) {
          html += '<figure><img src="' + escapeHtml(item.image) + '" alt="' + escapeHtml(item.title) +
            '"><figcaption>' + escapeHtml(item.sectionName) + '资料图 / 来源：' +
            escapeHtml(item.source || '公开资讯') + '</figcaption></figure>';
        }
      });
    }
    html += '<hr><p><strong>【新闻多一点】</strong></p>';
    html += '<p>看一条新闻，可以把信息拆成三个层次：已经确认的事实、仍未完全明确的细节，以及接下来可能影响普通人的变化。对尚未获得权威确认的内容，应保留判断空间。</p>';
    html += '<p>面对快速传播的信息，建议优先查看权威渠道原文，核对时间、地点、人物和关键数据，再作判断。热点值得关注，准确比速度更重要。</p>';
    html += '<h2>【接下来关注什么】</h2>';
    html += '<p>一是权威渠道是否补充说明；二是相关安排是否有明确时间表；三是事件对具体人群和日常生活是否产生可验证的影响。</p>';
    html += '<p><small>资料来源：' + items.map((item) => escapeHtml(item.source || '公开资讯')).join('、') +
      '。本文由热点工坊根据公开信息摘要整理，不代表来源媒体观点；发布前请完成事实与图片版权核验。</small></p>';
    html += '<p><small>原文参考：' + referenceText(items) + '</small></p>';
    return {
      id: state.article && state.article.id || 'article_' + Date.now(),
      title,
      html,
      cover: items.find((item) => item.image)?.image || '',
      sourceIds: items.map((item) => item.id),
      tags: [items[0].sectionName, articleModeLabel(articleType), '事件讨论'],
      articleMode: articleType,
      articleScope: 'single',
      status: 'editing',
      createdAt: state.article && state.article.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  function buildFeatureArticle(focusId, mode) {
    const articleType = mode === 'topic' ? 'topic' : 'feature';
    const items = articleItemsFor(focusId);
    if (!items.length) {
      showToast('还没有可用素材', '请等资讯加载完成后再试。', 'info');
      return null;
    }
    const main = items[0];
    const related = items.slice(1);
    const titles = articleType === 'topic'
      ? [
          '话题｜' + truncate(main.title, 21),
          '争议焦点｜' + truncate(main.title, 19),
          '今日讨论｜' + truncate(main.title, 18)
        ]
      : [
          '热点观察｜' + truncate(main.title, 19),
          '深度｜' + truncate(main.title, 21),
          '今日聚焦｜' + truncate(main.title, 18)
        ];
    const title = truncate(titles[state.variant % titles.length], 30);
    state.variant += 1;
    let html = '<p class="article-publish-meta"><span class="article-badge feature">' +
      escapeHtml(articleModeLabel(articleType)) + '</span>综合公开消息 · ' +
      escapeHtml(main.source || '热点工坊') + ' · ' + escapeHtml(main.publishedLabel || '今日') + '</p>';
    html += '<p class="article-lead">' + escapeHtml(truncate(main.summary || main.title, 150)) + '</p>';
    if (main.image) {
      html += '<figure><img src="' + escapeHtml(main.image) + '" alt="' + escapeHtml(main.title) +
        '"><figcaption>新闻图片 / 来源：' + escapeHtml(main.source || '公开资讯') + '</figcaption></figure>';
    }
    html += '<h2>【事件聚焦】</h2>';
    html += '<p><strong>' + escapeHtml(main.title) + '</strong></p>';
    html += factParagraphs(main, 5);
    html += galleryFigures(main, 2);
    if (related.length) {
      html += '<h2>【同事件信息补充】</h2>';
      related.forEach((item, index) => {
        html += '<h3>补充来源 ' + String(index + 2).padStart(2, '0') + '｜' + escapeHtml(item.source || '公开报道') + '</h3>';
        html += factParagraphs(item, item.detailText ? 3 : 1);
        if (item.image) {
          html += '<figure><img src="' + escapeHtml(item.image) + '" alt="' + escapeHtml(item.title) +
            '"><figcaption>同一事件报道 / 图片素材来源：' +
            escapeHtml(item.source || '公开资讯') + '</figcaption></figure>';
        }
      });
    }
    html += '<h2>【讨论焦点】</h2>';
    html += '<p>' + escapeHtml(analysisFor(main, 0)) + '</p>';
    html += '<p>' + escapeHtml(impactFor(main)) + '</p>';
    html += '<p>把几条公开信息放在一起看，可以发现关注点主要集中在事实进展、实际影响和后续执行三个层面。现有信息尚不足以覆盖全部细节，解读时应避免把单条报道扩大为确定结论。</p>';
    html += '<h2>【普通人需要知道什么】</h2>';
    html += '<p>对普通读者而言，最值得留意的不是情绪化判断，而是信息是否会改变具体的服务、价格、规则或生活安排。涉及个人决策时，应等待更多细节，并对照官方渠道和多个可靠来源，避免只依据一个标题作判断。</p>';
    html += '<p>同时，也需要区分“正在发生的事实”和“对未来的推测”。前者应尽可能核对原文，后者则应清楚标注为观察，而不是写成已经发生的结论。</p>';
    html += '<h2>【接下来关注什么】</h2>';
    html += '<p><strong>第一，权威信息是否进一步更新。</strong>涉及时间、数据和政策安排的内容，应以发布机构的最新说明为准。</p>';
    html += '<p><strong>第二，变化如何落到具体生活中。</strong>普通读者更关心的是服务是否可及、成本是否变化、相关群体能否真正受益。</p>';
    html += '<p><strong>第三，后续执行是否形成持续效果。</strong>新闻热度会过去，真正有信息价值的是后续数据和实际进展。</p>';
    html += '<hr><p><small>资料来源：' + items.map((item) => escapeHtml(item.source || '公开资讯')).join('、') +
      '。本文根据公开信息摘要整理，发布前请核验事实并确认图片使用授权。</small></p>';
    html += '<p><small>原文参考：' + referenceText(items) + '</small></p>';
    return {
      id: state.article && state.article.id || 'article_' + Date.now(),
      title,
      html,
      cover: items.find((item) => item.image)?.image || '',
      sourceIds: items.map((item) => item.id),
      tags: [main.sectionName, articleModeLabel(articleType), '事件观察'],
      articleMode: articleType,
      articleScope: 'single',
      status: 'editing',
      createdAt: state.article && state.article.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  function buildMultiArticle(mode) {
    const items = multiEventItems();
    if (!items.length) return null;
    const isFeature = mode === 'feature' || mode === 'topic';
    const modeLabel = articleModeLabel(mode);
    const lead = items[0];
    const titles = isFeature
      ? ['热点观察｜今日' + items.length + '个事件值得关注', '多事件讨论｜今天的几个重要变化', '深度盘点｜从' + items.length + '个热点看公共关注']
      : ['今日速览｜' + items.length + '个热点值得关注', '微新闻｜今日热点多事件讨论', '热点盘点｜这几件事有新进展'];
    const title = truncate(titles[state.variant % titles.length], 30);
    state.variant += 1;
    let html = '<p class="article-publish-meta"><span class="article-badge ' + (isFeature ? 'feature' : '') + '">' +
      '多事件 · ' + escapeHtml(modeLabel) + '</span>综合公开消息 · ' + items.length + '个独立事件 · 发布前人工核验</p>';
    html += '<p class="article-lead">今天值得关注的并不只有一件事。本文分别梳理' + items.length +
      '个独立热点的事实与进展，再讨论它们共同指向的公共关注点。各事件之间不一定存在因果联系。</p>';
    html += '<h2>【事件概览】</h2>';
    items.forEach((item, index) => {
      html += '<h3>' + String(index + 1).padStart(2, '0') + '｜' + escapeHtml(item.title) + '</h3>';
      html += '<p><strong>' + escapeHtml(item.sectionName) + ' · ' + escapeHtml(item.source || '公开资讯') + '</strong></p>';
      if (item.image) {
        html += '<figure><img src="' + escapeHtml(item.image) + '" alt="' + escapeHtml(item.title) +
          '"><figcaption>新闻图片 / 来源：' + escapeHtml(item.source || '公开资讯') + '</figcaption></figure>';
      }
      html += factParagraphs(item, isFeature ? 3 : 2);
      if (isFeature) html += '<p>' + escapeHtml(analysisFor(item, index)) + '</p>';
    });
    if (isFeature) {
      html += '<h2>【多事件观察】</h2>';
      html += '<p>把这些事件放在一起看，共同点不在于它们属于同一新闻，而在于公众对信息真实性、后续执行和现实影响有着相似的关注。不同板块的问题应分开判断，不能用一个事件的结论替代另一个事件。</p>';
      html += '<p>' + escapeHtml(impactFor(lead)) + '</p>';
      html += '<h2>【差异与边界】</h2>';
      html += '<p>多个热点同时出现时，容易产生“所有变化都相互关联”的错觉。本文只并列呈现公开事实，不对事件之间的因果关系作没有依据的推断。涉及政策、市场或国际关系的内容，尤其需要等待更多权威信息和后续数据。</p>';
      html += '<h2>【接下来共同关注什么】</h2>';
      html += '<p><strong>第一，事实是否更新。</strong>每一项事件都应回到对应来源，核对时间、地点、人物、数据和后续回应。</p>';
      html += '<p><strong>第二，影响是否具体。</strong>关注相关安排能否落实到具体服务、成本和人群，而不只看讨论热度。</p>';
      html += '<p><strong>第三，信息是否被准确理解。</strong>多事件阅读更要避免标题混用、截图拼接和脱离语境引用。</p>';
    } else {
      html += '<h2>【共同关注】</h2>';
      html += '<p>以上事件来自不同领域，但都提醒读者：面对快速更新的信息，应先确认发生了什么，再判断它可能影响谁。不能因为事件同时出现，就人为建立因果联系。</p>';
      html += '<p>后续可分别关注权威渠道更新、实际执行细节和公众反馈，本稿会保留各事件之间的边界。</p>';
    }
    html += '<hr><p><small>资料来源：' + items.map((item) => escapeHtml(item.source || '公开资讯')).join('、') +
      '。本文按多个独立事件整理，不代表来源媒体观点；发布前请完成事实与图片版权核验。</small></p>';
    html += '<p><small>原文参考：' + referenceText(items) + '</small></p>';
    return {
      id: state.article && state.article.id || 'article_' + Date.now(),
      title,
      html,
      cover: items.find((item) => item.image)?.image || '',
      sourceIds: items.map((item) => item.id),
      tags: unique([items[0].sectionName, modeLabel, '多事件讨论']),
      articleMode: mode,
      articleScope: 'multi',
      status: 'editing',
      createdAt: state.article && state.article.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  function buildArticle(mode, focusId, scope) {
    if (scope === 'multi') return buildMultiArticle(mode);
    return mode === 'feature' || mode === 'topic'
      ? buildFeatureArticle(focusId, mode)
      : buildMicroArticle(focusId, mode);
  }

  async function makeArticle(openView, options) {
    const settings = options || {};
    state.articleMode = settings.mode || state.articleMode || 'micro';
    state.articleScope = settings.scope || state.articleScope || 'single';
    state.articleFocusId = settings.focusId || (state.articleScope === 'single'
      ? selectedItems()[0]?.id || leadItem()?.id || ''
      : '');
    let sourceItems = state.articleScope === 'multi' ? multiEventItems() : articleItemsFor(state.articleFocusId);
    if (!sourceItems.length && (settings.customText || (settings.images || []).length)) {
      const customText = String(settings.customText || '').trim();
      const synthetic = normalizeItem({
        id: 'ai_custom_' + Date.now(),
        title: truncate(customText.split(/\r?\n/)[0] || '截图与视频素材创作', 42),
        summary: truncate(customText || '根据用户提供的截图、视频画面和提示词进行原创写作。', 600),
        detailText: customText,
        source: '我的 AI 素材',
        section: 'general',
        publishedAt: new Date().toISOString(),
        publishedLabel: '刚刚',
        score: 90,
        imported: true
      });
      state.news.unshift(synthetic);
      state.articleFocusId = synthetic.id;
      sourceItems = [synthetic];
    }
    if (!sourceItems.length) {
      showToast('还没有可用素材', '请等资讯加载完成后再试。', 'info');
      return;
    }
    const taskId = beginGeneration('article', sourceItems[0].title,
      state.articleScope === 'multi' ? '正在整理多事件图文' : '正在整理单事件图文');
    if (sourceItems.some((item) => item.url && /^https?:\/\//i.test(item.url) && !item.detailText)) {
      showLoading('正在丰富文章内容', '正在读取原始报道并整理新闻事实、背景与后续关注。');
    }
    try {
      await enrichTopics(sourceItems);
    } finally {
      if (!state.config.ai || !state.config.ai.enabled || !state.config.ai.hasKey) hideLoading();
    }
    const fallback = buildArticle(state.articleMode, state.articleFocusId, state.articleScope);
    if (!fallback) {
      failGeneration(taskId, '没有足够素材生成文章');
      return;
    }
    state.article = await buildAiArticle(sourceItems, state.articleMode, state.articleScope, fallback,
      settings.instructions || '', settings.images || [], settings.imageLabels || []);
    if ((settings.images || []).length) {
      const figures = settings.images.map((url, index) =>
        '<figure class="creative-source-image"><img src="' + escapeHtml(url) + '" alt=""><figcaption>' +
        escapeHtml((settings.imageLabels || [])[index] || ('用户提供素材 ' + (index + 1))) +
        '</figcaption></figure>').join('');
      state.article.html = state.article.html.replace(/<\/div>$/, figures + '</div>');
    }
    const templateId = $('#articleLayoutPreset') ? $('#articleLayoutPreset').value : state.articleTemplate;
    state.articleTemplate = ARTICLE_TEMPLATE_PROMPTS[templateId] ? templateId : 'news';
    state.article.template = state.articleTemplate;
    state.article.html = applyArticleTemplateHtml(state.article.html, state.articleTemplate);
    state.article.articleMode = state.articleMode;
    state.article.articleScope = state.articleScope;
    state.article.contentMode = state.articleContentMode || 'fact';
    state.article.focusId = state.articleScope === 'single' ? state.articleFocusId : '';
    saveJson(KEYS.article, state.article);
    renderArticle();
    if (openView) showView('article');
    finishGeneration(taskId, 'article', state.article);
    showToast('图文已生成', '已自动加入 ' + articleImages().length + ' 张新闻图片。');
  }

  function articleSourceItems() {
    const ids = state.article && (state.article.sourceIds || state.article.sources) || state.selected;
    return ids.map((id) => state.news.find((item) => item.id === id)).filter(Boolean);
  }

  function articleImages() {
    if (!state.article || !state.article.html) return [];
    const box = document.createElement('div');
    box.innerHTML = state.article.html;
    return $$('img', box);
  }

  function sanitizeAiSvg(source) {
    const match = String(source || '').match(/<svg[\s\S]*?<\/svg>/i);
    if (!match) throw new Error('AI 没有返回有效的 SVG 插画');
    const doc = new DOMParser().parseFromString(match[0], 'image/svg+xml');
    if (doc.querySelector('parsererror')) throw new Error('AI 返回的 SVG 格式无效');
    doc.querySelectorAll('script,foreignObject,iframe,object,embed,text').forEach((node) => node.remove());
    doc.querySelectorAll('*').forEach((node) => {
      Array.from(node.attributes).forEach((attr) => {
        if (/^on/i.test(attr.name) || /javascript:/i.test(attr.value)) node.removeAttribute(attr.name);
      });
    });
    const svg = doc.documentElement;
    svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    if (!svg.getAttribute('viewBox')) svg.setAttribute('viewBox', '0 0 1200 675');
    svg.setAttribute('width', '1200');
    svg.setAttribute('height', '675');
    return new XMLSerializer().serializeToString(svg);
  }

  function svgToPng(svg) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 1200;
        canvas.height = 675;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#17243a';
        ctx.fillRect(0, 0, 1200, 675);
        ctx.drawImage(image, 0, 0, 1200, 675);
        resolve(canvas.toDataURL('image/png'));
      };
      image.onerror = () => reject(new Error('AI 插画转换失败'));
      image.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    });
  }

  async function generateSvgIllustration(topic, prompt) {
    const aiReady = Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    if (!aiReady) throw new Error('文字 AI 尚未连接');
    showLoading('正在用 AI 生成正文插画', '文字 AI 正在根据当前文章和小节内容绘制原创图形。');
    try {
      const result = await withTimeout(api('/api/ai', {
        method: 'POST',
        body: JSON.stringify({
          system: '你是视觉设计师。只输出一个完整、合法、可独立显示的 SVG，不要Markdown，不要解释。',
          prompt: [
            '为下面这段文章内容制作一张横版新闻配图，画布 1200x675。',
            '必须与文章的具体主题、人物处境、地点和场景对应。',
            '使用清晰的矢量插画、自然配色、层次和留白；不要生成任何文字、数字、标签、Logo、水印或图片位编号。',
            '只使用 SVG 图形元素（rect、circle、path、polygon、linearGradient 等），不要使用 text。',
            '文章标题：' + cleanGeneratedImageText(topic && topic.title || ''),
            '正文上下文：' + truncate(cleanGeneratedImageText([
              topic && topic.summary, prompt
            ].filter(Boolean).join(' ')), 900)
          ].join('\n'),
          temperature: .72
        })
      }), 28000, 'AI 插画生成超时');
      if (!result.ok || !result.text) throw new Error(result.error || '文字 AI 没有返回 SVG');
      const svg = sanitizeAiSvg(result.text);
      const png = await svgToPng(svg);
      state.lastGeneratedImageKind = 'ai-svg';
      return png;
    } finally {
      hideLoading();
    }
  }

  async function generateVisibleFallbackImage(topic, prompt) {
    const query = cleanGeneratedImageText([topic && topic.title, prompt, '新闻配图'].filter(Boolean).join(' '));
    const asset = await findArticleImageAsset(query);
    if (asset && asset.url) {
      try {
        const embedded = await ensureEmbeddedImageSource(asset.url);
        state.lastGeneratedImageKind = 'real';
        return embedded;
      } catch (error) {}
    }
    state.lastGeneratedImageKind = 'card';
    const color = sectionInfo(topic && topic.section || 'general').color || '#4d8b69';
    return makeFallbackImage({
      title: truncate(cleanGeneratedImageText(topic && topic.title || prompt) || '新闻图卡', 64),
      sectionName: '自动生成新闻图卡'
    }, color);
  }

  async function generateAiIllustration(prompt) {
    const topic = state.article
      ? currentArticleImageTopic()
      : (articleSourceItems()[0] || leadItem());
    if (!topic) throw new Error('当前没有新闻主题');
    if (!state.config.imageAi || !state.config.imageAi.enabled || !state.config.imageAi.hasKey) {
      try {
        return await generateSvgIllustration(topic, prompt);
      } catch (error) {
        showToast('AI 插画暂不可用', '已自动改用真实图片或新闻图卡。', 'info');
        return await generateVisibleFallbackImage(topic, prompt);
      }
    }
    showLoading('正在生成 AI 写实配图', '图像模型正在生成具有真实摄影质感的新闻视觉。');
    try {
      const result = await api('/api/image-generate', {
        method: 'POST',
        body: JSON.stringify({
          prompt: [
            '生成一张写实、自然、有真实摄影质感的新闻配图。',
            '画面应克制、专业，避免卡通感、塑料感和夸张特效。',
            '不得生成媒体 Logo、水印或虚假现场标识，不冒充事件真实现场。',
            '画面中不要出现任何文字、数字、标题、字幕、图片位编号或排版占位符。',
            '事件标题：' + cleanGeneratedImageText(topic.title),
            '事件摘要：' + truncate(topic.summary, 260),
            prompt ? '额外要求：' + cleanGeneratedImageText(prompt) : ''
          ].filter(Boolean).join('\n'),
          size: '1024x1024'
        })
      });
      if (!result.ok || !result.url) throw new Error(result.error || '图像服务没有返回图片');
      const imageResponse = await fetch('/api/image?url=' + encodeURIComponent(result.url));
      if (!imageResponse.ok) throw new Error('生成图片读取失败');
      const blob = await imageResponse.blob();
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('生成图片转换失败'));
        reader.readAsDataURL(blob);
      });
      state.lastGeneratedImageKind = 'ai';
      return dataUrl;
    } catch (error) {
      showToast('专业图像模型暂不可用', '正在改用文字 AI 绘制原创插画。原提示：' + error.message, 'info');
      try {
        return await generateSvgIllustration(topic, prompt);
      } catch (svgError) {
        return await generateVisibleFallbackImage(topic, prompt);
      }
    } finally {
      hideLoading();
    }
  }

  function readImageFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('图片文件读取失败'));
      reader.readAsDataURL(file);
    });
  }

  function updatePresenterImageStatus() {
    if (!$('#presenterImageStatus')) return;
    $('#presenterImageStatus').textContent = state.presenterImage
      ? '已使用写实主播形象，重新生成会替换'
      : '未使用真人或写实形象';
  }

  async function generateRealisticPresenter() {
    if (!state.config.imageAi || !state.config.imageAi.enabled || !state.config.imageAi.hasKey) {
      showToast('写实主播需要图像模型', '请在设置中启用“AI 写实图片与人物生成”。文本 AI 无法生成真实感人物。', 'info');
      openSettings();
      return;
    }
    const female = state.presenter === 'female';
    showLoading('正在生成写实 AI 主播', '正在生成虚构的新闻主播形象，不使用真实公众人物肖像。');
    try {
      const result = await api('/api/image-generate', {
        method: 'POST',
        body: JSON.stringify({
          prompt: [
            '生成一位虚构的中国新闻视频主播，写实摄影风格，半身正面构图，正在自然讲述新闻。',
            '人物：' + (female ? '约30岁的知性女性，短发或低马尾，浅色衬衫与深色西装，自然妆容。' : '约35岁的沉稳男性，短发，深色西装与浅色衬衫。'),
            '场景：真实新闻演播室，柔和专业布光，景深自然，皮肤和布料有真实纹理。',
            '风格：纪实新闻摄影，不卡通、不塑料、不夸张美颜；面部清楚，适合竖屏视频。',
            '不得出现品牌Logo、水印、文字；人物必须是虚构形象，不模仿任何真实公众人物。'
          ].join('\n'),
          size: '1024x1024'
        })
      });
      if (!result.ok || !result.url) throw new Error(result.error || '图像服务没有返回人物图片');
      state.presenterImage = result.url;
      saveJson(KEYS.presenterImage, state.presenterImage);
      updatePresenterImageStatus();
      setCanvasRatio();
      showToast('写实 AI 主播已生成', '人物为 AI 虚构形象，成片中会明确标注。');
    } catch (error) {
      showToast('写实主播生成失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  async function captureVideoFrame(file) {
    const objectUrl = URL.createObjectURL(file);
    const video = document.createElement('video');
    video.muted = true;
    video.preload = 'metadata';
    video.src = objectUrl;
    try {
      await new Promise((resolve, reject) => {
        video.onloadedmetadata = resolve;
        video.onerror = () => reject(new Error('无法读取视频文件'));
        setTimeout(resolve, 5000);
      });
      const seekTime = Math.min(Math.max(.2, (video.duration || 2) / 3), Math.max(.2, (video.duration || 2) - .2));
      await new Promise((resolve) => {
        video.onseeked = resolve;
        try { video.currentTime = seekTime; } catch (error) { resolve(); }
        setTimeout(resolve, 3000);
      });
      const canvas = document.createElement('canvas');
      canvas.width = 1200;
      canvas.height = 675;
      const ctx = canvas.getContext('2d');
      const sourceRatio = video.videoWidth / Math.max(1, video.videoHeight);
      const targetRatio = 1200 / 675;
      let sx = 0, sy = 0, sw = video.videoWidth, sh = video.videoHeight;
      if (sourceRatio > targetRatio) {
        sw = video.videoHeight * targetRatio;
        sx = (video.videoWidth - sw) / 2;
      } else {
        sh = video.videoWidth / targetRatio;
        sy = (video.videoHeight - sh) / 2;
      }
      ctx.drawImage(video, sx, sy, sw, sh, 0, 0, 1200, 675);
      return canvas.toDataURL('image/jpeg', .88);
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  }

  async function ensureEmbeddedImageSource(src) {
    const value = String(src || '').trim();
    if (!value || value.startsWith('data:') || value.startsWith('blob:')) return value;
    if (!/^https?:\/\//i.test(value)) return value;
    const response = await withTimeout(
      fetch('/api/image?url=' + encodeURIComponent(value), { cache: 'no-store' }),
      4500,
      '图片下载超时，已改用新闻图卡'
    );
    if (!response.ok) throw new Error('图片下载失败');
    const blob = await response.blob();
    if (!blob.size) throw new Error('返回内容为空');
    const header = new Uint8Array(await blob.slice(0, 16).arrayBuffer());
    const isPng = header.length > 3 && header[0] === 0x89 && header[1] === 0x50 &&
      header[2] === 0x4e && header[3] === 0x47;
    const isJpeg = header.length > 2 && header[0] === 0xff && header[1] === 0xd8 &&
      header[2] === 0xff;
    const isGif = header.length > 2 && header[0] === 0x47 && header[1] === 0x49 &&
      header[2] === 0x46;
    const isWebp = header.length > 11 && header[8] === 0x57 && header[9] === 0x45 &&
      header[10] === 0x42 && header[11] === 0x50;
    const isSvg = /^image\/svg/i.test(blob.type || '');
    if (!isPng && !isJpeg && !isGif && !isWebp && !isSvg) {
      throw new Error('返回内容不是可识别的图片');
    }
    const normalizedType = isPng ? 'image/png' : isJpeg ? 'image/jpeg' :
      isGif ? 'image/gif' : isWebp ? 'image/webp' : 'image/svg+xml';
    const imageBlob = blob.type === normalizedType ? blob :
      new Blob([blob], { type: normalizedType });
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('图片转换失败'));
      reader.readAsDataURL(imageBlob);
    });
    const dimensions = await new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight });
      image.onerror = () => reject(new Error('图片解码失败'));
      image.src = dataUrl;
    });
    if (dimensions.width < 800 || dimensions.height < 450) {
      throw new Error('图片分辨率过低（' + dimensions.width + '×' + dimensions.height + '），已跳过');
    }
    return dataUrl;
  }

  function imagePreviewUrl(src) {
    const value = String(src || '');
    return /^https?:\/\//i.test(value) ? '/api/image?url=' + encodeURIComponent(value) : value;
  }

  async function insertArticleImage(src, caption, kind) {
    if (!state.article) {
      showToast('还没有文章', '请先生成或打开一篇图文。', 'info');
      return;
    }
    let displaySrc = String(src || '');
    if (/^https?:\/\//i.test(displaySrc)) {
      showToast('正在读取图片', '图片会先保存到当前文章，避免显示空白。', 'info');
      try {
        displaySrc = await ensureEmbeddedImageSource(displaySrc);
      } catch (error) {
        showToast('图片读取失败', error.message, 'error');
        return;
      }
    }
    state.article.cover = displaySrc;
    const material = {
      id: 'material_' + Date.now() + '_' + Math.random().toString(16).slice(2, 5),
      src: displaySrc,
      caption,
      kind: kind || 'other',
      createdAt: new Date().toISOString()
    };
    state.materials.unshift(material);
    state.materials = state.materials.slice(0, 40);
    saveJson(KEYS.materials, state.materials);
    const figure = document.createElement('figure');
    const image = document.createElement('img');
    const cap = document.createElement('figcaption');
    image.src = displaySrc;
    image.alt = state.article.title || '文章配图';
    cap.textContent = caption;
    figure.appendChild(image);
    figure.appendChild(cap);
    const body = $('#articleBody');
    const selection = window.getSelection();
    let inserted = false;
    const savedRange = state.articleInsertRange;
    const replaceNode = state.articleReplaceImageNode;
    if (replaceNode && body.contains(replaceNode)) {
      const target = replaceNode.closest('figure') || replaceNode;
      target.replaceWith(figure);
      inserted = true;
    } else if (savedRange && body.contains(savedRange.commonAncestorContainer)) {
      savedRange.deleteContents();
      savedRange.insertNode(figure);
      inserted = true;
    } else if (selection && selection.rangeCount && body.contains(selection.anchorNode)) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(figure);
      inserted = true;
    }
    if (!inserted) body.appendChild(figure);
    state.articleInsertRange = null;
    state.articleReplaceImageNode = null;
    persistArticle();
    closeModal();
    renderArticle();
    showToast('配图已加入文章', '封面候选也已同步更新。');
  }

  function cleanArticleImageContext(value) {
    return String(value || '')
      .replace(/【?图片位\s*\d*】?/g, ' ')
      .replace(/画面建议\s*[：:]?/g, ' ')
      .replace(/图注\s*[：:]?/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function articleImageContextFor(node) {
    if (!node) return '';
    let heading = /^H[23]$/.test(node.tagName) ? node.textContent || '' : '';
    let cursor = node.previousElementSibling;
    while (!heading && cursor) {
      if (/^H[23]$/.test(cursor.tagName)) {
        heading = cursor.textContent || '';
        break;
      }
      cursor = cursor.previousElementSibling;
    }
    if (!heading && node.parentElement) {
      cursor = node.parentElement.previousElementSibling;
      while (cursor) {
        if (/^H[23]$/.test(cursor.tagName)) {
          heading = cursor.textContent || '';
          break;
        }
        cursor = cursor.previousElementSibling;
      }
    }
    const own = node.textContent || '';
    const next = node.nextElementSibling && node.nextElementSibling.textContent || '';
    return cleanArticleImageContext([heading, own, next].filter(Boolean).join(' '));
  }

  function currentArticleImageTopic() {
    const articleTitle = ($('#articleTitle') && $('#articleTitle').value.trim()) ||
      (state.article && state.article.title) || '';
    let node = $('#articleBody');
    const range = state.articleInsertRange;
    if (range && range.startContainer) {
      const container = range.startContainer.nodeType === Node.ELEMENT_NODE
        ? range.startContainer : range.startContainer.parentElement;
      node = container && container.closest('p, h2, h3, blockquote, figure, div') || node;
    } else if (node) {
      node = node.querySelector('h2, h3, p') || node;
    }
    const context = articleImageContextFor(node);
    const bodyText = state.article ? stripHtml(state.article.html || '') : '';
    const source = state.article && articleSourceItems()[0];
    return {
      title: truncate([articleTitle, context].filter(Boolean).join(' '), 100) || '当前文章配图',
      summary: truncate(context || bodyText, 700),
      section: source && source.section || 'general'
    };
  }

  async function findArticleImageAsset(query, context) {
    const cacheKey = truncate(String(query || '').toLowerCase(), 100);
    const cached = articleImageAssetCache.get(cacheKey);
    if (cached && Date.now() - cached.at < 5 * 60 * 1000) return cached.item;
    try {
      const result = await withTimeout(
        api('/api/image-search?q=' + encodeURIComponent(truncate(query, 70))),
        3500,
        '图片检索超时'
      );
      const items = (result.items || []).filter((item) => item && item.url);
      if (!items.length) return null;
      const highResolution = items.filter((item) =>
        (Number(item.width) || 0) >= 1000 || (Number(item.height) || 0) >= 600);
      const candidates = highResolution.length ? highResolution : items;
      const grams = titleGrams(query + ' ' + (context || ''));
      const image = candidates.map((item, index) => {
        const candidate = [
          item.title, item.source, item.creator, item.license
        ].filter(Boolean).join(' ').toLowerCase();
        const relevance = grams.reduce((sum, gram) => sum + (candidate.includes(gram) ? 1 : 0), 0);
        const resolution = Math.min(8, Math.max(
          Number(item.width) || 0, Number(item.height) || 0) / 300);
        return { item, score: relevance * 3 + resolution, index };
      }).sort((first, second) => second.score - first.score || first.index - second.index)[0].item;
      articleImageAssetCache.set(cacheKey, { at: Date.now(), item: image });
      if (articleImageAssetCache.size > 40) {
        articleImageAssetCache.delete(articleImageAssetCache.keys().next().value);
      }
      return image;
    } catch (error) {
      articleImageAssetCache.set(cacheKey, { at: Date.now(), item: null });
      return null;
    }
  }

  function buildArticleFigure(src, caption, title) {
    const figure = document.createElement('figure');
    const image = document.createElement('img');
    const label = document.createElement('figcaption');
    image.src = src;
    image.alt = title || '文章配图';
    label.textContent = caption;
    figure.appendChild(image);
    figure.appendChild(label);
    return figure;
  }

  function updateArticleImageLayouts(root) {
    const container = root || $('#articleBody');
    if (!container) return;
    $$('img', container).forEach((image) => {
      const apply = () => {
        if (!image.naturalWidth || !image.naturalHeight) return;
        const figure = image.closest('figure') || image.parentElement;
        const caption = [
          image.alt, figure && figure.querySelector && figure.querySelector('figcaption') &&
            figure.querySelector('figcaption').textContent
        ].filter(Boolean).join(' ');
        const width = image.naturalWidth;
        const height = image.naturalHeight;
        const ratio = width / Math.max(1, height);
        image.classList.remove('article-image-wide', 'article-image-square',
          'article-image-portrait', 'article-image-lowres', 'article-image-chart');
        if (/图表|数据|表格|时间线|流程图|地图/.test(caption)) {
          image.classList.add('article-image-chart');
        } else if (ratio < .82) {
          image.classList.add('article-image-portrait');
        } else if (ratio < 1.16) {
          image.classList.add('article-image-square');
        } else {
          image.classList.add('article-image-wide');
        }
        if (width < 900) image.classList.add('article-image-lowres');
      };
      if (image.complete && image.naturalWidth) apply();
      else image.addEventListener('load', apply, { once: true });
    });
  }

  function showArticleImagePreview(src, caption, kind, regenerate) {
    showModal('图片预览', 'IMAGE PREVIEW',
      '<div class="generated-image-preview">' +
        '<img id="generatedImagePreview" src="' + escapeHtml(imagePreviewUrl(src)) + '" alt="配图预览">' +
        '<div><strong>' + (kind === 'ai' ? 'AI 生成配图' :
          kind === 'ai-svg' ? 'AI 原创插画' : kind === 'real' ? '真实图片素材' : '新闻图卡') +
          '</strong><p>' + escapeHtml(caption || '请确认图片内容与授权后再插入正文。') + '</p></div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" id="backToImageCenterBtn">返回配图中心</button>' +
      (regenerate
        ? '<button class="btn btn-secondary" type="button" id="regeneratePreviewImageBtn">重新生成</button>'
        : '') +
      '<button class="btn btn-primary" type="button" id="insertPreviewImageBtn">插入正文</button>');
    $('#backToImageCenterBtn').addEventListener('click', () => openMediaStudio());
    $('#insertPreviewImageBtn').addEventListener('click', () => insertArticleImage(src, caption, kind));
    if ($('#regeneratePreviewImageBtn')) {
      $('#regeneratePreviewImageBtn').addEventListener('click', regenerate);
    }
  }

  function showGeneratedImageSelection(batch) {
    state.generatedImageBatch = batch;
    showModal('请选择要插入的图片', 'SELECT GENERATED IMAGES',
      '<div class="generated-image-selection">' +
        '<p class="import-hint">已生成 ' + batch.candidates.length +
          ' 张候选图片，目前尚未插入正文。请勾选需要使用的图片。</p>' +
        '<div class="generated-image-selection-grid">' +
          batch.candidates.map((candidate, index) =>
            '<label class="generated-image-choice"><input type="checkbox" data-generated-image-select="' +
              index + '"><img src="' + escapeHtml(imagePreviewUrl(candidate.src)) +
              '" alt=""><span>' + String(index + 1).padStart(2, '0') + ' · ' +
              escapeHtml(candidate.label || '候选配图') + '</span></label>').join('') +
        '</div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>暂不插入</button>' +
      '<button class="btn btn-secondary" type="button" id="selectAllGeneratedImagesBtn">全选图片</button>' +
      '<button class="btn btn-primary" type="button" id="insertSelectedGeneratedImagesBtn">插入选中图片</button>');
    $('#selectAllGeneratedImagesBtn').addEventListener('click', () => {
      const boxes = $$('[data-generated-image-select]');
      const allSelected = boxes.every((box) => box.checked);
      boxes.forEach((box) => { box.checked = !allSelected; });
      $('#selectAllGeneratedImagesBtn').textContent = allSelected ? '全选图片' : '取消全选';
    });
    $('#insertSelectedGeneratedImagesBtn').addEventListener('click', async () => {
      const selectedIndexes = $$('[data-generated-image-select]:checked')
        .map((box) => Number(box.dataset.generatedImageSelect));
      if (!selectedIndexes.length) {
        showToast('还没有选择图片', '请先勾选至少一张图片，再点击插入。', 'info');
        return;
      }
      let inserted = 0;
      selectedIndexes.forEach((index) => {
        const candidate = batch.candidates[index];
        if (!candidate || !candidate.anchor) return;
        const figure = buildArticleFigure(candidate.src, candidate.caption, batch.title);
        const anchor = candidate.anchor;
        if (anchor.mode === 'replace' && anchor.node && anchor.node.parentNode) {
          anchor.node.replaceWith(figure);
        } else if (anchor.mode === 'after' && anchor.node && anchor.node.parentNode) {
          anchor.node.parentNode.insertBefore(figure, anchor.node.nextSibling);
        } else if (anchor.mode === 'before' && anchor.node && anchor.node.parentNode) {
          anchor.node.parentNode.insertBefore(figure, anchor.node);
        } else {
          batch.box.appendChild(figure);
        }
        if (!state.article.cover) state.article.cover = candidate.src;
        inserted += 1;
      });
      const remoteImages = $$('img[src^="http"]', batch.box).slice(0, 8);
      await Promise.all(remoteImages.map(async (image) => {
        try {
          image.src = await ensureEmbeddedImageSource(image.getAttribute('src'));
        } catch (error) {}
      }));
      state.article.html = batch.box.innerHTML;
      state.article.updatedAt = new Date().toISOString();
      state.generatedImageBatch = null;
      saveJson(KEYS.article, state.article);
      closeModal();
      renderArticle();
      showToast('已插入 ' + inserted + ' 张图片', '未勾选的候选图片没有写入文章。');
    });
  }

  function hideArticleCaretTools() {
    if ($('#articleCaretTools')) $('#articleCaretTools').hidden = true;
  }

  function captureArticleInsertionPoint() {
    const body = $('#articleBody');
    if (!body || !state.article) return false;
    const selection = window.getSelection();
    if (selection && selection.rangeCount && body.contains(selection.anchorNode)) {
      state.articleInsertRange = selection.getRangeAt(0).cloneRange();
      return true;
    }
    return Boolean(state.articleInsertRange);
  }

  function positionArticleCaretTools(clientX, clientY, range) {
    const tools = $('#articleCaretTools');
    if (!tools || !range || !$('#view-article').classList.contains('active')) return;
    const rect = range.getBoundingClientRect();
    const x = Number.isFinite(clientX) ? clientX : (rect.left || (window.innerWidth / 2));
    const y = Number.isFinite(clientY) ? clientY : (rect.top || (window.innerHeight / 2));
    tools.hidden = false;
    const width = tools.offsetWidth || 240;
    tools.style.left = Math.max(10, Math.min(window.innerWidth - width - 10, x - width / 2)) + 'px';
    tools.style.top = Math.max(10, y - (tools.offsetHeight || 46) - 10) + 'px';
  }

  async function generateArticleImageAtCaret() {
    if (!state.article) {
      showToast('还没有图文正文', '请先生成文章，再把鼠标放到需要配图的位置。', 'info');
      return;
    }
    captureArticleInsertionPoint();
    const range = state.articleInsertRange;
    if (!range) {
      showToast('请先在正文中点击需要插图的位置', null, 'info');
      return;
    }
    hideArticleCaretTools();
    const container = range.startContainer.nodeType === Node.ELEMENT_NODE
      ? range.startContainer
      : range.startContainer.parentElement;
    const nearby = container && container.closest('p, h2, h3, blockquote, div');
    const selectedText = cleanArticleImageContext(range.toString());
    const rawNearbyContext = [
      nearby && nearby.textContent,
      nearby && nearby.nextElementSibling && nearby.nextElementSibling.textContent
    ].filter(Boolean).join(' ');
    const nearbyContext = articleImageContextFor(nearby);
    const suggestionMatch = rawNearbyContext.match(/画面建议\s*[：:]?\s*([^。]{4,100})/);
    const context = truncate([selectedText, nearbyContext, $('#articleTitle').value || state.article.title || '']
      .filter(Boolean).join(' '), 140);
    const query = truncate([
      suggestionMatch && suggestionMatch[1],
      selectedText,
      nearbyContext,
      $('#articleTitle').value || state.article.title || ''
    ].filter(Boolean).join(' '), 90);
    showLoading('正在当前位置生成图片', '正在匹配真实图片；没有合适图片时会生成新闻图卡。');
    try {
      const asset = await findArticleImageAsset(query, context);
      let src = '';
      let caption = '自动生成新闻图卡 · 根据正文内容生成，不对应真实现场';
      let kind = 'card';
      if (asset && asset.url) {
        try {
          src = await ensureEmbeddedImageSource(asset.url);
          kind = 'real';
          caption = '真实图片素材 · ' + (asset.source || '公开图库') + ' · ' +
            (asset.creator || '') + ' · ' + (asset.license || '发布前请核对授权');
        } catch (error) {}
      }
      if (!src) {
        src = makeFallbackImage({
          title: truncate(cleanGeneratedImageText([suggestionMatch && suggestionMatch[1], nearbyContext, context]
            .filter(Boolean).join(' ')), 62),
          sectionName: '正文配图 · 新闻图卡'
        }, sectionInfo('general').color);
      }
      hideLoading();
      showArticleImagePreview(src, caption, kind);
    } catch (error) {
      showToast('当前位置配图失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  async function generateArticleImagesOneClick() {
    if (!state.article) {
      showToast('还没有图文正文', '请先生成或打开一篇文章，再点击一键配图。', 'info');
      return;
    }
    persistArticle();
    const box = document.createElement('div');
    box.innerHTML = $('#articleBody').innerHTML;
    const title = ($('#articleTitle').value || state.article.title || '新闻图文').trim();
    const anchors = [];
    const seenNodes = new Set();
    $$('p, div, blockquote', box).forEach((node) => {
      if (seenNodes.has(node) || Array.from(seenNodes).some((parent) => parent.contains(node)) ||
          node.querySelector('img')) return;
      const text = (node.textContent || '').trim();
      if (!/图片位\s*\d*|插入图片|配图位置/.test(text) || text.length > 360) return;
      const parent = node.parentElement;
      if (parent && parent !== box && /图片位\s*\d*/.test(parent.textContent || '') &&
          (parent.textContent || '').trim().length < 500) {
        if (!seenNodes.has(parent)) {
          seenNodes.add(parent);
          anchors.push({ node: parent, mode: 'replace' });
        }
      } else {
        seenNodes.add(node);
        anchors.push({ node, mode: 'replace' });
      }
    });
    const headings = $$('h2', box);
    if (!anchors.length) {
      if (headings[0]) anchors.push({ node: headings[0], mode: 'after' });
      if (headings.length > 1) anchors.push({ node: headings[headings.length - 1], mode: 'before' });
    }
    const desiredImages = Math.min(6, Math.max(4, headings.length + 1));
    headings.slice(0, 6).forEach((heading) => {
      if (anchors.length >= desiredImages) return;
      if (anchors.some((anchor) => anchor.node === heading ||
          anchor.node && anchor.node.parentElement === heading.parentElement &&
          anchor.node === heading.nextElementSibling)) return;
      anchors.push({ node: heading, mode: 'after' });
    });
    if (anchors.length < desiredImages) {
      $$('p', box).forEach((paragraph) => {
        if (anchors.length >= desiredImages || paragraph.querySelector('img') ||
            /图片位|画面建议|图注/.test(paragraph.textContent || '') ||
            String(paragraph.textContent || '').trim().length < 16) return;
        anchors.push({ node: paragraph, mode: 'after' });
      });
    }
    if (!anchors.length) anchors.push({ node: null, mode: 'append' });
    const limited = anchors.slice(0, 6);
    const imageContexts = limited.map((anchor, index) => {
      const rawContext = [
        anchor.node && anchor.node.textContent,
        anchor.node && anchor.node.nextElementSibling && anchor.node.nextElementSibling.textContent
      ].filter(Boolean).join(' ');
      const context = articleImageContextFor(anchor.node);
      const suggestion = rawContext.match(/画面建议[：:]?\s*([^。\n]{4,90})/);
      return {
        context,
        query: truncate([
          suggestion && suggestion[1],
          context,
          title,
          ['新闻现场', '人物与生活', '城市与公共空间', '背景与细节'][index] || ''
        ].filter(Boolean).join(' '), 90)
      };
    });
    showLoading('正在一键生成配图', '正在读取图片位并匹配真实图片素材，请稍候。');
    try {
      const assets = await Promise.all(imageContexts.map((entry) =>
        findArticleImageAsset(entry.query, entry.context)));
      const fallbackColor = sectionInfo(state.article.focusId && state.news.find((item) =>
        item.id === state.article.focusId)?.section || 'general').color;
      const candidates = await Promise.all(limited.map(async (anchor, index) => {
        const asset = assets[index];
        let src = '';
        let loadedReal = false;
        if (asset && asset.url) {
          try {
            src = await ensureEmbeddedImageSource(asset.url);
            loadedReal = Boolean(src);
          } catch (error) {
            src = '';
          }
        }
        if (!src) src = makeFallbackImage({
          title: truncate(cleanGeneratedImageText(imageContexts[index].context || title), 62),
          sectionName: '自动生成新闻图卡'
        }, fallbackColor || '#4d8b69');
        const caption = loadedReal
          ? '真实图片素材 · ' + (asset.source || '公开图库') + ' · ' +
            (asset.creator || '') + ' · ' + (asset.license || '发布前请核对授权')
          : '自动生成图卡 · 根据文章内容生成，不对应真实现场';
        return {
          src,
          caption,
          label: loadedReal ? '真实图片候选' : '新闻图卡候选',
          anchor
        };
      }));
      hideLoading();
      showGeneratedImageSelection({ candidates, box, title });
    } catch (error) {
      showToast('一键配图失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  function openMaterialLibrary() {
    const real = [];
    state.news.forEach((item) => {
      (item.gallery || []).concat(item.imageOriginal ? [item.imageOriginal] : []).forEach((url) => {
        if (/^https?:\/\//i.test(url) && !real.some((entry) => entry.url === url)) {
          real.push({ url, item, caption: item.source || '新闻来源' });
        }
      });
    });
    showModal('本机素材库', 'MATERIAL LIBRARY',
      '<div class="media-source-section"><div class="media-source-head"><strong>自动抓取的真实新闻图片</strong><span>' + real.length + ' 张</span></div>' +
        (real.length ? '<div class="real-image-grid material-library-grid">' + real.slice(0, 18).map((entry, index) =>
          '<button class="real-image-option" type="button" data-library-real="' + index + '"><img src="' +
          escapeHtml(imagePreviewUrl(entry.url)) + '" alt=""><span>' + escapeHtml(entry.caption) + '</span></button>').join('') + '</div>'
          : '<div class="media-empty">刷新新闻或从 Edge 采集页面后，原文图片会自动进入这里</div>') +
      '</div>' +
      '<div class="media-source-section"><div class="media-source-head"><strong>我的生成与截取素材</strong><span>' + state.materials.length + ' 个</span></div>' +
        (state.materials.length ? '<div class="real-image-grid material-library-grid">' + state.materials.slice(0, 18).map((material, index) =>
          '<button class="real-image-option" type="button" data-library-material="' + index + '"><img src="' +
          escapeHtml(imagePreviewUrl(material.src)) + '" alt=""><span>' + escapeHtml(material.kind === 'ai' ? 'AI配图' :
          material.kind === 'video' ? '视频截帧' : material.kind === 'upload' ? '本地上传' : '素材') + '</span></button>').join('') + '</div>'
          : '<div class="media-empty">AI 插画、本地上传和视频截帧会保存在这里</div>') +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>' +
      '<button class="btn btn-primary" type="button" id="openMediaFromLibrary">打开配图中心</button>');
    $$('.real-image-option[data-library-real]').forEach((button) => {
      button.addEventListener('click', () => {
        const entry = real[Number(button.dataset.libraryReal)];
        if (entry) insertArticleImage(entry.url, '真实新闻图片 · 来源：' + entry.caption + '（发布前请确认授权）', 'real');
      });
    });
    $$('.real-image-option[data-library-material]').forEach((button) => {
      button.addEventListener('click', () => {
        const material = state.materials[Number(button.dataset.libraryMaterial)];
        if (material) insertArticleImage(material.src, material.caption, material.kind);
      });
    });
    $('#openMediaFromLibrary').addEventListener('click', () => {
      closeModal();
      openMediaStudio();
    });
  }

  function openMediaStudio() {
    if (!state.article) {
      showToast('请先生成图文', '配图会直接插入当前文章。', 'info');
      return;
    }
    captureArticleInsertionPoint();
    hideArticleCaretTools();
    const articleTitle = ($('#articleTitle') && $('#articleTitle').value.trim()) ||
      state.article && state.article.title || '';
    const firstBodyBlock = $('#articleBody') && $('#articleBody').querySelector('h2, h3, p');
    const articleContext = firstBodyBlock && cleanArticleImageContext(
      articleImageContextFor(firstBodyBlock)) || '';
    const articleSearchQuery = truncate(cleanArticleImageContext([
      articleTitle,
      articleContext
    ].filter(Boolean).join(' ')), 90) || '当前文章配图';
    const articleTitleGrams = titleGrams(articleTitle);
    const realItems = [];
    articleSourceItems().forEach((item) => {
      const itemTitle = String(item.title || '');
      const relevance = articleTitleGrams.reduce(
        (score, gram) => score + (itemTitle.includes(gram) ? 1 : 0), 0);
      if (relevance >= 2 && item.imageOriginal &&
          !realItems.some((entry) => entry.imageOriginal === item.imageOriginal)) {
        realItems.push(item);
      }
    });
    const realGallery = realItems.slice(0, 6);
    const topic = currentArticleImageTopic();
    const imageQuery = articleSearchQuery || topic.title || '新闻现场';
    const baiduImageUrl = 'https://image.baidu.com/search/index?tn=baiduimage&word=' + encodeURIComponent(imageQuery);
    const vcgImageUrl = 'https://www.vcg.com/creative-image/?q=' + encodeURIComponent(imageQuery);
    showModal('配图中心', 'IMAGE & VIDEO SOURCES',
      '<div class="media-source-section"><div class="media-source-head"><strong>文章排版类型</strong><span>切换后立即应用到当前图文</span></div>' +
        '<div class="media-template-options">' + Object.keys(ARTICLE_TEMPLATE_LABELS).map((id) =>
          '<button type="button" class="' + (state.articleTemplate === id ? 'active' : '') +
          '" data-media-template="' + id + '">' + ARTICLE_TEMPLATE_LABELS[id] + '</button>').join('') + '</div></div>' +
      '<div class="media-source-section"><div class="media-source-head"><strong>真实新闻图片</strong><span>来自原文，发布前确认授权</span></div>' +
        (realGallery.length ? '<div class="real-image-grid">' + realGallery.map((item) =>
          '<button class="real-image-option" type="button" data-realism-id="' + escapeHtml(item.id) + '"><img src="' +
          escapeHtml(imagePreviewUrl(item.imageOriginal)) + '" alt=""><span>' + escapeHtml(item.source || '新闻来源') + '</span></button>').join('') + '</div>'
          : '<div class="media-empty">当前素材没有抓取到真实新闻图片</div>') +
      '</div>' +
      '<div class="media-source-section"><div class="media-source-head"><strong>百度图库与视觉中国</strong><span>真实图片检索 · 发布前确认授权</span></div>' +
        '<div class="media-url-row"><input id="realImageSearchQuery" type="search" value="' + escapeHtml(truncate(imageQuery, 60)) + '" placeholder="输入图片检索关键词"></div>' +
        '<div class="article-source-tools"><button type="button" id="searchBaiduImagesBtn">搜索百度图片</button>' +
        '<a href="' + escapeHtml(vcgImageUrl) + '" target="_blank" rel="noopener noreferrer" id="openVcgImageBtn">打开视觉中国图库</a></div>' +
        '<p class="import-hint">百度图片用于查找真实事件图片；视觉中国中的商业图片必须取得授权后再发布，程序不会绕过付费或水印限制。</p>' +
        '<div class="article-real-results" id="articleRealImageResults"></div></div>' +
      '<div class="media-source-section"><div class="media-source-head"><strong>AI 写实配图</strong><span>不用于冒充现场照片</span></div>' +
        '<div class="ai-image-form"><textarea id="aiImagePrompt" placeholder="可选：例如清晨城市、自然光、纪实摄影、不出现真实公众人物"></textarea>' +
        '<button class="btn btn-secondary" type="button" id="generateAiImageBtn">' + icon('wand') + '生成并预览配图</button></div></div>' +
      '<div class="media-source-section"><div class="media-source-head"><strong>本地上传 / 视频截帧</strong><span>仅处理你选择的文件</span></div>' +
        '<div class="media-file-actions"><label class="btn btn-secondary">上传图片<input id="localImageInput" type="file" accept="image/*"></label>' +
        '<label class="btn btn-secondary">从视频截帧<input id="localVideoInput" type="file" accept="video/*"></label></div></div>' +
      '<div class="media-source-section"><div class="media-source-head"><strong>网络图片地址</strong><span>其他抓取方式</span></div>' +
        '<div class="media-url-row"><input id="mediaImageUrl" type="url" placeholder="粘贴允许使用的图片地址"><button class="btn btn-secondary" type="button" id="useMediaUrlBtn">使用</button></div></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>');
    $$('.real-image-option').forEach((button) => {
      button.addEventListener('click', () => {
        const item = state.news.find((entry) => entry.id === button.dataset.realismId);
        if (item) showArticleImagePreview(item.imageOriginal,
          '真实新闻图片 · 来源：' + (item.source || '公开资讯') + '（发布前请确认授权）', 'real');
      });
    });
    $$('[data-media-template]').forEach((button) => {
      button.addEventListener('click', () => {
        selectArticleTemplate(button.dataset.mediaTemplate);
        $$('[data-media-template]').forEach((item) =>
          item.classList.toggle('active', item.dataset.mediaTemplate === state.articleTemplate));
        showToast('文章排版已切换', ARTICLE_TEMPLATE_LABELS[state.articleTemplate]);
      });
    });
    $('#openVcgImageBtn').addEventListener('click', (event) => {
      const query = $('#realImageSearchQuery').value.trim() || imageQuery;
      event.currentTarget.href = 'https://www.vcg.com/creative-image/?q=' + encodeURIComponent(query);
    });
    $('#searchBaiduImagesBtn').addEventListener('click', async () => {
      const query = $('#realImageSearchQuery').value.trim() || imageQuery;
      const results = $('#articleRealImageResults');
      const button = $('#searchBaiduImagesBtn');
      const fallbackUrl = 'https://image.baidu.com/search/index?tn=baiduimage&word=' + encodeURIComponent(query);
      button.disabled = true;
      results.innerHTML = '<div class="media-empty">正在检索百度图片…</div>';
      try {
        const response = await api('/api/image-search?source=baidu&q=' + encodeURIComponent(query));
        const allItems = response.items || [];
        const highResolution = allItems.filter((image) =>
          (Number(image.width) || 0) >= 1000 || (Number(image.height) || 0) >= 600);
        const items = highResolution.length ? highResolution : allItems;
        results.innerHTML = items.length ? items.map((image, index) =>
          '<button type="button" data-baidu-image="' + index + '"><img src="' +
          escapeHtml(imagePreviewUrl(image.thumbnail || image.url)) + '" alt=""><span>' +
          escapeHtml(image.creator || '百度图片') +
          (image.width || image.height ? ' · ' + (image.width || '?') + '×' + (image.height || '?') : '') +
          '</span></button>').join('')
          : '<div class="media-empty">没有找到图片。<a href="' + escapeHtml(fallbackUrl) +
            '" target="_blank" rel="noopener noreferrer">打开百度图片搜索</a></div>';
        $$('[data-baidu-image]').forEach((imageButton) => {
          imageButton.addEventListener('click', () => {
            const image = items[Number(imageButton.dataset.baiduImage)];
            if (!image) return;
            showArticleImagePreview(image.url, '真实图片 · 百度图片检索 · 来源：' +
              (image.creator || image.landingUrl || '原网页') + '（发布前确认版权授权）', 'real');
          });
        });
      } catch (error) {
        results.innerHTML = '<div class="media-empty">' + escapeHtml(error.message) +
          '<br><a href="' + escapeHtml(fallbackUrl) + '" target="_blank" rel="noopener noreferrer">打开百度图片搜索</a></div>';
      } finally {
        button.disabled = false;
      }
    });
    $('#generateAiImageBtn').addEventListener('click', async () => {
      const button = $('#generateAiImageBtn');
      const prompt = $('#aiImagePrompt').value.trim();
      button.disabled = true;
      try {
        const openPreview = async () => {
          const dataUrl = await generateAiIllustration(prompt);
          const kind = state.lastGeneratedImageKind;
          const caption = kind === 'real'
            ? '真实图片素材 · 自动匹配公开图库 · 发布前请确认授权'
            : kind === 'card'
              ? '自动生成新闻图卡 · 根据文章主题生成，不对应真实现场'
            : kind === 'ai-svg'
              ? 'AI 原创插画 · 根据当前正文上下文生成，不含文字和真实人物肖像'
              : 'AI 写实配图 · 根据事件主题生成，不对应真实现场';
          showArticleImagePreview(dataUrl, caption, kind || 'ai', openPreview);
        };
        await openPreview();
      } catch (error) {
        showToast('AI 配图生成失败', error.message, 'error');
      } finally {
        button.disabled = false;
      }
    });
    $('#localImageInput').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      try {
        const dataUrl = await readImageFile(file);
        showArticleImagePreview(dataUrl, '本地上传图片 · ' + file.name, 'upload');
      } catch (error) {
        showToast('图片读取失败', error.message, 'error');
      }
    });
    $('#localVideoInput').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      showLoading('正在截取视频画面', '正在从你选择的视频中读取一帧作为文章配图。');
      try {
        const dataUrl = await captureVideoFrame(file);
        hideLoading();
        showArticleImagePreview(dataUrl, '视频截帧 · ' + file.name, 'video');
      } catch (error) {
        hideLoading();
        showToast('视频截帧失败', error.message, 'error');
      }
    });
    $('#useMediaUrlBtn').addEventListener('click', () => {
      const url = $('#mediaImageUrl').value.trim();
      if (!/^https?:\/\//i.test(url)) {
        showToast('请输入完整的图片地址', null, 'info');
        return;
      }
      showArticleImagePreview(url, '网络图片 · ' + (hostName(url) || '外部来源') + '（发布前确认授权）', 'network');
    });
  }

  function renderArticle() {
    if ($('#articleStylePreset')) {
      $('#articleStylePreset').value = state.article && state.article.style || state.articleStyle || 'cctv';
      $('#articleWriterState').textContent = state.codexReady && state.config.ai && state.config.ai.hasKey
        ? 'Codex / AI 可用'
        : state.codexReady ? 'Codex 可用' : state.config.ai && state.config.ai.hasKey ? 'AI 可用' : '未连接';
    }
    if ($('#articleLayoutPreset')) {
      state.articleTemplate = state.article && state.article.template || state.articleTemplate || 'news';
      $('#articleLayoutPreset').value = ARTICLE_TEMPLATE_PROMPTS[state.articleTemplate] ? state.articleTemplate : 'news';
      renderArticleTemplateStrip();
    }
    if ($('#articleContentMode')) {
      state.articleContentMode = state.article && state.article.contentMode ||
        state.articleContentMode || 'fact';
      if (!ARTICLE_CONTENT_MODES[state.articleContentMode]) state.articleContentMode = 'fact';
      $('#articleContentMode').value = state.articleContentMode;
    }
    renderArticleAnglePicker();
    if (!state.article) {
      if ($('#articleBody') && !$('#articleBody').textContent.trim()) {
        $('#articleBody').innerHTML = '<p>还没有文章。返回首页点击“一键生成图文”，或从今日资讯中挑选素材。</p>';
      }
      return;
    }
    state.articleMode = state.article.articleMode || state.articleMode || 'micro';
    state.articleContentMode = state.article.contentMode || state.articleContentMode || 'fact';
    state.articleScope = state.article.articleScope || state.articleScope || 'single';
    $$('#articleModeSwitch button').forEach((button) => {
      button.classList.toggle('active', button.dataset.articleMode === state.articleMode);
    });
    $$('#articleScopeSwitch button').forEach((button) => {
      button.classList.toggle('active', button.dataset.articleScope === state.articleScope);
    });
    $('#articleStatus').textContent = state.article.aiGenerated
      ? 'AI辅助 · ' + articleModeLabel(state.articleMode) +
        (state.articleScope === 'multi' ? ' · 多事件' : '')
      : (state.articleScope === 'multi' ? '多事件 · ' : '') +
        articleModeLabel(state.articleMode) + '模板';
    const title = $('#articleTitle');
    const body = $('#articleBody');
    if (document.activeElement !== title) title.value = state.article.title;
    if (document.activeElement !== body) body.innerHTML = state.article.html;
    updateArticleImageLayouts(body);
    const cover = $('#coverChip');
    if (state.article.cover) {
      cover.hidden = false;
      cover.innerHTML = '<img src="' + escapeHtml(state.article.cover) + '" alt=""><div><strong>文章封面</strong><small>已选用首条资讯图片</small></div>' +
        '<button type="button" id="changeCoverBtn">更换</button>';
    } else {
      cover.hidden = true;
      cover.innerHTML = '';
    }
    renderArticleSources();
    updateArticleMetrics();
  }

  function renderArticleSources() {
    const items = articleSourceItems();
    $('#articleSources').innerHTML = items.length ? items.map((item) =>
      '<div class="source-item"><input type="checkbox" data-article-source-select="' +
      escapeHtml(item.id) + '"' + (state.articleSourceSelected.includes(item.id) ? ' checked' : '') +
      '><span class="source-logo">' + escapeHtml((item.source || '来').slice(0, 1)) + '</span><div><strong>' +
      escapeHtml(item.title) + '</strong><a href="' + escapeHtml(item.url) + '" target="_blank" rel="noreferrer">' +
      escapeHtml(item.source) + ' · 查看原文</a></div>' +
      '<button type="button" class="source-open-software" data-open-source-software="' +
      escapeHtml(item.url) + '">打开软件</button></div>'
    ).join('') : '<div class="empty-draft">暂无来源</div>';
    $('#sourceCount').textContent = items.length + ' 个来源';
  }

  function updateArticleMetrics() {
    if (!$('#articleTitle')) return;
    const title = $('#articleTitle').value;
    const body = $('#articleBody');
    const plain = body.innerText || '';
    const imageCount = $$('img', body).length;
    $('#titleCount').textContent = title.length + ' / 30';
    $('#articleMetrics').textContent = plain.replace(/\s/g, '').length + ' 字 · ' + imageCount + ' 张图片';
    const imageOk = imageCount > 0;
    const titleOk = title.length >= 6 && title.length <= 30;
    $('#readyScore').textContent = imageOk && titleOk ? '基础检查通过' : '请补充内容';
  }

  function persistArticle() {
    if (!state.article) return;
    state.article.title = $('#articleTitle').value.trim();
    state.article.html = $('#articleBody').innerHTML;
    state.article.updatedAt = new Date().toISOString();
    state.article.contentMode = state.articleContentMode;
    saveJson(KEYS.article, state.article);
    updateArticleMetrics();
  }

  function saveDraftLocal() {
    if (!state.article) return;
    const draft = Object.assign({}, state.article, {
      plainText: stripHtml(state.article.html),
      updatedAt: new Date().toISOString()
    });
    const index = state.drafts.findIndex((item) => item.id === draft.id);
    if (index >= 0) state.drafts[index] = draft;
    else state.drafts.unshift(draft);
    state.drafts = state.drafts.slice(0, 30);
    saveJson(KEYS.drafts, state.drafts);
    renderDrafts();
  }

  async function saveArticleToServer(showResult) {
    persistArticle();
    if (!state.article) {
      showToast('还没有文章', '请先生成一篇图文。', 'info');
      return false;
    }
    saveWorkToLibrary(buildWorkArtifact('article', state.article, 'manual_article_' + Date.now()), 'completed');
    try {
      await api('/api/draft', {
        method: 'POST',
        body: JSON.stringify({
          title: state.article.title,
          html: state.article.html,
          text: stripHtml(state.article.html),
          cover: state.article.cover,
          tags: state.article.tags,
          sources: state.article.sourceIds,
          kind: 'article'
        })
      });
      if (showResult) showToast('草稿已保存', '已保存到程序的数据目录。');
      return true;
    } catch (error) {
      if (showResult) showToast('保存失败', error.message, 'error');
      return false;
    }
  }

  async function copyArticle() {
    persistArticle();
    if (!state.article) return false;
    const fullHtml = '<h1>' + escapeHtml(state.article.title) + '</h1>' + state.article.html;
    const plain = state.article.title + '\n\n' + stripHtml(state.article.html);
    try {
      if (navigator.clipboard && window.ClipboardItem) {
        await navigator.clipboard.write([new ClipboardItem({
          'text/html': new Blob([fullHtml], { type: 'text/html' }),
          'text/plain': new Blob([plain], { type: 'text/plain' })
        })]);
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(plain);
      } else {
        throw new Error('clipboard unavailable');
      }
      return true;
    } catch (error) {
      const area = document.createElement('textarea');
      area.value = plain;
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      const copied = document.execCommand('copy');
      area.remove();
      return copied;
    }
  }

  async function publishArticle() {
    if (!state.article) {
      showToast('请先生成图文', '返回首页点击“一键生成图文”。', 'info');
      return;
    }
    await saveArticleToServer(false);
    const copied = await copyArticle();
    showModal('内容已准备到今日头条', 'SEND TO TOUTIAO',
      '<div class="publish-step"><span>01</span><div><strong>' + (copied ? '标题和正文已复制' : '请先在编辑器内手动复制') + '</strong><p>新闻图片会随富文本一起复制，粘贴后请在头条编辑器里检查。</p></div></div>' +
      '<div class="publish-step"><span>02</span><div><strong>打开创作后台，按 Ctrl + V</strong><p>补充封面、核验素材授权和事实信息。</p></div></div>' +
      '<div class="publish-step"><span>03</span><div><strong>由你确认最终发布</strong><p>程序不保存账号密码，也不绕过平台风控。</p></div></div>' +
      '<div class="modal-note">' + icon('check') + '<p>如果图片没有随粘贴进入，可在头条编辑器中从原文链接重新上传。</p></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>返回编辑</button>' +
      '<button class="btn btn-primary" type="button" id="modalOpenToutiao">' + icon('external') + '打开今日头条并粘贴</button>');
    $('#modalOpenToutiao').addEventListener('click', () => openToutiao(state.config.toutiaoUrl));
  }

  async function openToutiao(url) {
    closeModal();
    try {
      const result = await api('/api/open', { method: 'POST', body: JSON.stringify({ url }) });
      showToast(result.browser === 'edge-direct' || result.browser === 'microsoft-edge-protocol'
        ? '已在 Microsoft Edge 打开今日头条'
        : '已用系统浏览器打开今日头条',
      '登录后按 Ctrl + V 粘贴已复制内容。', 'info');
    } catch (error) {
      showToast('打开失败', error.message, 'error');
    }
  }

  function openDraft(id) {
    const draft = state.drafts.find((item) => item.id === id);
    if (!draft) return;
    state.article = Object.assign({}, draft);
    state.articleMode = draft.articleMode || 'micro';
    state.articleScope = draft.articleScope || 'single';
    state.articleFocusId = draft.focusId || draft.sourceIds?.[0] || '';
    saveJson(KEYS.article, state.article);
    renderArticle();
    showView('article');
  }

  function articleToVideo() {
    if (!state.article) {
      showToast('还没有文章', '请先生成或打开一篇图文。', 'info');
      return;
    }
    persistArticle();
    prepareOriginalVideoProject(
      state.article.title || '文章改编视频',
      stripHtml(state.article.html || '')
    );
  }

  async function generateVideoFromTopic(topicId, options) {
    const topic = state.news.find((item) => item.id === topicId);
    if (!topic) {
      showToast('找不到这条新闻素材', '请重新刷新或导入内容。', 'info');
      return;
    }
    const settings = options || {};
    prepareOriginalVideoProject(settings.title || topic.title, settings.capturedText || topic.detailText || topic.summary);
  }

  function openProgram(mode) {
    state.programMode = mode === 'story' ? 'story' : 'radio';
    const available = state.episodes.filter((episode) => episode.type === state.programMode);
    state.currentEpisodeId = available.length ? available[0].id : '';
    showView('programs');
    if (!available.length && state.news.length) setTimeout(() => createProgramEpisode(), 80);
  }

  function seedNovelPromptFromLatest() {
    const prompt = $('#novelInspiration');
    if (!prompt || state.novel || prompt.value.trim()) return;
    const items = visibleNews().length ? visibleNews().slice(0, 2) : state.news.slice(0, 2);
    if (!items.length) return;
    prompt.value = '参考今天的最新热点作为社会背景，创作一篇原创小说。只提炼现实处境和人物关系，不把虚构故事写成真实新闻。\n\n' +
      items.map((item) => item.title + '。' + truncate(item.summary, 180)).join('\n');
    showToast('已加入最新热点背景', '可以继续补充人物、冲突和结局，然后点击“生成原创小说”。', 'info');
  }

  function renderPrograms() {
    if (!$('#programEpisodeList')) return;
    const radio = state.programMode === 'radio';
    $('#programPageTitle').textContent = radio ? '热点电台' : '故事会';
    $('#programPageHint').textContent = radio
      ? '把多条热点整理成一期可听、可看的资讯电台。'
      : '围绕一个事件，整理成一段克制、完整的故事讲述。';
    $$('#programTabs button').forEach((button) => button.classList.toggle('active', button.dataset.programMode === state.programMode));
    const episodes = state.episodes.filter((episode) => episode.type === state.programMode);
    $('#programEpisodeCount').textContent = episodes.length + ' 期';
    if (!episodes.some((episode) => episode.id === state.currentEpisodeId)) {
      state.currentEpisodeId = episodes.length ? episodes[0].id : '';
    }
    $('#programEpisodeList').innerHTML = episodes.length ? episodes.map((episode) =>
      '<div class="program-episode' + (episode.id === state.currentEpisodeId ? ' active' : '') +
      '" data-episode-id="' + escapeHtml(episode.id) + '"><span class="program-cover ' + escapeHtml(episode.type) + '">' +
      (episode.cover ? '<img src="' + escapeHtml(episode.cover) + '" alt="">' : (radio ? '播' : '事')) +
      '</span><div><strong>' + escapeHtml(episode.title) + '</strong><small>' +
      (episode.sourceIds || []).length + ' 个素材 · ' + new Date(episode.createdAt).toLocaleDateString('zh-CN') +
      '</small></div></div>'
    ).join('') : '<div class="empty-program">还没有节目。点击“生成新一期”，程序会使用当前勾选的热点生成脚本。</div>';
    const current = episodes.find((episode) => episode.id === state.currentEpisodeId);
    $('#programTypeMark').textContent = radio ? 'RADIO' : 'STORY';
    $('#programEpisodeTitle').value = current ? current.title : '';
    $('#programEpisodeScript').value = current ? current.script : '';
    $('#programEpisodeMeta').textContent = current
      ? '更新于 ' + new Date(current.updatedAt || current.createdAt).toLocaleString('zh-CN')
      : '选择或生成一期节目';
    $('#programSaveState').textContent = current ? '已保存在本机' : '尚未生成节目';
  }

  function createProgramEpisode() {
    const items = state.programMode === 'radio' ? multiEventItems().slice(0, 4) : ensureSources(1).slice(0, 1);
    if (!items.length) {
      showToast('还没有节目素材', '请先刷新热点或从 Edge 导入内容。', 'info');
      return;
    }
    const date = formatDate();
    let title;
    let script;
    if (state.programMode === 'radio') {
      title = '热点电台｜' + date.month + '月' + date.day + '日新闻简报';
      script = '各位好，欢迎收听热点电台。今天是' + date.full + '，下面为你梳理几条值得关注的新闻。\n\n';
      items.forEach((item, index) => {
        script += '第' + (index + 1) + '条，' + item.title + '。据' + (item.source || '公开报道') + '，' +
          (item.summary || firstSentence(item.summary)) + '\n\n';
      });
      script += '以上就是本期的新闻内容。热点变化很快，节目中的信息请以权威渠道最新发布为准。感谢收听，我们下期见。';
    } else {
      const item = items[0];
      title = '故事会｜' + truncate(item.title, 20);
      script = '今天的故事，从一则新闻说起。\n\n' + item.title + '。\n\n据' + (item.source || '公开报道') +
        '，' + (item.summary || firstSentence(item.summary)) + '\n\n' +
        analysisFor(item, 0) + '\n\n' +
        '一条新闻背后，往往有更具体的人和更长久的生活。我们在关注进展的同时，也需要给事实留下被核验的时间。';
    }
    const episode = {
      id: 'episode_' + Date.now(),
      type: state.programMode,
      title,
      script,
      sourceIds: items.map((item) => item.id),
      cover: items.find((item) => item.imageOriginal)?.imageOriginal || items.find((item) => item.image)?.image || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    state.episodes.unshift(episode);
    state.episodes = state.episodes.slice(0, 60);
    state.currentEpisodeId = episode.id;
    saveJson(KEYS.episodes, state.episodes);
    renderPrograms();
    showToast('新一期节目已生成', '可以直接修改脚本、试听或转为短视频。');
  }

  function saveProgramEpisode(showToastMessage) {
    const episode = state.episodes.find((item) => item.id === state.currentEpisodeId);
    if (!episode) return null;
    episode.title = $('#programEpisodeTitle').value.trim() || episode.title;
    episode.script = $('#programEpisodeScript').value.trim();
    episode.updatedAt = new Date().toISOString();
    saveJson(KEYS.episodes, state.episodes);
    $('#programSaveState').textContent = '刚刚保存';
    if (showToastMessage) showToast('节目已保存');
    renderPrograms();
    return episode;
  }

  async function previewProgramAudio() {
    const episode = saveProgramEpisode(false);
    if (!episode || !episode.script) {
      showToast('节目脚本为空', '请先生成一期节目。', 'info');
      return;
    }
    showLoading('正在生成节目音频', '正在合成电台旁白。');
    try {
      const blob = await synthesizeTts(truncate(episode.script, 1400));
      if (state.programAudioUrl) URL.revokeObjectURL(state.programAudioUrl);
      state.programAudioUrl = URL.createObjectURL(blob);
      const audio = new Audio(state.programAudioUrl);
      await audio.play();
      showToast('正在播放本期节目', '可继续编辑或转为短视频。', 'info');
    } catch (error) {
      showToast('节目音频生成失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  function programToVideo() {
    const episode = saveProgramEpisode(false);
    if (!episode) {
      showToast('还没有节目', '请先生成新一期。', 'info');
      return;
    }
    prepareOriginalVideoProject(episode.title, episode.script);
  }

  function novelTextToHtml(text) {
    return String(text || '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((line) => {
      if (/^#{1,3}\s+/.test(line)) return '<h2>' + escapeHtml(line.replace(/^#{1,3}\s+/, '')) + '</h2>';
      if (/^(第[一二三四五六七八九十百\d]+[章节卷]|【[^】]+】)/.test(line)) return '<h2>' + escapeHtml(line) + '</h2>';
      if (/^[-*]\s+/.test(line)) return '<p>· ' + escapeHtml(line.replace(/^[-*]\s+/, '')) + '</p>';
      return '<p>' + escapeHtml(line) + '</p>';
    }).join('');
  }

  function renderNovel() {
    if (!$('#novelTitle')) return;
    if (!['short', 'medium', 'long'].includes(state.novelLength)) state.novelLength = 'short';
    $$('#novelLength button').forEach((button) =>
      button.classList.toggle('active', button.dataset.novelLength === state.novelLength));
    if ($('#novelModeLabel')) $('#novelModeLabel').textContent = novelLengthLabel(state.novelLength);
    if ($('#novelNarrativeStyle')) $('#novelNarrativeStyle').value = state.novelNarrativeStyle || 'oriental';
    if ($('#novelWriterState')) {
      $('#novelWriterState').textContent = state.codexReady && state.config.ai && state.config.ai.hasKey
        ? 'Codex 优先' : state.codexReady ? 'Codex 可用' : state.config.ai && state.config.ai.hasKey ? 'AI 可用' : '未连接';
    }
    if ($('#novelCodexLoginBtn')) {
      $('#novelCodexLoginBtn').hidden = state.codexReady;
      $('#novelCodexLoginBtn').textContent = state.codexInstalled && !state.codexLoggedIn
        ? '登录本机 Codex（首次使用）'
        : '连接 / 检测本机 Codex';
    }
    const novel = state.novel;
    if (!novel) {
      if (!$('#novelContent').textContent.trim()) $('#novelContent').innerHTML = '';
      $('#novelWordCount').textContent = '0 字';
      $('#novelStatus').textContent = '尚未生成';
      renderNovelMaterials();
      renderNovelStoryboard(null);
      return;
    }
    $('#novelTitle').value = novel.title || '';
    if (document.activeElement !== $('#novelContent')) $('#novelContent').innerHTML = novel.html || '';
    state.novelLength = novel.lengthType || 'short';
    state.novelNarrativeStyle = novel.narrativeStyle || 'oriental';
    if ($('#novelNarrativeStyle')) $('#novelNarrativeStyle').value = state.novelNarrativeStyle;
    if ($('#novelWriterState')) {
      $('#novelWriterState').textContent = state.codexReady && state.config.ai && state.config.ai.hasKey
        ? 'Codex 优先' : state.codexReady ? 'Codex 可用' : state.config.ai && state.config.ai.hasKey ? 'AI 可用' : '未连接';
    }
    $$('#novelLength button').forEach((button) => button.classList.toggle('active', button.dataset.novelLength === state.novelLength));
    $('#novelGenre').value = novel.genre || '都市情感';
    $('#novelModeLabel').textContent = novelLengthLabel(state.novelLength);
    $('#novelWordCount').textContent = (novel.html ? stripHtml(novel.html).replace(/\s/g, '').length : 0) + ' 字';
    $('#novelStatus').textContent = novel.updatedAt ? '已保存 · ' + new Date(novel.updatedAt).toLocaleString('zh-CN') : '已生成';
    if (novel.prompt && document.activeElement !== $('#novelInspiration')) $('#novelInspiration').value = novel.prompt;
    renderNovelMaterials();
    renderNovelStoryboard(novel);
  }

  function renderNovelStoryboard(novel) {
    if (!$('#novelOutlineTitle')) return;
    const bible = novel && novel.storyBible || {};
    const characters = Array.isArray(bible.characters) ? bible.characters : [];
    const outline = Array.isArray(bible.outline) ? bible.outline : [];
    const chapters = Array.isArray(bible.chapters) ? bible.chapters : [];
    const visuals = novel && Array.isArray(novel.visuals) ? novel.visuals : [];
    const sources = bible.sources || [];
    const title = $('#novelTitle').value.trim() || novel && novel.title || '等待生成';
    $('#novelOutlineTitle').textContent = title;
    $('#novelSynopsis').textContent = bible.synopsis || '填写提示词后点击“生成原创小说”，系统会自动联网读取素材并生成完整作品档案。';
    $('#novelCharacterCount').textContent = characters.length + ' 人';
    $('#novelChapterCount').textContent = chapters.length + ' 章';
    $('#novelCharacterList').innerHTML = characters.length
      ? characters.map((character, index) => {
          const name = character.name || ('人物 ' + (index + 1));
          return '<div class="novel-character"><span>' + escapeHtml(name.slice(0, 1)) + '</span><div><strong>' +
            escapeHtml(name) + '</strong><small>' +
            escapeHtml(character.appearance || character.description || character.role || '') +
            '</small></div></div>';
        }).join('')
      : '<div class="novel-research-empty">生成后自动识别人物</div>';
    $('#novelOutlineList').innerHTML = outline.length
      ? outline.map((item, index) => '<div class="novel-outline-item"><b>' + String(index + 1).padStart(2, '0') +
          '</b><div><strong>' + escapeHtml(item.title || item.name || '剧情节点') + '</strong><small>' +
          escapeHtml(item.summary || item.description || '') + '</small></div></div>').join('')
      : '<div class="novel-research-empty">生成后自动整理故事提纲</div>';
    $('#novelChapterList').innerHTML = chapters.length
      ? chapters.map((chapter, index) => {
          const available = Boolean(findNovelChapterTarget(novel, index));
          return '<button type="button" class="novel-chapter-item' + (available ? ' is-available' : '') +
            '" data-novel-chapter="' + index + '" title="' +
            (available ? '跳转至本章正文' : '本章待续写') + '"><b>' + String(index + 1).padStart(2, '0') +
            '</b><div><strong>' + escapeHtml(chapter.title || ('第 ' + (index + 1) + ' 章')) + '</strong><small>' +
            escapeHtml(chapter.summary || '') + '</small></div><span>' +
            (available ? '跳转 →' : '待续写') + '</span></button>';
        }).join('')
      : '<div class="novel-research-empty">生成后自动创建章节目录</div>';
    const imageItems = visuals.length
      ? visuals
      : state.selectedResearchImages.map((index) => state.researchImages[index]).filter(Boolean).slice(0, 4);
    $('#novelResearchCount').textContent = sources.length || imageItems.length
      ? (sources.length + ' 来源 · ' + imageItems.length + ' 图片')
      : '尚未读取';
    $('#novelResearchPreview').innerHTML = imageItems.length
      ? imageItems.slice(0, 4).map((image) => '<div class="novel-research-image"><img src="' +
          escapeHtml(image.thumbnail || image.url) + '" alt=""><span>' + escapeHtml(image.source || '免费图库') +
          '</span></div>').join('')
      : '<div class="novel-research-empty">生成时自动检索图片<br>优先使用免费图库</div>';
  }

  function chineseChapterNumber(number) {
    const digits = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
    const value = Number(number) || 1;
    if (value < 10) return digits[value];
    if (value === 10) return '十';
    if (value < 20) return '十' + digits[value % 10];
    if (value < 100) {
      return digits[Math.floor(value / 10)] + '十' +
        (value % 10 ? digits[value % 10] : '');
    }
    return String(value);
  }

  function findNovelChapterTarget(novel, index) {
    const body = $('#novelContent');
    const chapter = novel && novel.storyBible && novel.storyBible.chapters &&
      novel.storyBible.chapters[index];
    if (!body || !chapter) return null;
    const title = String(chapter.title || ('第' + (index + 1) + '章')).trim();
    const titleCore = title.replace(/^第[一二三四五六七八九十百零两\d]+[章节卷]\s*/, '').trim();
    const candidates = unique([
      title,
      '第' + (index + 1) + '章',
      '第' + chineseChapterNumber(index + 1) + '章',
      titleCore
    ].filter(Boolean).map((candidate) => candidate.replace(/\s+/g, '')));
    if (!candidates.length) return null;

    const heading = $$('h1, h2, h3', body).find((node) => {
      const text = (node.textContent || '').replace(/\s+/g, '');
      return candidates.some((candidate) =>
        candidate.length >= 3 && (text === candidate || text.includes(candidate)));
    });
    if (heading) return heading;

    const block = $$('p, strong', body).find((node) => {
      const text = (node.textContent || '').replace(/\s+/g, '');
      return candidates.some((candidate) =>
        candidate.length >= 3 && text.includes(candidate));
    });
    if (block) return block;

    const walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT);
    let textNode = null;
    while ((textNode = walker.nextNode())) {
      const value = (textNode.nodeValue || '').replace(/\s+/g, '');
      if (candidates.some((candidate) =>
          candidate.length >= 3 && value.includes(candidate))) {
        return textNode.parentElement;
      }
    }
    return null;
  }

  function scrollToNovelChapter(index) {
    const novel = state.novel;
    const chapter = novel && novel.storyBible && novel.storyBible.chapters &&
      novel.storyBible.chapters[index];
    if (!chapter) {
      showToast('章节不存在', '请重新生成或续写章节。', 'info');
      return;
    }
    const target = findNovelChapterTarget(novel, index);
    if (!target) {
      const title = String(chapter.title || ('第' + (index + 1) + '章')).trim();
      showToast('这一章还没有正文', '“' + title + '”目前只有章节计划，请先续写本章。', 'info');
      return;
    }
    $$('[data-novel-chapter]').forEach((button) =>
      button.classList.toggle('is-active', Number(button.dataset.novelChapter) === index));
    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    target.classList.add('chapter-jump-highlight');
    setTimeout(() => target.classList.remove('chapter-jump-highlight'), 1800);
    showToast('已定位到本章', String(chapter.title || ('第' + (index + 1) + '章')), 'info');
  }

  function renderNovelMaterials() {
    const list = $('#novelMaterialList');
    if (!list) return;
    list.innerHTML = state.novelMaterials.map((material, index) =>
      '<div class="novel-material-item" data-novel-material-id="' + escapeHtml(material.id) +
      '" title="点击查看原文"><input type="checkbox" data-novel-material-select="' +
      escapeHtml(material.id) + '"' + (state.novelMaterialSelected.includes(material.id) ? ' checked' : '') +
      '><span>' + (index + 1) + '</span><div><strong>' +
      escapeHtml(material.title) + '</strong><small>' + escapeHtml(material.source || '参考资料') +
      ' · ' + (material.text || '').replace(/\s/g, '').length + ' 字</small></div>' +
      '<button type="button" data-remove-novel-material="' + escapeHtml(material.id) + '" title="移除">' + icon('close') + '</button></div>'
    ).join('');
  }

  function saveNovelMaterial(material) {
    if (!material || !material.title || !material.text) return;
    state.novelMaterials.unshift(material);
    state.novelMaterials = state.novelMaterials.slice(0, 10);
    state.novelMaterialSelected = $('#novelMaterialUseMode') &&
      $('#novelMaterialUseMode').value === 'single'
      ? [material.id]
      : unique(state.novelMaterialSelected.concat(material.id)).slice(-10);
    saveJson(KEYS.novelMaterials, state.novelMaterials);
    renderNovelMaterials();
    $('#novelInspiration').value = [
      $('#novelInspiration').value.trim(),
      '参考资料《' + material.title + '》摘要：' + truncate(material.text, 900)
    ].filter(Boolean).join('\n\n');
    showToast('小说素材已读取', '已加入素材库，并填入灵感设定。生成时会只参考主题与结构，不复制原文。');
  }

  function openNovelMaterialImport() {
    state.novelEdgeSource = null;
    showModal('自动读取小说素材', 'EDGE MATERIAL READER',
      '<div class="import-form">' +
        '<div class="novel-platform-picker">' +
          '<a href="https://www.jjwxc.net/" data-direct-web="1" data-novel-platform="jinjiang">晋江小说</a>' +
          '<a href="https://fanqienovel.com/" data-direct-web="1" data-novel-platform="fanqie">番茄小说</a>' +
          '<a href="https://www.qimao.com/" data-direct-web="1" data-novel-platform="qimao">七猫小说</a>' +
          '<a href="https://www.zhihu.com/" data-direct-web="1" data-novel-platform="zhihu">知乎</a>' +
        '</div>' +
        '<div class="novel-edge-reader" id="novelEdgeReader">' +
          '<span class="novel-edge-mark">E</span>' +
          '<div><strong id="novelEdgeTitle">正在读取 Edge 当前页面…</strong><small id="novelEdgeHint">小程序会自动读取你最近打开的网页标题、正文和来源。</small></div>' +
          '<button type="button" id="refreshNovelEdge">重新读取</button>' +
        '</div>' +
        '<label>识别到的素材标题<input id="novelSourceTitle" placeholder="正在等待 Edge 页面"></label>' +
        '<label>自动读取正文<textarea id="novelSourceText" class="novel-source-text" placeholder="打开 Edge 网页后回到这里，正文会自动填入"></textarea></label>' +
        '<details class="novel-manual-more">' +
          '<summary>手动更换素材（链接或文件）</summary>' +
          '<div class="novel-manual-fields">' +
            '<label>网页链接<div class="import-reader"><input id="novelSourceUrl" type="url" placeholder="可选：粘贴公开小说或文章链接"><button class="btn btn-secondary" type="button" id="readNovelSourceUrl">读取</button></div></label>' +
            '<label>本地文件<input id="novelSourceFile" type="file" accept=".txt,.md,.markdown,.html,.htm,.json,text/plain,text/html,application/json"></label>' +
          '</div>' +
        '</details>' +
        '<p class="import-hint">素材用于提炼题材、人物关系、冲突和叙事方法。生成结果必须使用全新人物、设定和情节；不要逐字改写受版权保护的正文。</p>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-primary" type="button" id="confirmNovelMaterial">' + icon('plus') + '加入小说素材库</button>');

    $$('[data-novel-platform]').forEach((button) => {
      button.addEventListener('click', () => {
        const platform = button.dataset.novelPlatform;
        const name = button.textContent.trim();
        state.pendingWritingSourceRead = 'novel';
        scheduleWritingReturnFlow('novel', name, platform);
        setTimeout(closeModal, 80);
        showToast('正在打开 ' + name, '选择一本小说或一个章节后返回，小程序会读取当前内容。', 'info');
        if (button.dataset.directWeb !== '1') launchBrowseSource(platform, name, 'writing', 'novel');
      });
    });

    function showNovelEdgeState(kind, title, hint) {
      const reader = $('#novelEdgeReader');
      if (!reader) return;
      reader.classList.toggle('loaded', kind === 'loaded');
      reader.classList.toggle('error', kind === 'error');
      $('#novelEdgeTitle').textContent = title;
      $('#novelEdgeHint').textContent = hint;
    }

    function applyNovelSource(item, fallbackName) {
      if (!item || !item.text) return false;
      const url = String(item.url || '').trim();
      const source = item.site || hostName(url) || fallbackName || '本地素材';
      const capturedValue = String(item.capturedAt || '');
      const dotNetDate = capturedValue.match(/^\/Date\((\d+)(?:[+-]\d+)?\)\/$/);
      const capturedAt = capturedValue ? new Date(dotNetDate ? Number(dotNetDate[1]) : capturedValue) : null;
      const timeLabel = capturedAt && !Number.isNaN(capturedAt.getTime())
        ? capturedAt.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
        : '刚刚';
      state.novelEdgeSource = {
        url,
        source,
        title: item.title || fallbackName || '未命名素材',
        capturedAt: item.capturedAt || new Date().toISOString()
      };
      $('#novelSourceTitle').value = state.novelEdgeSource.title;
      $('#novelSourceText').value = item.text;
      $('#novelSourceUrl').value = url;
      showNovelEdgeState('loaded', state.novelEdgeSource.title,
        '已从 Edge 自动读取 · ' + source + ' · ' + item.text.replace(/\s/g, '').length + ' 字 · ' + timeLabel);
      return true;
    }

    async function readNovelFromEdge(showFeedback) {
      const button = $('#refreshNovelEdge');
      if (button) {
        button.disabled = true;
        button.textContent = '读取中…';
      }
      showNovelEdgeState('loading', '正在读取 Edge 当前页面…', '正在获取你最近浏览的网页标题、正文和来源。');
      try {
        const current = await api('/api/edge-current');
        let item = current && current.item;
        if (!item || !item.text) {
          const inbox = await api('/api/edge-inbox');
          item = recentCapturedItem(inbox.items || [], state.lastPlatformSource);
        }
        if ((!item || !item.text) && state.lastPlatformSource && state.lastPlatformSource !== 'edge') {
          const native = await api('/api/read-platform?platform=' + encodeURIComponent(state.lastPlatformSource));
          if (native && native.ok && native.text) {
            item = {
              title: native.title,
              text: native.text,
              url: native.url || '',
              site: native.site || state.lastPlatformSource,
              capturedAt: new Date().toISOString()
            };
          }
        }
        if (!applyNovelSource(item, 'Edge 网页')) {
          throw new Error('没有找到可读取的 Edge 网页。请先在 Edge 打开小说或文章，停留几秒后再点“重新读取”。');
        }
        if (showFeedback) showToast('Edge 素材已自动读取', '标题和正文已经填入，可以直接加入素材库。');
      } catch (error) {
        state.novelEdgeSource = null;
        showNovelEdgeState('error', '暂未读取到 Edge 页面', error.message || '请确认 Edge 采集扩展已开启。');
        if (showFeedback) showToast('Edge 自动读取失败', error.message, 'error');
      } finally {
        if (button) {
          button.disabled = false;
          button.textContent = '重新读取';
        }
      }
    }

    $('#refreshNovelEdge').addEventListener('click', () => readNovelFromEdge(true));
    $('#readNovelSourceUrl').addEventListener('click', async () => {
      const url = $('#novelSourceUrl').value.trim();
      if (!/^https?:\/\//i.test(url)) {
        showToast('请输入完整网页链接', null, 'info');
        return;
      }
      const button = $('#readNovelSourceUrl');
      button.disabled = true;
      button.textContent = '读取中…';
      try {
        const result = await api('/api/extract?url=' + encodeURIComponent(url));
        if (!result.ok || !result.text) throw new Error(result.error || '没有读取到正文');
        applyNovelSource({
          title: result.title || hostName(url),
          text: result.text,
          url,
          site: hostName(url),
          capturedAt: new Date().toISOString()
        }, hostName(url));
        showToast('网页素材已读取', '请确认你有权使用该内容作为创作参考。');
      } catch (error) {
        showToast('读取失败', error.message, 'error');
      } finally {
        button.disabled = false;
        button.textContent = '读取';
      }
    });
    $('#novelSourceFile').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      try {
        let text = await file.text();
        if (/\.html?$/i.test(file.name)) {
          const doc = new DOMParser().parseFromString(text, 'text/html');
          text = (doc.querySelector('article,main') || doc.body).textContent || '';
        } else if (/\.json$/i.test(file.name)) {
          try {
            const parsed = JSON.parse(text);
            text = parsed.text || parsed.content || parsed.summary || text;
          } catch (error) {}
        }
        applyNovelSource({
          title: file.name.replace(/\.[^.]+$/, ''),
          text: text.replace(/\s+/g, ' ').trim(),
          url: '',
          site: '本地文件 · ' + file.name,
          capturedAt: new Date().toISOString()
        }, file.name);
      } catch (error) {
        showToast('文件读取失败', error.message, 'error');
      }
    });
    $('#confirmNovelMaterial').addEventListener('click', () => {
      const title = $('#novelSourceTitle').value.trim() || '未命名参考素材';
      const text = $('#novelSourceText').value.trim();
      if (text.length < 30) {
        showToast('素材内容太短', '至少需要一段可分析的正文或摘要。', 'info');
        return;
      }
      saveNovelMaterial({
        id: 'novel_material_' + Date.now(),
        title: truncate(title, 80),
        text: truncate(text, 12000),
        url: state.novelEdgeSource && state.novelEdgeSource.url || $('#novelSourceUrl').value.trim(),
        source: state.novelEdgeSource && state.novelEdgeSource.source || hostName($('#novelSourceUrl').value.trim()) || '本地/手动素材',
        createdAt: new Date().toISOString()
      });
      closeModal();
    });
    readNovelFromEdge(false);
  }

  async function loadGitHubStatus() {
    if (!$('#githubReady')) return;
    try {
      const status = await api('/api/github/status');
      state.githubStatus = status;
      const ready = $('#githubReady');
      ready.textContent = status.ok ? '已连接' : '未找到仓库';
      ready.classList.toggle('ready', Boolean(status.ok));
      $('#githubRemote').textContent = status.remote || '尚未设置远程仓库';
      $('#githubBranch').textContent = status.branch || '—';
      $('#githubChanges').textContent = status.hasChanges ? status.issueCount + ' 项' : '无';
      $('#githubDesktopState').textContent = status.githubDesktopReady ? '可用' : '未安装';
      $('#githubRepoPath').value = status.repoPath || '';
      if (!state.config.githubRepoPath && status.repoPath) state.config.githubRepoPath = status.repoPath;
    } catch (error) {
      state.githubStatus = null;
      $('#githubReady').textContent = '读取失败';
      $('#githubReady').classList.remove('ready');
      $('#githubRemote').textContent = error.message;
    }
  }

  async function exportToGitHub(kind) {
    let payload;
    if (kind === 'novel') {
      if (!state.novel) {
        showToast('还没有小说', '请先在小说工坊生成或打开一篇小说。', 'info');
        return;
      }
      persistNovel();
      payload = {
        title: state.novel.title,
        html: state.novel.html,
        kind: 'novel'
      };
    } else {
      if (!state.article) {
        showToast('还没有图文', '请先生成或打开一篇图文。', 'info');
        return;
      }
      persistArticle();
      payload = {
        title: state.article.title,
        html: state.article.html,
        kind: 'article'
      };
    }
    try {
      const result = await api('/api/github/export', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      showToast('已保存到 GitHub 本地仓库', result.relativePath + '。打开 GitHub Desktop 后提交并点击 Push origin。');
      await loadGitHubStatus();
    } catch (error) {
      showToast('导出失败', error.message, 'error');
    }
  }

  function persistNovel() {
    if (!state.novel) return;
    state.novel.title = $('#novelTitle').value.trim();
    state.novel.html = $('#novelContent').innerHTML;
    state.novel.lengthType = state.novelLength;
    state.novel.genre = $('#novelGenre').value;
    state.novel.narrativeStyle = $('#novelNarrativeStyle') ? $('#novelNarrativeStyle').value : state.novelNarrativeStyle;
    state.novel.prompt = $('#novelInspiration').value.trim();
    state.novel.updatedAt = new Date().toISOString();
    saveJson(KEYS.novel, state.novel);
    $('#novelWordCount').textContent = stripHtml(state.novel.html).replace(/\s/g, '').length + ' 字';
    $('#novelSaveState').textContent = '刚刚自动保存';
    renderNovelStoryboard(state.novel);
  }

  const NOVEL_SECTION_LABELS = ['作品资料', '人物档案', '故事提纲', '章节目录', '章节更新', '人物动态', '正文'];

  function takeNovelSection(text, label) {
    const marker = '【' + label + '】';
    const start = text.indexOf(marker);
    if (start < 0) return '';
    const contentStart = start + marker.length;
    let end = text.length;
    NOVEL_SECTION_LABELS.forEach((other) => {
      if (other === label) return;
      const next = text.indexOf('【' + other + '】', contentStart);
      if (next >= 0 && next < end) end = next;
    });
    return text.slice(contentStart, end).trim();
  }

  function cleanNovelListLine(line) {
    return String(line || '').trim()
      .replace(/^```[a-z]*$/i, '')
      .replace(/^[-*•]\s*/, '')
      .replace(/^\d+[.、]\s*/, '')
      .replace(/^(人物|角色|章节|剧情|提纲)[一二三四五六七八九十\d]*[：:]\s*/, '')
      .trim();
  }

  function parseNovelCharacters(block) {
    return String(block || '').split(/\r?\n/).map(cleanNovelListLine).filter(Boolean).map((line, index) => {
      let parts = line.split(/\s*[｜|]\s*/).filter(Boolean);
      if (parts.length === 1) {
        const pair = line.match(/^(.{1,20}?)[：:]\s*(.+)$/);
        parts = pair ? [pair[1], pair[2]] : [line];
      }
      const identity = parts[1] || '';
      const appearance = parts[2] || '';
      const personality = parts[3] || '';
      const motivation = parts[4] || '';
      const relationship = parts.slice(5).join(' · ').trim();
      return {
        name: (parts[0] || ('人物 ' + (index + 1))).trim().slice(0, 24),
        role: identity.split(/[，,、（(]/)[0].trim() || '主要人物',
        identity,
        appearance,
        personality,
        motivation,
        relationship,
        description: parts.slice(1).join(' · ').trim()
      };
    }).filter((item) => item.name && !/^(人物介绍|主要人物|无)$/.test(item.name));
  }

  function parseNovelOutline(block, requireChapter) {
    return String(block || '').split(/\r?\n/).map(cleanNovelListLine).filter(Boolean).map((line, index) => {
      const parts = line.split(/\s*[｜|]\s*/).filter(Boolean);
      let title = parts[0] || ('章节 ' + (index + 1));
      if (requireChapter && !/^第.+[章节卷]/.test(title)) title = '第' + (index + 1) + '章 ' + title;
      return { title: title.trim().slice(0, 80), summary: parts.slice(1).join(' · ').trim() };
    }).filter((item) => item.title);
  }

  function parseNovelAiOutput(raw, fallbackTitle) {
    const text = String(raw || '').trim().replace(/^```(?:text|markdown|md)?\s*/i, '').replace(/\s*```$/, '');
    const work = takeNovelSection(text, '作品资料');
    const characterBlock = takeNovelSection(text, '人物档案') || takeNovelSection(text, '人物动态');
    const outlineBlock = takeNovelSection(text, '故事提纲');
    const chapterBlock = takeNovelSection(text, '章节目录') || takeNovelSection(text, '章节更新');
    let body = takeNovelSection(text, '正文');
    const titleMatch = (work.match(/标题[：:]\s*([^\r\n]+)/) || text.match(/^标题[：:]\s*([^\r\n]+)/m));
    const title = titleMatch ? titleMatch[1].trim() : (fallbackTitle || '');
    const synopsisMatch = work.match(/(?:一句话简介|简介)[：:]\s*([^\r\n]+)/);
    let synopsis = synopsisMatch ? synopsisMatch[1].trim() : '';
    if (!body) {
      const chapterStart = text.search(/^第[一二三四五六七八九十百零两\d]+[章节卷][^\r\n]*/m);
      body = chapterStart >= 0 ? text.slice(chapterStart) : text;
      body = body.replace(/^标题[：:].+\r?\n?/m, '').replace(/^简介[：:].+\r?\n?/m, '').trim();
    }
    let chapters = parseNovelOutline(chapterBlock, true);
    if (!chapters.length) {
      chapters = Array.from(body.matchAll(/^(第[一二三四五六七八九十百零两\d]+[章节卷][^\r\n]*)/gm)).map((match) => ({
        title: match[1].trim(),
        summary: ''
      }));
    }
    if (!chapters.length) chapters = [{ title: '正文', summary: truncate(synopsis || body, 100) }];
    if (!synopsis) synopsis = truncate(body.replace(/\s+/g, ' '), 180);
    if (!new RegExp('^' + chapters[0].title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).test(body)) {
      body = chapters[0].title + '\n\n' + body;
    }
    return {
      title,
      body,
      storyBible: {
        synopsis,
        characters: parseNovelCharacters(characterBlock),
        outline: parseNovelOutline(outlineBlock, false),
        chapters
      }
    };
  }

  function novelFiguresFromResearch(images) {
    return (images || []).slice(0, 2).map((image) =>
      '<figure><img src="' + escapeHtml(image.url) + '" alt="' + escapeHtml(image.title || '小说视觉参考') +
      '"><figcaption>视觉素材：' + escapeHtml(image.source || '免费图库') + ' · ' +
      escapeHtml(image.creator || '') + ' · ' + escapeHtml(image.license || '请查看来源授权') +
      '。图片仅作场景灵感，不代表小说中真实发生的事件。</figcaption></figure>'
    ).join('');
  }

  function addFiguresToNovelHtml(html, figures) {
    if (!figures) return html;
    const firstParagraphEnd = html.indexOf('</p>');
    if (firstParagraphEnd < 0) return html + figures;
    const insertAt = firstParagraphEnd + 4;
    return html.slice(0, insertAt) + figures + html.slice(insertAt);
  }

  function uniqueByKey(items, keyFn) {
    const seen = new Set();
    return (items || []).filter((item) => {
      const key = String(keyFn(item) || '');
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  async function collectNovelResearch(prompt, genre, continueChapter) {
    let edgeItem = null;
    try {
      const current = await api('/api/edge-current');
      edgeItem = current && current.item;
      if (!edgeItem || !edgeItem.text) {
        const inbox = await api('/api/edge-inbox');
        edgeItem = (inbox.items || [])[0];
      }
    } catch (error) {}
    if (edgeItem && edgeItem.text && edgeItem.text.replace(/\s/g, '').length >= 30) {
      const duplicate = state.novelMaterials.some((material) =>
        edgeItem.url && material.url === edgeItem.url ||
        material.title && edgeItem.title && material.title.replace(/\s/g, '') === edgeItem.title.replace(/\s/g, ''));
      if (!duplicate) {
        state.novelMaterials.unshift({
          id: 'novel_edge_' + Date.now(),
          title: edgeItem.title || 'Edge 最近页面',
          text: truncate(edgeItem.text, 12000),
          url: edgeItem.url || '',
          source: edgeItem.site || hostName(edgeItem.url) || 'Edge 网页',
          createdAt: new Date().toISOString()
        });
        state.novelMaterials = state.novelMaterials.slice(0, 10);
        saveJson(KEYS.novelMaterials, state.novelMaterials);
        renderNovelMaterials();
      }
    }
    const query = truncate([
      String(prompt || '').replace(/\s+/g, ' ').slice(0, 150),
      genre || '',
      '社会背景 人物关系 城市生活 文化 国内外 overseas international society culture lifestyle'
    ].filter(Boolean).join(' '), 220);
    if (!continueChapter || !state.researchArticles.length) {
      try {
        const result = await api('/api/research', {
          method: 'POST',
          body: JSON.stringify({ query })
        });
        state.researchArticles = result.articles || [];
        state.researchImages = result.images || [];
        state.selectedResearchSources = state.researchArticles.slice(0, 8).map((item) => item.id);
        state.selectedResearchImages = state.researchImages.slice(0, 4).map((item, index) => index);
      } catch (error) {
        if (!state.researchArticles.length) state.researchArticles = [];
        if (!state.researchImages.length) state.researchImages = [];
      }
    }
    const fallbackImages = [];
    (edgeItem && edgeItem.images || []).forEach((url) => fallbackImages.push({
      title: edgeItem.title || 'Edge 页面图片',
      thumbnail: url,
      url,
      source: edgeItem.site || 'Edge 页面',
      creator: '',
      license: '请核对原文图片授权'
    }));
    selectedItems().forEach((item) => {
      (item.gallery || []).forEach((url) => fallbackImages.push({
        title: item.title || '新闻素材图片',
        thumbnail: url,
        url,
        source: item.source || '新闻原文',
        creator: '',
        license: '请核对原文图片授权'
      }));
    });
    state.researchImages = state.researchImages.concat(fallbackImages).filter((image, index, all) =>
      image && image.url && all.findIndex((other) => other && other.url === image.url) === index
    ).slice(0, 20);
    state.selectedResearchImages = state.researchImages.slice(0, 4).map((item, index) => index);
    $('#novelAutoSourceStatus').textContent = (edgeItem ? 'Edge 页面 · ' : '') +
      state.researchArticles.length + ' 条国内外资料 · ' + state.researchImages.length + ' 张图片素材';
    return { edgeItem, query };
  }

  async function generateOriginalNovel(continueChapter, options) {
    const settings = options || {};
    if (!continueChapter && !settings.fromApprovedPlan) {
      return startNovelPlanningWorkflow(settings);
    }
    const aiReady = Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    const engine = settings.engine || ($('#novelEngine') ? $('#novelEngine').value : 'auto');
    if (engine === 'codex' && !state.codexReady) {
      if (state.codexInstalled) {
        showToast(state.codexLoggedIn ? 'Codex 尚未就绪' : '请先登录本机 Codex', '已自动打开登录入口。', 'info');
        $('#novelCodexLoginBtn').click();
      } else {
        showToast('未找到本机 Codex', '请重新安装 Codex 后再试。', 'error');
      }
      return;
    }
    if ((engine === 'ai' && !aiReady) || (engine === 'codex' && !state.codexReady) ||
        (engine === 'auto' && !aiReady && !state.codexReady)) {
      showToast('小说生成引擎未连接', '请配置 AI，或在本机登录 Codex 后重试。', 'info');
      openSettings();
      return;
    }
    const inspiration = String(settings.prompt || $('#novelInspiration').value || '').trim() ||
      (state.novel && state.novel.prompt || '');
    if (!inspiration && !selectedItems().length && !state.novel && !state.novelMaterials.length) {
      showToast('请先填写故事设定', '可以写人物、题材、冲突和想要的结局，也可以使用当前热点作背景。', 'info');
      $('#novelInspiration').focus();
      return;
    }
    const mode = ['short', 'medium', 'long'].includes(settings.length)
      ? settings.length
      : state.novelLength;
    state.novelLength = mode;
    const genre = settings.genre || $('#novelGenre').value;
    const narrativeStyle = $('#novelNarrativeStyle') ? $('#novelNarrativeStyle').value : 'oriental';
    state.novelNarrativeStyle = narrativeStyle;
    const currentTitle = $('#novelTitle').value.trim();
    const currentText = state.novel ? stripHtml($('#novelContent').innerHTML) : '';
    const useCodex = engine === 'codex' || (engine === 'auto' && state.codexReady);
    const taskId = beginGeneration('novel', currentTitle || truncate(inspiration, 36),
      continueChapter ? '正在续写' + novelLengthLabel(mode) + '下一章' : '正在生成' + novelLengthLabel(mode));
    showLoading(continueChapter ? '正在续写下一章' : '正在自动读取小说素材',
      '自动连接 Edge 最近页面，并检索国内外公开资料和免费图片。');
    try {
      const autoResearch = useCodex
        ? { edgeItem: null, query: '' }
        : await collectNovelResearch(inspiration, genre, continueChapter);
      const extraImages = (settings.images || []).filter((image) => image && image.url).map((image, index) => ({
        title: image.label || ('AI 工作台素材 ' + (index + 1)),
        thumbnail: image.url,
        url: image.url,
        source: 'AI 工作台素材',
        creator: '',
        license: '请核对图片或画面使用授权'
      }));
      if (extraImages.length) {
        state.researchImages = extraImages.concat(state.researchImages.filter((image) =>
          !extraImages.some((extra) => extra.url === image.url)
        )).slice(0, 20);
        state.selectedResearchImages = state.researchImages.slice(0, 4).map((image, index) => index);
      }
      showLoading(continueChapter ? '正在续写下一章' : '正在构建原创小说',
        '正在整理人物关系、故事提纲、章节结构，并撰写正文。');
      const selectedContext = selectedItems().slice(0, 4).map((item) =>
        item.title + '。' + item.summary
      ).join('\n');
      const materialContext = state.novelMaterials.slice(0, 5).map((material, index) =>
        '素材' + (index + 1) + '《' + material.title + '》：' + truncate(material.text, 1500)
      ).join('\n\n');
      const researchContext = state.researchArticles
        .filter((item) => state.selectedResearchSources.includes(item.id))
        .slice(0, 8)
        .map((item, index) => '公开资料' + (index + 1) + '（' + (item.region || '公开') + '）：' +
          item.title + '\n来源：' + (item.source || '公开网页') + '\n摘要：' + truncate(item.summary || '', 700))
        .join('\n\n');
      const selectedImages = state.selectedResearchImages
        .map((index) => state.researchImages[index]).filter(Boolean);
      const prompt = [
        '你是原创中文小说作者。必须创作全新的人物、关系、场景和情节，不得复制、逐字改写或高度模仿任何现有作品。',
        '把 Edge 页面与公开资料只当作社会背景、职业细节和氛围参考，不使用其中的人物名、专有设定、独特桥段或原句。',
        '类型：' + genre,
        '叙事风格：' + (NOVEL_STYLE_PROMPTS[narrativeStyle] || NOVEL_STYLE_PROMPTS.oriental),
        '篇幅模式：' + novelLengthLabel(mode),
        continueChapter
          ? '这是' + novelLengthLabel(mode) + '续写。只输出【章节更新】【人物动态】【正文】三个区块。章节更新写下一章的章名与一句梗概；人物动态只写本章新增或发生变化的人物；正文约' +
            (state.novel && state.novel.storyBible && state.novel.storyBible.targetWordsPerChapter || 2200) +
            '字，承接已有情节。'
          : mode === 'long'
            ? '请输出完整作品档案，并写第一章约2400-3400字。章节目录先列出至少8章，人物档案至少6人，故事提纲按起、承、转、合设计。'
            : mode === 'medium'
              ? '请输出完整作品档案，并写第一章约1800-2400字。章节目录先列出8-15章，人物档案至少5人，故事提纲要有完整的中段推进和结局规划。'
              : '请输出完整作品档案，并写一篇结构完整的短篇小说，正文约3000-4500字，分为3-5章，有清晰冲突、转折和收束。',
        '输出格式必须严格使用下列中文标签，不要输出代码块、JSON或创作解释：',
        '【作品资料】\n标题：...\n一句话简介：...',
        '【人物档案】\n姓名｜年龄与身份｜外貌与性格｜核心欲望与弱点｜人物关系',
        '【故事提纲】\n阶段名｜本阶段事件与人物变化',
        '【章节目录】\n第1章 章名｜本章核心事件',
        '【正文】\n具体的章节标题与完整正文',
        currentTitle ? '现有书名：' + currentTitle : '',
        '用户的小说提示词与设定（仅作灵感，不可照搬）：\n' + truncate(inspiration + '\n' + selectedContext, 6000),
        materialContext ? '额外参考素材（只提炼题材、叙事方法和人物关系，必须完全重新创作）：\n' + materialContext : '',
        researchContext ? '国内外公开背景资料（只提取社会背景，不得把虚构情节写成真实事件）：\n' + researchContext : '',
        currentText ? '已有小说最近内容（仅用于续写衔接）：\n' + currentText.slice(-4500) : ''
      ].filter(Boolean).join('\n\n');
      const result = await requestStandaloneWriting(
        prompt,
        mode,
        engine
      );
      if (!result.text) throw new Error('AI 没有返回小说内容');
      const parsed = parseNovelAiOutput(result.text, currentTitle);
      const title = parsed.title || currentTitle;
      const generatedHtml = novelTextToHtml(parsed.body);
      const sources = state.researchArticles
        .filter((item) => state.selectedResearchSources.includes(item.id))
        .slice(0, 8)
        .map((item) => ({
          title: item.title,
          source: item.source || '公开网页',
          region: item.region || '国内',
          url: item.url || ''
        }));
      if (autoResearch.edgeItem && autoResearch.edgeItem.text) {
        sources.unshift({
          title: autoResearch.edgeItem.title || 'Edge 最近页面',
          source: autoResearch.edgeItem.site || hostName(autoResearch.edgeItem.url) || 'Edge 页面',
          region: '本机浏览',
          url: autoResearch.edgeItem.url || ''
        });
      }
      const visuals = selectedImages.slice(0, 4).map((image) => ({
        title: image.title || '',
        thumbnail: image.thumbnail || image.url,
        url: image.url,
        source: image.source || '免费图库',
        creator: image.creator || '',
        license: image.license || '请查看来源授权'
      }));
      state.novel = continueChapter && state.novel
        ? Object.assign({}, state.novel, {
            html: state.novel.html + '<hr>' + generatedHtml,
            prompt: inspiration || state.novel.prompt || '',
            narrativeStyle,
            storyBible: (() => {
              const previous = state.novel.storyBible || {};
              const next = parsed.storyBible || {};
              const characters = (previous.characters || []).slice();
              (next.characters || []).forEach((character) => {
                const existing = characters.find((item) => item.name === character.name);
                if (existing) Object.assign(existing, character);
                else characters.push(character);
              });
              return {
                synopsis: previous.synopsis || next.synopsis || '',
                characters,
                outline: (next.outline && next.outline.length) ? next.outline : (previous.outline || []),
                chapters: (previous.chapters || []).concat(next.chapters || []),
                sources: uniqueByKey((previous.sources || []).concat(sources), (item) => item.url || item.title)
              };
            })(),
            updatedAt: new Date().toISOString()
          })
        : {
            id: 'novel_' + Date.now(),
            title: title || ('未命名' + novelLengthLabel(mode)),
            html: addFiguresToNovelHtml(generatedHtml, novelFiguresFromResearch(visuals)),
            lengthType: mode,
            genre,
            narrativeStyle,
            prompt: inspiration,
            storyBible: Object.assign({}, parsed.storyBible, {
              sources,
              researchQuery: $('#novelInspiration').value.trim() || inspiration
            }),
            visuals,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
      saveJson(KEYS.novel, state.novel);
      renderNovel();
      finishGeneration(taskId, 'novel', state.novel);
      showToast(continueChapter ? '下一章已生成' : '原创小说已生成',
        '已自动整理人物、提纲和章节，并附上 ' + sources.length + ' 条来源、' + visuals.length + ' 张图片素材。');
    } catch (error) {
      showToast('小说生成失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  async function createCompanionArticleFromNovel() {
    if (!state.novel) {
      showToast('还没有小说', '请先生成一篇小说，再制作同题图文导览。', 'info');
      return;
    }
    if (!state.config.ai || !state.config.ai.enabled || !state.config.ai.hasKey) {
      showToast('图文生成需要 AI', '请先在设置中完成 AI 连接。', 'info');
      openSettings();
      return;
    }
    persistNovel();
    const title = state.novel.title || '原创小说';
    const synopsis = state.novel.storyBible && state.novel.storyBible.synopsis || '';
    $('#inspirationTitle').value = '《' + title + '》原创小说图文导览';
    $('#inspirationPrompt').value = [
      '根据这部原创小说的设定，写一篇供读者了解作品的图文导览。',
      '写清故事看点、人物关系、主要冲突和阅读亮点。',
      '这是虚构小说宣传内容，不得写成真实新闻，不得声称故事真实发生。',
      synopsis ? '小说简介：' + synopsis : ''
    ].filter(Boolean).join('\n');
    state.inspirationMode = 'article';
    if (!state.researchArticles.length) await runResearch(false);
    await createFromInspiration();
  }

  function adaptNovelToVideo() {
    if (!state.novel) {
      showToast('还没有小说', '请先生成或打开一篇小说。', 'info');
      return;
    }
    persistNovel();
    const bible = state.novel.storyBible || {};
    const chapters = (bible.chapters || []).slice(0, 8);
    const outline = bible.outline || [];
    const hooks = (chapters.length ? chapters : outline).map((item, index) => ({
      label: chapters.length ? ('第' + (index + 1) + '段') : ('镜头 ' + (index + 1)),
      caption: item.summary || item.title || state.novel.title,
      visual: '使用授权视频中的对应人物、场景或氛围镜头',
      reason: item.title || '推进情节'
    }));
    state.videoBreakdown = {
      title: state.novel.title || '小说改编短视频',
      kind: '小说改编',
      summary: bible.synopsis || truncate(stripHtml(state.novel.html || ''), 180),
      characters: bible.characters || [],
      hooks: hooks.length ? hooks : [{
        label: '0-3秒',
        caption: state.novel.title || '小说高光片段',
        visual: '使用授权视频中的高能镜头',
        reason: '建立开场钩子'
      }],
      editNotes: ['按人物关系排列镜头', '用字幕交代章节信息', '结尾留下阅读期待']
    };
    const styleMap = {
      oriental: 'zhang', realism: 'zhengwu', suspense: 'nolan', urban: 'wong',
      classic: 'chen', scifi: 'guofan', myth: 'wushan', overseas: 'fincher'
    };
    state.directorStyle = styleMap[state.novel.narrativeStyle] || 'zhang';
    state.videoComposition = 'montage';
    state.videoVisualStyle = 'cinematic';
    state.videoDuration = 30;
    state.videoEpisodeTitle = state.novel.title || '小说改短视频';
    state.videoScript = [
      state.videoBreakdown.summary,
      ...state.videoBreakdown.hooks.map((hook) => hook.caption)
    ].filter(Boolean).join('。');
    showView('video');
    renderVideoControlState();
    renderVideoBreakdown(state.videoBreakdown);
    showToast('小说已转换为视频方案', '导入授权视频后点击“按拆解方案自动剪辑”。', 'info');
  }

  async function copyNovelAndOpen(platform) {
    if (!state.novel) {
      showToast('还没有小说', '请先生成一篇原创小说。', 'info');
      return;
    }
    persistNovel();
    const title = $('#novelTitle').value.trim();
    const text = title + '\n\n' + stripHtml($('#novelContent').innerHTML);
    try {
      await navigator.clipboard.writeText(text);
    } catch (error) {
      const area = document.createElement('textarea');
      area.value = text;
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      area.remove();
    }
    const targets = {
      fanqie: 'https://fanqienovel.com/',
      zhihu: 'https://zhuanlan.zhihu.com/write',
      jinjiang: 'https://my.jjwxc.net/'
    };
    showModal('原创小说已复制', 'PUBLISH ORIGINAL FICTION',
      '<div class="publish-step"><span>01</span><div><strong>小说标题和正文已复制</strong><p>请确认作品为你的原创内容，并完成必要的事实与版权检查。</p></div></div>' +
      '<div class="publish-step"><span>02</span><div><strong>在平台创作入口粘贴</strong><p>登录对应平台，按 Ctrl+V 粘贴，平台可能要求补充标签、简介、封面和授权声明。</p></div></div>' +
      '<div class="modal-note">' + icon('check') + '<p>程序不会接管账号或自动点击最终发布。请遵守晋江、番茄和知乎各自的原创与发布规则。</p></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>稍后</button>' +
      '<button class="btn btn-primary" type="button" id="novelOpenPlatform">' + icon('external') + '打开创作平台</button>');
    $('#novelOpenPlatform').addEventListener('click', async () => {
      closeModal();
      try {
        const result = await api('/api/open-novel-platform', {
          method: 'POST',
          body: JSON.stringify({ platform, url: targets[platform] })
        });
        showToast(result.method === 'desktop-app' ? '已打开平台桌面客户端' : '已打开平台官方网页',
          result.method === 'desktop-app'
            ? '正文已经复制，请粘贴到平台编辑器。'
            : '当前电脑未检测到该平台桌面客户端，正文已经复制到剪贴板。', 'info');
      } catch (error) {
        showToast('打开平台失败', error.message, 'error');
      }
    });
  }

  function downloadPlainText(title, text, extension) {
    const safeTitle = String(title || '未命名原文')
      .replace(/[\\/:*?"<>|]/g, '_').slice(0, 100);
    const blob = new Blob([String(text || '')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = safeTitle + '.' + (extension || 'txt');
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function downloadRichHtmlDocument(title, bodyHtml, kind) {
    const safeTitle = String(title || '未命名原文')
      .replace(/[\\/:*?"<>|]/g, '_').slice(0, 100);
    const html = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">' +
      '<meta name="viewport" content="width=device-width,initial-scale=1">' +
      '<title>' + escapeHtml(title || '未命名原文') + '</title>' +
      '<style>body{max-width:860px;margin:42px auto;padding:0 28px;color:#27322d;' +
      'font:17px/1.9 "Microsoft YaHei",sans-serif}h1{font-size:32px;line-height:1.4}' +
      'img{max-width:100%;height:auto;border-radius:10px}figure{margin:24px 0}' +
      'figcaption{color:#7c8781;font-size:13px}h2{font-size:24px}h3{font-size:20px}' +
      'blockquote{padding:12px 16px;border-left:4px solid #4b8b68;background:#f4faf6}' +
      '.meta{color:#84918a;font-size:13px;margin-bottom:28px}</style></head><body>' +
      '<h1>' + escapeHtml(title || '未命名原文') + '</h1>' +
      '<div class="meta">' + escapeHtml(kind === 'novel' ? '原创小说原文' : '图文文章原文') +
      ' · 由热点工坊导出 · ' + new Date().toLocaleString('zh-CN') + '</div>' +
      (bodyHtml || '') + '</body></html>';
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = safeTitle + '-' + (kind === 'novel' ? '小说原文' : '图文原文') + '.html';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1800);
  }

  function detectSourcePlatform(url) {
    const host = String(url || '').toLowerCase();
    if (host.includes('jjwxc.net')) return 'jinjiang';
    if (host.includes('fanqienovel.com')) return 'fanqie';
    if (host.includes('qimao.com')) return 'qimao';
    if (host.includes('zhihu.com')) return 'zhihu';
    if (host.includes('weibo.com') || host.includes('weibo.cn')) return 'weibo';
    if (host.includes('news.163.com') || host.includes('163.com')) return 'netease';
    if (host.includes('news.qq.com') || host.includes('new.qq.com') || host.includes('qq.com')) return 'tencent';
    if (host.includes('toutiao.com')) return 'toutiao';
    if (host.includes('youku.com')) return 'youku';
    if (host.includes('mgtv.com')) return 'mgtv';
    if (host.includes('iqiyi.com')) return 'iqiyi';
    if (host.includes('bilibili.com')) return 'bilibili';
    return '';
  }

  async function openSourceInSoftware(url) {
    if (!/^https?:\/\//i.test(url || '')) {
      showToast('没有来源地址', '请先读取原文或素材链接。', 'info');
      return;
    }
    const platform = detectSourcePlatform(url);
    try {
      const endpoint = ['jinjiang', 'fanqie', 'qimao', 'zhihu'].includes(platform)
        ? '/api/open-novel-platform'
        : '/api/open-platform';
      const result = await api(endpoint, {
        method: 'POST',
        body: JSON.stringify({ platform, url })
      });
      showToast(result.method === 'web' ? '已打开原文网页' : '已跳转到对应软件',
        '可在软件内下载原文或保存完整内容。');
    } catch (error) {
      try {
        await api('/api/open', {
          method: 'POST',
          body: JSON.stringify({ url, browserId: 'edge' })
        });
        showToast('已用 Edge 打开原文');
      } catch (fallbackError) {
        showToast('打开原文失败', fallbackError.message, 'error');
      }
    }
  }

  async function openWritingDestination(kind, platform, customUrl) {
    const novelTargets = {
      jinjiang: 'https://my.jjwxc.net/',
      fanqie: 'https://fanqienovel.com/',
      qimao: 'https://www.qimao.com/',
      zhihu: 'https://zhuanlan.zhihu.com/write'
    };
    const articleTargets = {
      toutiao: state.config.toutiaoUrl,
      tencent: 'https://news.qq.com/',
      weibo: 'https://weibo.com/',
      netease: 'https://news.163.com/'
    };
    const targets = kind === 'novel' ? novelTargets : articleTargets;
    const url = customUrl || targets[platform] || '';
    if (!url) return;
    try {
      const endpoint = kind === 'novel' ? '/api/open-novel-platform' : '/api/open-platform';
      const result = await api(endpoint, {
        method: 'POST',
        body: JSON.stringify({ platform, url })
      });
      showToast(result.method === 'web' || result.method === 'default-browser'
        ? '已打开对应官网' : '已尝试跳转到对应软件',
        '名称已复制；如果没有自动跳出，请使用下一步窗口中的搜索链接。');
    } catch (error) {
      try {
        await api('/api/open', {
          method: 'POST',
          body: JSON.stringify({ url, browserId: 'edge' })
        });
        showToast('已用 Edge 打开对应网站');
      } catch (fallbackError) {
        showToast('跳转失败', fallbackError.message, 'error');
      }
    }
  }

  async function openUrlInEdge(url) {
    if (!/^https?:\/\//i.test(url || '')) throw new Error('目标链接无效');
    try {
      return await api('/api/open', {
        method: 'POST',
        body: JSON.stringify({ url, browserId: 'edge' })
      });
    } catch (error) {
      return await api('/api/open-platform', {
        method: 'POST',
        body: JSON.stringify({ platform: detectSourcePlatform(url), url })
      });
    }
  }

  function showResolvedWritingDestination(kind, platform, title, resolution) {
    const labels = {
      jinjiang: '晋江文学城', fanqie: '番茄小说', qimao: '七猫小说', zhihu: '知乎',
      toutiao: '今日头条', tencent: '腾讯新闻', weibo: '微博', netease: '网易新闻'
    };
    const candidates = Array.isArray(resolution.candidates) ? resolution.candidates.slice(0, 8) : [];
    showModal(kind === 'novel' ? '已定位到小说正文' : '已定位到文章页面', 'DIRECT DESTINATION',
      '<div class="resolved-writing-destination">' +
        '<div class="title-search-query"><small>输入名称</small><strong>' + escapeHtml(title) +
          '</strong><span>已打开：' + escapeHtml(labels[platform] || platform) + '</span></div>' +
        '<div class="resolved-writing-card">' +
          '<strong>' + escapeHtml(resolution.matchedTitle || title) + '</strong>' +
          '<small>已跳过搜索页，直接进入可阅读页面</small>' +
          '<a href="' + escapeHtml(resolution.url) + '" target="_blank" rel="noopener">' +
            escapeHtml(resolution.url) + '</a>' +
        '</div>' +
        (candidates.length > 1
          ? '<div class="resolved-writing-candidates"><strong>如果打开的不是你要找的作品，可选择其他结果：</strong>' +
            candidates.map((item, index) => '<button type="button" data-resolved-writing-url="' +
              escapeHtml(item.url) + '" data-resolved-writing-title="' + escapeHtml(item.title) + '">' +
              String(index + 1).padStart(2, '0') + ' · ' + escapeHtml(item.title) + '</button>').join('') +
            '</div>'
          : '') +
        '<p class="import-hint">进入正文后返回热点工坊，点击“读取当前正文”即可继续生成原创内容。</p>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>稍后处理</button>' +
      '<button class="btn btn-secondary" type="button" id="readResolvedWritingSourceBtn">读取当前正文</button>' +
      '<button class="btn btn-primary" type="button" id="reopenResolvedWritingBtn">再次打开正文</button>');
    $('#reopenResolvedWritingBtn').addEventListener('click', async () => {
      try {
        await openUrlInEdge(resolution.url);
        showToast('已再次打开正文页', resolution.matchedTitle || title);
      } catch (error) {
        showToast('打开正文失败', error.message, 'error');
      }
    });
    $('#readResolvedWritingSourceBtn').addEventListener('click', async () => {
      state.lastPlatformSource = platform;
      closeModal();
      await readWritingSource(kind, false);
    });
    $$('[data-resolved-writing-url]').forEach((button) => {
      button.addEventListener('click', async () => {
        const url = button.dataset.resolvedWritingUrl;
        const nextTitle = button.dataset.resolvedWritingTitle || title;
        try {
          await openUrlInEdge(url);
          closeModal();
          showResolvedWritingDestination(kind, platform, title, Object.assign({}, resolution, {
            url,
            matchedTitle: nextTitle
          }));
        } catch (error) {
          showToast('打开候选结果失败', error.message, 'error');
        }
      });
    });
  }

  function showSoftwareJumpNextStep(kind, platform, title, searchUrl) {
    const labels = {
      jinjiang: '晋江文学城', fanqie: '番茄小说', qimao: '七猫小说', zhihu: '知乎',
      toutiao: '今日头条', tencent: '腾讯新闻', weibo: '微博', netease: '网易新闻'
    };
    const homeUrls = {
      jinjiang: 'https://www.jjwxc.net/',
      fanqie: 'https://fanqienovel.com/',
      qimao: 'https://www.qimao.com/',
      zhihu: 'https://www.zhihu.com/',
      toutiao: 'https://www.toutiao.com/',
      tencent: 'https://news.qq.com/',
      weibo: 'https://weibo.com/',
      netease: 'https://news.163.com/'
    };
    showModal('下一步：打开搜索结果', 'NEXT STEP',
      '<div class="title-search-next">' +
        '<div class="title-search-query"><small>要搜索的名称</small><strong>' +
          escapeHtml(title) + '</strong><span>目标软件：' +
          escapeHtml(labels[platform] || '对应软件') + '</span></div>' +
        '<p>名称已经复制。程序已尝试打开对应软件；如果软件没有自动弹出，请使用下面的按钮。</p>' +
        '<a class="btn btn-primary btn-block" href="' + escapeHtml(searchUrl) +
          '" target="_blank" rel="noopener">在 Edge 直接打开搜索结果</a>' +
        '<a class="btn btn-secondary btn-block" href="' +
          escapeHtml(homeUrls[platform] || searchUrl) +
          '" target="_blank" rel="noopener">打开对应软件官网首页</a>' +
        '<div class="modal-note"><p>进入软件或网页后，将复制的名称粘贴到搜索框。找到小说或文章后，可使用浏览器的抓取功能读取内容。</p></div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>稍后处理</button>' +
      '<button class="btn btn-secondary" type="button" id="retryOpenWritingSoftwareBtn">再次打开软件</button>');
    $('#retryOpenWritingSoftwareBtn').addEventListener('click', async () => {
      try {
        await openUrlInEdge(searchUrl);
        showToast('已在 Edge 打开搜索页');
      } catch (error) {
        showToast('打开搜索页失败', error.message, 'error');
      }
    });
  }

  async function searchWritingTitle(kind, platform, title) {
    const query = encodeURIComponent(title);
    const searchUrls = {
      jinjiang: 'https://www.jjwxc.net/search.php?kw=' + query + '&t=1',
      fanqie: 'https://fanqienovel.com/search/' + query,
      qimao: 'https://www.qimao.com/search?keyword=' + query,
      zhihu: 'https://www.zhihu.com/search?type=content&q=' + query,
      toutiao: 'https://so.toutiao.com/search?keyword=' + query,
      tencent: 'https://news.qq.com/search?query=' + query,
      weibo: 'https://s.weibo.com/weibo?q=' + query,
      netease: 'https://www.163.com/search?keyword=' + query
    };
    try {
      await navigator.clipboard.writeText(title);
    } catch (error) {
      downloadPlainText('搜索名称', title, 'txt');
    }
    const searchUrl = searchUrls[platform];
    showToast('正在定位正文页', '正在解析“' + title + '”的公开搜索结果。');
    try {
      const resolution = await api('/api/writing-title-resolve', {
        method: 'POST',
        body: JSON.stringify({ kind, platform, title })
      });
      if (resolution && resolution.ok && /^https?:\/\//i.test(resolution.url || '')) {
        await openUrlInEdge(resolution.url);
        showResolvedWritingDestination(kind, platform, title, resolution);
        return;
      }
    } catch (error) {
      reportClientLog('title-resolve', error.message, platform + ':' + title);
    }
    await openUrlInEdge(searchUrl);
    showSoftwareJumpNextStep(kind, platform, title, searchUrl);
  }

  function openWritingTitleLookupDialog(kind, initialTitle) {
    const isNovel = kind === 'novel';
    const platforms = isNovel
      ? [['jinjiang', '晋江文学城'], ['fanqie', '番茄小说'], ['qimao', '七猫小说'], ['zhihu', '知乎']]
      : [['toutiao', '今日头条'], ['tencent', '腾讯新闻'], ['weibo', '微博'], ['netease', '网易新闻']];
    let platform = isNovel ? 'fanqie' : 'toutiao';
    showModal(isNovel ? '按小说名直达' : '按文章名直达', 'TITLE LOOKUP',
      '<div class="title-lookup-dialog">' +
        '<label>' + (isNovel ? '小说名称' : '文章 / 事件名称') +
          '<input id="writingTitleLookupInput" type="text" maxlength="120" placeholder="输入名称后打开对应软件搜索"></label>' +
        '<div class="title-lookup-platforms">' +
          platforms.map(([id, name]) => '<button type="button" data-title-platform="' + id +
            '" class="' + (id === platform ? 'active' : '') + '">' + name + '</button>').join('') +
        '</div>' +
        '<p class="field-hint">程序会复制名称，并优先打开已安装的软件；未安装时打开官方搜索网页。</p>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-primary" type="button" id="openWritingTitleLookupBtn">搜索并打开软件</button>');
    $('#writingTitleLookupInput').value = initialTitle || '';
    $$('[data-title-platform]').forEach((button) => {
      button.addEventListener('click', () => {
        platform = button.dataset.titlePlatform;
        $$('[data-title-platform]').forEach((item) =>
          item.classList.toggle('active', item === button));
      });
    });
    $('#openWritingTitleLookupBtn').addEventListener('click', async () => {
      const title = $('#writingTitleLookupInput').value.trim();
      if (!title) {
        showToast('请输入名称', isNovel ? '例如：输入小说名。' : '例如：输入文章或事件名。', 'info');
        $('#writingTitleLookupInput').focus();
        return;
      }
      closeModal();
      await searchWritingTitle(kind, platform, title);
    });
  }

  function openOriginalDownloadDialog(kind) {
    const isNovel = kind === 'novel';
    const title = isNovel
      ? ($('#novelTitle')?.value.trim() || state.novel?.title || '未命名小说')
      : ($('#articleTitle')?.value.trim() || state.article?.title || '未命名图文');
    const bodyHtml = isNovel
      ? ($('#novelContent')?.innerHTML || state.novel?.html || '')
      : ($('#articleBody')?.innerHTML || state.article?.html || '');
    const plain = isNovel
      ? ($('#novelContent')?.innerText || stripHtml(bodyHtml))
      : ($('#articleBody')?.innerText || stripHtml(bodyHtml));
    if (!plain.trim()) {
      showToast(isNovel ? '还没有小说正文' : '还没有图文正文',
        '请先生成或填写内容。', 'info');
      return;
    }
    const sourceUrl = isNovel
      ? (state.novelMaterials.find((item) => item.url)?.url || '')
      : (articleSourceItems()[0]?.url || '');
    const detected = detectSourcePlatform(sourceUrl);
    const novelPlatforms = [
      ['jinjiang', '晋江文学城'], ['fanqie', '番茄小说'],
      ['qimao', '七猫小说'], ['zhihu', '知乎']
    ];
    const articlePlatforms = [
      ['toutiao', '今日头条'], ['tencent', '腾讯新闻'],
      ['weibo', '微博'], ['netease', '网易新闻']
    ];
    const destinations = isNovel ? novelPlatforms : articlePlatforms;
    let targetPlatform = destinations.some(([id]) => id === detected)
      ? detected
      : (isNovel ? 'fanqie' : 'toutiao');
    showModal(isNovel ? '下载小说原文' : '下载图文原文', 'DOWNLOAD ORIGINAL TEXT',
      '<div class="original-text-download">' +
        '<strong>' + escapeHtml(title) + '</strong>' +
        '<p>HTML 原文会保留标题、段落、章节、图片和基础排版；TXT 只保存纯文字。</p>' +
        '<small>共 ' + plain.replace(/\s/g, '').length + ' 字 · ' +
          (bodyHtml.match(/<img\b/gi) || []).length + ' 张图片</small>' +
        '<div class="original-download-target">' +
          '<strong>下载后打开</strong>' +
          '<div>' + destinations.map(([id, name]) =>
            '<button type="button" data-original-target="' + id + '" class="' +
            (id === targetPlatform ? 'active' : '') + '">' + name + '</button>').join('') +
          '</div>' +
          '<label><input id="autoOpenOriginalTarget" type="checkbox" checked>' +
          '<span>下载完成后自动跳转</span></label>' +
        '</div>' +
        '<div class="original-title-lookup">' +
          '<label>' + (isNovel ? '按小说名搜索' : '按文章名搜索') +
            '<input id="originalTitleLookupInput" type="text" maxlength="120"></label>' +
          '<button type="button" id="searchOriginalTitleBtn">在所选软件中搜索</button>' +
        '</div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-secondary" type="button" id="openOriginalSoftwareBtn">打开来源软件</button>' +
      '<button class="btn btn-secondary" type="button" id="downloadOriginalTxtBtn">下载纯文本</button>' +
      '<button class="btn btn-primary" type="button" id="downloadOriginalHtmlBtn">下载 HTML 原文</button>');
    $$('[data-original-target]').forEach((button) => {
      button.addEventListener('click', () => {
        targetPlatform = button.dataset.originalTarget;
        $$('[data-original-target]').forEach((item) =>
          item.classList.toggle('active', item === button));
      });
    });
    const afterDownload = async () => {
      if (!$('#autoOpenOriginalTarget')?.checked) return;
      try {
        if (isNovel) await copyNovelText();
        else await copyArticle();
      } catch (error) {}
      setTimeout(() => {
        closeModal();
        openWritingDestination(kind, targetPlatform);
      }, 650);
    };
    $('#downloadOriginalHtmlBtn').addEventListener('click', () => {
      downloadRichHtmlDocument(title, bodyHtml, kind);
      showToast('原文已下载', '已保存为包含排版的 HTML 文件。');
      afterDownload();
    });
    $('#downloadOriginalTxtBtn').addEventListener('click', () => {
      downloadPlainText(title, title + '\n\n' + plain, 'txt');
      showToast('纯文本已下载', '已保存为 TXT 文件。');
      afterDownload();
    });
    $('#openOriginalSoftwareBtn').addEventListener('click', () => {
      closeModal();
      openWritingDestination(kind, targetPlatform);
    });
    $('#originalTitleLookupInput').value = title;
    $('#searchOriginalTitleBtn').addEventListener('click', async () => {
      const name = $('#originalTitleLookupInput').value.trim();
      if (!name) {
        showToast('请输入名称', isNovel ? '例如：输入小说名。' : '例如：输入文章名。', 'info');
        return;
      }
      closeModal();
      await searchWritingTitle(kind, targetPlatform, name);
    });
  }

  function downloadNovelOriginal() {
    const body = $('#novelContent')?.innerText.trim() ||
      stripHtml(state.novel?.html || '');
    if (!body) {
      openWritingTitleLookupDialog('novel', $('#novelTitle')?.value.trim() || '');
      return;
    }
    openOriginalDownloadDialog('novel');
  }

  function downloadArticleOriginal() {
    const body = $('#articleBody')?.innerText.trim() ||
      stripHtml(state.article?.html || '');
    if (!body) {
      openWritingTitleLookupDialog('article', $('#articleTitle')?.value.trim() || '');
      return;
    }
    openOriginalDownloadDialog('article');
  }

  function openNovelMaterialPreview(materialId) {
    const material = state.novelMaterials.find((item) => item.id === materialId);
    if (!material) return;
    showModal(material.title || '参考素材原文', 'NOVEL MATERIAL',
      '<div class="novel-material-preview">' +
        '<div class="novel-source-preview">' + escapeHtml(material.text || '') + '</div>' +
        '<p class="field-hint">来源：' + escapeHtml(material.source || '参考资料') +
          ' · ' + String(material.text || '').replace(/\s/g, '').length + ' 字</p>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>' +
      (material.url
        ? '<button class="btn btn-secondary" type="button" id="openNovelMaterialSourceBtn">打开来源软件</button>'
        : '') +
      '<button class="btn btn-secondary" type="button" id="downloadNovelMaterialBtn">下载原文</button>' +
      '<button class="btn btn-primary" type="button" id="useNovelMaterialBtn">加入小说提示词</button>');
    $('#downloadNovelMaterialBtn').addEventListener('click', () => {
      downloadPlainText(material.title || '参考素材原文',
        (material.title || '') + '\n\n' + (material.text || ''), 'txt');
    });
    $('#useNovelMaterialBtn').addEventListener('click', () => {
      $('#novelInspiration').value = [
        $('#novelInspiration').value.trim(),
        '参考素材《' + material.title + '》摘要：' + truncate(material.text || '', 1200)
      ].filter(Boolean).join('\n\n');
      closeModal();
      showToast('参考素材已加入提示词');
    });
    if ($('#openNovelMaterialSourceBtn')) {
      $('#openNovelMaterialSourceBtn').addEventListener('click', () =>
        openSourceInSoftware(material.url));
    }
  }

  async function copyNovelText() {
    if (!state.novel) {
      showToast('还没有小说', '请先生成一篇原创小说。', 'info');
      return;
    }
    persistNovel();
    const text = $('#novelTitle').value.trim() + '\n\n' + stripHtml($('#novelContent').innerHTML);
    try {
      await navigator.clipboard.writeText(text);
      showToast('小说正文已复制');
    } catch (error) {
      showToast('复制失败', '请手动选择正文复制。', 'error');
    }
  }

  function openFreeImageSearch() {
    showModal('免费图片素材', 'FREE IMAGE SOURCES',
      '<div class="import-form"><label>搜索关键词<div class="import-reader"><input id="freeImageQuery" placeholder="例如：雨夜、城市、森林、人物背影"><button class="btn btn-secondary" type="button" id="searchFreeImageBtn">搜索</button></div></label>' +
      '<p class="import-hint">素材来自 Openverse 和 Wikimedia Commons，请在使用前查看来源页的署名与授权要求。</p><div class="free-image-results" id="freeImageResults"></div></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>');
    $('#searchFreeImageBtn').addEventListener('click', async () => {
      const query = $('#freeImageQuery').value.trim();
      if (!query) return;
      const container = $('#freeImageResults');
      container.innerHTML = '<div class="media-empty">正在搜索免费图片…</div>';
      try {
        const result = await api('/api/image-search?q=' + encodeURIComponent(query));
        container.innerHTML = (result.items || []).length ? result.items.map((item, index) =>
          '<button class="free-image-card" type="button" data-free-image="' + index + '"><img src="' +
          escapeHtml(item.thumbnail || item.url) + '" alt=""><span><b>' + escapeHtml(truncate(item.title, 30)) +
          '</b><small>' + escapeHtml(item.source) + ' · ' + escapeHtml(item.license) + '</small></span></button>'
        ).join('') : '<div class="media-empty">没有找到结果</div>';
        $$('#freeImageResults [data-free-image]').forEach((button) => {
          button.addEventListener('click', () => {
            const item = result.items[Number(button.dataset.freeImage)];
            if (!state.novel) state.novel = { id: 'novel_' + Date.now(), title: $('#novelTitle').value || '未命名小说', html: '', lengthType: state.novelLength, genre: $('#novelGenre').value, createdAt: new Date().toISOString() };
            state.novel.html += '<figure><img src="' + escapeHtml(item.url) + '" alt="' + escapeHtml(item.title) + '"><figcaption>图片来源：' +
              escapeHtml(item.source) + ' · ' + escapeHtml(item.creator || '') + ' · ' + escapeHtml(item.license) + '</figcaption></figure>';
            saveJson(KEYS.novel, state.novel);
            renderNovel();
            closeModal();
            showToast('图片素材已加入小说', '发布前请查看来源页并完成署名。');
          });
        });
      } catch (error) {
        container.innerHTML = '<div class="media-empty">' + escapeHtml(error.message) + '</div>';
      }
    });
  }

  function relatedTopics(item) {
    return state.news
      .filter((entry) => entry.id !== item.id)
      .sort((a, b) => {
        const sectionA = a.section === item.section ? 1 : 0;
        const sectionB = b.section === item.section ? 1 : 0;
        return sectionB - sectionA || (b.score || 0) - (a.score || 0);
      })
      .slice(0, 3);
  }

  function openTopic(id) {
    const item = state.news.find((entry) => entry.id === id);
    if (!item) return;
    const related = relatedTopics(item);
    const selected = state.selected.includes(item.id);
    showModal('热点讨论详情', 'DISCUSS & CREATE',
      (item.image ? '<img class="topic-cover" src="' + escapeHtml(item.image) + '" alt="">' : '') +
      '<h3 class="topic-title">' + escapeHtml(item.title) + '</h3>' +
      '<div class="topic-meta"><span>' + escapeHtml(item.sectionName) + '</span><span>来源：' + escapeHtml(item.source) +
      '</span><span>' + escapeHtml(item.publishedLabel) + '</span><span>讨论热度 ' + Math.round(item.score || 70) + '</span>' +
      (item.imported ? '<span class="imported-tag">已导入</span>' : '') + '</div>' +
      '<p class="topic-summary">' + escapeHtml(item.summary) + '</p>' +
      '<div class="topic-focus"><strong>讨论焦点</strong><p>' + escapeHtml(analysisFor(item, 0)) +
      '</p></div>' +
      '<strong style="font-size:9px;color:#555e69">其他正在讨论的热点（不会混入当前文章）</strong>' +
      '<div class="related-topics">' + related.map((entry, index) =>
        '<div class="related-topic"><span>' + String(index + 2).padStart(2, '0') + '</span><p>' +
        escapeHtml(entry.title) + '</p><small>' + escapeHtml(entry.sectionName) + '</small></div>').join('') + '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>' +
      (item.url ? '<button class="btn btn-secondary" type="button" id="topicOpenSourceBtn">' + icon('external') + '打开原文 / 观看</button>' : '') +
      '<button class="btn btn-secondary" type="button" id="topicSelectBtn">' + icon(selected ? 'check' : 'plus') +
      (selected ? '已加入选题' : '加入选题') + '</button>' +
      '<button class="btn btn-secondary" type="button" id="topicMicroBtn">' + icon('doc') + '生成微新闻</button>' +
      '<button class="btn btn-secondary" type="button" id="topicFeatureBtn">' + icon('wand') + '生成深度图文</button>' +
      '<button class="btn btn-primary" type="button" id="topicVideoBtn">' + icon('video') + '导入原片并剪辑</button>');
    $('#topicSelectBtn').addEventListener('click', () => {
      toggleSelection(item.id);
      closeModal();
      showToast(state.selected.includes(item.id) ? '已加入选题' : '已移出选题');
    });
    $('#topicMicroBtn').addEventListener('click', () => makeTopicArticle(item.id, 'micro'));
    $('#topicFeatureBtn').addEventListener('click', () => makeTopicArticle(item.id, 'feature'));
    if ($('#topicOpenSourceBtn')) {
      $('#topicOpenSourceBtn').addEventListener('click', async () => {
        try {
          await api('/api/open', {
            method: 'POST',
            body: JSON.stringify({ url: item.url, browserId: state.config.preferredBrowserId || 'edge' })
          });
          showToast('已打开原文', '可在 Edge 中观看完整内容。', 'info');
        } catch (error) {
          showToast('打开原文失败', error.message, 'error');
        }
      });
    }
    $('#topicVideoBtn').addEventListener('click', () => {
      closeModal();
      generateVideoFromTopic(item.id);
    });
  }

  function makeTopicArticle(topicId, mode) {
    closeModal();
    const currentFocus = state.news.find((item) => item.id === topicId);
    if (!currentFocus) return;
    state.article = null;
    state.articleMode = mode;
    state.articleScope = 'single';
    state.articleFocusId = topicId;
    state.selected = articleItemsFor(topicId).map((item) => item.id);
    saveJson(KEYS.selected, state.selected);
    makeArticle(false, { mode, focusId: topicId, scope: 'single' });
    showView('article');
  }

  function hostName(url) {
    try {
      return new URL(url).hostname.replace(/^www\./, '');
    } catch (error) {
      return '';
    }
  }

  function edgeCaptureBookmarklet() {
    return "javascript:(()=>{const u=encodeURIComponent(location.href),t=encodeURIComponent(document.title),s=encodeURIComponent((getSelection()?getSelection().toString():'').slice(0,1800));window.open('http://127.0.0.1:18766/?edgeCapture=1&url='+u+'&title='+t+'&selected='+s,'_blank','noopener')})()";
  }

  function persistImportedTopic(imported) {
    const duplicate = state.news.some((item) =>
      (imported.url && item.url === imported.url) ||
      item.title.replace(/\s/g, '') === imported.title.replace(/\s/g, ''));
    if (duplicate) return false;
    state.imported.unshift(imported);
    state.imported = state.imported.slice(0, 100);
    saveJson(KEYS.imported, state.imported);
    const remote = state.news.filter((item) => !item.imported);
    state.news = mergeImported(remote);
    if (!state.selected.includes(imported.id) && state.selected.length < 5) state.selected.unshift(imported.id);
    saveJson(KEYS.selected, state.selected);
    return true;
  }

  function edgeCaptureKey(item) {
    const url = String(item && item.url || '').replace(/[?#].*$/, '').replace(/\/$/, '').toLowerCase();
    const title = String(item && item.title || '').replace(/\s/g, '').toLowerCase();
    return url || title;
  }

  function markEdgeSeen(id, item) {
    if (!id) return;
    state.edgeSeen = unique(state.edgeSeen.concat(id)).slice(-200);
    saveJson(KEYS.edgeSeen, state.edgeSeen);
    const key = edgeCaptureKey(item);
    if (key) {
      state.edgeSeenKeys = unique(state.edgeSeenKeys.concat(key)).slice(-300);
      saveJson(KEYS.edgeSeenKeys, state.edgeSeenKeys);
    }
  }

  function importCaptureAsTopic(item) {
    const title = String(item.title || '未命名抓取内容').trim();
    const existing = state.news.find((entry) =>
      (item.url && entry.url === item.url) || entry.title.replace(/\s/g, '') === title.replace(/\s/g, ''));
    if (existing) return existing.id;
    const detected = detectSourcePlatform(item.url || '');
    const section = ['jinjiang', 'fanqie', 'qimao', 'zhihu', 'tencent', 'weibo', 'netease'].includes(detected)
      ? detected
      : guessSection(title + ' ' + (item.description || ''));
    const imported = {
      id: 'edge_' + (item.id || Date.now()),
      title,
      summary: item.description || truncate(item.text || '', 500),
      detailText: item.text || item.description || '',
      url: item.url || '',
      image: item.image || (item.images || [])[0] || '',
      imageOriginal: item.image || (item.images || [])[0] || '',
      gallery: unique(item.images || []),
      source: item.site || hostName(item.url) || '抓取内容',
      section,
      sectionName: sectionInfo(section).name,
      publishedAt: new Date().toISOString(),
      publishedLabel: item.captureMode === 'manual' ? '手动抓取' : 'Edge 自动读取',
      score: 96,
      rank: 0,
      tag: '抓取素材',
      imported: true
    };
    state.imported.unshift(imported);
    state.imported = state.imported.slice(0, 100);
    saveJson(KEYS.imported, state.imported);
    state.news = mergeImported(state.news.filter((entry) => !entry.imported));
    renderAll();
    return imported.id;
  }

  async function captureEverythingNow() {
    showLoading('正在抓取当前内容', '正在读取整篇文章、文本、图片，并检测小说与正在播放的视频。');
    let item = null;
    let captureSource = 'Edge 当前页';
    try {
      try {
        const current = await api('/api/edge-current');
        if (current && current.item && current.item.text) {
          const capturedAt = captureTime(current.item);
          if (!capturedAt || Date.now() - capturedAt < 30 * 60 * 1000) item = current.item;
        }
      } catch (error) {}
      if (!item || !item.text) {
        try {
          const inbox = await api('/api/edge-inbox');
          const recent = (inbox.items || []).find((entry) => {
            if (!entry || !entry.text) return false;
            const capturedAt = captureTime(entry);
            return !capturedAt || Date.now() - capturedAt < 30 * 60 * 1000;
          });
          if (recent) item = recent;
        } catch (error) {}
      }
      if (!item || !item.text) {
        const native = await api('/api/read-platform?platform=edge');
        if (native && native.ok && native.text) {
          item = {
            id: 'edge_window_' + Date.now(),
            title: native.title || 'Edge 当前页面',
            text: native.text,
            url: '',
            site: 'Edge 当前窗口',
            image: '',
            images: [],
            capturedAt: new Date().toISOString(),
            captureMode: 'manual'
          };
          captureSource = 'Edge 窗口文字';
        }
      }
      if (item && item.url && /^https?:\/\//i.test(item.url)) {
        try {
          const extracted = await api('/api/extract?url=' + encodeURIComponent(item.url));
          if (extracted && String(extracted.text || '').replace(/\s/g, '').length >
              String(item.text || '').replace(/\s/g, '').length) {
            item = Object.assign({}, item, {
              title: extracted.title || item.title,
              text: extracted.text,
              image: extracted.image || item.image,
              images: unique((extracted.images || []).concat(item.images || []))
            });
          }
        } catch (error) {}
      }
      item = Object.assign({}, item || {}, {
        captureMode: 'manual',
        capturedAt: item && item.capturedAt || new Date().toISOString()
      });
      let media = null;
      try {
        const detected = await api('/api/media-window');
        if (detected && detected.ok && detected.title) media = detected;
      } catch (error) {}
      hideLoading();
      if (!item.text || String(item.text).replace(/\s/g, '').length < 20) {
        if (media) {
          showModal('检测到正在播放的视频', 'VIDEO DETECTED',
            '<div class="post-browse-source"><strong>' + escapeHtml(media.title) + '</strong><small>' +
              escapeHtml(media.process || '视频软件') + ' · 可抓取当前播放内容</small></div>' +
            '<p class="import-hint">当前页面没有可读正文，但检测到正在播放的视频。可立即抓取画面和可用视频源。</p>',
            '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>' +
            '<button class="btn btn-primary" type="button" id="captureDetectedVideoNow">抓取当前视频</button>');
          $('#captureDetectedVideoNow').addEventListener('click', () => {
            closeModal();
            showView('video');
            capturePlayingVideo();
          });
          return;
        }
        openCaptureLibrary();
        return;
      }
      const importedId = importCaptureAsTopic(item);
      markEdgeSeen(item.id, item);
      const platform = detectSourcePlatform(item.url || '');
      const isNovel = ['jinjiang', 'fanqie', 'qimao', 'zhihu'].includes(platform);
      const isVideoPage = ['qqlive', 'youku', 'mgtv', 'iqiyi', 'bilibili', 'youtube'].includes(platform) ||
        Boolean(media);
      const words = String(item.text || '').replace(/\s/g, '').length;
      const images = unique([item.image].concat(item.images || []).filter(Boolean));
      showModal('抓取完成', 'CONTENT CAPTURED',
        '<div class="source-read-success">' +
          '<div class="post-browse-source"><strong>' + escapeHtml(item.title || '当前内容') + '</strong><small>' +
            escapeHtml(isNovel ? '小说章节' : isVideoPage ? '视频页面' : '文章 / 文本') + ' · ' +
            words + ' 字 · ' + images.length + ' 张图片</small></div>' +
          '<div class="source-read-checks"><span>正文已抓取</span><span>标题已识别</span><span>可生成图文或小说</span></div>' +
          (images.length ? '<div class="capture-image-preview">' +
            images.slice(0, 4).map((url) => '<img src="' + escapeHtml(url) + '" alt="">').join('') + '</div>' : '') +
          '<p class="import-hint">内容已加入抓取素材库。选择下面一个出口，程序会带入全文继续处理。</p>' +
        '</div>',
        '<button class="btn btn-secondary" type="button" data-modal-close>稍后处理</button>' +
        '<button class="btn btn-secondary" type="button" id="captureToNovelBtn">生成原创小说</button>' +
        '<button class="btn btn-secondary" type="button" id="captureToVisualBtn">生成图文卡片</button>' +
        '<button class="btn btn-primary" type="button" id="captureToDigestBtn">生成新闻快读</button>' +
        (isVideoPage ? '<button class="btn btn-secondary" type="button" id="captureToVideoBtn">抓取视频</button>' : ''));
      const useCaptured = (target) => {
        closeModal();
        applyWritingSource(target, item.title || '当前内容', item.text, item.url || '',
          item.site || hostName(item.url) || captureSource);
      };
      $('#captureToNovelBtn').addEventListener('click', () => useCaptured('novel'));
      $('#captureToDigestBtn').addEventListener('click', () => useCaptured('article'));
      $('#captureToVisualBtn').addEventListener('click', () => {
        closeModal();
        showView('article');
        if ($('#articleContentMode')) $('#articleContentMode').value = 'visual';
        state.articleContentMode = 'visual';
        if ($('#articleLayoutPreset')) $('#articleLayoutPreset').value = 'photo';
        selectArticleTemplate('photo');
        applyWritingSource('article', item.title || '当前内容', item.text, item.url || '',
          item.site || hostName(item.url) || captureSource);
      });
      if ($('#captureToVideoBtn')) {
        $('#captureToVideoBtn').addEventListener('click', () => {
          closeModal();
          showView('video');
          capturePlayingVideo();
        });
      }
      return importedId;
    } catch (error) {
      hideLoading();
      reportClientLog('capture-one-click', error && (error.stack || error.message) || error);
      showToast('一键抓取失败', error.message, 'error');
      return false;
    }
  }

  async function openCaptureLibrary() {
    showLoading('正在读取抓取内容', '正在汇总我主动抓取和最近浏览的网页素材。');
    let items = [];
    try {
      const result = await api('/api/edge-inbox');
      items = (result.items || []).filter((item) => item && item.text);
      try {
        const current = await api('/api/edge-current');
        if (current && current.item && current.item.text &&
            !items.some((item) => item.id === current.item.id)) items.unshift(current.item);
      } catch (error) {}
    } catch (error) {
      hideLoading();
      showToast('读取抓取内容失败', error.message, 'error');
      return;
    }
    hideLoading();
    if (!items.length) {
      showModal('抓取内容库', 'CAPTURE LIBRARY',
        '<div class="media-empty">还没有抓取内容。请在 Edge 打开新闻、文章或节目页，鼠标右键选择“抓取当前页面到热点工坊”，再回到这里。</div>' +
        '<div class="modal-note"><p>右键抓取不会上传账号密码，只保存当前页面可访问的标题、正文和图片，供你在本机挑选生成。</p></div>',
        '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>');
      return;
    }
    const selected = new Set(items.slice(0, 1).map((item) => item.id));
    const renderRows = () => items.map((item, index) => {
      const checked = selected.has(item.id);
      const words = String(item.text || '').replace(/\s/g, '').length;
      return '<button class="capture-row' + (checked ? ' selected' : '') + '" type="button" data-capture-select="' +
        escapeHtml(item.id) + '"><span class="capture-check">' + (checked ? '✓' : '') + '</span>' +
        '<span class="capture-thumb">' + (item.image ? '<img src="' + escapeHtml(item.image) + '" alt="">' : '文') + '</span>' +
        '<span class="capture-copy"><strong>' + escapeHtml(item.title || '未命名抓取内容') + '</strong><small>' +
        escapeHtml((item.site || hostName(item.url) || '网页') + ' · ' + words + ' 字 · ' +
          (item.captureMode === 'manual' ? '手动抓取' : '最近浏览')) + '</small><em>' +
        escapeHtml(truncate(item.description || item.text || '', 110)) + '</em></span></button>';
    }).join('');
    const update = () => {
      if ($('#captureSelectionCount')) $('#captureSelectionCount').textContent = '已选 ' + selected.size + ' 条';
      if ($('#captureRowList')) {
        $('#captureRowList').innerHTML = renderRows();
        bindRows();
      }
      if ($('#captureSingleArticle')) $('#captureSingleArticle').disabled = selected.size !== 1;
      if ($('#captureMultiArticle')) $('#captureMultiArticle').disabled = selected.size < 2;
      if ($('#captureNovelBtn')) $('#captureNovelBtn').disabled = selected.size < 1;
      if ($('#captureVideoBtn')) $('#captureVideoBtn').disabled = selected.size < 1;
    };
    const bindRows = () => {
      $$('[data-capture-select]').forEach((button) => {
        button.addEventListener('click', () => {
          const id = button.dataset.captureSelect;
          if (selected.has(id)) {
            selected.delete(id);
          } else if (selected.size >= 8) {
            showToast('一次最多选择 8 条', '请先取消部分内容，再继续添加。', 'info');
            return;
          } else {
            selected.add(id);
          }
          update();
        });
      });
    };
    const chosen = () => items.filter((item) => selected.has(item.id));
    showModal('抓取内容库', 'CAPTURE LIBRARY',
      '<div class="capture-library-head"><div><strong>选择要使用的内容</strong><span id="captureSelectionCount"></span></div>' +
      '<div><button type="button" id="captureSelectLatest">仅选最新</button><button type="button" id="captureSelectAll">全选前 8 条</button></div></div>' +
      '<div class="capture-row-list" id="captureRowList"></div>' +
      '<div class="capture-action-grid">' +
      '<button type="button" id="captureSingleArticle">单条生成图文</button>' +
      '<button type="button" id="captureMultiArticle">多条合并生成</button>' +
      '<button type="button" id="captureNovelBtn">生成原创小说</button>' +
      '<button type="button" id="captureVideoBtn">进入原片剪辑</button>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>' +
      '<button class="btn btn-secondary" type="button" id="captureSaveOnly">仅保存到素材库</button>');
    update();
    $('#captureSelectLatest').addEventListener('click', () => {
      selected.clear();
      selected.add(items[0].id);
      update();
    });
    $('#captureSelectAll').addEventListener('click', () => {
      items.slice(0, 8).forEach((item) => selected.add(item.id));
      update();
    });
    $('#captureSaveOnly').addEventListener('click', () => {
      chosen().forEach(importCaptureAsTopic);
      closeModal();
      showToast('抓取内容已保存', '已加入首页资讯和素材库，可继续单选或多选生成。');
    });
    $('#captureSingleArticle').addEventListener('click', async () => {
      const item = chosen()[0];
      if (!item) return;
      const topicId = importCaptureAsTopic(item);
      closeModal();
      state.article = null;
      state.articleMode = 'feature';
      state.articleScope = 'single';
      state.articleFocusId = topicId;
      state.selected = [topicId].concat(state.selected.filter((id) => id !== topicId)).slice(0, 5);
      saveJson(KEYS.selected, state.selected);
      await makeArticle(true, { scope: 'single', mode: 'feature', focusId: topicId });
    });
    $('#captureMultiArticle').addEventListener('click', async () => {
      const selectedRows = chosen();
      if (selectedRows.length < 2) return;
      const ids = selectedRows.map(importCaptureAsTopic);
      closeModal();
      state.article = null;
      state.articleMode = 'feature';
      state.articleScope = 'multi';
      state.selected = ids.slice(0, 8);
      saveJson(KEYS.selected, state.selected);
      await makeArticle(true, { scope: 'multi', mode: 'feature' });
    });
    $('#captureNovelBtn').addEventListener('click', async () => {
      const selectedRows = chosen();
      if (!selectedRows.length) return;
      selectedRows.forEach((item) => {
        const title = item.title || '抓取素材';
        if (state.novelMaterials.some((material) => material.url && material.url === item.url)) return;
        state.novelMaterials.unshift({
          id: 'novel_capture_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
          title,
          text: truncate(item.text || item.description || '', 12000),
          url: item.url || '',
          source: item.site || hostName(item.url) || '抓取内容',
          createdAt: new Date().toISOString()
        });
      });
      state.novelMaterials = state.novelMaterials.slice(0, 20);
      saveJson(KEYS.novelMaterials, state.novelMaterials);
      const prompt = selectedRows.map((item) => item.title + '：' + truncate(item.description || item.text || '', 280)).join('\n');
      $('#novelQuickPrompt').value = truncate(selectedRows[0].title || '原创小说', 40);
      $('#novelInspiration').value = '参考下列已抓取素材提炼社会背景、人物关系和生活细节，创作完全原创的小说，不复刻原文：\n' + prompt;
      closeModal();
      showView('novel');
      renderNovelMaterials();
      await runNovelQuickWrite();
    });
    $('#captureVideoBtn').addEventListener('click', () => {
      const selectedRows = chosen();
      if (!selectedRows.length) return;
      const text = selectedRows.map((item) => (item.title || '') + '。' + (item.text || item.description || '')).join('\n\n');
      closeModal();
      prepareOriginalVideoProject(selectedRows[0].title || '抓取素材原片剪辑', text);
    });
  }

  function enqueueEdgeCapture(item) {
    if (!item || !item.id || state.edgeSeen.includes(item.id)) return;
    if (state.edgeSeenKeys.includes(edgeCaptureKey(item))) return;
    if (state.browseFlow.active && state.browseFlow.kind === 'writing') return;
    if (item.captureMode === 'manual') {
      markEdgeSeen(item.id, item);
      showToast('已抓取到内容库', item.title || '返回小程序后可勾选生成。');
      return;
    }
    if (state.edgeQueue.some((queued) => queued.id === item.id)) return;
    state.edgeQueue.push(item);
    presentNextEdgeCapture();
  }

  function presentNextEdgeCapture() {
    if (!state.edgeQueue.length || !$('#modalBackdrop').hidden) return;
    const item = state.edgeQueue.shift();
    markEdgeSeen(item.id, item);
    showEdgeConfirm(item);
  }

  function showEdgeConfirm(item) {
    const images = (item.images || []).filter((url) => /^https?:\/\//i.test(url)).slice(0, 6);
    const section = guessSection((item.title || '') + ' ' + (item.description || ''));
    showModal('确认读取这个 Edge 页面？', 'EDGE PAGE CONFIRMATION',
      (images[0] ? '<img class="topic-cover" src="' + escapeHtml(images[0]) + '" alt="">' : '') +
      '<h3 class="topic-title">' + escapeHtml(item.title) + '</h3>' +
      '<div class="topic-meta"><span>' + escapeHtml(item.site || hostName(item.url)) + '</span><span>' +
      escapeHtml(item.url) + '</span><span>正文 ' + (item.text || '').replace(/\s/g, '').length + ' 字</span><span>' +
      images.length + ' 张图片</span></div>' +
      '<p class="topic-summary">' + escapeHtml(truncate(item.description || item.text || '未读取到摘要', 360)) + '</p>' +
      (images.length > 1 ? '<div class="real-image-grid">' + images.map((url, index) =>
        '<div class="real-image-option"><img src="' + escapeHtml(url) + '" alt=""><span>图片 ' + (index + 1) + '</span></div>').join('') + '</div>' : '') +
      '<div class="topic-focus"><strong>确认后如何处理？</strong><p>可以生成单事件图文或原创小说；视频剪辑会要求导入完整原片，不再用网页图片拼成视频。</p></div>' +
      '<label class="edge-confirm-section">归入板块<select id="edgeConfirmSection">' +
      state.config.sections.filter((entry) => entry.enabled).map((entry) =>
        '<option value="' + escapeHtml(entry.id) + '"' + (entry.id === section ? ' selected' : '') + '>' +
        escapeHtml(entry.name) + '</option>').join('') + '</select></label>' +
      (state.edgeQueue.length ? '<p class="import-hint">还有 ' + state.edgeQueue.length + ' 个页面等待确认。</p>' : ''),
      '<button class="btn btn-secondary" type="button" id="edgeIgnoreBtn">忽略本次</button>' +
      '<button class="btn btn-secondary" type="button" id="edgeIgnoreAllBtn">忽略全部待确认</button>' +
      '<button class="btn btn-secondary" type="button" id="edgeImportOnlyBtn">' + icon('save') + '仅导入素材</button>' +
      '<button class="btn btn-secondary" type="button" id="edgeImportMicroBtn">' + icon('doc') + '生成微新闻</button>' +
      '<button class="btn btn-secondary" type="button" id="edgeImportAiBtn">' + icon('doc') + '生成完整图文</button>' +
      '<button class="btn btn-secondary" type="button" id="edgeImportNovelBtn">' + icon('edit') + '生成原创小说</button>' +
      '<button class="btn btn-primary" type="button" id="edgeImportVideoBtn">' + icon('video') + '导入原片并剪辑</button>');
    $('#edgeIgnoreBtn').addEventListener('click', () => {
      closeModal();
      showToast('已忽略本次 Edge 页面');
    });
    $('#edgeIgnoreAllBtn').addEventListener('click', () => {
      state.edgeQueue.forEach((queued) => markEdgeSeen(queued.id, queued));
      state.edgeQueue = [];
      closeModal();
      showToast('已忽略全部待确认页面', '后续打开新的网页时仍会重新提示。');
    });
    $('#edgeImportOnlyBtn').addEventListener('click', () => importEdgeCapture(item, false));
    $('#edgeImportMicroBtn').addEventListener('click', () => importEdgeCapture(item, 'micro'));
    $('#edgeImportAiBtn').addEventListener('click', () => importEdgeCapture(item, true));
    $('#edgeImportNovelBtn').addEventListener('click', () => importEdgeCapture(item, 'novel'));
    $('#edgeImportVideoBtn').addEventListener('click', () => importEdgeCapture(item, 'video'));
  }

  async function importEdgeCapture(item, action) {
    const section = $('#edgeConfirmSection') ? $('#edgeConfirmSection').value : guessSection(item.title);
    let existing = state.news.find((entry) =>
      (item.url && entry.url === item.url) || entry.title.replace(/\s/g, '') === item.title.replace(/\s/g, ''));
    let topicId = existing && existing.id;
    if (!existing) {
      const imported = {
        id: 'edge_' + item.id,
        title: item.title,
        summary: item.description || truncate(item.text, 500),
        detailText: item.text || '',
        url: item.url,
        image: item.image || (item.images || [])[0] || '',
        imageOriginal: item.image || (item.images || [])[0] || '',
        gallery: unique(item.images || []),
        source: item.site || hostName(item.url) || 'Edge 网页',
        section,
        sectionName: sectionInfo(section).name,
        publishedAt: new Date().toISOString(),
        publishedLabel: 'Edge 自动读取',
        score: 96,
        rank: 0,
        tag: 'Edge 自动采集',
        imported: true
      };
      state.imported.unshift(imported);
      state.imported = state.imported.slice(0, 100);
      saveJson(KEYS.imported, state.imported);
      const remote = state.news.filter((entry) => !entry.imported);
      state.news = mergeImported(remote);
      topicId = imported.id;
    }
    if (!state.selected.includes(topicId) && state.selected.length < 5) state.selected.unshift(topicId);
    saveJson(KEYS.selected, state.selected);
    renderAll();
    closeModal();
    if (action === 'video') {
      await generateVideoFromTopic(topicId, {
        capturedText: item.text || '',
        title: item.title || ''
      });
    } else if (action === 'novel') {
      const materialTitle = item.title || 'Edge 页面素材';
      const materialText = String(item.text || item.description || '').replace(/\s+/g, ' ').trim();
      state.novelMaterials.unshift({
        id: 'novel_edge_' + Date.now(),
        title: materialTitle,
        text: truncate(materialText, 12000),
        url: item.url || '',
        source: item.site || hostName(item.url) || 'Edge 网页',
        createdAt: new Date().toISOString()
      });
      state.novelMaterials = state.novelMaterials.slice(0, 10);
      saveJson(KEYS.novelMaterials, state.novelMaterials);
      state.researchImages = (item.images || []).map((url) => ({
        title: materialTitle,
        thumbnail: url,
        url,
        source: item.site || 'Edge 页面',
        creator: '',
        license: '发布前请核对原图授权'
      }));
      state.selectedResearchImages = state.researchImages.slice(0, 4).map((entry, index) => index);
      $('#novelInspiration').value = [
        '参考下面这篇已确认读取的素材进行全新原创小说创作，只提炼背景、人物关系和社会细节。',
        '素材标题：' + materialTitle,
        '素材来源：' + (item.site || hostName(item.url) || 'Edge 网页'),
        '素材正文：' + truncate(materialText, 6000)
      ].join('\n');
      $('#novelQuickPrompt').value = materialTitle;
      showView('novel');
      await runNovelQuickWrite();
    } else if (action === true || action === 'article' || action === 'micro') {
      if (!state.config.ai.enabled || !state.config.ai.hasKey) {
        showToast('素材已导入，但 AI 尚未连接', '请在设置中完成 AI 连接后再点击成稿。', 'info');
        openSettings();
        return;
      }
      state.article = null;
      await makeArticle(true, {
        scope: 'single',
        mode: action === 'micro' ? 'micro' : 'feature',
        focusId: topicId
      });
    } else {
      showToast('Edge 素材已导入', '已保存标题、正文和 ' + ((item.images || []).length) + ' 张图片。');
      showPostBrowseActions(item.title || 'Edge 页面', item.site || hostName(item.url) || 'Edge 网页');
    }
  }

  async function pollEdgeInbox() {
    try {
      const result = await api('/api/edge-inbox');
      const items = result.items || [];
      if (!state.edgeInboxInitialized) {
        items.forEach((item) => state.edgeInboxKnownIds.add(item.id));
        state.edgeInboxInitialized = true;
      } else {
        items.slice().reverse().forEach((item) => {
          if (state.edgeInboxKnownIds.has(item.id)) return;
          state.edgeInboxKnownIds.add(item.id);
          enqueueEdgeCapture(item);
        });
      }
      loadEdgeStatus();
    } catch (error) {
      // The app may be starting while the extension is posting.
    }
  }

  async function openNeteaseWatch() {
    try {
      const startedAt = Date.now();
      await api('/api/netease-watch/start', { method: 'POST', body: '{}' });
      const result = await api('/api/open-music', { method: 'POST', body: '{}' });
      state.neteaseWatchStart = startedAt;
      state.neteasePromptedAt = 0;
      if (String(result.method || '').startsWith('desktop')) {
        showToast('网易云音乐已打开', '请选择电台或内容页面，然后切回热点工坊；程序会自动读取并等待你确认。', 'info');
      } else {
        showModal('网易云桌面版没有显示窗口', 'NETEASE MUSIC',
          '<p class="topic-summary">网易云后台进程正在运行，但没有找到可见窗口。可以直接重启桌面版；如果仍然失败，请从开始菜单手动打开一次网易云。</p>',
          '<button class="btn btn-secondary" type="button" data-modal-close>稍后处理</button>' +
          '<button class="btn btn-primary" type="button" id="restartNeteaseBtn">重启网易云桌面版</button>');
        $('#restartNeteaseBtn').addEventListener('click', async () => {
          const button = $('#restartNeteaseBtn');
          button.disabled = true;
          button.textContent = '正在重启…';
          try {
            const restarted = await api('/api/restart-music', { method: 'POST', body: '{}' });
            if (String(restarted.method || '').startsWith('desktop')) {
              state.neteaseWatchStart = Date.now();
              state.neteasePromptedAt = 0;
              closeModal();
              showToast('网易云桌面版已重新启动', '选择电台或页面后，切回热点工坊即可自动读取。');
            } else {
              button.disabled = false;
              button.textContent = '重新尝试';
              showToast('仍未能显示网易云窗口', '请从 Windows 开始菜单手动打开网易云一次。', 'error');
            }
          } catch (error) {
            button.disabled = false;
            button.textContent = '重新尝试';
            showToast('重启失败', error.message, 'error');
          }
        });
      }
    } catch (error) {
      showToast('打开网易云失败', error.message, 'error');
    }
  }

  async function pollNeteaseSnapshot() {
    if (!state.neteaseWatchStart || !$('#modalBackdrop').hidden) return;
    try {
      const snapshot = await api('/api/netease-snapshot');
      if (!snapshot.available || !snapshot.activeAtUtc) return;
      if (Number(snapshot.activeAtUtc) <= Math.max(state.neteaseWatchStart, state.neteasePromptedAt)) return;
      state.neteasePromptedAt = Number(snapshot.activeAtUtc);
      showNeteaseConfirm(snapshot);
    } catch (error) {
      // Waiting for the desktop watcher to produce a snapshot.
    }
  }

  function showNeteaseConfirm(snapshot) {
    const text = truncate(String(snapshot.text || '').replace(/\s+/g, ' ').trim(), 1200);
    const sections = parseNeteaseSections(snapshot);
    showModal('网易云内容已读取', 'NETEASE CLOUD CAPTURE',
      (snapshot.imageUrl ? '<img class="topic-cover" src="' + escapeHtml(snapshot.imageUrl) + '" alt="">' : '') +
      '<h3 class="topic-title">' + escapeHtml(snapshot.title || '网易云音乐当前页面') + '</h3>' +
      '<div class="topic-meta"><span>网易云音乐</span><span>本机窗口读取</span></div>' +
      '<p class="topic-summary">' + escapeHtml(text || '已读取网易云窗口，但可识别文字较少。') + '</p>' +
      (sections.length ? '<div class="netease-section-block"><strong>选择要生成视频的小节</strong><div class="netease-section-list">' +
        sections.map((section, index) => '<label><input type="radio" name="neteaseSection" value="' + index + '"' +
          (index === 0 ? ' checked' : '') + '><span><b>' + escapeHtml(section.label ? section.label + ' · ' : '') +
          escapeHtml(section.title) + '</b><small>' + escapeHtml(section.meta || '当前节目列表') +
          '</small></span></label>').join('') + '</div></div>' : '') +
      '<div class="topic-focus"><strong>确认后如何处理？</strong><p>“生成短视频”会保存当前截图和文字，并自动整理为短视频脚本。请确认你有权使用页面中出现的封面、人物和内容。</p></div>',
      '<button class="btn btn-secondary" type="button" id="neteaseIgnoreBtn">忽略本次</button>' +
      '<button class="btn btn-secondary" type="button" id="neteaseSaveBtn">保存为话题</button>' +
      '<button class="btn btn-primary" type="button" id="neteaseVideoBtn">' + icon('video') + '生成短视频</button>');
    $('#neteaseIgnoreBtn').addEventListener('click', async () => {
      closeModal();
      state.neteaseWatchStart = 0;
      await api('/api/netease-watch/stop', { method: 'POST', body: '{}' }).catch(() => null);
    });
    $('#neteaseSaveBtn').addEventListener('click', () => importNeteaseSnapshot(snapshot, sections, false));
    $('#neteaseVideoBtn').addEventListener('click', () => importNeteaseSnapshot(snapshot, sections, true));
  }

  function parseNeteaseSections(snapshot) {
    const lines = String(snapshot.text || '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    const sections = [];
    const seen = new Set();
    const addSection = (label, title, meta) => {
      const cleanTitle = String(title || '').replace(/^\d{2,4}\s*/, '').trim();
      if (cleanTitle.length < 3 || cleanTitle.length > 90 || seen.has(cleanTitle)) return;
      if (/^(播放全部|搜索|评论|声音|主理人|收藏|分享)$/.test(cleanTitle)) return;
      seen.add(cleanTitle);
      sections.push({ label: label || '', title: cleanTitle, meta: meta || '' });
    };
    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      const combined = line.match(/^#?(\d{2,4})[.、\s]+(.{3,80}?)(?:\s+(\d{1,2}:\d{2}))?$/);
      if (combined) {
        addSection(combined[1], combined[2], combined[3] || '');
        continue;
      }
      if (/^\d{2,4}$/.test(line) && lines[i + 1]) {
        const nearby = lines.slice(i + 1, Math.min(lines.length, i + 5)).join(' ');
        const duration = nearby.match(/\b\d{1,2}:\d{2}\b/);
        addSection(line, lines[i + 1], duration ? duration[0] : '');
        continue;
      }
      const withDuration = line.match(/^(.{4,90}?)\s+(\d{1,2}:\d{2})$/);
      if (withDuration) addSection('', withDuration[1], withDuration[2]);
    }
    if (!sections.length && snapshot.title) {
      sections.push({ label: '', title: snapshot.title, meta: '当前播放页面' });
    }
    return sections.slice(0, 20);
  }

  async function importNeteaseSnapshot(snapshot, sections, makeVideo) {
    const cleanText = String(snapshot.text || '').replace(/\s+/g, ' ').trim();
    const checked = document.querySelector('input[name="neteaseSection"]:checked');
    const selectedSection = sections && sections.length ? sections[Number(checked ? checked.value : 0)] : null;
    const title = truncate(selectedSection ? selectedSection.title : (snapshot.title || '网易云音乐内容分享'), 80);
    let script = '本期节目：' + title + '。' + (selectedSection && selectedSection.meta ? '节目时长' + selectedSection.meta + '。' : '') +
      '结合当前页面公开可见信息，我们来看这一小节的主要内容。' + truncate(cleanText, 360);
    if (makeVideo && state.config.ai.enabled && state.config.ai.hasKey) {
      showLoading('正在整理短视频脚本', '根据网易云页面标题和可见文字生成简洁旁白，不复制歌曲歌词。');
      try {
        const result = await api('/api/ai', {
          method: 'POST',
          body: JSON.stringify({
            system: '你是短视频编导。只根据给出的页面标题和可见文字撰写客观中文旁白，不编造内容，不复述完整歌词。',
            prompt: '请写成120到220字的短视频旁白，直接可用于口播。页面标题：' + title + '\n可见文字：' + truncate(cleanText, 1800),
            temperature: .5
          })
        });
        if (result.ok && result.text) script = result.text.trim();
      } catch (error) {
        // Keep the local fallback script.
      } finally {
        hideLoading();
      }
    }
    const imported = {
      id: 'netease_' + Date.now(),
      title,
      summary: truncate(cleanText || '网易云音乐当前页面', 700),
      detailText: cleanText,
      url: '',
      image: snapshot.imageUrl || '',
      imageOriginal: snapshot.imageUrl || '',
      gallery: snapshot.imageUrl ? [snapshot.imageUrl] : [],
      source: '网易云音乐',
      section: 'entertainment',
      sectionName: '文娱',
      publishedAt: new Date().toISOString(),
      publishedLabel: '网易云读取',
      score: 94,
      rank: 0,
      tag: '网易云内容',
      imported: true
    };
    persistImportedTopic(imported);
    state.selected = unique([imported.id].concat(state.selected)).slice(0, 5);
    saveJson(KEYS.selected, state.selected);
    renderAll();
    closeModal();
    state.neteaseWatchStart = 0;
    await api('/api/netease-watch/stop', { method: 'POST', body: '{}' }).catch(() => null);
    if (makeVideo) {
      state.videoScript = script;
      state.videoEpisodeTitle = title;
      state.videoComposition = 'montage';
      state.videoVisualStyle = 'platform';
      state.videoDuration = 30;
      showView('video');
      primeAudio();
      setTimeout(() => renderVideo(), 100);
    } else {
      showToast('网易云内容已保存', '可在素材库或视频页继续使用。');
    }
  }

  function guessSection(text) {
    const value = String(text || '');
    const rules = [
      ['tech', /人工智能|科技|芯片|互联网|算法|机器人|数码/],
      ['finance', /经济|金融|股票|基金|消费|市场|企业|投资/],
      ['sports', /体育|比赛|足球|篮球|奥运|运动员/],
      ['auto', /汽车|新能源车|车企|驾驶|车型/],
      ['entertainment', /电影|电视剧|演员|艺人|娱乐|演出/],
      ['military', /军事|国防|军队|战机|舰艇/],
      ['digital', /手机|数码|电脑|相机|耳机|平板/],
      ['game', /游戏|电竞|主机|手游|玩家/],
      ['world', /国际|全球|外交|美国|欧洲|联合国/],
      ['society', /社会|社区|学校|医院|交通|天气|城市/]
    ];
    const match = rules.find((rule) => rule[1].test(value));
    return match ? match[0] : 'general';
  }

  async function importEdgeFiles(fileList) {
    const files = Array.from(fileList || []).slice(0, 20);
    if (!files.length) return;
    let added = 0;
    let skipped = 0;
    showLoading('正在读取 Edge 文件', '正在解析你选择的 HTML、TXT、Markdown 或 JSON 文件。');
    for (const file of files) {
      try {
        if (file.size > 8 * 1024 * 1024) {
          skipped += 1;
          continue;
        }
        const raw = await file.text();
        let title = file.name.replace(/\.[^.]+$/, '');
        let summary = raw;
        let image = '';
        let url = '';
        if (/\.html?$/i.test(file.name)) {
          const doc = new DOMParser().parseFromString(raw, 'text/html');
          title = doc.querySelector('h1')?.textContent?.trim() || doc.querySelector('title')?.textContent?.trim() || title;
          image = doc.querySelector('meta[property="og:image"]')?.content || doc.querySelector('meta[name="twitter:image"]')?.content || '';
          url = doc.querySelector('link[rel="canonical"]')?.href || doc.querySelector('meta[property="og:url"]')?.content || '';
          const article = doc.querySelector('article') || doc.querySelector('main') || doc.body;
          summary = article ? article.textContent : raw;
        } else if (/\.json$/i.test(file.name)) {
          const parsed = JSON.parse(raw);
          const value = Array.isArray(parsed) ? parsed[0] : parsed;
          title = value.title || value.name || title;
          summary = value.content || value.text || value.summary || JSON.stringify(value, null, 2);
          image = value.image || value.cover || '';
          url = value.url || value.link || '';
        } else if (/\.(md|markdown)$/i.test(file.name)) {
          title = raw.match(/^#\s+(.+)$/m)?.[1]?.trim() || title;
          summary = raw.replace(/^#{1,6}\s+/gm, '').replace(/[*_`>#-]/g, ' ');
        }
        summary = truncate(summary.replace(/\s+/g, ' ').trim(), 1800);
        if (!summary || summary.length < 20) {
          skipped += 1;
          continue;
        }
        const section = guessSection(title + summary);
        const imported = {
          id: 'edgefile_' + Date.now() + '_' + Math.random().toString(16).slice(2, 6),
          title: truncate(title, 80),
          summary,
          url: /^https?:\/\//i.test(url) ? url : '',
          image,
          source: 'Edge 文件 · ' + file.name,
          section,
          sectionName: sectionInfo(section).name,
          publishedAt: new Date().toISOString(),
          publishedLabel: '文件导入',
          score: 95,
          rank: 0,
          tag: 'Edge 导入',
          imported: true
        };
        if (persistImportedTopic(imported)) added += 1;
        else skipped += 1;
      } catch (error) {
        skipped += 1;
      }
    }
    renderAll();
    closeModal();
    hideLoading();
    showToast('Edge 文件导入完成', '成功导入 ' + added + ' 个话题' + (skipped ? '，跳过 ' + skipped + ' 个空文件或重复内容' : '') + '。');
  }

  async function readImportUrlIntoForm(url) {
    const button = $('#readImportUrlBtn');
    button.disabled = true;
    button.textContent = '读取中…';
    try {
      const result = await api('/api/extract?url=' + encodeURIComponent(url));
      if (!result.ok) throw new Error(result.error || '没有读取到正文');
      $('#importTitle').value = result.title || $('#importTitle').value;
      $('#importSummary').value = truncate(result.text || $('#importSummary').value, 1800);
      $('#importImage').value = result.image || '';
      $('#importSource').value = hostName(url) || 'Edge 页面';
      showToast('链接内容已读取', '请检查标题、摘要和图片后再导入。');
    } catch (error) {
      showToast('自动读取正文失败', '可直接使用 Edge 中选中的文字，或手动补充内容：' + error.message, 'error');
    } finally {
      button.disabled = false;
      button.textContent = '读取';
    }
  }

  function openImportHot(prefill) {
    showModal('导入一个热点', 'IMPORT HOT TOPIC',
      '<form class="import-form" id="importHotForm">' +
        '<div class="edge-capture-box">' +
          '<div><strong>从 Edge 当前新闻页采集</strong><p>显示 Edge 收藏栏后，把右侧按钮拖到收藏栏；在新闻页点击它即可送入热点工坊。</p></div>' +
          '<a id="edgeBookmarklet" href="javascript:void(0)">采集到热点工坊</a>' +
          '<button type="button" id="copyBookmarkletBtn">复制采集书签</button>' +
        '</div>' +
        '<label class="edge-file-button">从 Edge 下载目录选择文件<input id="edgeFileInput" type="file" accept=".html,.htm,.txt,.md,.markdown,.json,text/html,text/plain,application/json" multiple></label>' +
        '<p class="import-hint">支持一次选择多个 HTML、TXT、Markdown 或 JSON 文件。只会读取你主动选择的文件。</p>' +
        '<label>新闻或热点链接<div class="import-reader"><input id="importUrl" type="url" placeholder="粘贴公开新闻链接，自动读取标题和图片"><button class="btn btn-secondary" type="button" id="readImportUrlBtn">读取</button></div></label>' +
        '<p class="import-hint">也可以不填链接，直接手动录入热点内容。</p>' +
        '<div class="two-col"><label>标题<input id="importTitle" required placeholder="热点标题"></label><label>来源<input id="importSource" placeholder="例如：公开报道"></label></div>' +
        '<label>频道<select id="importSection">' + state.config.sections.filter((section) => section.enabled).map((section) =>
          '<option value="' + escapeHtml(section.id) + '">' + escapeHtml(section.name) + '</option>').join('') + '</select></label>' +
        '<label>讨论内容 / 摘要<textarea id="importSummary" required placeholder="粘贴事件内容、讨论焦点或你的观察"></textarea></label>' +
        '<label>图片地址（可选）<input id="importImage" type="url" placeholder="https://..."></label>' +
      '</form>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-primary" type="button" id="confirmImportBtn">' + icon('plus') + '导入话题库</button>');
    const bookmarklet = edgeCaptureBookmarklet();
    $('#edgeBookmarklet').href = bookmarklet;
    $('#edgeBookmarklet').addEventListener('click', (event) => {
      event.preventDefault();
      showToast('请先加入 Edge 收藏栏', '把这个按钮拖到 Edge 收藏栏，再在新闻页面点击;也可以复制书签代码后手动新建收藏。', 'info');
    });
    $('#copyBookmarkletBtn').addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(bookmarklet);
        showToast('采集书签代码已复制', '在 Edge 收藏夹中新建网址并粘贴，或直接把左侧“采集到热点工坊”拖到收藏栏。');
      } catch (error) {
        showToast('复制失败', '可直接将“采集到热点工坊”拖到 Edge 收藏栏。', 'error');
      }
    });
    $('#edgeFileInput').addEventListener('change', (event) => importEdgeFiles(event.target.files));
    if (prefill && prefill.url) {
      $('#importUrl').value = prefill.url;
      $('#importTitle').value = prefill.title || '';
      $('#importSummary').value = prefill.selected || '';
      $('#importSource').value = hostName(prefill.url) || 'Edge 页面';
      if (prefill.autoRead) setTimeout(() => readImportUrlIntoForm(prefill.url), 80);
    }
    $('#readImportUrlBtn').addEventListener('click', () => {
      const url = $('#importUrl').value.trim();
      if (!/^https?:\/\//i.test(url)) {
        showToast('请输入完整链接', '链接应以 http:// 或 https:// 开头。', 'info');
        return;
      }
      readImportUrlIntoForm(url);
    });
    $('#confirmImportBtn').addEventListener('click', () => {
      const title = $('#importTitle').value.trim();
      const summary = $('#importSummary').value.trim();
      if (!title || !summary) {
        showToast('标题和内容不能为空', null, 'info');
        return;
      }
      const url = $('#importUrl').value.trim();
      const section = $('#importSection').value;
      const duplicate = state.news.some((item) =>
        (url && item.url === url) || item.title.replace(/\s/g, '') === title.replace(/\s/g, ''));
      if (duplicate) {
        showToast('这个热点已经在话题库中', '可以直接在列表里打开讨论。', 'info');
        return;
      }
      const imported = {
        id: 'imported_' + Date.now(),
        title,
        summary,
        url,
        image: $('#importImage').value.trim(),
        source: $('#importSource').value.trim() || hostName(url) || '手动导入',
        section,
        sectionName: sectionInfo(section).name,
        publishedAt: new Date().toISOString(),
        publishedLabel: '刚刚导入',
        score: 96,
        rank: 0,
        tag: '自定义热点',
        imported: true
      };
      state.imported.unshift(imported);
      state.imported = state.imported.slice(0, 100);
      saveJson(KEYS.imported, state.imported);
      const remote = state.news.filter((item) => !item.imported);
      state.news = mergeImported(remote);
      if (!state.selected.includes(imported.id)) state.selected.unshift(imported.id);
      state.selected = state.selected.slice(0, 5);
      saveJson(KEYS.selected, state.selected);
      renderAll();
      closeModal();
      showToast('热点已导入', '已加入话题库和当前选题。');
      openTopic(imported.id);
    });
  }

  function showPublishMenu() {
    showModal('发布一篇新内容', 'CREATE',
      '<div class="publish-step"><span>01</span><div><strong>单事件讨论</strong><p>只围绕当前热点，生成微新闻或单事件深度稿。</p></div></div>' +
      '<div class="publish-step"><span>02</span><div><strong>多事件讨论</strong><p>分别陈述多个已选热点，再讨论共同关注，不虚构事件关联。</p></div></div>' +
      '<div class="publish-step"><span>03</span><div><strong>生成人物口播</strong><p>AI 主播讲述新闻，自动加入画面、字幕和旁白。</p></div></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-secondary" type="button" id="modalMakeArticle">' + icon('doc') + '单事件</button>' +
      '<button class="btn btn-secondary" type="button" id="modalMakeMulti">' + icon('news') + '多事件</button>' +
      '<button class="btn btn-primary" type="button" id="modalMakeVideo">' + icon('video') + '人物口播</button>');
    $('#modalMakeArticle').addEventListener('click', () => {
      closeModal();
      state.article = null;
      makeArticle(true, { scope: 'single', focusId: leadItem()?.id || '' });
    });
    $('#modalMakeMulti').addEventListener('click', () => {
      closeModal();
      state.article = null;
      makeArticle(true, { scope: 'multi', mode: 'feature' });
    });
    $('#modalMakeVideo').addEventListener('click', () => { closeModal(); startVideoFromHome(); });
  }

  function loadCanvasImage(url) {
    if (!url) return Promise.resolve(null);
    if (imageCache.has(url)) return imageCache.get(url);
    const promise = new Promise((resolve) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => resolve(null);
      image.src = (url.startsWith('data:') || url.startsWith('/')) ? url : '/api/image?url=' + encodeURIComponent(url);
    });
    imageCache.set(url, promise);
    return promise;
  }

  function roundRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
  }

  function drawCover(ctx, image, x, y, width, height, zoom) {
    if (!image) return false;
    const ratio = Math.max(width / image.width, height / image.height) * (zoom || 1);
    const sw = width / ratio;
    const sh = height / ratio;
    ctx.drawImage(image, (image.width - sw) / 2, (image.height - sh) / 2, sw, sh, x, y, width, height);
    return true;
  }

  function wrapLines(ctx, text, maxWidth, maxLines) {
    const chars = Array.from(String(text || ''));
    const lines = [];
    let line = '';
    for (let i = 0; i < chars.length; i += 1) {
      const next = line + chars[i];
      if (ctx.measureText(next).width > maxWidth && line) {
        lines.push(line);
        line = chars[i];
        if (lines.length === maxLines - 1) break;
      } else {
        line = next;
      }
    }
    if (line && lines.length < maxLines) lines.push(line);
    return lines;
  }

  function drawPresenter(ctx, cx, cy, scale, time, mouthOpen, female) {
    const bob = Math.sin(time * 2.1) * 3 * scale;
    const blinkCycle = (time % 4.2);
    const blink = blinkCycle > 3.92 && blinkCycle < 4.15;
    const skin = female ? '#efc3aa' : '#d9ad91';
    const skinShade = female ? '#dfa88e' : '#c58e72';
    const hair = female ? '#32251f' : '#24262a';
    const jacket = female ? '#eb7467' : '#28466e';
    const jacketDark = female ? '#c95653' : '#1d3658';
    const faceW = 118 * scale;
    const faceH = 153 * scale;
    const headY = cy + bob;

    ctx.save();
    ctx.translate(cx, 0);
    const shoulderY = headY + 190 * scale;
    const shoulderW = 248 * scale;
    const bodyGradient = ctx.createLinearGradient(-shoulderW, shoulderY, shoulderW, headY + 550 * scale);
    bodyGradient.addColorStop(0, jacket);
    bodyGradient.addColorStop(1, jacketDark);
    ctx.fillStyle = bodyGradient;
    ctx.beginPath();
    ctx.moveTo(-48 * scale, headY + 130 * scale);
    ctx.bezierCurveTo(-72 * scale, headY + 182 * scale, -196 * scale, headY + 185 * scale, -shoulderW, shoulderY);
    ctx.bezierCurveTo(-300 * scale, headY + 380 * scale, -330 * scale, headY + 530 * scale, -350 * scale, headY + 650 * scale);
    ctx.lineTo(350 * scale, headY + 650 * scale);
    ctx.bezierCurveTo(325 * scale, headY + 500 * scale, 286 * scale, headY + 330 * scale, shoulderW, shoulderY);
    ctx.bezierCurveTo(186 * scale, headY + 180 * scale, 66 * scale, headY + 180 * scale, 48 * scale, headY + 130 * scale);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#fffaf4';
    ctx.beginPath();
    ctx.moveTo(-45 * scale, headY + 164 * scale);
    ctx.lineTo(0, headY + 248 * scale);
    ctx.lineTo(45 * scale, headY + 164 * scale);
    ctx.lineTo(73 * scale, headY + 215 * scale);
    ctx.lineTo(18 * scale, headY + 390 * scale);
    ctx.lineTo(-38 * scale, headY + 390 * scale);
    ctx.lineTo(-102 * scale, headY + 213 * scale);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = jacketDark;
    ctx.beginPath();
    ctx.moveTo(-48 * scale, headY + 175 * scale);
    ctx.lineTo(-10 * scale, headY + 270 * scale);
    ctx.lineTo(-102 * scale, headY + 500 * scale);
    ctx.lineTo(-150 * scale, headY + 210 * scale);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(48 * scale, headY + 175 * scale);
    ctx.lineTo(10 * scale, headY + 270 * scale);
    ctx.lineTo(102 * scale, headY + 500 * scale);
    ctx.lineTo(150 * scale, headY + 210 * scale);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = skinShade;
    ctx.fillRect(-38 * scale, headY + 104 * scale, 76 * scale, 88 * scale);
    ctx.fillStyle = skin;
    ctx.fillRect(-37 * scale, headY + 100 * scale, 74 * scale, 88 * scale);

    if (female) {
      ctx.fillStyle = hair;
      ctx.beginPath();
      ctx.ellipse(0, headY - 14 * scale, 148 * scale, 178 * scale, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-143 * scale, headY - 12 * scale);
      ctx.quadraticCurveTo(-177 * scale, headY + 160 * scale, -116 * scale, headY + 195 * scale);
      ctx.lineTo(-77 * scale, headY + 83 * scale);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(143 * scale, headY - 12 * scale);
      ctx.quadraticCurveTo(177 * scale, headY + 160 * scale, 116 * scale, headY + 195 * scale);
      ctx.lineTo(77 * scale, headY + 83 * scale);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.fillStyle = hair;
      ctx.beginPath();
      ctx.ellipse(0, headY - 30 * scale, 128 * scale, 140 * scale, 0, Math.PI, Math.PI * 2);
      ctx.lineTo(122 * scale, headY + 22 * scale);
      ctx.quadraticCurveTo(60 * scale, headY - 90 * scale, -98 * scale, headY + 12 * scale);
      ctx.closePath();
      ctx.fill();
    }

    ctx.fillStyle = skin;
    ctx.beginPath();
    ctx.ellipse(0, headY, faceW, faceH, 0, 0, Math.PI * 2);
    ctx.fill();
    if (female) {
      ctx.fillStyle = hair;
      ctx.beginPath();
      ctx.moveTo(-112 * scale, headY - 45 * scale);
      ctx.quadraticCurveTo(-60 * scale, headY - 190 * scale, 72 * scale, headY - 140 * scale);
      ctx.quadraticCurveTo(10 * scale, headY - 83 * scale, 118 * scale, headY - 45 * scale);
      ctx.quadraticCurveTo(32 * scale, headY - 111 * scale, -112 * scale, headY - 45 * scale);
      ctx.fill();
    }
    ctx.fillStyle = skinShade;
    ctx.beginPath();
    ctx.ellipse(-faceW + 6 * scale, headY + 8 * scale, 17 * scale, 29 * scale, 0, 0, Math.PI * 2);
    ctx.ellipse(faceW - 6 * scale, headY + 8 * scale, 17 * scale, 29 * scale, 0, 0, Math.PI * 2);
    ctx.fill();

    const eyeY = headY - 19 * scale;
    const eyeGap = 43 * scale;
    if (blink) {
      ctx.strokeStyle = '#57443e';
      ctx.lineWidth = 3 * scale;
      [-eyeGap, eyeGap].forEach((eyeX) => {
        ctx.beginPath();
        ctx.moveTo(eyeX - 15 * scale, eyeY);
        ctx.quadraticCurveTo(eyeX, eyeY + 4 * scale, eyeX + 15 * scale, eyeY);
        ctx.stroke();
      });
    } else {
      [-eyeGap, eyeGap].forEach((eyeX) => {
        ctx.fillStyle = '#fffdfa';
        ctx.beginPath();
        ctx.ellipse(eyeX, eyeY, 15 * scale, 9 * scale, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#3b2c29';
        ctx.beginPath();
        ctx.arc(eyeX + 2 * scale, eyeY + 1 * scale, 5 * scale, 0, Math.PI * 2);
        ctx.fill();
      });
    }
    ctx.strokeStyle = female ? '#6f4b41' : '#573f34';
    ctx.lineWidth = 3.4 * scale;
    ctx.beginPath();
    ctx.moveTo(-62 * scale, headY - 53 * scale);
    ctx.quadraticCurveTo(-43 * scale, headY - 66 * scale, -24 * scale, headY - 54 * scale);
    ctx.moveTo(24 * scale, headY - 54 * scale);
    ctx.quadraticCurveTo(43 * scale, headY - 66 * scale, 62 * scale, headY - 53 * scale);
    ctx.stroke();
    ctx.strokeStyle = skinShade;
    ctx.lineWidth = 3 * scale;
    ctx.beginPath();
    ctx.moveTo(0, headY + 2 * scale);
    ctx.quadraticCurveTo(-5 * scale, headY + 35 * scale, 4 * scale, headY + 38 * scale);
    ctx.stroke();

    const mouthH = (7 + mouthOpen * 18) * scale;
    ctx.fillStyle = '#8c3f48';
    roundRect(ctx, -29 * scale, headY + 64 * scale, 58 * scale, mouthH, mouthH / 2);
    ctx.fill();
    if (mouthH > 11 * scale) {
      ctx.fillStyle = '#fff5f2';
      ctx.fillRect(-18 * scale, headY + 66 * scale, 36 * scale, 4 * scale);
    }
    if (female) {
      ctx.fillStyle = '#d7ae68';
      ctx.beginPath();
      ctx.arc(-faceW + 6 * scale, headY + 33 * scale, 6 * scale, 0, Math.PI * 2);
      ctx.arc(faceW - 6 * scale, headY + 33 * scale, 6 * scale, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.strokeStyle = jacket;
    ctx.lineWidth = 66 * scale;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-195 * scale, headY + 315 * scale);
    ctx.quadraticCurveTo(-262 * scale, headY + 380 * scale, -244 * scale, headY + 465 * scale);
    ctx.stroke();
    ctx.fillStyle = skin;
    ctx.beginPath();
    ctx.ellipse(-245 * scale, headY + 480 * scale, 31 * scale, 43 * scale, -.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#eb514a';
    ctx.beginPath();
    ctx.arc(145 * scale, headY + 285 * scale, 7 * scale, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.85)';
    ctx.font = '600 ' + 16 * scale + 'px "Microsoft YaHei UI"';
    ctx.textAlign = 'center';
    ctx.fillText('AI主播 · ' + (female ? '小热' : '小闻'), 145 * scale, headY + 320 * scale);
    ctx.restore();
  }

  async function drawTalkingFrame(items, stageIndex, time, ratio, presenterFemale) {
    const canvas = $('#videoCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const portrait = ratio === '9:16';
    const item = stageIndex >= 0 && stageIndex < items.length ? items[stageIndex] : items[0] || null;
    const image = item ? await loadCanvasImage(item.image) : null;
    const presenterPhoto = state.presenterImage ? await loadCanvasImage(state.presenterImage) : null;

    const base = ctx.createLinearGradient(0, 0, width, height);
    base.addColorStop(0, '#101a2b');
    base.addColorStop(.55, '#1d2c45');
    base.addColorStop(1, '#432d36');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, width, height);
    if (image) {
      ctx.save();
      ctx.globalAlpha = .22;
      ctx.filter = 'blur(30px)';
      drawCover(ctx, image, -40, -30, width + 80, height + 60, 1.1);
      ctx.restore();
    }
    ctx.save();
    ctx.globalAlpha = .07;
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 1.5;
    const step = portrait ? 72 : 58;
    for (let x = 0; x < width; x += step) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
    }
    for (let y = 0; y < height; y += step) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
    }
    ctx.restore();

    const margin = portrait ? 58 : 48;
    ctx.fillStyle = '#ff7259';
    ctx.fillRect(margin, portrait ? 66 : 34, portrait ? 58 : 42, 7);
    ctx.fillStyle = '#fff';
    ctx.font = '700 ' + (portrait ? 28 : 20) + 'px "Microsoft YaHei UI"';
    ctx.textAlign = 'left';
    ctx.fillText('热点工坊 · 今日口播', margin, portrait ? 112 : 75);
    ctx.fillStyle = '#a4afc1';
    ctx.font = '500 ' + (portrait ? 21 : 15) + 'px "Microsoft YaHei UI"';
    ctx.textAlign = 'right';
    ctx.fillText(dateLabel(), width - margin, portrait ? 112 : 75);
    ctx.textAlign = 'left';

    if (portrait) {
      const panelX = 56;
      const panelY = 172;
      const panelW = width - 112;
      const panelH = 655;
      ctx.save();
      roundRect(ctx, panelX, panelY, panelW, panelH, 24);
      ctx.clip();
      if (image) drawCover(ctx, image, panelX, panelY, panelW, panelH, 1.02);
      else {
        const fallback = ctx.createLinearGradient(panelX, panelY, panelX + panelW, panelY + panelH);
        fallback.addColorStop(0, '#334a68');
        fallback.addColorStop(1, '#c56e5c');
        ctx.fillStyle = fallback;
        ctx.fillRect(panelX, panelY, panelW, panelH);
      }
      const shade = ctx.createLinearGradient(0, panelY + 300, 0, panelY + panelH);
      shade.addColorStop(0, 'rgba(10,17,29,0)');
      shade.addColorStop(1, 'rgba(10,17,29,.86)');
      ctx.fillStyle = shade;
      ctx.fillRect(panelX, panelY, panelW, panelH);
      ctx.restore();

      if (stageIndex < 0) {
        ctx.fillStyle = '#ff8a73';
        ctx.font = '800 28px "Microsoft YaHei UI"';
        ctx.fillText('TODAY’S STORY  /  今日速览', margin, 310);
        ctx.fillStyle = '#fff';
        ctx.font = '800 86px "Microsoft YaHei UI"';
        const intro = state.videoEpisodeTitle
          ? wrapLines(ctx, state.videoEpisodeTitle, panelW - 60, 3)
          : ['大家好，', '今天聊' + items.length + '件事。'];
        intro.forEach((line, index) => ctx.fillText(line, margin, 430 + index * 92));
        ctx.fillStyle = '#a6b2c5';
        ctx.font = '500 26px "Microsoft YaHei UI"';
        ctx.fillText('AI 主播为你梳理今天值得关注的新闻', margin, 668);
      } else if (stageIndex >= items.length) {
        ctx.fillStyle = '#ff8a73';
        ctx.font = '800 28px "Microsoft YaHei UI"';
        ctx.fillText('THE END  /  信息仍在更新', margin, 320);
        ctx.fillStyle = '#fff';
        ctx.font = '800 92px "Microsoft YaHei UI"';
        ['先核验，', '再表达。'].forEach((line, index) => ctx.fillText(line, margin, 455 + index * 115));
        ctx.fillStyle = '#a6b2c5';
        ctx.font = '500 27px "Microsoft YaHei UI"';
        ctx.fillText('热点工坊 · 明天继续为你梳理', margin, 738);
      } else {
        ctx.fillStyle = '#ff7b63';
        roundRect(ctx, margin, 675, 150, 42, 8);
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.font = '700 20px "Microsoft YaHei UI"';
        ctx.fillText(item.sectionName, margin + 22, 704);
        ctx.font = '800 45px "Microsoft YaHei UI"';
        const titleLines = wrapLines(ctx, item.title, panelW - 80, 2);
        titleLines.forEach((line, index) => ctx.fillText(line, margin + 4, 770 + index * 60));
      }

      if (presenterPhoto) {
        ctx.save();
        roundRect(ctx, 400, 815, 600, 810, 34);
        ctx.clip();
        drawCover(ctx, presenterPhoto, 400, 815, 600, 810, 1.02);
        ctx.restore();
        ctx.fillStyle = 'rgba(8,16,29,.8)';
        roundRect(ctx, 425, 1518, 250, 38, 8);
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.font = '600 18px "Microsoft YaHei UI"';
        ctx.fillText('AI/真人主播形象', 445, 1543);
      } else {
        drawPresenter(ctx, 684, stageIndex < 0 || stageIndex >= items.length ? 1080 : 1102, 1.0, time, .3 + Math.abs(Math.sin(time * 11)) * .7, presenterFemale);
      }

      const captionY = 1570;
      ctx.fillStyle = 'rgba(13,22,36,.88)';
      roundRect(ctx, margin, captionY, width - margin * 2, 212, 22);
      ctx.fill();
      ctx.fillStyle = '#ff8a72';
      ctx.font = '700 20px "Microsoft YaHei UI"';
      ctx.fillText('AI 主播正在讲述', margin + 29, captionY + 42);
      ctx.fillStyle = '#f5f7fb';
      ctx.font = '600 29px "Microsoft YaHei UI"';
      const caption = stageIndex < 0 ? '大家好，这里是热点工坊的今日资讯速览。' :
        stageIndex >= items.length ? '以上就是今天的新闻。发布前记得核验事实和素材授权。' :
        firstSentence(item.summary);
      const captionLines = wrapLines(ctx, caption, width - margin * 2 - 58, 3);
      captionLines.forEach((line, index) => ctx.fillText(line, margin + 29, captionY + 92 + index * 43));
    } else {
      const panelX = 610;
      const panelY = 142;
      const panelW = 580;
      const panelH = 350;
      ctx.save();
      roundRect(ctx, panelX, panelY, panelW, panelH, 20);
      ctx.clip();
      if (image) drawCover(ctx, image, panelX, panelY, panelW, panelH, 1.03);
      else {
        const fallback = ctx.createLinearGradient(panelX, panelY, panelX + panelW, panelY + panelH);
        fallback.addColorStop(0, '#334a68');
        fallback.addColorStop(1, '#c56e5c');
        ctx.fillStyle = fallback;
        ctx.fillRect(panelX, panelY, panelW, panelH);
      }
      ctx.restore();
      if (stageIndex < 0) {
        ctx.fillStyle = '#ff8a73';
        ctx.font = '800 21px "Microsoft YaHei UI"';
        ctx.fillText('TODAY’S STORY', 55, 154);
        ctx.fillStyle = '#fff';
        ctx.font = '800 53px "Microsoft YaHei UI"';
        (state.videoEpisodeTitle
          ? wrapLines(ctx, state.videoEpisodeTitle, 520, 3)
          : ['大家好，今天', '聊' + items.length + '件事。']).forEach((line, index) => ctx.fillText(line, 55, 232 + index * 66));
      } else if (stageIndex >= items.length) {
        ctx.fillStyle = '#ff8a73';
        ctx.font = '800 21px "Microsoft YaHei UI"';
        ctx.fillText('THE END', 55, 154);
        ctx.fillStyle = '#fff';
        ctx.font = '800 54px "Microsoft YaHei UI"';
        ['先核验，', '再表达。'].forEach((line, index) => ctx.fillText(line, 55, 232 + index * 67));
      } else {
        ctx.fillStyle = '#ff7b63';
        ctx.font = '700 20px "Microsoft YaHei UI"';
        ctx.fillText(item.sectionName + '  ·  ' + String(stageIndex + 1).padStart(2, '0'), 55, 154);
        ctx.fillStyle = '#fff';
        ctx.font = '800 34px "Microsoft YaHei UI"';
        const titleLines = wrapLines(ctx, item.title, 520, 3);
        titleLines.forEach((line, index) => ctx.fillText(line, 55, 225 + index * 48));
      }
      if (presenterPhoto) {
        ctx.save();
        roundRect(ctx, 70, 175, 470, 390, 22);
        ctx.clip();
        drawCover(ctx, presenterPhoto, 70, 175, 470, 390, 1.02);
        ctx.restore();
      } else {
        drawPresenter(ctx, 295, 475, .7, time, .3 + Math.abs(Math.sin(time * 11)) * .7, presenterFemale);
      }
      ctx.fillStyle = 'rgba(13,22,36,.88)';
      roundRect(ctx, 40, 576, width - 80, 104, 15);
      ctx.fill();
      ctx.fillStyle = '#f5f7fb';
      ctx.font = '600 22px "Microsoft YaHei UI"';
      const caption = stageIndex < 0 ? '大家好，这里是热点工坊的今日资讯速览。' :
        stageIndex >= items.length ? '以上就是今天的新闻，发布前请核验事实和素材授权。' :
        firstSentence(item.summary);
      const lines = wrapLines(ctx, caption, width - 120, 2);
      lines.forEach((line, index) => ctx.fillText(line, 62, 615 + index * 31));
    }

    ctx.fillStyle = '#ff7259';
    ctx.beginPath();
    ctx.arc(width - margin - 12, height - 38, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#8290a5';
    ctx.font = '500 ' + (portrait ? 19 : 14) + 'px "Microsoft YaHei UI"';
    ctx.textAlign = 'right';
    ctx.fillText('AI 生成画面 · 发布前请核验', width - margin - 28, height - 31);
    ctx.textAlign = 'left';
  }

  async function drawMontageFrame(items, stageIndex, time, ratio, globalProgress) {
    const canvas = $('#videoCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const portrait = ratio === '9:16';
    const intro = stageIndex < 0;
    const outro = stageIndex >= items.length;
    const item = intro ? items[0] : (outro ? items[items.length - 1] : items[stageIndex]);
    const image = item ? await loadCanvasImage(item.image) : null;
    const platform = state.videoVisualStyle === 'platform';
    const accent = platform ? '#ff5a48' : '#e33e32';
    const secondary = platform ? '#4b78f2' : '#205f9b';
    const background = ctx.createLinearGradient(0, 0, width, height);
    background.addColorStop(0, platform ? '#10131c' : '#15243c');
    background.addColorStop(.7, platform ? '#20263a' : '#233756');
    background.addColorStop(1, platform ? '#46242d' : '#562e36');
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, width, height);
    if (image) {
      ctx.save();
      ctx.globalAlpha = .18;
      ctx.filter = 'blur(28px)';
      drawCover(ctx, image, -30, -30, width + 60, height + 60, 1.12);
      ctx.restore();
    }

    const margin = portrait ? 52 : 46;
    ctx.fillStyle = accent;
    ctx.fillRect(margin, portrait ? 58 : 34, portrait ? 58 : 44, 7);
    ctx.fillStyle = '#fff';
    ctx.font = '800 ' + (portrait ? 28 : 20) + 'px "Microsoft YaHei UI"';
    ctx.fillText(platform ? '今日热点快剪' : '今日新闻速览', margin, portrait ? 105 : 75);
    ctx.textAlign = 'right';
    ctx.fillStyle = '#b7c0cf';
    ctx.font = '500 ' + (portrait ? 19 : 14) + 'px "Microsoft YaHei UI"';
    ctx.fillText(dateLabel(), width - margin, portrait ? 105 : 75);
    ctx.textAlign = 'left';

    if (portrait) {
      const imageX = 50;
      const imageY = 160;
      const imageW = width - 100;
      const imageH = 830;
      const drift = platform ? Math.sin(time * .8) * 5 : 0;
      ctx.save();
      roundRect(ctx, imageX + drift, imageY, imageW, imageH, 24);
      ctx.clip();
      if (image) drawCover(ctx, image, imageX + drift, imageY, imageW, imageH, 1.03);
      else {
        const fallback = ctx.createLinearGradient(imageX, imageY, imageX + imageW, imageY + imageH);
        fallback.addColorStop(0, secondary);
        fallback.addColorStop(1, accent);
        ctx.fillStyle = fallback;
        ctx.fillRect(imageX, imageY, imageW, imageH);
      }
      const shade = ctx.createLinearGradient(0, imageY + 420, 0, imageY + imageH);
      shade.addColorStop(0, 'rgba(8,14,24,0)');
      shade.addColorStop(1, 'rgba(8,14,24,.88)');
      ctx.fillStyle = shade;
      ctx.fillRect(imageX, imageY, imageW, imageH);
      ctx.restore();

      if (intro) {
        ctx.fillStyle = '#ff8b76';
        ctx.font = '800 26px "Microsoft YaHei UI"';
        ctx.fillText('NEWS MONTAGE · 自动剪辑', margin + 6, 320);
        ctx.fillStyle = '#fff';
        ctx.font = '800 88px "Microsoft YaHei UI"';
        (state.videoEpisodeTitle
          ? wrapLines(ctx, state.videoEpisodeTitle, imageW - 80, 3)
          : ['今天值得', '关注的新闻']).forEach((line, index) => ctx.fillText(line, margin + 6, 455 + index * 92));
        ctx.fillStyle = '#b9c4d4';
        ctx.font = '500 26px "Microsoft YaHei UI"';
        ctx.fillText(items.length + ' 条素材 · 自动配图与配音', margin + 6, 725);
      } else if (outro) {
        ctx.fillStyle = '#ff8b76';
        ctx.font = '800 26px "Microsoft YaHei UI"';
        ctx.fillText('END · 热点仍在更新', margin + 6, 325);
        ctx.fillStyle = '#fff';
        ctx.font = '800 86px "Microsoft YaHei UI"';
        ['先核验，', '再发布。'].forEach((line, index) => ctx.fillText(line, margin + 6, 465 + index * 112));
      } else {
        ctx.fillStyle = accent;
        roundRect(ctx, margin + 18, 695, 176, 44, 8);
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.font = '700 20px "Microsoft YaHei UI"';
        ctx.fillText(item.sectionName, margin + 40, 725);
        ctx.font = '800 48px "Microsoft YaHei UI"';
        const titleLines = wrapLines(ctx, item.title, imageW - 80, 3);
        titleLines.forEach((line, index) => ctx.fillText(line, margin + 22, 790 + index * 64));
      }

      ctx.fillStyle = 'rgba(10,18,31,.9)';
      roundRect(ctx, margin, 1045, width - margin * 2, 560, 22);
      ctx.fill();
      ctx.fillStyle = accent;
      ctx.font = '800 22px "Microsoft YaHei UI"';
      ctx.fillText(intro ? '今日看什么' : outro ? '内容提示' : '新闻要点', margin + 30, 1093);
      ctx.fillStyle = '#f5f7fb';
      ctx.font = '700 ' + (platform ? 38 : 34) + 'px "Microsoft YaHei UI"';
      const title = intro ? '从多条新闻里，快速抓住今天的关键信息。' :
        outro ? '热点变化很快，发布前请核验来源、事实与图片授权。' : item.title;
      const titleLines = wrapLines(ctx, title, width - margin * 2 - 60, 3);
      titleLines.forEach((line, index) => ctx.fillText(line, margin + 30, 1150 + index * 52));
      ctx.fillStyle = '#aeb9c9';
      ctx.font = '500 27px "Microsoft YaHei UI"';
      const summary = intro ? '自动提取新闻图片、标题和摘要，组合成竖屏短视频。' :
        outro ? '关注热点工坊，继续整理下一条重要新闻。' : firstSentence(item.summary);
      const summaryLines = wrapLines(ctx, summary, width - margin * 2 - 60, 3);
      summaryLines.forEach((line, index) => ctx.fillText(line, margin + 30, 1390 + index * 44));
      ctx.fillStyle = '#8794a8';
      ctx.font = '500 20px "Microsoft YaHei UI"';
      ctx.fillText(intro ? 'AUTO NEWS EDIT' : (outro ? '热点工坊 · LOCAL NEWS STUDIO' : (item.source || '公开资讯') + ' · ' + item.sectionName), margin + 30, 1538);
    } else {
      const imageW = 650;
      ctx.save();
      roundRect(ctx, margin, 150, imageW, 440, 20);
      ctx.clip();
      if (image) drawCover(ctx, image, margin, 150, imageW, 440, 1.03);
      else {
        ctx.fillStyle = secondary;
        ctx.fillRect(margin, 150, imageW, 440);
      }
      ctx.restore();
      const panelX = margin + imageW + 30;
      const panelW = width - panelX - margin;
      ctx.fillStyle = accent;
      ctx.font = '800 20px "Microsoft YaHei UI"';
      ctx.fillText(intro ? 'NEWS MONTAGE' : outro ? 'END' : (item.sectionName + ' · ' + String(stageIndex + 1).padStart(2, '0')), panelX, 188);
      ctx.fillStyle = '#fff';
      ctx.font = '800 ' + (platform ? 40 : 36) + 'px "Microsoft YaHei UI"';
      const title = intro ? (state.videoEpisodeTitle || '今天值得关注的新闻') : outro ? '先核验，再发布。' : item.title;
      const titleLines = wrapLines(ctx, title, panelW, 4);
      titleLines.forEach((line, index) => ctx.fillText(line, panelX, 250 + index * 49));
      ctx.fillStyle = '#aeb9c9';
      ctx.font = '500 21px "Microsoft YaHei UI"';
      const summary = intro ? '多条新闻素材自动组合。' : outro ? '发布前核验事实和图片授权。' : firstSentence(item.summary);
      const summaryLines = wrapLines(ctx, summary, panelW, 3);
      summaryLines.forEach((line, index) => ctx.fillText(line, panelX, 500 + index * 34));
      ctx.fillStyle = '#718096';
      ctx.font = '500 16px "Microsoft YaHei UI"';
      ctx.fillText(item ? (item.source || '公开资讯') : '', panelX, 625);
    }

    ctx.fillStyle = 'rgba(255,255,255,.15)';
    ctx.fillRect(margin, height - (portrait ? 72 : 26), width - margin * 2, 4);
    ctx.fillStyle = accent;
    ctx.fillRect(margin, height - (portrait ? 72 : 26), (width - margin * 2) * Math.max(0, globalProgress || 0), 4);
    ctx.fillStyle = '#8290a5';
    ctx.font = '500 ' + (portrait ? 18 : 13) + 'px "Microsoft YaHei UI"';
    ctx.fillText('热点工坊 · 自动剪辑', margin, height - 28);
    ctx.textAlign = 'right';
    ctx.fillText('发布前请核验素材', width - margin, height - 28);
    ctx.textAlign = 'left';
  }

  async function drawVideoVisual(items, stageIndex, time, ratio, presenterFemale, globalProgress) {
    if (state.videoComposition !== 'talk') {
      return drawMontageFrame(items, stageIndex, time, ratio, globalProgress);
    }
    return drawTalkingFrame(items, stageIndex, time, ratio, presenterFemale);
  }

  function videoQualitySpec() {
    const fullHd = state.videoQuality !== 'hd';
    return {
      label: fullHd ? '超清 1080P' : '高清 720P',
      portrait: fullHd ? [1080, 1920] : [720, 1280],
      landscape: fullHd ? [1920, 1080] : [1280, 720],
      bitrate: fullHd ? 12000000 : 6500000,
      fps: 30
    };
  }

  function setCanvasRatio() {
    const canvas = $('#videoCanvas');
    if (!canvas || state.recording) return;
    const quality = videoQualitySpec();
    const dimensions = state.ratio === '9:16' ? quality.portrait : quality.landscape;
    canvas.width = dimensions[0];
    canvas.height = dimensions[1];
    if (state.localVideoClips.length) {
      const ctx = canvas.getContext('2d');
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      gradient.addColorStop(0, '#111827');
      gradient.addColorStop(1, '#4a2828');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.textAlign = 'center';
      ctx.fillStyle = '#fff';
      ctx.font = '800 ' + (state.ratio === '9:16' ? 62 : 42) + 'px "Microsoft YaHei UI"';
      ctx.fillText('已导入 ' + state.localVideoClips.length + ' 段原片', canvas.width / 2, canvas.height * .43);
      ctx.fillStyle = '#d8b26b';
      ctx.font = '600 ' + (state.ratio === '9:16' ? 28 : 20) + 'px "Microsoft YaHei UI"';
      ctx.fillText('选择剪辑方式后开始生成', canvas.width / 2, canvas.height * .43 + 75);
      ctx.textAlign = 'left';
      return;
    }
    const items = videoItemsForComposition();
    drawVideoVisual(items, 0, 0, state.ratio, state.presenter === 'female', 0);
  }

  function videoItemsForComposition() {
    if (state.videoComposition !== 'talk') return ensureSources(2).slice(0, 5);
    return ensureSources(1).slice(0, 1);
  }

  function renderVideoSources() {
    const items = videoItemsForComposition();
    const container = $('#videoSources');
    if (!container) return;
    if (state.localVideoClips.length) {
      container.innerHTML = state.localVideoClips.map((clip, index) =>
        '<div class="video-source-wrap">' +
          '<input class="video-material-check" type="checkbox" data-video-material-select="' +
          escapeHtml(originalClipKey(clip)) + '"' +
          (state.videoLibrarySelected.includes(originalClipKey(clip)) ? ' checked' : '') + '>' +
          '<button type="button" class="video-source" data-video-local-index="' + index + '"><span>' +
          String(index + 1).padStart(2, '0') + '</span><div><strong>' +
          escapeHtml(clip.name) + '</strong><small>授权原片 · ' + Math.round(clip.duration || 0) +
          ' 秒</small></div><b>预览</b></button>' +
          '<button type="button" class="video-source-delete" data-video-local-delete="' +
          escapeHtml(clip.libraryId || clip.id || '') + '">删除</button>' +
        '</div>'
      ).join('');
      return;
    }
    container.innerHTML = items.slice(0, 5).map((item, index) =>
      '<button type="button" class="video-source' + (state.selected.includes(item.id) ? ' selected' : '') +
      '" data-video-news-id="' + escapeHtml(item.id) + '"><span>' + String(index + 1).padStart(2, '0') +
      '</span><div><strong>' + escapeHtml(item.title) + '</strong><small>' + escapeHtml(item.source) +
      ' · ' + escapeHtml(item.sectionName) + '</small></div><b>打开</b></button>'
    ).join('') || '<div class="empty-draft">从首页选择新闻素材</div>';
  }

  function renderVideoLibraries() {
    const originals = $('#originalLibraryList');
    const finished = $('#finishedLibraryList');
    const capturedList = $('#capturedVideoLibraryList');
    if (!originals || !finished) return;
    const capturedClips = state.localVideoClips
      .filter((clip) => clip.originType === 'captured')
      .sort((a, b) => Number(b.capturedAt || 0) - Number(a.capturedAt || 0));
    const regularClips = state.localVideoClips.filter((clip) => clip.originType !== 'captured');
    $('#originalLibraryCount').textContent = regularClips.length + ' 段';
    if ($('#capturedVideoLibraryCount')) {
      $('#capturedVideoLibraryCount').textContent = capturedClips.length + ' 段';
    }
    $('#finishedLibraryCount').textContent = state.finishedVideos.length + ' 个';
    originals.innerHTML = regularClips.length
      ? regularClips.map((clip, index) =>
          '<div class="video-library-item"><input type="checkbox" data-video-library-select="' +
          escapeHtml(originalClipKey(clip)) + '"' +
          (state.videoLibrarySelected.includes(originalClipKey(clip)) ? ' checked' : '') +
          '><span class="video-library-index">' +
          String(index + 1).padStart(2, '0') + '</span><div><strong>' + escapeHtml(clip.name) +
          '</strong><small>' + Math.round(clip.duration || 0) + ' 秒 · ' +
          formatFileSize(clip.size) + ' · 保存在本机素材库</small></div>' +
          '<button type="button" data-library-play="original" data-library-id="' + escapeHtml(clip.libraryId || clip.id || '') +
          '">预览</button><button type="button" data-library-edit="original" data-library-id="' +
          escapeHtml(clip.libraryId || clip.id || '') + '">剪辑</button><button type="button" data-library-delete="original" data-library-id="' +
          escapeHtml(clip.libraryId || clip.id || '') + '" class="danger">删除</button></div>'
        ).join('')
      : '<span class="video-library-empty">导入或从软件、网站下载授权原片后，会保存在这里。</span>';
    if (capturedList) {
      if (!capturedClips.length) {
        capturedList.innerHTML =
          '<span class="video-library-empty">尚未抓取视频内容。使用“抓取当前播放视频”后会显示在这里。</span>';
      } else {
        const groups = new Map();
        capturedClips.forEach((clip) => {
          const timestamp = Number(clip.capturedAt) || new Date(clip.createdAt || 0).getTime();
          const date = Number.isFinite(timestamp) && timestamp > 0 ? new Date(timestamp) : new Date();
          const key = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') +
            '-' + String(date.getDate()).padStart(2, '0');
          if (!groups.has(key)) groups.set(key, { date, items: [] });
          groups.get(key).items.push({ clip, date });
        });
        capturedList.innerHTML = Array.from(groups.entries()).map(([key, group]) => {
          const dateLabel = group.date.toLocaleDateString('zh-CN', {
            year: 'numeric', month: 'long', day: 'numeric', weekday: 'short'
          });
          return '<div class="captured-date-group"><div class="captured-date-head"><strong>' +
            escapeHtml(dateLabel) + '</strong><small>' + group.items.length + ' 段</small></div>' +
            '<div class="captured-date-items">' +
            group.items.map(({ clip, date }) => {
              const id = escapeHtml(clip.libraryId || clip.id || '');
              return '<div class="captured-video-item"><input type="checkbox" data-video-library-select="' +
                id + '"' + (state.videoLibrarySelected.includes(clip.libraryId || clip.id || '') ? ' checked' : '') +
                '><span class="captured-video-time">' +
                date.toLocaleTimeString('zh-CN', { hour12: false }) + '</span>' +
                '<div><strong>' + escapeHtml(clip.name || '抓取视频') + '</strong><small>' +
                Math.round(clip.duration || 0) + ' 秒 · ' + formatFileSize(clip.size) +
                '</small></div>' +
                '<button type="button" data-library-play="original" data-library-id="' + id +
                '">预览</button><button type="button" data-library-edit="original" data-library-id="' +
                id + '">剪辑</button><button type="button" data-library-delete="original" data-library-id="' +
                id + '" class="danger">删除</button></div>';
            }).join('') + '</div></div>';
        }).join('');
      }
    }
    finished.innerHTML = state.finishedVideos.length
      ? state.finishedVideos.map((video) =>
          '<div class="video-library-item finished"><span class="video-library-index">成</span><div><strong>' +
          escapeHtml(video.title || '原片剪辑成品') + '</strong><small>' +
          Math.round(video.duration || 0) + ' 秒 · ' + formatFileSize(video.size) + ' · ' +
          escapeHtml(video.composition === 'montage' ? '高光快切' : '原片顺序') + '</small></div>' +
          '<button type="button" data-library-play="finished" data-library-id="' + escapeHtml(video.id) +
          '">预览</button><button type="button" data-library-download="' + escapeHtml(video.id) +
          '">下载</button><button type="button" data-library-delete="finished" data-library-id="' +
          escapeHtml(video.id) + '" class="danger">删除</button></div>'
        ).join('')
      : '<span class="video-library-empty">每次剪辑完成后，成品会自动保存在这里。</span>';
    renderOriginalPublishBoard();
  }

  function originalClipKey(clip) {
    return String(clip.libraryId || clip.id || clip.name || '');
  }

  function toggleVideoSelectionScope(clips) {
    const ids = clips.map(originalClipKey).filter(Boolean);
    if (!ids.length) return;
    const selected = new Set(state.videoLibrarySelected);
    const allSelected = ids.every((id) => selected.has(id));
    ids.forEach((id) => {
      if (allSelected) selected.delete(id);
      else selected.add(id);
    });
    state.videoLibrarySelected = Array.from(selected);
    renderVideoSources();
    renderVideoLibraries();
  }

  async function deleteSelectedVideoMaterials() {
    const ids = state.videoLibrarySelected.slice();
    if (!ids.length) {
      showToast('没有选择视频', '请先勾选要删除的原片。', 'info');
      return;
    }
    if (!window.confirm('确定删除已勾选的 ' + ids.length + ' 段视频吗？本机文件也会删除。')) return;
    state.videoLibrarySelected = [];
    for (const id of ids) {
      try { await deleteLibraryVideo('original', id, true); } catch (error) {}
    }
    renderVideoSources();
    renderVideoLibraries();
    showToast('所选视频已删除', '共删除 ' + ids.length + ' 段，本机文件已同步清理。');
  }

  function renderOriginalPublishBoard() {
    const list = $('#originalPublishList');
    if (!list) return;
    const clips = state.localVideoClips.filter((clip) => clip && clip.url);
    if (!clips.length) {
      list.innerHTML = '<span class="video-library-empty">导入或抓取原片后可在这里直接选择发布。</span>';
      return;
    }
    const validIds = new Set(clips.map(originalClipKey));
    state.originalPublishSelected = state.originalPublishSelected.filter((id) => validIds.has(id));
    if (!state.originalPublishSelectionTouched) {
      state.originalPublishSelected = clips.map(originalClipKey);
    }
    list.innerHTML = clips.map((clip) => {
      const id = originalClipKey(clip);
      return '<label class="original-publish-item">' +
        '<input type="checkbox" data-publish-original-id="' + escapeHtml(id) + '"' +
        (state.originalPublishSelected.includes(id) ? ' checked' : '') + '>' +
        '<span><strong>' + escapeHtml(clip.name || '原视频') + '</strong><small>' +
        Math.round(clip.duration || 0) + ' 秒 · ' + formatFileSize(clip.size) +
        ' · ' + (clip.originType === 'captured' ? '网页抓取' : '原片素材') +
        '</small></span><em>直接原片</em></label>';
    }).join('');
  }

  async function loadMediaLibraries() {
    try {
      const records = await Promise.all([
        mediaStoreAll(MEDIA_ORIGINAL_STORE),
        mediaStoreAll(MEDIA_FINISHED_STORE)
      ]);
      const originals = (records[0] || []).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
      originals.forEach((record) => {
        if (!record.blob || state.localVideoClips.some((clip) => clip.libraryId === record.id)) return;
        const inferredCaptured = String(record.name || '').startsWith('网页视频抓取-');
        state.localVideoClips.push({
          id: record.id,
          libraryId: record.id,
          name: record.name || '已保存原片',
          size: record.size || record.blob.size || 0,
          duration: record.duration || 0,
          analysis: record.analysis || [],
          serverFile: record.serverFile || '',
          originType: record.originType || (inferredCaptured ? 'captured' : 'downloaded'),
          capturedAt: record.capturedAt ||
            (inferredCaptured && record.createdAt ? new Date(record.createdAt).getTime() : ''),
          url: URL.createObjectURL(record.blob)
        });
      });
      state.localVideoClips = state.localVideoClips.slice(0, 20);
      state.finishedVideos = (records[1] || [])
        .filter((record) => record.blob)
        .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
        .map((record) => Object.assign({}, record, { url: URL.createObjectURL(record.blob) }));
    } catch (error) {
      console.warn('Local media library unavailable', error);
    } finally {
      state.mediaLibraryReady = true;
      renderVideoLibraries();
      renderLocalClipList();
      renderVideoSources();
    }
  }

  async function persistOriginalVideo(file, material) {
    const id = 'original_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    const record = {
      id,
      name: file.name,
      size: file.size,
      duration: material.duration || 0,
      analysis: material.analysis || [],
      serverFile: material.serverFile || '',
      originType: material.originType || 'downloaded',
      capturedAt: material.capturedAt || '',
      createdAt: new Date().toISOString(),
      blob: file
    };
    material.id = id;
    material.libraryId = id;
    material.size = file.size;
    await mediaStorePut(MEDIA_ORIGINAL_STORE, record);
  }

  async function persistFinishedVideo(blob, title) {
    const id = 'finished_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    const record = {
      id,
      title: title || '原片剪辑成品',
      duration: state.videoDuration,
      composition: state.videoComposition,
      style: state.videoVisualStyle,
      size: blob.size,
      createdAt: new Date().toISOString(),
      blob
    };
    await mediaStorePut(MEDIA_FINISHED_STORE, record);
    state.finishedVideos.unshift(Object.assign({}, record, { url: URL.createObjectURL(blob) }));
    state.finishedVideos = state.finishedVideos.slice(0, 20);
    renderVideoLibraries();
    return record;
  }

  async function loadServerOriginals(showResult) {
    if (state.serverOriginalsLoading) return false;
    state.serverOriginalsLoading = true;
    let added = 0;
    try {
      const result = await api('/api/originals');
      if (result.folder) {
        state.originalFolder = result.folder;
        if ($('#originalLibraryPath')) $('#originalLibraryPath').textContent = '保存位置：' + result.folder;
      }
      const items = (result.items || []).slice(0, 12);
      for (const item of items.reverse()) {
        if (!item || !item.url) continue;
        const existing = state.localVideoClips.find((clip) =>
          clip.serverFile === item.file || (!clip.serverFile && clip.name === item.file));
        if (existing) {
          existing.serverFile = item.file;
          continue;
        }
        const response = await fetch(item.url, { cache: 'no-store' });
        if (!response.ok) continue;
        const blob = await response.blob();
        if (!blob.size) continue;
        const file = new File([blob], item.file || ('原片-' + Date.now() + '.mp4'), {
          type: blob.type || 'video/mp4'
        });
        const objectUrl = URL.createObjectURL(blob);
        const material = await analyzeVideoMaterial(objectUrl, file.name);
        material.size = blob.size;
        material.serverFile = item.file || '';
        material.originType = 'downloaded';
        try {
          await persistOriginalVideo(file, material);
        } catch (storageError) {
          material.id = 'original_server_' + Date.now();
          material.libraryId = material.id;
        }
        state.localVideoClips.unshift(material);
        added += 1;
      }
      state.localVideoClips = state.localVideoClips.slice(0, 20);
      state.serverOriginalsLoaded = true;
      if (added) {
        renderLocalClipList();
        renderVideoSources();
        renderVideoLibraries();
        if (showResult) showToast('原片已加入素材库', '已导入 ' + added + ' 段原片，可以开始选择剪辑方式。');
      } else if (showResult) {
        showToast('没有新的原片', '请先在软件或网站中右键下载，或通过“导入已下载原片”添加。', 'info');
      }
      return added > 0;
    } catch (error) {
      if (showResult) showToast('读取原片栏失败', error.message, 'error');
      return false;
    } finally {
      state.serverOriginalsLoading = false;
    }
  }

  async function showVideoDownloadTask(taskId, title) {
    trackVideoDownloadTask(taskId, title);
    showView('video');
    showModal('正在下载原片', 'DOWNLOADING',
      '<div class="video-download-progress-card" id="videoDownloadProgressCard">' +
        '<div class="download-progress-head"><span class="download-pulse"></span><div><strong>' +
        escapeHtml(title || '视频原片') + '</strong><small id="videoDownloadStage">正在连接视频源…</small></div><b id="videoDownloadPercent">0%</b></div>' +
        '<div class="download-progress-track"><i id="videoDownloadBar"></i></div>' +
        '<div class="download-progress-meta"><span id="videoDownloadBytes">等待服务器响应</span><span>下载完成后自动预览</span></div>' +
        '<div class="download-location"><span>保存位置</span><code id="videoDownloadFolder">' +
        escapeHtml(state.originalFolder || '程序目录\\data\\originals') + '</code>' +
        '<button type="button" id="openVideoDownloadFolderBtn">打开文件夹</button></div>' +
        '<button class="btn btn-secondary btn-block" id="videoDownloadImportButton" type="button" hidden>导入已下载原片</button>' +
        '<button class="btn btn-primary btn-block" id="videoDownloadCaptureButton" type="button" hidden>抓取当前播放的视频内容</button>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>查看下载队列</button>');
    $('#videoDownloadImportButton').addEventListener('click', () => {
      closeModal();
      state.autoStartAfterClipImport = true;
      $('#localClipInput').click();
    });
    $('#videoDownloadCaptureButton').addEventListener('click', () => {
      closeModal();
      capturePlayingVideo();
    });
    $('#openVideoDownloadFolderBtn').addEventListener('click', async () => {
      try {
        const result = await api('/api/open-originals', { method: 'POST', body: '{}' });
        if (result.folder) $('#videoDownloadFolder').textContent = result.folder;
      } catch (error) {
        showToast('无法打开原片文件夹', error.message, 'error');
      }
    });
    let attempts = 0;
    const update = async () => {
      if ($('#modalBackdrop').hidden || !$('#videoDownloadProgressCard')) return;
      attempts += 1;
      try {
        const status = await api('/api/video-import-status?id=' + encodeURIComponent(taskId));
        applyVideoDownloadStatus(taskId, status);
        if (status.folder) {
          state.originalFolder = status.folder;
          $('#videoDownloadFolder').textContent = status.folder;
          if ($('#originalLibraryPath')) $('#originalLibraryPath').textContent = '保存位置：' + status.folder;
        }
        const progress = Math.max(0, Math.min(100, Number(status.progress) || 0));
        $('#videoDownloadPercent').textContent = progress + '%';
        $('#videoDownloadBar').style.width = progress + '%';
        $('#videoDownloadBytes').textContent = status.size
          ? formatFileSize(status.size)
          : progress < 10 ? '正在建立连接' : '正在接收视频数据';
        $('#videoDownloadStage').textContent = status.status === 'completed'
          ? '下载完成，正在生成预览…'
          : status.status === 'failed'
            ? '下载未完成'
            : status.status === 'queued'
              ? '已加入下载队列' +
                (status.queuePosition ? ' · 第 ' + status.queuePosition + ' 个' : '')
            : '正在下载原片，请稍候…';
        if (status.status === 'completed') {
          $('#videoDownloadPercent').textContent = '100%';
          $('#videoDownloadBar').style.width = '100%';
          let guard = 0;
          while (state.serverOriginalsLoading && guard < 30) {
            await new Promise((resolve) => setTimeout(resolve, 200));
            guard += 1;
          }
          state.serverOriginalsLoaded = false;
          await loadServerOriginals(false);
          const clip = state.localVideoClips.find((item) => item.serverFile === status.file);
          closeModal();
          if (clip) {
            openLibraryVideo('original', clip.libraryId || clip.id);
            showToast('原片下载完成', '已自动打开原片预览，可以开始剪辑。');
          } else {
            showVideoNextStep('原片栏', '下载已完成，请点击“导入已下载原片”或从原片保存栏预览。');
            showToast('原片下载完成', '请在原片保存栏中打开预览。', 'info');
          }
          return;
        }
        if (status.status === 'failed') {
          $('#videoDownloadStage').textContent = status.error || '下载失败';
          $('#videoDownloadBytes').textContent = status.manualRequired
            ? '请在平台官方下载后导入原片'
            : '可以重试或手动导入';
          $('#videoDownloadImportButton').hidden = false;
          $('#videoDownloadCaptureButton').hidden = false;
          return;
        }
        if (attempts < 900) setTimeout(update, 700);
      } catch (error) {
        $('#videoDownloadStage').textContent = error.message;
        $('#videoDownloadBytes').textContent = '可切换到后台下载，完成后手动导入';
        $('#videoDownloadImportButton').hidden = false;
        $('#videoDownloadCaptureButton').hidden = false;
      }
    };
    update();
  }

  function saveVideoDownloadTasks() {
    state.videoDownloadTasks = state.videoDownloadTasks
      .filter((task) => task && task.taskId)
      .sort((a, b) => Number(b.startedAt || 0) - Number(a.startedAt || 0))
      .slice(0, 20);
    saveJson(KEYS.videoDownloads, state.videoDownloadTasks);
    renderVideoDownloadQueue();
  }

  function trackVideoDownloadTask(taskId, title) {
    if (!taskId) return null;
    let task = state.videoDownloadTasks.find((item) => item.taskId === taskId);
    if (!task) {
      task = {
        taskId,
        title: title || '视频原片',
        status: 'downloading',
        progress: 0,
        size: 0,
        file: '',
        error: '',
        startedAt: Date.now(),
        libraryLoaded: false
      };
      state.videoDownloadTasks.unshift(task);
    } else {
      task.title = title || task.title;
    }
    saveVideoDownloadTasks();
    return task;
  }

  function applyVideoDownloadStatus(taskId, status) {
    const task = trackVideoDownloadTask(taskId, status.title || '视频原片');
    if (!task) return null;
    task.status = status.status || task.status;
    task.progress = Math.max(0, Math.min(100, Number(status.progress) || 0));
    task.size = Number(status.size) || task.size || 0;
    task.file = status.file || task.file || '';
    task.queuePosition = Number(status.queuePosition) || 0;
    task.error = status.error || '';
    task.folder = status.folder || task.folder || state.originalFolder || '';
    if (status.status === 'completed') task.progress = 100;
    saveVideoDownloadTasks();
    return task;
  }

  function renderVideoDownloadQueue() {
    const panel = $('#videoDownloadQueue');
    const list = $('#videoDownloadQueueList');
    if (!panel || !list) return;
    const tasks = state.videoDownloadTasks || [];
    panel.hidden = tasks.length === 0;
    if (!tasks.length) {
      list.innerHTML = '';
      return;
    }
    const active = tasks.filter((task) => task.status === 'downloading').length;
    const queued = tasks.filter((task) => task.status === 'queued').length;
    $$('#videoDownloadModeSwitch button').forEach((button) =>
      button.classList.toggle('active', button.dataset.downloadMode === state.videoDownloadMode));
    list.innerHTML =
      '<div class="download-queue-summary"><strong>' +
        (active
          ? active + ' 个任务正在下载' + (queued ? ' · ' + queued + ' 个排队中' : '')
          : queued ? queued + ' 个任务等待下载' : '当前没有进行中的任务') +
      '</strong><small>' +
        (state.videoDownloadMode === 'sequential'
          ? '依次下载：完成一个后自动开始下一个'
          : '同时下载：多个视频可并行加速') +
        ' · 共 ' + tasks.length + ' 个任务</small></div>' +
      tasks.map((task) => {
        const progress = Math.max(0, Math.min(100, Number(task.progress) || 0));
        const stateText = task.status === 'completed'
          ? '下载完成'
          : task.status === 'failed'
            ? (task.error || '下载失败')
            : task.status === 'expired'
              ? (task.error || '任务记录已过期')
              : task.status === 'queued'
                ? '排队中' + (task.queuePosition ? ' · 第 ' + task.queuePosition + ' 个' : '')
                : '正在下载 ' + progress + '%';
        return '<article class="download-queue-item ' + escapeHtml(task.status || 'downloading') + '">' +
          '<div class="download-queue-main"><div><strong>' + escapeHtml(task.title || '视频原片') +
            '</strong><small>' + escapeHtml(stateText) + '</small></div><b>' +
            (task.status === 'downloading' ? progress + '%' :
              task.status === 'completed' ? '完成' :
              task.status === 'queued' ? '排队' : '') +
          '</b></div>' +
          '<div class="download-queue-track"><i style="width:' + progress + '%"></i></div>' +
          '<div class="download-queue-meta"><span>' +
            escapeHtml(task.size ? formatFileSize(task.size) : '等待文件大小') +
          '</span><span>' + escapeHtml(task.file || '等待保存文件') + '</span></div>' +
          '<div class="download-queue-actions">' +
            (task.status === 'downloading'
              ? '<button type="button" data-download-resume="' + escapeHtml(task.taskId) + '">查看进度</button>'
              : task.status === 'completed'
                ? '<button type="button" data-download-preview="' + escapeHtml(task.taskId) + '">预览原片</button>'
                : task.status === 'queued'
                  ? '<button type="button" data-download-prioritize="' + escapeHtml(task.taskId) +
                    '">优先下一个</button>'
                : '<button type="button" data-download-library="1">查看原片栏</button>') +
            '<button type="button" data-download-folder="1">打开文件夹</button>' +
            '<button type="button" class="danger" data-download-remove="' + escapeHtml(task.taskId) + '">移除记录</button>' +
          '</div>' +
        '</article>';
      }).join('');
  }

  async function refreshVideoDownloadTasks() {
    let needsLibraryRefresh = false;
    try {
      const data = await api('/api/video-import-tasks');
      if (typeof data.sequential === 'boolean') {
        state.videoDownloadMode = data.sequential ? 'sequential' : 'parallel';
        saveJson(KEYS.videoDownloadMode, state.videoDownloadMode);
      }
      const serverTasks = data.tasks || [];
      const serverIds = new Set(serverTasks.map((task) => task.taskId));
      serverTasks.forEach((status) => {
        const existing = state.videoDownloadTasks.find((task) => task.taskId === status.taskId);
        const libraryLoaded = existing ? existing.libraryLoaded : false;
        const task = applyVideoDownloadStatus(status.taskId, status);
        if (task) {
          task.startedAt = Date.parse(status.startedAt || '') || task.startedAt || Date.now();
          task.libraryLoaded = libraryLoaded;
          if (status.status === 'completed' && !libraryLoaded) {
            task.libraryLoaded = true;
            needsLibraryRefresh = true;
          }
        }
      });
      state.videoDownloadTasks.forEach((task) => {
        if (task.status === 'downloading' && !serverIds.has(task.taskId)) {
          task.status = 'expired';
          task.error = '任务已结束，请在原片保存栏查看文件';
        }
      });
    } catch (error) {
      const active = state.videoDownloadTasks.filter((task) => task.status === 'downloading');
      await Promise.all(active.map(async (task) => {
        try {
          const status = await api('/api/video-import-status?id=' + encodeURIComponent(task.taskId));
          applyVideoDownloadStatus(task.taskId, status);
        } catch (statusError) {
          if (/不存在|not found|404/i.test(statusError.message || '')) {
            task.status = 'expired';
            task.error = '程序重启后任务进度已失效，请在原片保存栏查看文件';
          }
        }
      }));
    }
    if (needsLibraryRefresh) {
      state.serverOriginalsLoaded = false;
      await loadServerOriginals(false);
    }
    saveVideoDownloadTasks();
  }

  async function previewQueuedDownload(taskId) {
    const task = state.videoDownloadTasks.find((item) => item.taskId === taskId);
    if (!task) return;
    if (!state.serverOriginalsLoaded) await loadServerOriginals(false);
    let clip = state.localVideoClips.find((item) => task.file && item.serverFile === task.file);
    if (!clip && task.title) {
      clip = state.localVideoClips.find((item) => (item.name || '').includes(task.title));
    }
    if (clip) openLibraryVideo('original', clip.libraryId || clip.id);
    else showToast('原片还在整理', '请稍后点击“刷新进度”，或从原片保存栏预览。', 'info');
  }

  function openLibraryVideo(kind, id) {
    const record = kind === 'finished'
      ? state.finishedVideos.find((item) => item.id === id)
      : state.localVideoClips.find((item) => (item.libraryId || item.id) === id);
    if (!record || !record.url) {
      showToast('素材不存在', '请重新导入该视频。', 'info');
      return;
    }
    showModal(kind === 'finished' ? '成品预览' : '原片预览', 'LOCAL VIDEO LIBRARY',
      '<div class="library-preview"><video controls playsinline src="' + escapeHtml(record.url) + '"></video>' +
      '<strong>' + escapeHtml(record.title || record.name) + '</strong>' +
      '<small>视频保存在本机程序素材库，不会上传到外部服务器。</small></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>' +
      (kind === 'original'
        ? '<a class="btn btn-secondary" href="' + escapeHtml(record.url) +
          '" target="_blank" rel="noopener">用 Edge 播放</a>' +
          '<button class="btn btn-primary" type="button" id="previewEditOriginal">开始剪辑这段原片</button>'
        : ''));
    const previewVideo = $('.library-preview video');
    if (previewVideo) {
      previewVideo.addEventListener('error', () => {
        showToast('内置播放器无法打开', '请点击“用 Edge 播放”，或重新下载这段原片。', 'error');
      });
    }
    if (kind === 'original' && $('#previewEditOriginal')) {
      $('#previewEditOriginal').addEventListener('click', () => {
        closeModal();
        openOriginalEditing(id);
      });
    }
  }

  function openOriginalEditing(id) {
    const index = state.localVideoClips.findIndex((item) => (item.libraryId || item.id) === id);
    if (index < 0) {
      showToast('原片不存在', '请重新导入该视频。', 'info');
      return;
    }
    const clip = state.localVideoClips[index];
    state.localVideoClips = [clip].concat(state.localVideoClips.filter((item, itemIndex) => itemIndex !== index));
    state.videoEpisodeTitle = clip.name.replace(/\.[^.]+$/, '');
    if ($('#clipPrompt')) $('#clipPrompt').value = state.videoEpisodeTitle;
    showView('video');
    renderVideoSources();
    renderLocalClipList();
    showVideoNextStep('原片剪辑', '已选择“' + clip.name + '”。请在下方选择声音与人物方式，再点击“原片智能剪辑”。');
    setTimeout(() => {
      const settings = $('#videoDurationOptions')?.closest('.side-card') || $('#videoComposition');
      if (settings) settings.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 180);
  }

  function downloadLibraryVideo(id) {
    const record = state.finishedVideos.find((item) => item.id === id);
    if (!record || !record.url) return;
    const extension = String(record.blob && record.blob.type || '').includes('mp4') ? 'mp4' : 'webm';
    const link = document.createElement('a');
    link.href = record.url;
    link.download = (record.title || '原片剪辑成品').replace(/[\\/:*?"<>|]/g, '_') + '.' + extension;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  function selectedOriginalClipsForPublish() {
    const selected = new Set(state.originalPublishSelected);
    return state.localVideoClips.filter((clip) => clip && clip.url &&
      selected.has(originalClipKey(clip)));
  }

  function downloadSelectedOriginals() {
    const clips = selectedOriginalClipsForPublish();
    if (!clips.length) {
      showToast('没有选择原片', '请至少勾选一段原视频。', 'info');
      return;
    }
    clips.forEach((clip, index) => {
      setTimeout(() => {
        const extension = (String(clip.name || '').match(/\.(mp4|webm|mov|m4v|ogv|ogg)$/i) || [])[1] || 'mp4';
        const base = String(clip.name || ('原视频-' + (index + 1)))
          .replace(/\.[^.]+$/, '').replace(/[\\/:*?"<>|]/g, '_');
        const link = document.createElement('a');
        link.href = clip.url;
        link.download = base + '.' + extension.toLowerCase();
        document.body.appendChild(link);
        link.click();
        link.remove();
      }, index * 450);
    });
    showToast('正在下载所选原视频', '共 ' + clips.length + ' 段，文件不会添加任何标题或字幕。');
  }

  async function mergeSelectedOriginalsForPublish() {
    const clips = selectedOriginalClipsForPublish();
    if (!clips.length) {
      showToast('没有选择原片', '请至少勾选一段原视频。', 'info');
      return;
    }
    if (state.recording) {
      showToast('视频正在生成', '请等待当前任务完成。', 'info');
      return;
    }
    const backup = state.localVideoClips.slice();
    const previousDuration = state.videoDuration;
    const totalDuration = clips.reduce((sum, clip) => sum + Math.max(1, Number(clip.duration) || 1), 0);
    state.localVideoClips = clips.slice();
    state.videoOutputMode = 'clean';
    state.clipAudioMode = 'original';
    state.videoComposition = 'precise';
    state.videoDuration = Math.max(1, Math.min(86400, Math.round(totalDuration)));
    if ($('#clipPrompt')) {
      $('#clipPrompt').value = String(clips[0].name || '原视频').replace(/\.[^.]+$/, '');
    }
    renderVideoControlState();
    renderVideoSources();
    try {
      await renderLocalClipMontage();
    } finally {
      state.localVideoClips = backup;
      state.videoDuration = previousDuration;
      renderVideoControlState();
      renderVideoSources();
      renderVideoLibraries();
    }
  }

  async function deleteLibraryVideo(kind, id, silent) {
    const store = kind === 'finished' ? MEDIA_FINISHED_STORE : MEDIA_ORIGINAL_STORE;
    const record = kind === 'finished'
      ? state.finishedVideos.find((item) => item.id === id)
      : state.localVideoClips.find((item) => (item.libraryId || item.id) === id);
    if (kind === 'original' && record) {
      let serverFile = record.serverFile || '';
      if (!serverFile) {
        try {
          const result = await api('/api/originals');
          const match = (result.items || []).find((item) =>
            item.file === record.name || item.title === record.name);
          serverFile = match && match.file || '';
        } catch (error) {}
      }
      if (serverFile) {
        await api('/api/original-delete', {
          method: 'POST',
          body: JSON.stringify({ file: serverFile })
        });
      }
    }
    await mediaStoreDelete(store, id);
    if (kind === 'finished') {
      if (record && record.url) URL.revokeObjectURL(record.url);
      state.finishedVideos = state.finishedVideos.filter((item) => item.id !== id);
    } else {
      if (record && record.url) URL.revokeObjectURL(record.url);
      state.localVideoClips = state.localVideoClips.filter((item) => (item.libraryId || item.id) !== id);
      renderLocalClipList();
      renderVideoSources();
    }
    renderVideoLibraries();
    if (!silent) {
      showToast('已从素材库删除', kind === 'original' ? '本机原片文件也已删除，不会再次出现。' : '成品记录已删除。');
    }
  }

  function renderLocalClipList() {
    const list = $('#localClipList');
    if (!list) return;
    list.innerHTML = state.localVideoClips.length
      ? state.localVideoClips.map((clip, index) =>
          '<div class="local-clip-item"><span>' + (index + 1) + '. ' + escapeHtml(clip.name) +
          '</span><small>' + Math.round(clip.duration || 0) + ' 秒 · 扫描 ' + ((clip.analysis || []).length) + ' 帧</small></div>').join('')
      : '<span>尚未导入视频素材</span>';
    if ($('#emptyVideo')) {
      $('#emptyVideo strong').textContent = state.localVideoClips.length
        ? '已导入 ' + state.localVideoClips.length + ' 段授权视频'
        : '导入视频，开始自动剪辑';
      $('#emptyVideo p').textContent = state.localVideoClips.length
        ? '选择导演风格和时长，然后生成高光快剪成片'
        : '支持授权视频、素材快剪、旁白、字幕和网易云背景音乐';
      $('#emptyGenerateVideo').textContent = state.localVideoClips.length ? '自动剪辑这组素材' : '选择视频并自动剪辑';
    }
  }

  async function addLocalClipFiles(fileList) {
    const files = Array.from(fileList || []).filter((file) => /^video\//i.test(file.type) || /\.(mp4|mov|webm|m4v|avi|mkv)$/i.test(file.name));
    for (const file of files) {
      const url = URL.createObjectURL(file);
      try {
        showLoading('正在扫描整段原片', '正在从视频开头到结尾抽取画面并定位高光时间点：' + file.name);
        const material = await analyzeVideoMaterial(url, file.name);
        material.size = file.size;
        try {
          await persistOriginalVideo(file, material);
        } catch (storageError) {
          console.warn('Original video was not persisted', storageError);
          material.id = 'original_session_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
          material.libraryId = material.id;
        }
        state.localVideoClips.push(material);
      } catch (error) {
        URL.revokeObjectURL(url);
        showToast('视频读取失败', error.message, 'error');
      }
    }
    state.localVideoClips = state.localVideoClips.slice(0, 20);
    renderLocalClipList();
    renderVideoLibraries();
    const input = $('#localClipInput');
    if (input) input.value = '';
    if (files.length) showToast('视频素材已加入', '共 ' + state.localVideoClips.length + ' 段，可开始自动快剪。');
    if (files.length && state.autoStartAfterClipImport) {
      state.autoStartAfterClipImport = false;
      setTimeout(() => renderLocalClipMontage(), 350);
    }
    hideLoading();
  }

  async function capturePlayingVideo() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      showToast('当前浏览器不支持抓取播放内容', '请使用最新版 Microsoft Edge。', 'error');
      return;
    }
    let stream;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 30 },
        audio: true,
        preferCurrentTab: false
      });
    } catch (error) {
      if (error.name !== 'NotAllowedError') {
        showToast('无法抓取视频画面', error.message, 'error');
      }
      return;
    }
    const videoTrack = stream.getVideoTracks()[0];
    if (!videoTrack) {
      stream.getTracks().forEach((track) => track.stop());
      showToast('没有获得视频画面', '请在共享窗口中选择正在播放的 Edge 标签页。', 'error');
      return;
    }
    const mime = chooseMime();
    const chunks = [];
    const recorder = new MediaRecorder(stream,
      Object.assign({ videoBitsPerSecond: 8500000, audioBitsPerSecond: 192000 },
        mime ? { mimeType: mime } : {}));
    let startedAt = performance.now();
    let timer = null;
    let stopping = false;
    const stopCapture = () => {
      if (stopping) return;
      stopping = true;
      if (timer) clearInterval(timer);
      if (recorder.state !== 'inactive') recorder.stop();
      stream.getTracks().forEach((track) => track.stop());
    };
    recorder.ondataavailable = (event) => {
      if (event.data && event.data.size) chunks.push(event.data);
    };
    const recorded = new Promise((resolve) => {
      recorder.onstop = () => resolve(new Blob(chunks,
        { type: mime || 'video/webm' }));
    });
    videoTrack.addEventListener('ended', stopCapture);
    recorder.start(1000);
    showModal('正在抓取播放内容', 'CAPTURE PLAYING VIDEO',
      '<div class="capture-video-live">' +
        '<div class="capture-video-pulse"></div>' +
        '<strong>请在浏览器的共享提示中选择正在播放视频的标签页</strong>' +
        '<p>勾选“共享标签页音频”才能保留原声。视频播放多久，就会抓取多久；受 DRM 保护的画面可能显示为黑屏。</p>' +
        '<div class="capture-video-time" id="captureVideoTime">00:00</div>' +
        '<button class="btn btn-primary btn-block" type="button" id="stopCaptureVideoBtn">停止抓取并保存到原片库</button>' +
      '</div>',
      '');
    $('#stopCaptureVideoBtn').addEventListener('click', stopCapture);
    timer = setInterval(() => {
      const seconds = Math.floor((performance.now() - startedAt) / 1000);
      if ($('#captureVideoTime')) {
        $('#captureVideoTime').textContent =
          String(Math.floor(seconds / 60)).padStart(2, '0') + ':' +
          String(seconds % 60).padStart(2, '0');
      }
      if (seconds >= 600) stopCapture();
    }, 500);
    const blob = await recorded;
    if (!blob.size) {
      closeModal();
      showToast('没有抓到有效视频', '请确认选择了正在播放视频的标签页。', 'error');
      return;
    }
    const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
    const file = new File([blob], '网页视频抓取-' + stamp + '.webm',
      { type: blob.type || 'video/webm' });
    const objectUrl = URL.createObjectURL(file);
    showLoading('正在读取抓取内容', '正在抽取画面并加入原片库…');
    try {
      const material = await analyzeVideoMaterial(objectUrl, file.name);
      material.size = file.size;
      material.originType = 'captured';
      material.capturedAt = Date.now();
      try {
        await persistOriginalVideo(file, material);
      } catch (storageError) {
        material.id = 'captured_' + Date.now();
        material.libraryId = material.id;
      }
      state.localVideoClips.unshift(material);
      state.localVideoClips = state.localVideoClips.slice(0, 20);
      renderLocalClipList();
      renderVideoSources();
      renderVideoLibraries();
      closeModal();
      openLibraryVideo('original', material.libraryId || material.id);
      showToast('视频内容已抓取', '已保存为原片，可以预览和剪辑。');
    } catch (error) {
      showToast('抓取内容读取失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  async function readDirectVideoSource() {
    const input = $('#directVideoSourceUrl');
    const sourceText = $('#directVideoSourceText').value.trim();
    const status = $('#directVideoSourceStatus');
    const url = input.value.trim();
    const sourceMode = $('#directSourceMode button.active')?.dataset.directSourceMode || 'url';
    if (sourceMode === 'url' && !/^https?:\/\//i.test(url)) {
      showToast('请输入完整地址', '网址需要以 http:// 或 https:// 开头。', 'info');
      input.focus();
      return;
    }
    if (sourceMode === 'source' && !sourceText) {
      showToast('请粘贴视频包源文本', '可以粘贴 m3u8 清单、页面源码或视频地址。', 'info');
      $('#directVideoSourceText').focus();
      return;
    }
    const button = $('#readDirectVideoSourceBtn');
    button.disabled = true;
    button.textContent = '正在读取';
    status.textContent = '正在分析页面中的完整视频源，请稍候…';
    try {
      const resolved = await api(sourceMode === 'source'
        ? '/api/video-source-text-resolve'
        : '/api/video-source-resolve', {
        method: 'POST',
        body: JSON.stringify(sourceMode === 'source'
          ? { sourceText, pageUrl: url }
          : { url })
      });
      if (!resolved.ok || !resolved.videoUrl) {
        status.textContent = resolved.error ||
          '没有找到可直接保存的完整视频，请使用“抓取当前播放内容”。';
        showToast('未找到完整视频源', resolved.error || '可改用共享播放抓取。', 'info');
        return;
      }
      status.textContent = '已找到完整视频源，正在加入下载队列…';
      const job = await api('/api/video-import', {
        method: 'POST',
        body: JSON.stringify({
          title: resolved.title || '读取的视频原片',
          pageUrl: resolved.pageUrl || url,
          videoUrl: resolved.videoUrl
        })
      });
      trackVideoDownloadTask(job.taskId, job.title || resolved.title || '读取的视频原片');
      status.textContent = '完整视频源已加入下载队列。';
      showToast('完整视频源读取成功', '已加入下载任务，可继续读取其他地址。');
    } catch (error) {
      status.textContent = error.message;
      showToast('完整视频源读取失败', error.message, 'error');
    } finally {
      button.disabled = false;
      button.textContent = '读取完整源';
    }
  }

  function openVideoSourceReaderDialog() {
    let mode = 'source';
    showModal('读取完整视频源', 'VIDEO PACKAGE SOURCE',
      '<div class="video-source-reader-dialog">' +
        '<div class="segmented" id="videoSourceReaderMode">' +
          '<button type="button" data-reader-mode="url">网页或视频地址</button>' +
          '<button class="active" type="button" data-reader-mode="source">视频包源文本</button>' +
        '</div>' +
        '<div id="videoSourceReaderUrlPane" hidden>' +
          '<label>完整地址<input id="videoSourceReaderUrl" type="url" placeholder="https://...mp4、.webm 或 .m3u8"></label>' +
        '</div>' +
        '<div id="videoSourceReaderTextPane">' +
          '<label>视频包源文本<textarea id="videoSourceReaderText" rows="9" placeholder="粘贴 m3u8 清单、页面源码、接口返回内容或包含视频地址的源文本"></textarea></label>' +
          '<label>页面地址（可选，用于相对链接）<input id="videoSourceReaderPageUrl" type="url" placeholder="https://原网页地址"></label>' +
        '</div>' +
        '<p class="field-hint" id="videoSourceReaderStatus">支持公开 MP4、WebM 和未加密 fMP4 HLS 包源。</p>' +
        '<div class="video-source-reader-actions">' +
          '<button type="button" id="pasteVideoSourceClipboardBtn">从剪贴板粘贴</button>' +
          '<button type="button" id="submitVideoSourceReaderBtn">读取并保存到小程序</button>' +
        '</div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>' +
      '<button class="btn btn-secondary" type="button" id="readerCaptureCurrentBtn">抓取当前播放</button>');
    const status = $('#videoSourceReaderStatus');
    $$('#videoSourceReaderMode button').forEach((button) => {
      button.addEventListener('click', () => {
        mode = button.dataset.readerMode;
        $$('#videoSourceReaderMode button').forEach((item) =>
          item.classList.toggle('active', item === button));
        $('#videoSourceReaderUrlPane').hidden = mode !== 'url';
        $('#videoSourceReaderTextPane').hidden = mode !== 'source';
      });
    });
    $('#pasteVideoSourceClipboardBtn').addEventListener('click', async () => {
      try {
        const text = await navigator.clipboard.readText();
        if (!text) throw new Error('剪贴板为空');
        if (mode === 'url') $('#videoSourceReaderUrl').value = text.trim();
        else $('#videoSourceReaderText').value = text;
        status.textContent = '内容已粘贴。';
      } catch (error) {
        showToast('无法读取剪贴板', '请手动粘贴视频地址或包源文本。', 'info');
      }
    });
    $('#readerCaptureCurrentBtn').addEventListener('click', () => {
      closeModal();
      capturePlayingVideo();
    });
    $('#submitVideoSourceReaderBtn').addEventListener('click', async () => {
      const submit = $('#submitVideoSourceReaderBtn');
      const url = $('#videoSourceReaderUrl').value.trim();
      const sourceText = $('#videoSourceReaderText').value.trim();
      const pageUrl = $('#videoSourceReaderPageUrl').value.trim();
      if (mode === 'url' && !/^https?:\/\//i.test(url)) {
        status.textContent = '请输入完整的 http/https 地址。';
        return;
      }
      if (mode === 'source' && !sourceText) {
        status.textContent = '请先粘贴视频包源文本。';
        return;
      }
      submit.disabled = true;
      submit.textContent = '正在读取';
      status.textContent = '正在解析并读取完整视频源…';
      try {
        const result = await api(mode === 'source'
          ? '/api/video-source-text-resolve'
          : '/api/video-source-resolve', {
          method: 'POST',
          body: JSON.stringify(mode === 'source'
            ? { sourceText, pageUrl }
            : { url })
        });
        if (!result.ok || !result.videoUrl) {
          status.textContent = result.error || '没有找到可直接保存的视频源。';
          return;
        }
        const job = await api('/api/video-import', {
          method: 'POST',
          body: JSON.stringify({
            title: result.title || '视频包源原片',
            pageUrl: result.pageUrl || pageUrl || url,
            videoUrl: result.videoUrl
          })
        });
        trackVideoDownloadTask(job.taskId, job.title || result.title || '视频包源原片');
        closeModal();
        showToast(result.package ? '视频包源已开始读取' : '完整视频已开始下载',
          '可以在“原片下载任务”中查看进度。');
      } catch (error) {
        status.textContent = error.message;
        showToast('视频源读取失败', error.message, 'error');
      } finally {
        submit.disabled = false;
        submit.textContent = '读取并保存到小程序';
      }
    });
  }

  async function analyzeVideoMaterial(url, name) {
    const video = document.createElement('video');
    video.preload = 'auto';
    video.muted = true;
    video.playsInline = true;
    video.src = url;
    await new Promise((resolve, reject) => {
      video.onloadedmetadata = resolve;
      video.onerror = () => reject(new Error('无法读取 ' + name));
    });
    const duration = Number(video.duration || 0);
    const sampleCount = Math.max(10, Math.min(48, Math.ceil(duration / 12)));
    const canvas = document.createElement('canvas');
    canvas.width = 96;
    canvas.height = 54;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const samples = [];
    let previous = null;
    for (let index = 0; index < sampleCount; index += 1) {
      const time = duration * ((index + .5) / sampleCount);
      await new Promise((resolve) => {
        const done = () => resolve();
        video.onseeked = done;
        video.currentTime = Math.max(.05, Math.min(duration - .1, time));
        setTimeout(done, 1800);
      });
      try {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
        let brightness = 0;
        let difference = 0;
        for (let offset = 0; offset < pixels.length; offset += 16) {
          const value = (pixels[offset] + pixels[offset + 1] + pixels[offset + 2]) / 3;
          brightness += value;
          if (previous) difference += Math.abs(value - previous[offset]);
        }
        const count = Math.ceil(pixels.length / 16);
        samples.push({
          time: video.currentTime,
          score: difference / count * 1.8 + brightness / count * .08
        });
        previous = pixels;
      } catch (error) {}
    }
    video.removeAttribute('src');
    video.load();
    return { name, url, duration, analysis: samples };
  }

  function buildLocalClipPlan(total, segmentSeconds) {
    const clips = state.localVideoClips.filter((clip) => clip && clip.url);
    const precise = state.videoComposition === 'precise';
    const plan = [];
    let remaining = total;
    let guard = 0;
    const sequentialOffsets = clips.map(() => 0);
    const highlightCandidates = clips.map((clip) => {
      const duration = Math.max(1, Number(clip.duration) || 1);
      const analyzed = (clip.analysis || [])
        .filter((sample) => Number.isFinite(sample.time) && Number.isFinite(sample.score))
        .sort((a, b) => b.score - a.score)
        .map((sample) => Math.max(0, Math.min(duration - segmentSeconds - .15, sample.time - segmentSeconds * .18)));
      if (analyzed.length) return unique(analyzed.map((time) => Math.round(time * 4) / 4));
      return [0.08, .28, .48, .68, .86]
        .map((ratio) => Math.max(0, Math.min(duration - segmentSeconds - .15, duration * ratio)));
    });
    const candidateOffsets = clips.map(() => 0);
    const maxSegments = Math.max(64, Math.ceil(total / Math.max(.65, segmentSeconds)) + 12);
    while (remaining > .2 && clips.length && guard < maxSegments) {
      guard += 1;
      const clipIndex = plan.length % clips.length;
      const clip = clips[clipIndex];
      const duration = Math.max(.5, Number(clip.duration) || segmentSeconds + .2);
      const maxStart = Math.max(0, duration - segmentSeconds - .15);
      let start;
      if (precise) {
        if (sequentialOffsets[clipIndex] > maxStart + .01) sequentialOffsets[clipIndex] = 0;
        start = Math.min(maxStart, sequentialOffsets[clipIndex]);
        sequentialOffsets[clipIndex] = Math.min(duration - .1, sequentialOffsets[clipIndex] + segmentSeconds);
      } else {
        const candidates = highlightCandidates[clipIndex];
        start = candidates[candidateOffsets[clipIndex] % candidates.length];
        candidateOffsets[clipIndex] += 1;
      }
      const seconds = Math.min(segmentSeconds, remaining, Math.max(.6, duration - start - .05));
      plan.push({ clip, start: Math.max(0, start), seconds });
      remaining -= seconds;
    }
    return plan;
  }

  async function readCurrentMediaWindow() {
    const hint = $('#mediaWindowHint');
    try {
      const result = await api('/api/media-window');
      if (!result.ok || !result.title) throw new Error('未找到正在播放的视频窗口');
      const cleanTitle = String(result.title || '').replace(/\s+/g, ' ').trim();
      const genericTitle = /^(爱奇艺|腾讯视频|优酷|芒果\s*TV|哔哩哔哩|剪映|QyClient|QQLive|YOUKU|哔哩哔哩-.*)$/i.test(cleanTitle);
      const processNames = {
        QyClient: '爱奇艺', QQLive: '腾讯视频', QQLiveBrowser: '腾讯视频',
        YOUKU: '优酷', Mango: '芒果TV', MGTV: '芒果TV',
        bilibili: '哔哩哔哩', JianyingPro: '剪映'
      };
      const sourceName = processNames[result.process] || result.process || '视频软件';
      if (genericTitle) {
        throw new Error('已打开' + sourceName + '，但客户端没有提供具体节目名称');
      }
      $('#clipPrompt').value = cleanTitle;
      if ($('#videoBreakdownTitle')) $('#videoBreakdownTitle').value = cleanTitle;
      hint.textContent = '已读取：' + cleanTitle;
      showToast('已读取当前观看内容', cleanTitle, 'success');
      openVideoContinueWizard(sourceName, cleanTitle);
    } catch (error) {
      hint.textContent = error.message;
      showToast('没有读到具体节目名', '请在抓取内容库选择节目页面，或手动填写片名后导入完整原片。', 'info');
      const sourceName = state.browseFlow.sourceName || '视频软件';
      showVideoNextStep(sourceName, '没有自动读到节目名。请在软件中下载原片，完成后点击“导入已下载原片”，或再次点击“读取当前视频”。');
    }
  }

  async function openVideoMaterialSearch(source) {
    const queryInput = $('#videoMaterialQuery').value.trim();
    const type = $('#videoMaterialType').value;
    const query = queryInput || VIDEO_MATERIAL_DEFAULTS[type] || '官方视频片段';
    const buildUrl = VIDEO_MATERIAL_SOURCES[source];
    if (!buildUrl) return;
    const url = buildUrl(query);
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => link.remove(), 500);
    $('#videoMaterialQuery').value = query;
    showVideoNextStep(source, '已打开搜索结果。下载授权原片后，点击“导入已下载原片”即可继续剪辑。');
    showToast('已打开素材搜索结果', '请选择官方预告、公开版权内容或已授权片段，再导出为本地视频导入剪辑。', 'info');
  }

  function showVideoNextStep(sourceName, hint) {
    if (!$('#videoNextStepPanel')) return;
    $('#videoNextStepTitle').textContent = '下一步：从' + (sourceName || '视频软件') + '获取原片';
    $('#videoNextStepHint').textContent = hint ||
      '打开影视内容后使用官方下载；下载完成后返回这里，点击“导入已下载原片”。';
    const hasOriginal = state.localVideoClips.length > 0;
    $('#videoNextStartEditBtn').hidden = !hasOriginal;
    $('#videoNextImportBtn').classList.toggle('primary', !hasOriginal);
    $('#videoNextStepPanel').hidden = false;
    $('#videoNextStepPanel').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function openArchiveVideoLibrary(initialCountry = 'all') {
    showModal('公开版权原片库', 'LEGAL VIDEO LIBRARY',
      '<div class="archive-library">' +
        '<p class="archive-library-note">优先显示可在小程序内预览和下载的 Wikimedia、Internet Archive 公开素材。BFI、RaiPlay 等官方平台可能受所在地区、登录或版权限制，程序不会绕过这些限制。</p>' +
        '<label class="archive-country-field">国家 / 地区经典片库' +
          '<select id="archiveLibraryCountry">' +
            '<option value="all">全部国家</option>' +
            '<option value="china">中国 · 经典电影与电视剧</option>' +
            '<option value="korea">韩国 · 经典电影与电视剧</option>' +
            '<option value="italy">意大利 · 经典电影</option>' +
            '<option value="germany">德国 · 经典电影</option>' +
            '<option value="france">法国 · 经典电影</option>' +
            '<option value="japan">日本 · 经典电影</option>' +
            '<option value="anime">动漫 · 番剧与动画电影</option>' +
            '<option value="variety">综艺 · 真人秀与脱口秀</option>' +
            '<option value="uk">英国 · 经典电影</option>' +
            '<option value="usa">美国 · 公共版权电影</option>' +
          '</select>' +
        '</label>' +
        '<div class="archive-library-search">' +
          '<input id="archiveLibraryQuery" type="search" placeholder="输入片名或主题，例如：卓别林、纪录片、老电影">' +
          '<button type="button" id="archiveLibrarySearchBtn">搜索片库</button>' +
        '</div>' +
        '<div class="archive-library-links">' +
          '<a href="https://commons.wikimedia.org/wiki/Category:Videos" target="_blank" rel="noopener">Wikimedia 视频</a>' +
          '<a href="https://www.pexels.com/videos/" target="_blank" rel="noopener">Pexels 视频</a>' +
          '<a href="https://pixabay.com/videos/" target="_blank" rel="noopener">Pixabay 视频</a>' +
          '<a href="https://www.newcger.com/" target="_blank" rel="noopener">新CG儿素材</a>' +
          '<a href="https://www.vjshi.com/" target="_blank" rel="noopener">光厂授权素材</a>' +
          '<a href="https://www.vcg.com/" target="_blank" rel="noopener">视觉中国</a>' +
          '<a href="https://archive.org/details/movies" target="_blank" rel="noopener">Internet Archive 详情页</a>' +
        '</div>' +
        '<div class="archive-library-results" id="archiveLibraryResults">' +
          '<div class="archive-library-empty">片库载入中，请稍候…</div>' +
        '</div>' +
        '<p class="archive-library-note">仅下载公开版权、免费授权或你拥有权利的内容。会员影视和 DRM 加密内容不在自动下载范围内。</p>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>');
    if ($('#archiveLibraryCountry') && COUNTRY_VIDEO_LIBRARIES[initialCountry]) {
      $('#archiveLibraryCountry').value = initialCountry;
    }
    const materialQuery = $('#videoMaterialQuery')?.value.trim();
    if (materialQuery) $('#archiveLibraryQuery').value = materialQuery;

    const externalSearchLinks = (query) => {
      const text = query || '纪录片';
      const encoded = encodeURIComponent(text);
      return '<div class="archive-external-actions">' +
        '<a href="https://commons.wikimedia.org/w/index.php?search=' + encoded +
          '&title=Special:MediaSearch&type=video" target="_blank" rel="noopener">Wikimedia 搜索</a>' +
        '<a href="https://www.pexels.com/search/videos/' + encoded +
          '/" target="_blank" rel="noopener">Pexels 搜索</a>' +
        '<a href="https://pixabay.com/videos/search/' + encoded +
          '/" target="_blank" rel="noopener">Pixabay 搜索</a>' +
        '<a href="https://www.newcger.com/?s=' + encoded +
          '" target="_blank" rel="noopener">新CG儿搜索</a>' +
        '<a href="https://www.baidu.com/sf/vsearch?pd=video&wd=' + encoded +
          '" target="_blank" rel="noopener">百度视频搜索</a>' +
      '</div>';
    };
    const countryCatalogItems = (query) => {
      const selected = $('#archiveLibraryCountry')?.value || 'all';
      const queryText = query || '经典电影';
      const keys = selected === 'all' ? Object.keys(COUNTRY_VIDEO_LIBRARIES) : [selected];
      return keys.flatMap((key) => {
        const group = COUNTRY_VIDEO_LIBRARIES[key];
        if (!group) return [];
        const catalog = (group.items || []).map((item, index) => ({
          identifier: 'official-' + key + '-' + index,
          title: item.title,
          description: item.description,
          source: group.name + ' · ' + item.source,
          detailUrl: item.url(queryText),
          externalOnly: true
        }));
        const classics = selected === 'all' ? null : COUNTRY_CLASSIC_TITLES[key];
        if (!classics) return catalog;
        const classicItems = (classics.titles || []).map((title, index) => ({
          identifier: 'classic-' + key + '-' + index,
          title: group.name + '经典 · ' + title,
          description: '在 ' + group.name + '官方片库中查找《' + title + '》的播放、修复或馆藏信息。',
          source: group.name + ' · 经典片单',
          detailUrl: classics.search(title),
          externalOnly: true
        }));
        return catalog.concat(classicItems);
      });
    };
    const cacheKey = (query) => {
      const country = $('#archiveLibraryCountry')?.value || 'all';
      return country + '|' + String(query || '').trim().toLowerCase();
    };
    let currentItems = [];
    const renderResults = (items) => {
      currentItems = items || [];
      if (!items || !items.length) {
        $('#archiveLibraryResults').innerHTML =
          '<div class="archive-library-empty">没有搜到可直接下载的影片。' +
            '可以换个关键词，或直接在浏览器中搜索：' +
            externalSearchLinks($('#archiveLibraryQuery').value.trim()) +
          '</div>';
        return;
      }
      $('#archiveLibraryResults').innerHTML = items.map((item) =>
        '<article class="archive-library-item">' +
          '<div><h3>' + escapeHtml(item.title || '未命名影片') + '</h3>' +
          '<p>' + escapeHtml(item.description || '公开版权或授权影片，可在详情页核对许可信息。') + '</p>' +
          '<small>' + escapeHtml([item.source, item.year, item.downloads ? item.downloads + ' 次浏览' : '']
            .filter(Boolean).join(' · ')) + '</small></div>' +
          '<div class="archive-library-item-actions">' +
            (item.videoUrl
              ? '<button type="button" class="preview" data-archive-preview="' +
                currentItems.indexOf(item) + '">站内预览</button>'
              : '') +
            '<button type="button" data-archive-index="' + currentItems.indexOf(item) + '">' +
              (item.externalOnly ? '打开官网（可能限地区）' : '下载到小程序') +
            '</button>' +
          '</div>' +
        '</article>').join('');
    };

    const searchArchiveLibrary = async () => {
      const query = $('#archiveLibraryQuery').value.trim();
      const selectedCountry = $('#archiveLibraryCountry')?.value || 'all';
      const countryHint = COUNTRY_SEARCH_HINTS[selectedCountry] || '';
      const remoteQuery = selectedCountry !== 'all' && countryHint
        ? [query || '经典电影', countryHint].join(' ')
        : query;
      const results = $('#archiveLibraryResults');
      const button = $('#archiveLibrarySearchBtn');
      const localItems = countryCatalogItems(query);
      const cache = loadJson(KEYS.archiveSearchCache, {});
      const cached = cache[cacheKey(query)];
      const cachedItems = cached && Date.now() - Number(cached.savedAt || 0) < 7 * 24 * 60 * 60 * 1000
        ? (cached.items || [])
        : [];
      button.disabled = true;
      button.textContent = '正在搜索';
      renderResults(localItems.length ? localItems.concat(cachedItems) : cachedItems);
      if (!localItems.length && !cachedItems.length) {
        results.innerHTML = '<div class="archive-library-empty">正在连接公开片库，通常需要几秒…</div>';
      }
      let lastError = null;
      for (let attempt = 1; attempt <= 2; attempt += 1) {
        try {
          const data = await api('/api/archive-search?q=' + encodeURIComponent(remoteQuery));
          const remoteItems = data.items || [];
          const merged = remoteItems.concat(localItems);
          const nextCache = loadJson(KEYS.archiveSearchCache, {});
          nextCache[cacheKey(query)] = {
            savedAt: Date.now(),
            source: data.source || '',
            items: remoteItems
          };
          saveJson(KEYS.archiveSearchCache, nextCache);
          renderResults(merged);
          button.disabled = false;
          button.textContent = '搜索片库';
          return;
        } catch (error) {
          lastError = error;
          if (attempt === 1) {
            button.textContent = '自动重试中';
            await new Promise((resolve) => setTimeout(resolve, 500));
          }
        }
      }
      const fallbackItems = localItems.concat(cachedItems);
      if (fallbackItems.length) {
        renderResults(fallbackItems);
        results.insertAdjacentHTML('afterbegin',
          '<div class="archive-library-empty">远程片库暂时不可用，已保留国家官方片库和上次搜索结果。' +
          '你可以直接打开官方片库查找内容。</div>');
        showToast('已切换到稳定片库模式',
          '远程搜索暂不可用，但国家官方片库仍可正常打开。', 'info');
      } else {
        results.innerHTML =
          '<div class="archive-library-empty">' +
            escapeHtml(lastError && lastError.message || '公开片库暂时连接失败') +
            '<br><br>已在下方生成对应关键词的搜索入口。Edge 打开后即可选择并下载素材：' +
            externalSearchLinks(query) +
          '</div>';
      }
      button.disabled = false;
      button.textContent = '搜索片库';
    };

    $('#archiveLibrarySearchBtn').addEventListener('click', searchArchiveLibrary);
    $('#archiveLibraryCountry').addEventListener('change', searchArchiveLibrary);
    $('#archiveLibraryQuery').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        searchArchiveLibrary();
      }
    });
    $('#archiveLibraryResults').addEventListener('click', async (event) => {
      const previewButton = event.target.closest('[data-archive-preview]');
      if (previewButton) {
        const item = currentItems[Number(previewButton.dataset.archivePreview)];
        if (!item || !item.videoUrl) return;
        showModal('素材在线预览', 'PLAYABLE SOURCE',
          '<div class="archive-preview-player">' +
            '<video controls autoplay playsinline src="' + escapeHtml(item.videoUrl) + '"></video>' +
            '<strong>' + escapeHtml(item.title || '公开视频素材') + '</strong>' +
            '<small>这是站内可试播的公开视频源；关闭预览后可返回片库下载。</small>' +
          '</div>',
          '<button class="btn btn-secondary" type="button" data-modal-close>关闭预览</button>');
        const video = $('.archive-preview-player video');
        if (video) {
          video.addEventListener('error', () => {
            showToast('素材源暂时无法播放',
              '该站点可能限制外链或当前网络无法访问，请换一个站内预览结果。', 'error');
          });
        }
        return;
      }
      const button = event.target.closest('[data-archive-download]');
      if (!button) {
        const indexedButton = event.target.closest('[data-archive-index]');
        if (!indexedButton) return;
        const item = currentItems[Number(indexedButton.dataset.archiveIndex)];
        if (!item) return;
        if (item.externalOnly) {
          window.open(item.detailUrl, '_blank', 'noopener');
          return;
        }
        const oldText = indexedButton.textContent;
        indexedButton.disabled = true;
        indexedButton.textContent = '正在解析';
        try {
          const resolved = item.videoUrl ? item : await api('/api/archive-resolve?id=' +
            encodeURIComponent(item.identifier));
          if (resolved.ok === false || !resolved.videoUrl) {
            throw new Error(resolved.error || '没有找到可下载的官方视频文件');
          }
          const job = await api('/api/video-import', {
            method: 'POST',
            body: JSON.stringify({
              title: resolved.title || item.title || '公开影片',
              pageUrl: resolved.pageUrl || resolved.detailUrl || '',
              videoUrl: resolved.videoUrl
            })
          });
          trackVideoDownloadTask(job.taskId, job.title || item.title || '公开影片');
          indexedButton.textContent = '已加入下载';
          setTimeout(() => {
            indexedButton.disabled = false;
            indexedButton.textContent = oldText;
          }, 1200);
          showToast('已加入下载队列', '可以继续选择其他影片，多个任务会同时下载。', 'success');
        } catch (error) {
          indexedButton.disabled = false;
          indexedButton.textContent = oldText;
          showToast('原片下载未开始', error.message, 'error');
        }
        return;
      }
      const oldText = button.textContent;
      button.disabled = true;
      button.textContent = '正在解析';
      try {
        const resolved = await api('/api/archive-resolve?id=' +
          encodeURIComponent(button.dataset.archiveDownload));
        if (!resolved.ok || !resolved.videoUrl) {
          throw new Error(resolved.error || '没有找到可下载的官方 MP4 文件');
        }
        const job = await api('/api/video-import', {
          method: 'POST',
          body: JSON.stringify({
            title: resolved.title || button.dataset.archiveTitle || '公开影片',
            pageUrl: resolved.pageUrl || '',
            videoUrl: resolved.videoUrl
          })
        });
        closeModal();
        showVideoDownloadTask(job.taskId, job.title || resolved.title || '公开影片');
      } catch (error) {
        button.disabled = false;
        button.textContent = oldText;
        showToast('原片下载未开始', error.message, 'error');
      }
    });
    searchArchiveLibrary();
  }

  function openVideoSourcePicker() {
    let openMode = 'app';
    const sources = [
      ['qqlive', '腾讯视频'], ['youku', '优酷'], ['mgtv', '芒果TV'],
      ['iqiyi', '爱奇艺'], ['bilibili', '哔哩哔哩'], ['jianying', '剪映'],
      ['baidu', '百度视频'], ['sohu', '搜狐视频'], ['youtube', '海外视频 YouTube'],
      ['ted', 'TED 演讲'], ['archive', 'Internet Archive']
    ];
    showModal('下载原片：选择软件或网站', 'VIDEO SOURCE',
      '<div class="video-source-picker">' +
        '<p class="import-hint">先选择对应的视频软件或网站，打开电影、电视剧或其他视频。网页中如有公开或已授权的视频画面，可在画面上点右键选择“下载原片到热点工坊”；平台内下载时请使用官方功能，完成后返回这里点击“导入已下载原片”。</p>' +
        '<div class="video-source-mode" id="videoSourceMode">' +
          '<button class="active" type="button" data-video-open-mode="app">打开已安装软件</button>' +
          '<button type="button" data-video-open-mode="web">在 Edge 网页中打开</button>' +
        '</div>' +
        '<p class="video-source-mode-hint" id="videoSourceModeHint">软件内请使用官方下载；完成后回到这里导入原片。</p>' +
        '<div class="video-source-picker-grid">' +
          sources.map(([id, name]) =>
            '<button type="button" data-pick-video-source="' + id + '">' + name + '</button>').join('') +
        '</div>' +
        '<small class="video-platform-hint">腾讯视频、优酷、芒果 TV、爱奇艺、哔哩哔哩等平台的会员或 DRM 内容不会自动下载；请使用平台官方下载/导出功能或授权素材。</small>' +
        '<div class="video-source-picker-local"><button type="button" id="pickLocalVideoSource">导入已下载 / 已授权原片</button><button type="button" id="pickCurrentVideoSource">读取正在播放的视频</button></div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>');
    $$('[data-video-open-mode]').forEach((button) => {
      button.addEventListener('click', () => {
        openMode = button.dataset.videoOpenMode;
        $$('[data-video-open-mode]').forEach((item) => item.classList.toggle('active', item === button));
        $('#videoSourceModeHint').textContent = openMode === 'web'
          ? '将使用 Edge 打开网页；视频页面出现后，可点左下角“下载原片到热点工坊”或按 Alt+Shift+V。'
          : '软件内请使用官方下载；完成后回到这里导入原片。';
      });
    });
    $$('[data-pick-video-source]').forEach((button) => {
      button.addEventListener('click', async () => {
        const source = button.dataset.pickVideoSource;
        if (source === 'archive') {
          closeModal();
          openArchiveVideoLibrary();
          return;
        }
        state.platformOpenGuard[source] = 0;
        state.pendingVideoSource = button.textContent.trim();
        state.pendingVideoSourceAt = Date.now();
        closeModal();
        if (openMode === 'web') {
          const url = browseSourceUrl(source);
          showVideoNextStep(button.textContent.trim(),
            '正在用 Edge 打开网页。请在网页视频画面中点击悬浮下载按钮，或按 Alt+Shift+V。');
          try {
            if (!url) throw new Error('没有配置网页地址');
            await api('/api/open', {
              method: 'POST',
              body: JSON.stringify({ url, browserId: 'edge' })
            });
            showToast('已用 Edge 打开网页', '视频页面加载后可使用悬浮按钮下载授权原片。');
          } catch (error) {
            showToast('网页打开失败', error.message, 'error');
          }
          return;
        }
        showVideoNextStep(button.textContent.trim(),
          '已在后台打开对应软件或网站。选择电影、电视剧或其他视频后，使用官方下载；完成后返回并导入原片。');
        scheduleVideoReturnFlow(source);
        launchBrowseSource(source, button.textContent.trim(), 'video', 'video');
        if (source !== 'jianying') {
          $('#mediaWindowHint').textContent = '进入软件选择一集或一个节目，再回小程序点击“读取正在观看的视频”。';
        }
      });
    });
    $('#pickLocalVideoSource').addEventListener('click', () => {
      closeModal();
      state.autoStartAfterClipImport = true;
      setTimeout(() => $('#localClipInput').click(), 120);
    });
    $('#pickCurrentVideoSource').addEventListener('click', async () => {
      closeModal();
      await readCurrentMediaWindow();
    });
  }

  function scheduleVideoReturnFlow(sourceId) {
    const sourceName = state.pendingVideoSource || '视频软件';
    const flow = state.browseFlow;
    if (flow.active && flow.kind === 'video' && flow.sourceName === sourceName) {
      armBrowseFallback(flow);
      return;
    }
    state.pendingVideoSource = sourceName;
    state.pendingVideoSourceAt = Date.now();
    state.pendingWritingSourceRead = '';
    Object.assign(flow, {
      active: true,
      kind: 'video',
      sourceId: sourceId || flow.sourceId || '',
      sourceName,
      target: 'video',
      startedAt: Date.now(),
      resuming: false,
      handled: false
    });
    armBrowseFallback(flow);
  }

  function scheduleWritingReturnFlow(target, sourceName, sourceId) {
    const flow = state.browseFlow;
    Object.assign(flow, {
      active: true,
      kind: 'writing',
      sourceId: sourceId || flow.sourceId || '',
      sourceName: sourceName || flow.sourceName || '素材软件',
      target: target || 'article',
      startedAt: Date.now(),
      resuming: false,
      handled: false
    });
    state.writingSourceTarget = target || 'article';
    state.pendingWritingSourceRead = target || 'article';
    state.pendingVideoSource = '';
    state.pendingVideoSourceAt = 0;
    armBrowseFallback(flow);
  }

  function openVideoContinueWizard(sourceName, title) {
    const cleanName = sourceName || '视频软件';
    showModal('继续剪辑', 'VIDEO PROJECT',
      '<div class="video-continue-wizard">' +
        '<div class="video-continue-source"><strong>素材来源：' + escapeHtml(cleanName) + '</strong>' +
          '<small>如果你已在软件里选择电影、剧集或节目，可以继续建立剪辑项目。</small></div>' +
        '<label>素材或节目名称<input id="continueVideoTitle" value="' + escapeHtml(title || '') + '" placeholder="例如：某部电影第 1 集"></label>' +
        '<label>剪辑主题或开头文案<textarea id="continueVideoPrompt" placeholder="例如：三分钟看懂这部悬疑剧的人物关系与反转"></textarea></label>' +
        '<div class="modal-note">平台受 DRM 保护的完整内容不能直接读取。请选择你导出、购买或获得授权的本地视频；选择文件后会立即开始自动剪辑。</div>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-secondary" type="button" id="continueBuildPlanBtn">先建立拆解方案</button>' +
      '<button class="btn btn-primary" type="button" id="continuePickVideoBtn">选择视频并开始剪辑</button>');
    $('#continuePickVideoBtn').addEventListener('click', () => {
      const title = $('#continueVideoTitle').value.trim() || cleanName;
      const prompt = $('#continueVideoPrompt').value.trim() || title;
      $('#clipPrompt').value = prompt;
      $('#videoBreakdownTitle').value = title;
      state.autoStartAfterClipImport = true;
      closeModal();
      setTimeout(() => $('#localClipInput').click(), 120);
    });
    $('#continueBuildPlanBtn').addEventListener('click', () => {
      const title = $('#continueVideoTitle').value.trim();
      if (!title) {
        showToast('请填写素材名称', null, 'info');
        return;
      }
      $('#videoBreakdownTitle').value = title;
      $('#clipPrompt').value = $('#continueVideoPrompt').value.trim() || title;
      closeModal();
      runVideoBreakdown();
    });
  }

  function parseVideoBreakdown(raw, fallbackTitle, kind) {
    const text = String(raw || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
      const start = text.indexOf('{');
      const end = text.lastIndexOf('}');
      if (start >= 0 && end > start) {
        const value = JSON.parse(text.slice(start, end + 1));
        return Object.assign({
          title: fallbackTitle,
          kind,
          summary: '',
          characters: [],
          hooks: [],
          editNotes: []
        }, value, {
          characters: Array.isArray(value.characters) ? value.characters : [],
          hooks: Array.isArray(value.hooks) ? value.hooks : [],
          editNotes: Array.isArray(value.editNotes) ? value.editNotes : []
        });
      }
    } catch (error) {}
    const lines = text.split(/\r?\n/).map((line) =>
      line.replace(/^#+\s*/, '').replace(/^[-*]\s*/, '').trim()).filter(Boolean);
    return {
      title: fallbackTitle,
      kind,
      summary: truncate(lines.slice(0, 2).join(' '), 180),
      characters: [],
      hooks: lines.slice(0, 8).map((line, index) => ({
        label: index < 3 ? '0-' + ((index + 1) * 3) + '秒' : '第' + (index + 1) + '段',
        caption: truncate(line, 70),
        visual: '使用授权视频中的对应高光镜头',
        reason: '推进剧情信息'
      })),
      editNotes: ['强开场', '短镜头快切', '动态字幕', '音乐节拍转场']
    };
  }

  function renderVideoBreakdown(breakdown) {
    const result = $('#videoBreakdownResult');
    if (!result) return;
    if (!breakdown) {
      result.innerHTML = '<span>输入片名后生成精彩片段清单、人物关系和剪辑顺序。</span>';
      $('#applyVideoBreakdownBtn').disabled = false;
      return;
    }
    result.innerHTML = '<p class="breakdown-summary">' + escapeHtml(breakdown.summary || breakdown.title || '拆解方案') + '</p>' +
      (breakdown.hooks || []).slice(0, 8).map((hook, index) =>
        '<div class="breakdown-hook"><b>' + escapeHtml(hook.label || ('镜头 ' + (index + 1))) +
        '</b><div><strong>' + escapeHtml(hook.caption || hook.visual || '精彩片段') +
        '</strong><small>' + escapeHtml([hook.visual, hook.reason].filter(Boolean).join(' · ')) +
        '</small></div></div>').join('');
    $('#applyVideoBreakdownBtn').disabled = false;
  }

  async function runVideoBreakdown() {
    const title = $('#videoBreakdownTitle').value.trim();
    const kind = $('#videoBreakdownKind').value;
    const angle = $('#videoBreakdownAngle').value;
    if (!title) {
      showToast('请输入视频名称', '例如：流浪地球、甄嬛传、脱口秀大会。', 'info');
      $('#videoBreakdownTitle').focus();
      return;
    }
    const prompt = [
      '视频名称：' + title,
      '类型：' + kind,
      '拆解方向：' + angle,
      '请按照视频拆解JSON格式返回精彩片段清单。只基于公开主题、人物关系、常见叙事结构和官方预告层面提出方案。',
      '不得复制大段台词，不得声称已经观看或获取受版权保护的完整片源。'
    ].join('\n');
    showLoading('正在拆解视频', '正在整理核心冲突、精彩片段、人物关系和短视频剪辑顺序。');
    try {
      let raw = '';
      if (state.config.ai && state.config.ai.enabled && state.config.ai.hasKey) {
        const response = await api('/api/ai', {
          method: 'POST',
          body: JSON.stringify({
            system: '你是严谨的影视短视频策划。只输出合法、原创的剪辑分析，不提供盗版片源，不复刻具体受版权保护的镜头。',
            prompt,
            temperature: .55
          })
        });
        raw = response.text || '';
      } else if (state.codexReady) {
        const response = await api('/api/codex-write', {
          method: 'POST',
          body: JSON.stringify({ prompt, kind: 'breakdown' })
        });
        raw = response.text || '';
      } else {
        throw new Error('请先配置 AI 或登录 Codex');
      }
      if (!raw.trim()) throw new Error('AI 没有返回拆解方案');
      state.videoBreakdown = parseVideoBreakdown(raw, title, kind);
      renderVideoBreakdown(state.videoBreakdown);
      $('#videoBreakdownTitle').value = state.videoBreakdown.title || title;
      $('#clipPrompt').value = state.videoBreakdown.summary || title;
      showToast('视频拆解完成', '已生成精彩片段清单，可导入授权素材后自动剪辑。');
    } catch (error) {
      showToast('视频拆解失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  function applyVideoBreakdown() {
    if (!state.videoBreakdown) {
      showToast('还没有拆解方案', '请先输入片名并点击“AI 拆解”。', 'info');
      return;
    }
    if (!state.localVideoClips.length) {
      showToast('剪辑方案已就绪', '请选择视频软件或导入该作品的授权视频片段。', 'info');
      openVideoSourcePicker();
      return;
    }
    renderLocalClipMontage();
  }

  function splitSubtitleLines(text) {
    return String(text || '')
      .replace(/\r/g, '')
      .split(/\n+|[。！？!?；;]+/)
      .map((line) => line.trim())
      .filter(Boolean)
      .slice(0, 80);
  }

  function currentSourceSubtitleText(includeManual = true) {
    const manual = String(state.originalSubtitleText || '').trim();
    if (includeManual && manual) return manual;
    const breakdown = state.videoBreakdown;
    const captions = breakdown && (breakdown.hooks || [])
      .map((hook) => hook.caption || hook.visual || '')
      .filter(Boolean);
    if (captions && captions.length) return captions.join('\n');
    if (state.videoScript && state.videoScript.trim()) return state.videoScript.trim();
    return $('#clipPrompt')?.value.trim() || state.videoEpisodeTitle ||
      state.localVideoClips[0]?.name.replace(/\.[^.]+$/, '') || '授权视频素材';
  }

  async function translateSubtitleText(text) {
    const prompt = [
      '把下面的原片字幕翻译成自然、简洁、适合短视频阅读的简体中文。',
      '保留专有名词，不编造没有的信息，只输出翻译后的字幕，每句单独一行。',
      '原字幕：',
      String(text || '').slice(0, 6000)
    ].join('\n');
    let translated = '';
    if (state.config.ai && state.config.ai.enabled && state.config.ai.hasKey) {
      const result = await api('/api/ai', {
        method: 'POST',
        body: JSON.stringify({
          system: '你是专业的影视字幕翻译，只输出准确、自然的中文翻译。',
          prompt,
          temperature: .2
        })
      });
      translated = result.text || '';
    } else if (state.codexReady) {
      const result = await api('/api/codex-write', {
        method: 'POST',
        body: JSON.stringify({ prompt, kind: 'subtitle-translation' })
      });
      translated = result.text || '';
    } else {
      throw new Error('请先配置 AI，或登录 Codex 后再自动翻译');
    }
    translated = String(translated || '').trim();
    if (!translated) throw new Error('翻译服务没有返回字幕');
    return translated;
  }

  async function recognizeSpeechSubtitles() {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) throw new Error('当前 Edge 不支持在线语音识别，请手动粘贴原字幕');
    const clip = state.localVideoClips[0];
    if (!clip || !clip.url) throw new Error('请先导入或下载一段原片');
    const video = document.createElement('video');
    video.src = clip.url;
    video.playsInline = true;
    video.preload = 'auto';
    await new Promise((resolve, reject) => {
      video.onloadedmetadata = resolve;
      video.onerror = () => reject(new Error('无法读取这段原片的音轨'));
    });
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    await audioContext.resume();
    const source = audioContext.createMediaElementSource(video);
    const destination = audioContext.createMediaStreamDestination();
    source.connect(destination);
    const audioTrack = destination.stream.getAudioTracks()[0];
    if (!audioTrack) throw new Error('视频中没有检测到人物声音');
    const recognition = new Recognition();
    recognition.lang = state.subtitleSourceLanguage || 'en-US';
    recognition.continuous = true;
    recognition.interimResults = true;
    const phrases = [];
    let interimText = '';
    let stopRequested = false;
    let fatalSpeechError = '';
    recognition.onresult = (event) => {
      let interim = '';
      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        const item = event.results[index];
        const text = String(item[0] && item[0].transcript || '').trim();
        if (!text) continue;
        if (item.isFinal) {
          phrases.push({ time: video.currentTime || 0, text });
        } else {
          interim = text;
        }
      }
      interimText = interim;
      $('#speechRecognitionStatus').textContent = interim
        ? '正在识别：' + interim
        : '已识别 ' + phrases.length + ' 句人物对白…';
    };
    recognition.onerror = (event) => {
      if (event.error === 'no-speech') return;
      fatalSpeechError = event.error === 'language-not-supported'
        ? '当前语言不受 Edge 语音识别支持'
        : '语音识别失败：' + event.error;
      interimText = fatalSpeechError;
    };
    recognition.onend = () => {
      if (!stopRequested && !video.ended) {
        try { recognition.start(audioTrack); } catch (error) {}
      }
    };
    try {
      recognition.start(audioTrack);
    } catch (error) {
      audioContext.close().catch(() => {});
      throw new Error('当前 Edge 版本不能直接识别视频音轨，请更新 Edge 或手动粘贴字幕');
    }
    const maxSeconds = Math.min(120, Math.max(8, Number(video.duration) || clip.duration || 30));
    try { await video.play(); } catch (error) {}
    await new Promise((resolve) => {
      const startedAt = performance.now();
      const timer = setInterval(() => {
        const elapsed = (performance.now() - startedAt) / 1000;
        $('#speechRecognitionStatus').textContent =
          '正在识别人物说话 ' + Math.min(elapsed, maxSeconds).toFixed(0) + ' / ' +
          maxSeconds.toFixed(0) + ' 秒 · 已识别 ' + phrases.length + ' 句';
        if (fatalSpeechError || video.ended || video.currentTime >= maxSeconds || elapsed >= maxSeconds + 2) {
          clearInterval(timer);
          resolve();
        }
      }, 300);
    });
    stopRequested = true;
    try { recognition.stop(); } catch (error) {}
    video.pause();
    try { source.disconnect(); } catch (error) {}
    await audioContext.close().catch(() => {});
    if (fatalSpeechError) throw new Error(fatalSpeechError);
    if (interimText && (!phrases.length || phrases[phrases.length - 1].text !== interimText)) {
      phrases.push({ time: video.currentTime || maxSeconds, text: interimText });
    }
    const transcript = phrases.map((item) => item.text).join('\n').trim();
    if (!transcript) throw new Error('没有识别到清晰的人物说话，请换一段对白更清楚的素材');
    return transcript;
  }

  function formatClock(seconds) {
    const total = Math.max(0, Math.round(Number(seconds) || 0));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const secs = total % 60;
    return (hours > 0 ? String(hours).padStart(2, '0') + ':' : '') +
      String(minutes).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
  }

  async function acquireVideoWakeLock() {
    try {
      if (navigator.wakeLock && navigator.wakeLock.request && !state.videoWakeLock) {
        state.videoWakeLock = await navigator.wakeLock.request('screen');
      }
    } catch (error) {}
  }

  async function releaseVideoWakeLock() {
    try {
      if (state.videoWakeLock) {
        await state.videoWakeLock.release();
        state.videoWakeLock = null;
      }
    } catch (error) {
      state.videoWakeLock = null;
    }
  }

  function setVideoDurationValue(rawSeconds) {
    const seconds = Math.max(1, Math.min(86400, Math.round(Number(rawSeconds) || 30)));
    state.videoDuration = seconds;
    $$('#videoDurationOptions button').forEach((item) =>
      item.classList.toggle('active', Number(item.dataset.videoDuration) === seconds));
    $('#videoProgress').textContent = '00:00 / ' + formatClock(seconds);
    $('#videoState').textContent = '成片时长：' + formatClock(seconds);
    showToast('视频时长已选择',
      seconds >= 300 ? formatClock(seconds) + '，长视频生成时间和文件体积会明显增加。' : formatClock(seconds));
  }

  function renderVideoControlState() {
    if (state.videoComposition === 'talk') state.videoComposition = 'precise';
    $$('#videoComposition button').forEach((button) =>
      button.classList.toggle('active', button.dataset.composition === state.videoComposition));
    $$('#videoOutputMode button').forEach((button) =>
      button.classList.toggle('active', button.dataset.outputMode === state.videoOutputMode));
    $$('#videoVisualStyle button').forEach((button) =>
      button.classList.toggle('active', button.dataset.visualStyle === state.videoVisualStyle));
    $$('#videoDurationOptions button').forEach((button) =>
      button.classList.toggle('active', Number(button.dataset.videoDuration) === state.videoDuration));
    $$('#qualityOptions button').forEach((button) =>
      button.classList.toggle('active', button.dataset.videoQuality === state.videoQuality));
    if ($('#videoQualityHint')) {
      $('#videoQualityHint').textContent = state.videoQuality === 'fhd'
        ? '超清 1080P：画质更清晰，导出时间略长。'
        : '高清 720P：导出更快，适合快速预览和发布。';
    }
    $$('#clipAudioOptions button').forEach((button) =>
      {
        const active = button.dataset.clipAudio === state.clipAudioMode;
        button.classList.toggle('active', active);
        button.setAttribute('aria-checked', active ? 'true' : 'false');
      });
    const cleanOutput = state.videoOutputMode === 'clean';
    if (cleanOutput && state.clipAudioMode !== 'original') {
      state.clipAudioMode = 'original';
      $$('#clipAudioOptions button').forEach((button) => {
        const active = button.dataset.clipAudio === 'original';
        button.classList.toggle('active', active);
        button.setAttribute('aria-checked', active ? 'true' : 'false');
      });
    }
    $('#clipAudioOptions').classList.toggle('controls-locked', cleanOutput);
    $$('#clipAudioOptions button').forEach((button) => { button.disabled = cleanOutput; });
    if ($('#videoOutputModeHint')) {
      $('#videoOutputModeHint').textContent = cleanOutput
        ? '原视频直出：只保留画面和原声，去除程序添加的标题、字幕、导演文字、人物和进度条。'
        : '图文包装版适合资讯短视频；原视频直出适合直接发布干净原片。';
    }
    const personMode = state.clipAudioMode === 'person';
    const subtitleMode = state.clipAudioMode === 'original-subs' ||
      state.clipAudioMode === 'original-cn';
    $('#presenterOptions').hidden = !personMode;
    $('#presenterTools').hidden = !personMode;
    $('#speedOptionsRow').hidden = !personMode;
    if ($('#directorStyle')) {
      const director = DIRECTOR_STYLES[state.directorStyle] || DIRECTOR_STYLES.zhang;
      $('#directorStyle').value = state.directorStyle;
      $('#directorStyleHint').textContent = director.note;
    }
    $('#subtitleModeCard').hidden = !subtitleMode;
    $('#subtitleModeHint').textContent = state.clipAudioMode === 'original-cn'
      ? '保留原声；可以粘贴原字幕后翻译，也可以直接编辑中文翻译字幕。'
      : '保留原声；可以粘贴或使用视频拆解得到的原文字幕。';
    if ($('#subtitleSourceLanguage')) {
      $('#subtitleSourceLanguage').value = state.subtitleSourceLanguage || 'en-US';
    }
    const needsTranslation = state.clipAudioMode === 'original-cn' && !cleanOutput;
    if ($('#chineseSubtitleLabel')) $('#chineseSubtitleLabel').hidden = !needsTranslation;
    if ($('#translateSubtitleBtn')) $('#translateSubtitleBtn').hidden = !needsTranslation;
    if ($('#subtitleTranslateStatus')) $('#subtitleTranslateStatus').hidden = !needsTranslation;
    if ($('#recognizeSpeechSubtitlesBtn')) {
      $('#recognizeSpeechSubtitlesBtn').textContent = needsTranslation
        ? '识别人物说话并翻译' : '识别人物说话';
    }
    if (document.activeElement !== $('#originalSubtitleText')) {
      $('#originalSubtitleText').value = state.originalSubtitleText || '';
    }
    if (document.activeElement !== $('#chineseSubtitleText')) {
      $('#chineseSubtitleText').value = state.chineseSubtitleText || '';
    }
    $('#generateVideoBtn span').textContent = state.localVideoClips.length ? '原片智能剪辑' : '选择原片并剪辑';
    $('#videoProgress').textContent = '00:00 / ' + formatClock(state.videoDuration);
    const hasPreset = Array.from($$('#videoDurationOptions button'))
      .some((button) => Number(button.dataset.videoDuration) === Number(state.videoDuration));
    if (!hasPreset && $('#customVideoDuration')) {
      $('#customVideoDuration').value = state.videoDuration;
      $('#customVideoDurationUnit').value = state.videoDuration >= 120 ? 'minutes' : 'seconds';
      if (state.videoDuration >= 120) {
        $('#customVideoDuration').value = Math.round(state.videoDuration / 60 * 10) / 10;
      }
    }
    updatePresenterImageStatus();
  }

  function openDirectorStylePicker() {
    const options = Object.keys(DIRECTOR_STYLES).map((id) => {
      const style = DIRECTOR_STYLES[id];
      return '<button type="button" data-director-choice="' + id + '"' +
        (state.directorStyle === id ? ' class="active"' : '') + '><strong>' +
        escapeHtml(style.name) + '</strong><small>' + escapeHtml(style.note) + '</small></button>';
    }).join('');
    showModal('选择导演风格', 'DIRECTOR STYLE',
      '<div class="director-picker-grid">' + options + '</div>' +
      '<p class="field-hint">仅作为色彩、构图和剪辑节奏参考，不复制具体影视作品镜头。</p>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>');
    $$('[data-director-choice]').forEach((button) => {
      button.addEventListener('click', () => {
        const style = DIRECTOR_STYLES[button.dataset.directorChoice] || DIRECTOR_STYLES.zhang;
        state.directorStyle = button.dataset.directorChoice;
        saveJson(KEYS.directorStyle, state.directorStyle);
        $('#directorStyle').value = state.directorStyle;
        $('#directorStyleHint').textContent = style.note;
        closeModal();
        setCanvasRatio();
        showToast('导演风格已选择', style.name);
      });
    });
  }

  function startAutoVideoEditing() {
    if (!state.localVideoClips.length) {
      openVideoSourcePicker();
      return;
    }
    renderLocalClipMontage();
  }

  function prepareVideoView() {
    videoItemsForComposition();
    state.videoBlob = null;
    state.videoUrl = '';
    $('#videoResult').hidden = true;
    $('#downloadVideoBtn').hidden = true;
    $('#downloadVideoBtn').disabled = false;
    $('#emptyVideo').hidden = false;
    $('#videoState').textContent = '准备就绪';
    renderVideoControlState();
    renderVideoSources();
    renderLocalClipList();
    renderVideoLibraries();
    renderVoiceoverPanel();
    if (!state.serverOriginalsLoaded) loadServerOriginals(false);
    setCanvasRatio();
  }

  function startVideoFromHome() {
    const item = leadItem() || state.news[0];
    prepareOriginalVideoProject(item ? item.title : '原片智能剪辑',
      item ? item.summary || item.detailText || '' : '');
  }

  function prepareOriginalVideoProject(title, text) {
    const sentences = splitFactSentences(text || '').slice(0, 8);
    state.videoBreakdown = {
      title: title || '原片智能剪辑',
      kind: '原片剪辑',
      summary: truncate(text || title || '导入完整原片后自动提取高光片段。', 220),
      characters: [],
      hooks: sentences.length ? sentences.map((sentence, index) => ({
        label: String(index + 1).padStart(2, '0'),
        caption: truncate(sentence, 80),
        visual: '从完整原片中自动查找对应画面',
        reason: index === 0 ? '建立开场钩子' : '推进内容信息'
      })) : [{
        label: '01',
        caption: title || '原片高光剪辑',
        visual: '从完整原片中自动选择高能镜头',
        reason: '建立开场'
      }],
      editNotes: ['扫描整段素材', '选择高光片段', '保留原声或生成旁白']
    };
    state.videoEpisodeTitle = title || '原片智能剪辑';
    state.videoScript = [state.videoBreakdown.summary].concat(sentences).join('。');
    state.videoComposition = 'precise';
    state.videoVisualStyle = 'cinematic';
    state.videoDuration = 30;
    state.videoBlob = null;
    state.videoUrl = '';
    showView('video');
    renderVideoControlState();
    renderVideoBreakdown(state.videoBreakdown);
    setTimeout(openVideoSourcePicker, 120);
  }

  function primeAudio() {
    try {
      if (!state.audioContext) state.audioContext = new (window.AudioContext || window.webkitAudioContext)();
      state.audioContext.resume();
    } catch (error) {
      console.warn(error);
    }
  }

  async function captureNeteaseAudio() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      showToast('无法采集网易云声音', '请使用最新版 Microsoft Edge。', 'error');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false
        },
        systemAudio: 'include',
        preferCurrentTab: false,
        selfBrowserSurface: 'exclude'
      });
      const audioTracks = stream.getAudioTracks();
      if (!audioTracks.length) {
        stream.getTracks().forEach((track) => track.stop());
        throw new Error('所选窗口没有共享音频，请重新选择并开启“共享音频”');
      }
      stream.getVideoTracks().forEach((track) => track.stop());
      if (state.neteaseAudioStream) state.neteaseAudioStream.getTracks().forEach((track) => track.stop());
      state.neteaseAudioStream = stream;
      audioTracks[0].addEventListener('ended', () => {
        state.neteaseAudioStream = null;
        $('#musicCaptureStatus').textContent = '网易云声音已断开，可重新接入。';
      });
      $('#musicFileName').textContent = '网易云音乐 · 系统音频已接入';
      $('#musicCaptureStatus').textContent = '正在采集网易云播放声音，生成视频时自动混入。';
      showToast('网易云音乐已接入', '生成视频时会混入当前播放声音；请确认拥有使用授权。');
    } catch (error) {
      showToast('网易云声音接入失败', error.message, 'info');
    }
  }

  function narration(items, targetSeconds) {
    if (state.videoScript) {
      const maxChars = Math.max(60, Math.floor((targetSeconds || 30) * 4.1));
      return state.videoScript.length <= maxChars
        ? state.videoScript
        : state.videoScript.slice(0, maxChars).replace(/[，。；、\s]+$/, '') + '。';
    }
    const name = state.presenter === 'female' ? '小热' : '小闻';
    const lines = ['大家好，我是 AI 主播' + name + '，欢迎收看今天的新闻速览。'];
    items.slice(0, 5).forEach((item) => {
      lines.push(item.title + '。' + firstSentence(item.summary));
    });
    lines.push('以上就是今天的重点新闻。发布前记得核验来源、事实和图片授权。');
    const text = lines.join(' ');
    const maxChars = Math.max(48, Math.floor((targetSeconds || 30) * 4.1));
    return text.length <= maxChars ? text : text.slice(0, maxChars).replace(/[，。；、\s]+$/, '') + '。';
  }

  async function synthesizeTts(text, voiceName) {
    try {
      const rate = state.speed === 'slow' ? -2 : state.speed === 'fast' ? 2 : 0;
      const result = await api('/api/tts', {
        method: 'POST',
        body: JSON.stringify({ text, voice: voiceName || state.voiceoverVoice, rate })
      });
      if (result.ok && result.url) {
        const response = await fetch(result.url, { cache: 'no-store' });
        if (response.ok) {
          const blob = await response.blob();
          if (blob.size > 100) return blob;
        }
      }
    } catch (error) {
      console.warn('Local speech synthesis unavailable', error);
    }
    return synthesizeOnlineTts(text, voiceName);
  }

  function synthesizeOnlineTts(text, voiceName) {
    return new Promise((resolve, reject) => {
      const voice = voiceName || (state.presenter === 'female' ? 'zh-CN-XiaoxiaoNeural' : 'zh-CN-YunxiNeural');
      const rate = state.speed === 'slow' ? '-12%' : state.speed === 'fast' ? '+13%' : '+2%';
      const token = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
      const id = crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '') : String(Date.now()) + Math.random().toString(16).slice(2);
      const ws = new WebSocket('wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=' + token);
      ws.binaryType = 'arraybuffer';
      const chunks = [];
      let done = false;
      const timer = setTimeout(() => finish(new Error('旁白生成超时')), 30000);
      function finish(error, blob) {
        if (done) return;
        done = true;
        clearTimeout(timer);
        try { ws.close(); } catch (ignore) {}
        if (error) reject(error);
        else resolve(blob);
      }
      ws.onopen = () => {
        const config = 'X-Timestamp:' + new Date().toString() + '\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n' +
          JSON.stringify({ context: { synthesis: { audio: { metadataoptions: { sentenceBoundaryEnabled: false, wordBoundaryEnabled: false }, outputFormat: 'audio-24khz-48kbitrate-mono-mp3' } } } });
        ws.send(config);
        const escaped = String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const ssml = 'X-RequestId:' + id + '\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:' + new Date().toString() +
          '\r\nPath:ssml\r\n\r\n<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="zh-CN"><voice name="' +
          voice + '"><prosody rate="' + rate + '" pitch="+0Hz">' + escaped + '</prosody></voice></speak>';
        ws.send(ssml);
      };
      ws.onmessage = (event) => {
        if (typeof event.data === 'string') {
          if (event.data.includes('Path:turn.end')) {
            if (chunks.length) finish(null, new Blob(chunks, { type: 'audio/mpeg' }));
            else finish(new Error('语音服务未返回音频'));
          }
          return;
        }
        const buffer = event.data;
        if (buffer.byteLength < 2) return;
        const view = new DataView(buffer);
        const headerLength = view.getUint16(0);
        if (buffer.byteLength < headerLength + 2) return;
        const header = new TextDecoder().decode(new Uint8Array(buffer, 2, Math.min(headerLength, 300)));
        if (header.includes('Path:audio')) chunks.push(new Uint8Array(buffer, 2 + headerLength));
      };
      ws.onerror = () => finish(new Error('在线语音暂不可用'));
      ws.onclose = () => {
        if (!done) {
          if (chunks.length) finish(null, new Blob(chunks, { type: 'audio/mpeg' }));
          else finish(new Error('在线语音连接已关闭'));
        }
      };
    });
  }

  function renderVoiceoverPanel() {
    if (!$('#voiceoverText')) return;
    if (document.activeElement !== $('#voiceoverText')) {
      $('#voiceoverText').value = state.voiceoverText || '';
    }
    $('#voiceoverVoice').value = state.voiceoverVoice || 'zh-CN-XiaoxiaoNeural';
    const audio = $('#voiceoverAudio');
    audio.hidden = !state.voiceoverUrl;
    if (state.voiceoverUrl && audio.getAttribute('src') !== state.voiceoverUrl) {
      audio.src = state.voiceoverUrl;
    }
    $('#downloadVoiceoverBtn').disabled = false;
    $('#voiceoverStatus').textContent = state.voiceoverBlob
      ? '配音已生成 · 可试听、下载或直接用于剪辑'
      : '尚未生成配音';
  }

  function extractVoiceoverText() {
    const items = videoItemsForComposition();
    const hooks = state.videoBreakdown && (state.videoBreakdown.hooks || [])
      .map((hook) => hook.caption || hook.visual || '')
      .filter(Boolean);
    const source = hooks && hooks.length
      ? [state.videoBreakdown.summary || ''].concat(hooks).join('。')
      : narration(items, state.videoDuration);
    state.voiceoverText = truncate(source.replace(/。{2,}/g, '。'), 900);
    state.voiceoverBlob = null;
    if (state.voiceoverUrl) URL.revokeObjectURL(state.voiceoverUrl);
    state.voiceoverUrl = '';
    renderVoiceoverPanel();
    showToast('旁白文字已提取', '可以修改文字，再生成试听配音。');
  }

  async function generateVoiceover(autoplay) {
    const text = String($('#voiceoverText').value || '').trim();
    const voice = $('#voiceoverVoice').value || 'zh-CN-XiaoxiaoNeural';
    if (!text) {
      showToast('请先输入或提取旁白文字', null, 'info');
      $('#voiceoverText').focus();
      return false;
    }
    const button = $('#generateVoiceoverBtn');
    button.disabled = true;
    showLoading('正在生成 AI 旁白', '正在合成自然中文配音，请稍候。');
    try {
      const blob = await synthesizeTts(truncate(text, 1800), voice);
      if (state.voiceoverUrl) URL.revokeObjectURL(state.voiceoverUrl);
      state.voiceoverText = text;
      state.voiceoverVoice = voice;
      state.voiceoverBlob = blob;
      state.voiceoverUrl = URL.createObjectURL(blob);
      renderVoiceoverPanel();
      if (autoplay !== false) {
        try { await $('#voiceoverAudio').play(); } catch (error) {}
      }
      showToast('AI 旁白已生成', '可以下载 MP3，或直接带入原片剪辑。');
      return true;
    } catch (error) {
      state.voiceoverText = text;
      state.voiceoverVoice = voice;
      if (previewWithSystemSpeech(text, voice)) {
        $('#voiceoverStatus').textContent = '已用系统语音试听 · MP3 合成暂不可用';
        showToast('已用系统语音试听', '当前没有生成可下载的音频，请稍后重试或检查网络。', 'info');
      } else {
        showToast('旁白生成失败', error.message, 'error');
      }
      return false;
    } finally {
      button.disabled = false;
      hideLoading();
    }
  }

  function downloadVoiceoverAudio() {
    if (!state.voiceoverBlob || !state.voiceoverUrl) {
      showToast('还没有配音', '请先生成并试听。', 'info');
      return;
    }
    const link = document.createElement('a');
    const extension = String(state.voiceoverBlob.type || '').includes('wav') ? 'wav' : 'mp3';
    link.href = state.voiceoverUrl;
    link.download = '热点工坊_AI旁白_' + new Date().toISOString().slice(0, 10) + '.' + extension;
    document.body.appendChild(link);
    link.click();
    link.remove();
    showToast('配音已开始下载');
  }

  function previewWithSystemSpeech(text, voiceName) {
    if (!window.speechSynthesis || !window.SpeechSynthesisUtterance) return false;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'zh-CN';
      utterance.rate = state.speed === 'slow' ? .86 : state.speed === 'fast' ? 1.12 : 1;
      const voices = window.speechSynthesis.getVoices();
      const chinese = voices.filter((voice) => /^zh/i.test(voice.lang));
      const wantsMale = /Yunxi|Yunyang/i.test(voiceName || '');
      utterance.voice = chinese.find((voice) =>
        wantsMale ? /male|kangkang|yunxi|yunyang/i.test(voice.name) :
          /female|huihui|xiaoxiao|xiaoyi|yaoyao/i.test(voice.name)
      ) || chinese[0] || null;
      window.speechSynthesis.speak(utterance);
      return true;
    } catch (error) {
      return false;
    }
  }

  async function voiceoverToVideo() {
    const text = String($('#voiceoverText').value || '').trim();
    if (!text) {
      extractVoiceoverText();
      if (!$('#voiceoverText').value.trim()) return;
    }
    const voice = $('#voiceoverVoice').value || state.voiceoverVoice;
    if (!state.voiceoverBlob || state.voiceoverText !== text || state.voiceoverVoice !== voice) {
      const generated = await generateVoiceover(false);
      if (!generated) return;
    }
    state.videoScript = text;
    state.clipAudioMode = 'voiceover';
    $$('#clipAudioOptions button').forEach((button) =>
      button.classList.toggle('active', button.dataset.clipAudio === 'voiceover'));
    if (!state.localVideoClips.length) {
      state.autoStartAfterClipImport = true;
      showToast('旁白已准备好', '请选择软件、网站或本地原片，导入完成后会自动开始配音剪辑。', 'info');
      openVideoSourcePicker();
      return;
    }
    await renderLocalClipMontage();
  }

  function chooseMime() {
    const types = [
      'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
      'video/webm;codecs=h264,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm;codecs=vp9,opus',
      'video/webm'
    ];
    return types.find((type) => MediaRecorder.isTypeSupported(type)) || '';
  }

  function setProgress(elapsed, total) {
    const safeTotal = Math.max(1, total);
    $('#videoProgressBar').style.width = Math.min(100, elapsed / safeTotal * 100) + '%';
    $('#videoProgress').textContent = formatClock(Math.floor(elapsed)) + ' / ' + formatClock(Math.ceil(safeTotal));
  }

  async function renderVideo() {
    if (state.recording) return;
    if (state.localVideoClips.length) {
      await renderLocalClipMontage();
      return;
    }
    const items = videoItemsForComposition();
    if (!items.length) {
      showToast('没有视频素材', '请等资讯加载完成后再试。', 'info');
      return;
    }
    if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) {
      showToast('当前浏览器不支持视频生成', '请使用最新版 Microsoft Edge。', 'error');
      return;
    }
    const taskId = beginGeneration('video', state.videoEpisodeTitle || $('#clipPrompt').value.trim() || '短视频成品',
      state.videoComposition === 'montage' ? '正在生成多素材快剪' : '正在生成图文视频');
    primeAudio();
    acquireVideoWakeLock();
    state.recording = true;
    hideVideoTextEditor();
    $('#generateVideoBtn').disabled = true;
    $('#downloadVideoBtn').hidden = true;
    $('#videoResult').hidden = true;
    $('#videoCanvas').hidden = false;
    $('#emptyVideo').hidden = true;
    $('#videoState').textContent = '正在生成';
    let activeAudioSources = [];
    showLoading(state.videoComposition === 'montage' ? '正在制作多素材快剪' : '正在制作人物口播',
      '正在生成 AI 旁白、新闻画面和字幕。');
    try {
      await Promise.all(items.map((item) => loadCanvasImage(item.image)));
      let audioBuffer = null;
      let audioContext = state.audioContext || new (window.AudioContext || window.webkitAudioContext)();
      state.audioContext = audioContext;
      await audioContext.resume();
      try {
        showLoading('正在生成 AI 主播旁白', '主播口型、字幕和新闻画面将随旁白一起录制。');
        const blob = await synthesizeTts(narration(items, state.videoDuration));
        audioBuffer = await audioContext.decodeAudioData(await blob.arrayBuffer());
      } catch (error) {
        showToast('旁白暂不可用', '将先生成带字幕的静音版本。' + error.message, 'info');
      }
      let musicBuffer = null;
      if (state.musicFile) {
        try {
          musicBuffer = await audioContext.decodeAudioData(await state.musicFile.arrayBuffer());
        } catch (error) {
          showToast('背景音乐读取失败', '将不使用背景音乐继续生成。', 'info');
        }
      }

      const canvas = $('#videoCanvas');
      const exportQuality = videoQualitySpec();
      const exportDimensions = state.ratio === '9:16' ? exportQuality.portrait : exportQuality.landscape;
      canvas.width = exportDimensions[0];
      canvas.height = exportDimensions[1];
      const canvasStream = canvas.captureStream(exportQuality.fps);
      const tracks = canvasStream.getVideoTracks();
      const destination = audioContext.createMediaStreamDestination();
      if (audioBuffer) {
        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(destination);
        source.connect(audioContext.destination);
        source.start();
        activeAudioSources.push(source);
      }
      if (musicBuffer) {
        const music = audioContext.createBufferSource();
        const gain = audioContext.createGain();
        music.buffer = musicBuffer;
        music.loop = true;
        gain.gain.value = .11;
        music.connect(gain);
        gain.connect(destination);
        gain.connect(audioContext.destination);
        music.start();
        activeAudioSources.push(music);
      }
      if (state.neteaseAudioStream) {
        try {
          const neteaseSource = audioContext.createMediaStreamSource(state.neteaseAudioStream);
          const neteaseGain = audioContext.createGain();
          neteaseGain.gain.value = .35;
          neteaseSource.connect(neteaseGain);
          neteaseGain.connect(destination);
          activeAudioSources.push(neteaseSource);
        } catch (error) {}
      }
      if (audioBuffer || musicBuffer || state.neteaseAudioStream) {
        destination.stream.getAudioTracks().forEach((track) => tracks.push(track));
      }
      const stream = new MediaStream(tracks);
      const mime = chooseMime();
      const recorder = new MediaRecorder(stream, Object.assign({ videoBitsPerSecond: exportQuality.bitrate, audioBitsPerSecond: 192000 }, mime ? { mimeType: mime } : {}));
      const chunks = [];
      recorder.ondataavailable = (event) => { if (event.data && event.data.size) chunks.push(event.data); };
      const stopped = new Promise((resolve) => { recorder.onstop = () => resolve(new Blob(chunks, { type: mime || 'video/webm' })); });
      recorder.start(1000);

      const baseDuration = Math.max(8, Number(state.videoDuration) || 30);
      const total = audioBuffer && audioBuffer.duration > 8 ? Math.max(baseDuration, audioBuffer.duration + .8) : baseDuration;
      state.generatedVideoSeconds = total;
      const started = performance.now();
      await new Promise((resolve) => {
        let frame = 0;
        function animate(now) {
          const elapsed = (now - started) / 1000;
          const progress = Math.min(1, elapsed / total);
          const adjusted = progress * total;
          let stage = -1;
          if (adjusted >= 2.5) {
            const contentElapsed = adjusted - 2.5;
            const contentDuration = total - 5;
            const contentPer = contentDuration / items.length;
            stage = Math.floor(contentElapsed / contentPer);
            if (stage >= items.length) stage = items.length;
          }
          drawVideoVisual(items, stage, elapsed, state.ratio, state.presenter === 'female', progress);
          setProgress(elapsed, total);
          if (elapsed < total) frame = requestAnimationFrame(animate);
          else {
            cancelAnimationFrame(frame);
            resolve();
          }
        }
        frame = requestAnimationFrame(animate);
      });
      if (recorder.state !== 'inactive') recorder.stop();
      activeAudioSources.forEach((source) => { try { source.stop(); } catch (error) {} });
      const blob = await stopped;
      if (state.videoUrl) URL.revokeObjectURL(state.videoUrl);
      state.videoBlob = blob;
      state.videoUrl = URL.createObjectURL(blob);
      $('#videoResult').src = state.videoUrl;
      $('#videoResult').hidden = false;
      $('#downloadVideoBtn').hidden = false;
      canvas.hidden = true;
      $('#downloadVideoBtn').disabled = false;
      finishGeneration(taskId, 'video', {
        title: state.videoEpisodeTitle || $('#clipPrompt').value.trim() || '短视频成品',
        videoBlob: state.videoBlob,
        videoUrl: state.videoUrl,
        duration: state.generatedVideoSeconds || state.videoDuration,
        cover: ''
      });
      showVideoTextEditor();
      $('#videoState').textContent = state.videoComposition === 'montage'
        ? (audioBuffer ? '多素材快剪已完成' : '静音快剪已完成')
        : (audioBuffer ? '口播成片已完成' : '静音成片已完成');
      showToast(state.videoComposition === 'montage' ? '多素材快剪已生成' : '人物口播已生成',
        audioBuffer ? '可以预览并下载成片。' : '本次旁白不可用，已保留字幕版。', audioBuffer ? 'success' : 'info');
    } catch (error) {
      console.error(error);
      failGeneration(taskId, error.message);
      showToast('视频生成失败', error.message, 'error');
      $('#videoState').textContent = '生成失败';
    } finally {
      failGeneration(taskId, '视频生成未完成，可重新发起');
      activeAudioSources.forEach((source) => { try { source.stop(); } catch (error) {} });
      state.recording = false;
      releaseVideoWakeLock();
      $('#generateVideoBtn').disabled = false;
      hideLoading();
      renderCreationSaveBar();
    }
  }

  function drawPresenterOverlay(ctx, photo, time, female, ink, accent) {
    const width = ctx.canvas.width;
    const height = ctx.canvas.height;
    const portrait = height > width;
    const boxWidth = portrait ? 255 : 195;
    const boxHeight = portrait ? 315 : 235;
    const x = width - boxWidth - (portrait ? 55 : 42);
    const y = portrait ? height * .19 : height * .16;
    ctx.save();
    roundRect(ctx, x, y, boxWidth, boxHeight, 22);
    ctx.clip();
    ctx.fillStyle = ink;
    ctx.fillRect(x, y, boxWidth, boxHeight);
    if (photo) {
      drawCover(ctx, photo, x, y, boxWidth, boxHeight, 1.03);
    } else {
      const gradient = ctx.createLinearGradient(x, y, x, y + boxHeight);
      gradient.addColorStop(0, '#263b4d');
      gradient.addColorStop(1, '#10202d');
      ctx.fillStyle = gradient;
      ctx.fillRect(x, y, boxWidth, boxHeight);
      drawPresenter(ctx, x + boxWidth / 2, y + boxHeight * .22, portrait ? .34 : .26,
        time, Math.max(0, Math.sin(time * 7.5)) * .55, female);
    }
    ctx.restore();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 4;
    roundRect(ctx, x, y, boxWidth, boxHeight, 22);
    ctx.stroke();
    ctx.fillStyle = 'rgba(11,20,27,.82)';
    roundRect(ctx, x + 12, y + boxHeight - 46, boxWidth - 24, 32, 8);
    ctx.fill();
    ctx.fillStyle = '#fffaf2';
    ctx.font = '700 ' + (portrait ? 19 : 16) + 'px "Microsoft YaHei UI"';
    ctx.textAlign = 'center';
    ctx.fillText('AI 人物口播 · ' + (female ? '小热' : '小闻'), x + boxWidth / 2, y + boxHeight - 23);
    ctx.textAlign = 'left';
  }

  function drawLocalClipFrame(ctx, video, caption, title, progress, segmentIndex, showPresenter, presenterPhoto, time, showCaption) {
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    const width = ctx.canvas.width;
    const height = ctx.canvas.height;
    const portrait = height > width;
    const style = DIRECTOR_STYLES[state.directorStyle] || DIRECTOR_STYLES.zhang;
    const accent = style.accent;
    const gold = style.gold;
    const ink = style.ink;
    const vw = video.videoWidth || 16;
    const vh = video.videoHeight || 9;
    const zoom = 1.035 + Math.sin(progress * Math.PI) * .04;
    const scale = Math.max(width / vw, height / vh) * zoom;
    const sw = width / scale;
    const sh = height / scale;
    const sx = Math.max(0, (vw - sw) / 2);
    const sy = Math.max(0, (vh - sh) / 2);
    ctx.fillStyle = '#080b12';
    ctx.fillRect(0, 0, width, height);
    try { ctx.drawImage(video, sx, sy, sw, sh, 0, 0, width, height); } catch (error) {}
    if (state.videoOutputMode === 'clean') return;
    const shade = ctx.createLinearGradient(0, 0, 0, height);
    shade.addColorStop(0, ink + 'a8');
    shade.addColorStop(.46, ink + '18');
    shade.addColorStop(1, ink + 'ee');
    ctx.fillStyle = shade;
    ctx.fillRect(0, 0, width, height);
    const vignette = ctx.createRadialGradient(width / 2, height * .45, width * .18, width / 2, height * .45, width * .78);
    vignette.addColorStop(0, 'rgba(0,0,0,0)');
    vignette.addColorStop(1, ink + 'a0');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, width, height);
    const margin = portrait ? 52 : 42;
    ctx.fillStyle = accent;
    ctx.fillRect(margin, portrait ? 55 : 30, portrait ? 72 : 54, 5);
    ctx.fillStyle = gold;
    ctx.fillRect(margin, portrait ? 64 : 39, portrait ? 22 : 18, 3);
    ctx.fillStyle = '#f7f1e8';
    ctx.font = '700 ' + (portrait ? 25 : 18) + 'px ' + style.font;
    ctx.fillText(style.name + ' · 自动剪辑', margin, portrait ? 103 : 72);
    ctx.textAlign = 'right';
    ctx.fillStyle = '#d5dbe5';
    ctx.font = '600 ' + (portrait ? 18 : 13) + 'px "Microsoft YaHei UI"';
    ctx.fillText(String(segmentIndex + 1).padStart(2, '0') + ' / CINEMATIC CUT', width - margin, portrait ? 103 : 72);
    ctx.textAlign = 'left';
    const titleLines = wrapLines(ctx, title || '授权视频素材快剪', width - margin * 2, 3);
    ctx.font = '900 ' + (portrait ? 57 : 40) + 'px ' + style.font;
    titleLines.forEach((line, index) => {
      ctx.fillStyle = ink + 'b8';
      roundRect(ctx, margin - 10, 175 + index * (portrait ? 66 : 50), ctx.measureText(line).width + 20, portrait ? 62 : 46, 7);
      ctx.fill();
      ctx.fillStyle = '#fffaf2';
      ctx.fillText(line, margin, 220 + index * (portrait ? 66 : 50));
    });
    if (showCaption) {
      const captionLines = wrapLines(ctx, caption || '精选高能片段，快速进入内容。', width - margin * 2 - 24, 3);
      const captionHeight = 38 + captionLines.length * (portrait ? 44 : 34);
      ctx.fillStyle = ink + 'e8';
      roundRect(ctx, margin, height - captionHeight - 105, width - margin * 2, captionHeight, 16);
      ctx.fill();
      ctx.strokeStyle = gold + '70';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.fillStyle = gold;
      ctx.font = '800 ' + (portrait ? 18 : 14) + 'px "Microsoft YaHei UI"';
      ctx.fillText('字幕 / 导演风格参考', margin + 18, height - captionHeight - 66);
      ctx.fillStyle = '#fffaf2';
      ctx.font = '700 ' + (portrait ? 28 : 21) + 'px ' + style.font;
      captionLines.forEach((line, index) => ctx.fillText(line, margin + 18, height - captionHeight - 20 + index * (portrait ? 41 : 32)));
    }
    ctx.fillStyle = 'rgba(255,255,255,.2)';
    ctx.fillRect(margin, height - 43, width - margin * 2, 5);
    ctx.fillStyle = accent;
    ctx.fillRect(margin, height - 43, (width - margin * 2) * Math.max(0, Math.min(1, progress)), 5);
    if (portrait) {
      ctx.fillStyle = ink + 'b0';
      ctx.fillRect(0, 0, margin * .34, height);
      ctx.fillRect(width - margin * .34, 0, margin * .34, height);
    }
    if (showPresenter) {
      drawPresenterOverlay(ctx, presenterPhoto, time || 0, state.presenter === 'female', ink, accent);
    }
  }

  function showVideoTextEditor() {
    const editor = $('#videoTextEditor');
    if (!editor) return;
    const title = state.videoEpisodeTitle || $('#clipPrompt')?.value.trim() || '成片标题';
    const subtitle = state.clipAudioMode === 'original-cn'
      ? (state.chineseSubtitleText || state.originalSubtitleText || '')
      : (state.originalSubtitleText || state.voiceoverText || '');
    $('#videoPostTitle').value = title;
    $('#videoPostSubtitle').value = subtitle;
    $('#videoTextEditorState').textContent = state.videoOutputMode === 'clean'
      ? '原视频直出' : '图文包装';
    editor.hidden = false;
  }

  function openPrePublishEditor() {
    const clean = state.videoOutputMode === 'clean';
    const audioMode = clean ? 'original' : state.clipAudioMode;
    const title = state.videoEpisodeTitle || $('#clipPrompt')?.value.trim() ||
      state.localVideoClips[0]?.name.replace(/\.[^.]+$/, '') || '视频标题';
    const narration = state.voiceoverText || state.originalSubtitleText ||
      state.chineseSubtitleText || state.videoScript || '';
    showModal('发布前编辑', 'PRE-PUBLISH EDITOR',
      '<div class="pre-publish-editor">' +
        '<label>视频标题<input id="prePublishTitle" type="text" maxlength="120"></label>' +
        '<label>旁白 / 字幕文字<textarea id="prePublishNarration" rows="6" placeholder="输入要用于 AI 旁白或视频字幕的文字"></textarea></label>' +
        '<div class="pre-publish-audio" id="prePublishAudio">' +
          '<button type="button" data-prepublish-audio="original" class="' +
            (audioMode === 'original' ? 'active' : '') + '">原片原声</button>' +
          '<button type="button" data-prepublish-audio="voiceover" class="' +
            (audioMode === 'voiceover' ? 'active' : '') + '">AI 旁白</button>' +
          '<button type="button" data-prepublish-audio="mute" class="' +
            (audioMode === 'mute' ? 'active' : '') + '">仅字幕</button>' +
        '</div>' +
        '<label class="pre-publish-voice">旁白声音<select id="prePublishVoice">' +
          '<option value="zh-CN-XiaoxiaoNeural">晓晓 · 温暖女声</option>' +
          '<option value="zh-CN-XiaoyiNeural">晓伊 · 明亮女声</option>' +
          '<option value="zh-CN-YunxiNeural">云希 · 沉稳男声</option>' +
          '<option value="zh-CN-YunyangNeural">云扬 · 新闻男声</option>' +
        '</select></label>' +
        '<label class="pre-publish-clean"><input id="prePublishCleanText" type="checkbox"' +
          (clean ? ' checked' : '') + '><span><strong>去除无关文字</strong><small>移除程序添加的标题、字幕、导演文字、人物和进度条，保留干净原画面。</small></span></label>' +
        '<p class="field-hint">原视频画面中已经烧录的文字无法无损擦除；此选项只去除热点工坊添加的文字。</p>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-secondary" type="button" id="directPublishCurrentBtn">直接发布当前成片</button>' +
      '<button class="btn btn-primary" type="button" id="applyPrePublishBtn">保存并重新生成</button>');
    $('#prePublishTitle').value = title;
    $('#prePublishNarration').value = narration;
    $('#prePublishVoice').value = state.voiceoverVoice || 'zh-CN-XiaoxiaoNeural';
    $('#prePublishCleanText').addEventListener('change', (event) => {
      $$('#prePublishAudio button').forEach((button) => {
        button.disabled = event.target.checked;
        if (event.target.checked) button.classList.toggle('active', button.dataset.prepublishAudio === 'original');
      });
    });
    $$('#prePublishAudio button').forEach((button) => {
      button.disabled = $('#prePublishCleanText').checked;
      button.addEventListener('click', () => {
        if ($('#prePublishCleanText').checked) return;
        $$('#prePublishAudio button').forEach((item) => item.classList.toggle('active', item === button));
      });
    });
    $('#applyPrePublishBtn').addEventListener('click', () => {
      const applyClean = $('#prePublishCleanText').checked;
      const selectedAudio = $('.pre-publish-audio button.active');
      const audio = applyClean ? 'original' : (selectedAudio?.dataset.prepublishAudio || 'original');
      state.videoOutputMode = applyClean ? 'clean' : 'styled';
      state.clipAudioMode = audio;
      if (!applyClean && audio === 'original') state.clipAudioMode = 'original-subs';
      state.videoEpisodeTitle = $('#prePublishTitle').value.trim() || '视频标题';
      state.voiceoverText = $('#prePublishNarration').value.trim();
      state.originalSubtitleText = state.voiceoverText;
      state.chineseSubtitleText = state.voiceoverText;
      state.voiceoverVoice = $('#prePublishVoice').value;
      saveJson(KEYS.videoOutputMode, state.videoOutputMode);
      saveJson(KEYS.originalSubtitleText, state.originalSubtitleText);
      saveJson(KEYS.chineseSubtitleText, state.chineseSubtitleText);
      if ($('#clipPrompt')) $('#clipPrompt').value = state.videoEpisodeTitle;
      closeModal();
      renderVideoControlState();
      if (!state.localVideoClips.length) {
        showToast('发布设置已保存', '当前没有原片可重新生成，发布时将使用现有成片。', 'info');
        return;
      }
      setTimeout(() => renderLocalClipMontage(), 250);
    });
    $('#directPublishCurrentBtn').addEventListener('click', () => {
      closeModal();
      if (state.videoBlob) downloadVideo();
      else showToast('当前没有成片', '请先重新生成或选择原视频发布。', 'info');
      openToutiao(state.config.videoUrl);
    });
  }

  function hideVideoTextEditor() {
    if ($('#videoTextEditor')) $('#videoTextEditor').hidden = true;
  }

  function applyVideoTextEdit(clearAll) {
    if (!$('#videoPostTitle')) return;
    if (clearAll) {
      state.videoOutputMode = 'clean';
      saveJson(KEYS.videoOutputMode, state.videoOutputMode);
      showToast('已切换为干净直出', '将移除程序添加的全部标题、字幕和包装文字。');
    } else {
      const title = $('#videoPostTitle').value.trim();
      const subtitle = $('#videoPostSubtitle').value.trim();
      state.videoOutputMode = 'styled';
      state.videoEpisodeTitle = title || '成片标题';
      state.originalSubtitleText = subtitle;
      if (state.clipAudioMode === 'original-cn') state.chineseSubtitleText = subtitle;
      if (state.clipAudioMode === 'voiceover' || state.clipAudioMode === 'person')
        state.voiceoverText = subtitle;
      saveJson(KEYS.videoOutputMode, state.videoOutputMode);
      saveJson(KEYS.originalSubtitleText, state.originalSubtitleText);
      saveJson(KEYS.chineseSubtitleText, state.chineseSubtitleText || '');
      if ($('#clipPrompt')) $('#clipPrompt').value = state.videoEpisodeTitle;
      if (state.clipAudioMode === 'original') state.clipAudioMode = 'original-subs';
      showToast('文字修改已应用', '正在按新标题和字幕重新生成视频。');
    }
    if (state.localVideoClips.length) {
      hideVideoTextEditor();
      renderVideoControlState();
      setTimeout(() => renderLocalClipMontage(), 250);
    } else {
      showToast('无法重新生成', '当前没有可用原片，请重新导入素材。', 'info');
    }
  }

  async function generateCoreVideoTitle() {
    const button = $('#generateCoreVideoTitleBtn');
    const box = $('#videoCoreTitleSuggestions');
    const currentTitle = $('#videoPostTitle').value.trim() ||
      state.videoEpisodeTitle || $('#clipPrompt')?.value.trim() || '视频原片';
    const breakdown = state.videoBreakdown;
    const hooks = breakdown && (breakdown.hooks || [])
      .map((hook) => hook.caption || hook.visual || '').filter(Boolean);
    const subtitle = $('#videoPostSubtitle').value.trim() ||
      state.originalSubtitleText || state.chineseSubtitleText || '';
    const clipNames = state.localVideoClips.map((clip) => clip.name).filter(Boolean);
    const context = [
      '当前片名：' + currentTitle,
      breakdown && breakdown.summary ? '视频内容摘要：' + breakdown.summary : '',
      hooks && hooks.length ? '核心片段：' + hooks.join('；') : '',
      subtitle ? '人物对白/字幕：' + subtitle.slice(0, 1600) : '',
      clipNames.length ? '原片素材：' + clipNames.join('；') : ''
    ].filter(Boolean).join('\n');
    button.disabled = true;
    button.textContent = '正在生成';
    box.innerHTML = '<span>正在分析视频内容…</span>';
    let titles = [];
    const prompt = [
      '根据下面的视频内容生成 3 个中文核心标题。',
      '要求：准确、有吸引力、不夸张、不编造、每个不超过24字，只输出标题，每行一个。',
      context
    ].join('\n');
    try {
      let raw = '';
      if (state.config.ai && state.config.ai.enabled && state.config.ai.hasKey) {
        const result = await api('/api/ai', {
          method: 'POST',
          body: JSON.stringify({
            system: '你是严谨的中文视频标题编辑，只输出三个可用标题。',
            prompt,
            temperature: .55
          })
        });
        raw = result.text || '';
      } else if (state.codexReady) {
        const result = await api('/api/codex-write', {
          method: 'POST',
          body: JSON.stringify({ prompt, kind: 'video-core-title' })
        });
        raw = result.text || '';
      }
      titles = String(raw || '').split(/\n+/)
        .map((line) => line.replace(/^\s*(?:[-*#]|\d+[.、:：])\s*/, '').trim())
        .filter((line) => line && line.length <= 80)
        .slice(0, 3);
    } catch (error) {
      console.warn('Core title generation failed', error);
    }
    if (!titles.length) {
      const base = (breakdown && breakdown.title) || currentTitle.replace(/\.[^.]+$/, '');
      titles = [
        base + '：核心内容一次看懂',
        '一条视频看懂' + base,
        base + '背后的关键问题'
      ];
    }
    box.innerHTML = titles.map((title) =>
      '<button type="button" data-core-title="' + escapeHtml(title) + '">' +
      escapeHtml(title) + '</button>').join('');
    $$('[data-core-title]', box).forEach((item) => {
      item.addEventListener('click', () => {
        $('#videoPostTitle').value = item.dataset.coreTitle;
        $('#videoTextEditorState').textContent = '标题已选择';
        showToast('核心标题已应用', '点击“应用文字并重新生成”即可写入成片。');
      });
    });
    button.disabled = false;
    button.textContent = '重新生成';
  }

  function openTextPrePublishEditor(kind) {
    const isNovel = kind === 'novel';
    const title = isNovel
      ? ($('#novelTitle')?.value.trim() || state.novel?.title || '')
      : ($('#articleTitle')?.value.trim() || state.article?.title || '');
    const bodyHtml = isNovel
      ? ($('#novelContent')?.innerHTML || state.novel?.html || '')
      : ($('#articleBody')?.innerHTML || state.article?.html || '');
    const bodyText = stripHtml(bodyHtml);
    const summary = isNovel
      ? (state.novel?.synopsis || '')
      : (state.article?.summary || bodyText.slice(0, 260));
    if (!title && !bodyText) {
      showToast(isNovel ? '还没有小说内容' : '还没有图文内容',
        '请先生成或打开一篇内容。', 'info');
      return;
    }
    showModal(isNovel ? '小说发布前编辑' : '图文发布前编辑', 'PRE-PUBLISH TEXT EDITOR',
      '<div class="text-pre-publish-editor">' +
        '<label>核心标题<input id="textPrePublishTitle" type="text" maxlength="120"></label>' +
        '<label>' + (isNovel ? '作品简介' : '导语 / 摘要') +
          '<textarea id="textPrePublishSummary" rows="4"></textarea></label>' +
        '<div class="text-core-title-tools">' +
          '<button type="button" id="generateTextCoreTitlesBtn">根据内容生成 3 个核心标题</button>' +
          '<div id="textCoreTitleSuggestions"><span>会根据正文、素材和当前标题生成。</span></div>' +
        '</div>' +
        (isNovel
          ? '<label>发布平台<select id="textPrePublishPlatform">' +
            '<option value="fanqie">番茄小说</option>' +
            '<option value="zhihu">知乎</option>' +
            '<option value="jinjiang">晋江文学城</option></select></label>'
          : '<p class="field-hint">应用后会同步更新编辑器，并保留全部图片和排版。</p>') +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button>' +
      '<button class="btn btn-secondary" type="button" id="applyTextPrePublishBtn">仅应用编辑</button>' +
      '<button class="btn btn-primary" type="button" id="publishTextPrePublishBtn">' +
        (isNovel ? '应用并打开小说平台' : '应用并发布到头条') + '</button>');
    $('#textPrePublishTitle').value = title;
    $('#textPrePublishSummary').value = summary;
    const applyChanges = () => {
      const nextTitle = $('#textPrePublishTitle').value.trim() || title || '未命名作品';
      const nextSummary = $('#textPrePublishSummary').value.trim();
      if (isNovel) {
        if (!state.novel) state.novel = { title: nextTitle, synopsis: nextSummary, html: bodyHtml };
        state.novel.title = nextTitle;
        state.novel.synopsis = nextSummary;
        if ($('#novelTitle')) $('#novelTitle').value = nextTitle;
        persistNovel();
        renderNovel();
      } else {
        if (!state.article) state.article = { title: nextTitle, summary: nextSummary, html: bodyHtml };
        state.article.title = nextTitle;
        state.article.summary = nextSummary;
        if ($('#articleTitle')) $('#articleTitle').value = nextTitle;
        saveJson(KEYS.article, state.article);
        renderArticle();
      }
    };
    $('#applyTextPrePublishBtn').addEventListener('click', () => {
      applyChanges();
      closeModal();
      showToast('发布设置已应用', '标题和导语已经同步到编辑器。');
    });
    $('#publishTextPrePublishBtn').addEventListener('click', () => {
      applyChanges();
      const platform = isNovel ? $('#textPrePublishPlatform').value : '';
      closeModal();
      if (isNovel) copyNovelAndOpen(platform);
      else publishArticle();
    });
    $('#generateTextCoreTitlesBtn').addEventListener('click', async () => {
      const button = $('#generateTextCoreTitlesBtn');
      const box = $('#textCoreTitleSuggestions');
      const currentTitle = $('#textPrePublishTitle').value.trim() || title;
      const contextText = bodyText.slice(0, 6000);
      if (!contextText) {
        showToast('没有正文内容', '请先生成或填写正文。', 'info');
        return;
      }
      button.disabled = true;
      button.textContent = '正在生成';
      box.innerHTML = '<span>正在分析正文内容…</span>';
      const prompt = '根据下面的' + (isNovel ? '小说' : '图文') +
        '内容生成3个准确、有吸引力、不夸张的中文核心标题，每个不超过24字，每行一个。\n当前标题：' +
        currentTitle + '\n正文：' + contextText;
      let raw = '';
      try {
        if (state.config.ai && state.config.ai.enabled && state.config.ai.hasKey) {
          const response = await api('/api/ai', {
            method: 'POST',
            body: JSON.stringify({
              system: '你是严谨的中文标题编辑，只输出三个可用标题。',
              prompt,
              temperature: .55
            })
          });
          raw = response.text || '';
        } else if (state.codexReady) {
          const response = await api('/api/codex-write', {
            method: 'POST',
            body: JSON.stringify({ prompt, kind: 'text-core-title' })
          });
          raw = response.text || '';
        }
      } catch (error) {}
      let titles = raw.split(/\n+/)
        .map((line) => line.replace(/^\s*(?:[-*#]|\d+[.、:：])\s*/, '').trim())
        .filter(Boolean).slice(0, 3);
      if (!titles.length) {
        const base = currentTitle || '当前作品';
        titles = [base + '：核心内容一次看懂', '一文看懂' + base, base + '背后的关键问题'];
      }
      box.innerHTML = titles.map((item) =>
        '<button type="button" data-text-core-title="' + escapeHtml(item) + '">' +
        escapeHtml(item) + '</button>').join('');
      $$('[data-text-core-title]', box).forEach((item) => {
        item.addEventListener('click', () => {
          $('#textPrePublishTitle').value = item.dataset.textCoreTitle;
          showToast('核心标题已选择');
        });
      });
      button.disabled = false;
      button.textContent = '重新生成 3 个标题';
    });
  }

  async function renderLocalClipMontage() {
    if (state.recording) return;
    if (!state.localVideoClips.length) {
      openVideoSourcePicker();
      return;
    }
    if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) {
      showToast('当前浏览器不支持视频剪辑', '请使用最新版 Microsoft Edge。', 'error');
      return;
    }
    const taskId = beginGeneration('video', state.videoEpisodeTitle || $('#clipPrompt').value.trim() || '原片剪辑成品',
      '正在扫描原片并生成高光剪辑');
    primeAudio();
    acquireVideoWakeLock();
    state.recording = true;
    $('#generateClipMontageBtn').disabled = true;
    $('#generateVideoBtn').disabled = true;
    $('#downloadVideoBtn').hidden = true;
    $('#videoResult').hidden = true;
    $('#videoCanvas').hidden = false;
    $('#emptyVideo').hidden = true;
    $('#videoState').textContent = '正在自动快剪';
    const canvas = $('#videoCanvas');
    const exportQuality = videoQualitySpec();
    const exportDimensions = state.ratio === '9:16' ? exportQuality.portrait : exportQuality.landscape;
    canvas.width = exportDimensions[0];
    canvas.height = exportDimensions[1];
    const audioContext = state.audioContext || new (window.AudioContext || window.webkitAudioContext)();
    state.audioContext = audioContext;
    await audioContext.resume();
    const presenterPhoto = state.clipAudioMode === 'person' && state.presenterImage
      ? await loadCanvasImage(state.presenterImage)
      : null;
    const activeSources = [];
    showLoading('正在自动剪辑授权素材', '正在按原片内容生成镜头顺序、字幕和所选音频。');
    try {
      const breakdown = state.videoBreakdown;
      const title = breakdown && breakdown.title || $('#clipPrompt').value.trim() ||
        state.localVideoClips[0].name.replace(/\.[^.]+$/, '');
      const hookCaptions = breakdown && (breakdown.hooks || []).map((hook) =>
        hook.caption || hook.visual || '').filter(Boolean);
      const defaultNarrationText = (breakdown && breakdown.summary ? breakdown.summary + '。' : '') +
        (hookCaptions && hookCaptions.length
          ? hookCaptions.join('。') + '。'
          : title + '。精选高能画面，快速梳理人物关系与核心冲突。') +
        '以下内容使用授权素材制作。';
      const cleanOutput = state.videoOutputMode === 'clean';
      const preserveOriginalAudio = cleanOutput ||
        ['original', 'original-subs', 'original-cn'].includes(state.clipAudioMode);
      const showSubtitles = !cleanOutput && state.clipAudioMode !== 'original';
      let originalSubtitleText = String(state.originalSubtitleText || '').trim() ||
        (hookCaptions && hookCaptions.length ? hookCaptions.join('\n') : title);
      let chineseSubtitleText = String(state.chineseSubtitleText || '').trim();
      if (state.clipAudioMode === 'original-cn' && !chineseSubtitleText) {
        showLoading('正在生成中文字幕', '正在把原片字幕翻译为中文，随后开始剪辑。');
        try {
          chineseSubtitleText = await translateSubtitleText(originalSubtitleText);
          state.chineseSubtitleText = chineseSubtitleText;
          saveJson(KEYS.chineseSubtitleText, chineseSubtitleText);
          if ($('#chineseSubtitleText')) $('#chineseSubtitleText').value = chineseSubtitleText;
        } catch (error) {
          chineseSubtitleText = defaultNarrationText;
          if ($('#subtitleTranslateStatus')) {
            $('#subtitleTranslateStatus').textContent =
              '自动翻译未完成，已改用当前中文视频拆解字幕：' + error.message;
          }
        }
      }
      const needsSpeech = state.clipAudioMode === 'voiceover' || state.clipAudioMode === 'person';
      const narrationText = needsSpeech && state.voiceoverText.trim()
        ? state.voiceoverText.trim()
        : defaultNarrationText;
      let audioBuffer = null;
      if (needsSpeech) {
        try {
          showLoading(state.clipAudioMode === 'person' ? '正在生成人物口播' : '正在生成 AI 声音',
            state.clipAudioMode === 'person' ? 'AI 旁白和人物画面将随原片一起录制。' : 'AI 配音将跟随原片镜头。');
          const audioBlob = state.voiceoverBlob && state.voiceoverText.trim() === narrationText.trim()
            ? state.voiceoverBlob
            : await synthesizeTts(narrationText, state.voiceoverVoice || 'zh-CN-XiaoxiaoNeural');
          audioBuffer = await audioContext.decodeAudioData(await audioBlob.arrayBuffer());
        } catch (error) {}
      }
      const destination = audioContext.createMediaStreamDestination();
      if (audioBuffer) {
        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(destination);
        source.connect(audioContext.destination);
        source.start();
        activeSources.push(source);
      }
      if (state.musicFile) {
        try {
          const musicBuffer = await audioContext.decodeAudioData(await state.musicFile.arrayBuffer());
          const music = audioContext.createBufferSource();
          const gain = audioContext.createGain();
          music.buffer = musicBuffer;
          music.loop = true;
          gain.gain.value = .09;
          music.connect(gain);
          gain.connect(destination);
          gain.connect(audioContext.destination);
          music.start();
          activeSources.push(music);
        } catch (error) {}
      }
      if (state.neteaseAudioStream) {
        try {
          const neteaseSource = audioContext.createMediaStreamSource(state.neteaseAudioStream);
          const neteaseGain = audioContext.createGain();
          neteaseGain.gain.value = .35;
          neteaseSource.connect(neteaseGain);
          neteaseGain.connect(destination);
          activeSources.push(neteaseSource);
        } catch (error) {}
      }
      const canvasStream = canvas.captureStream(exportQuality.fps);
      const tracks = canvasStream.getVideoTracks();
      if (destination.stream.getAudioTracks().length) destination.stream.getAudioTracks().forEach((track) => tracks.push(track));
      const stream = new MediaStream(tracks);
      const mime = chooseMime();
      const recorder = new MediaRecorder(stream, Object.assign({ videoBitsPerSecond: exportQuality.bitrate, audioBitsPerSecond: 192000 }, mime ? { mimeType: mime } : {}));
      const chunks = [];
      recorder.ondataavailable = (event) => { if (event.data && event.data.size) chunks.push(event.data); };
      const stopped = new Promise((resolve) => { recorder.onstop = () => resolve(new Blob(chunks, { type: mime || 'video/webm' })); });
      recorder.start(1000);
      const total = Math.max(12, Number(state.videoDuration) || 30);
      const precise = state.videoComposition === 'precise';
      const segmentSeconds = precise ? 4.0 : 2.4;
      const plan = buildLocalClipPlan(total, segmentSeconds);
      if (!plan.length) throw new Error('没有可用的原片片段');
      const overallStart = performance.now();
      let elapsedTotal = 0;
      let segmentIndex = 0;
      const captions = state.clipAudioMode === 'original-cn'
        ? splitSubtitleLines(chineseSubtitleText || defaultNarrationText)
        : state.clipAudioMode === 'original-subs'
          ? splitSubtitleLines(originalSubtitleText)
          : state.originalSubtitleText && state.originalSubtitleText.trim()
            ? splitSubtitleLines(state.originalSubtitleText)
            : hookCaptions && hookCaptions.length
            ? hookCaptions
            : splitSubtitleLines(narrationText);
      while (segmentIndex < plan.length && elapsedTotal < total) {
        const segment = plan[segmentIndex];
        const clip = segment.clip;
        const video = document.createElement('video');
        video.src = clip.url;
        video.muted = !preserveOriginalAudio;
        video.playsInline = true;
        video.preload = 'auto';
        await new Promise((resolve, reject) => {
          video.onloadedmetadata = resolve;
          video.onerror = reject;
        });
        const maxStart = Math.max(0, (video.duration || clip.duration || 1) - segmentSeconds - .2);
        const wanted = Math.min(maxStart, segment.start);
        if (Number.isFinite(wanted) && wanted > 0) {
          await new Promise((resolve) => {
            video.onseeked = resolve;
            video.currentTime = wanted;
            setTimeout(resolve, 900);
          });
        }
        let originalAudioNode = null;
        if (preserveOriginalAudio) {
          try {
            originalAudioNode = audioContext.createMediaElementSource(video);
            const gain = audioContext.createGain();
            gain.gain.value = .9;
            originalAudioNode.connect(gain);
            gain.connect(destination);
          } catch (error) {
            originalAudioNode = null;
          }
        }
        try { await video.play(); } catch (error) {}
        const segmentStart = performance.now();
        const segmentTarget = Math.min(segment.seconds, total - elapsedTotal);
        await new Promise((resolve) => {
          function frame(now) {
            const local = (now - segmentStart) / 1000;
            elapsedTotal = Math.min(total, (now - overallStart) / 1000);
            const caption = captions[Math.min(captions.length - 1, Math.floor(elapsedTotal / total * captions.length))] || title;
            drawLocalClipFrame(canvas.getContext('2d'), video, caption, title, elapsedTotal / total,
              segmentIndex, !cleanOutput && state.clipAudioMode === 'person',
              presenterPhoto, elapsedTotal, showSubtitles);
            setProgress(elapsedTotal, total);
            if (local < segmentTarget && elapsedTotal < total) requestAnimationFrame(frame);
            else resolve();
          }
          requestAnimationFrame(frame);
        });
        video.pause();
        if (originalAudioNode) {
          try { originalAudioNode.disconnect(); } catch (error) {}
        }
        video.removeAttribute('src');
        video.load();
        segmentIndex++;
      }
      if (recorder.state !== 'inactive') recorder.stop();
      activeSources.forEach((source) => { try { source.stop(); } catch (error) {} });
      const blob = await stopped;
      if (state.videoUrl) URL.revokeObjectURL(state.videoUrl);
      state.videoBlob = blob;
      state.videoUrl = URL.createObjectURL(blob);
      $('#videoResult').src = state.videoUrl;
      $('#videoResult').hidden = false;
      $('#downloadVideoBtn').hidden = false;
      canvas.hidden = true;
      $('#downloadVideoBtn').disabled = false;
      let finishedRecord = null;
      try {
        finishedRecord = await persistFinishedVideo(blob, title);
      } catch (storageError) {
        console.warn('Finished video was not persisted', storageError);
      }
      finishGeneration(taskId, 'video', {
        title: state.videoEpisodeTitle || $('#clipPrompt').value.trim() || '原片剪辑成品',
        videoBlob: state.videoBlob,
        videoUrl: state.videoUrl,
        duration: state.videoDuration,
        cover: '',
        libraryId: finishedRecord && finishedRecord.id || ''
      });
      showVideoTextEditor();
      $('#videoState').textContent = '授权素材快剪已完成';
      showToast('自动快剪已完成', '可以预览、下载，或导入剪映继续精修。');
    } catch (error) {
      console.error(error);
      showToast('自动快剪失败', error.message, 'error');
      $('#videoState').textContent = '剪辑失败';
    } finally {
      failGeneration(taskId, '视频生成未完成，可重新发起');
      activeSources.forEach((source) => { try { source.stop(); } catch (error) {} });
      state.recording = false;
      releaseVideoWakeLock();
      $('#generateClipMontageBtn').disabled = false;
      $('#generateVideoBtn').disabled = false;
      hideLoading();
      renderCreationSaveBar();
    }
  }

  function downloadVideo() {
    if (!state.videoBlob) {
      showToast('还没有成片', '请先导入授权原片并完成智能剪辑。', 'info');
      return;
    }
    const extension = state.videoBlob.type.includes('mp4') ? 'mp4' : 'webm';
    const link = document.createElement('a');
    link.href = state.videoUrl;
    link.download = '热点工坊_人物口播_' + new Date().toISOString().slice(0, 10) + '.' + extension;
    document.body.appendChild(link);
    link.click();
    link.remove();
    showToast('已开始下载', '请在今日头条视频后台上传成片。');
  }

  async function previewVideo() {
    if (state.videoBlob) {
      const video = $('#videoResult');
      if (video.paused) video.play(); else video.pause();
      return;
    }
    const items = selectedItems();
    if (!items.length) return;
    if (state.previewTimer) {
      cancelAnimationFrame(state.previewTimer);
      state.previewTimer = null;
      return;
    }
    $('#emptyVideo').hidden = true;
    const start = performance.now();
    const total = 2.8 + items.length * 3.2 + 2.5;
    function loop(now) {
      const elapsed = ((now - start) / 1000) % total;
      const stage = Math.max(-1, Math.min(items.length, Math.floor((elapsed - 2.5) / 3.2)));
      drawVideoVisual(items, stage, elapsed, state.ratio, state.presenter === 'female', elapsed / total);
      setProgress(elapsed, total);
      state.previewTimer = requestAnimationFrame(loop);
    }
    state.previewTimer = requestAnimationFrame(loop);
  }

  function drawAvatarPreview() {
    const canvas = $('#avatarPreview');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const gradient = ctx.createLinearGradient(0, 0, 220, 260);
    gradient.addColorStop(0, '#dfe8ff');
    gradient.addColorStop(1, '#f7ded2');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 220, 260);
    drawPresenter(ctx, 110, 125, .46, 0.3, .55, true);
  }

  function currentWritingMode() {
    if ($('#view-article').classList.contains('active')) return 'article';
    if ($('#view-novel').classList.contains('active')) return 'novel';
    if ($('#view-inspiration').classList.contains('active')) return 'inspiration';
    if ($('#view-ai').classList.contains('active')) return 'ai';
    return 'article';
  }

  function currentWritingPrompt(mode) {
    if (mode === 'novel') {
      return [
        $('#novelInspiration').value.trim(),
        $('#novelQuickPrompt').value.trim(),
        state.novel && state.novel.title ? '已有小说：' + state.novel.title : ''
      ].filter(Boolean).join('\n\n');
    }
    if (mode === 'inspiration') {
      return [ $('#inspirationTitle').value.trim(), $('#inspirationPrompt').value.trim()]
        .filter(Boolean).join('\n\n');
    }
    if (mode === 'ai') return $('#aiInstructions').value.trim();
    return state.article
      ? state.article.title + '\n\n' + stripHtml(state.article.html || '')
      : $('#articleQuickPrompt').value.trim();
  }

  async function openWorkbuddyBridge(launchImmediately, customPrompt, importMode, sourceArtifact) {
    const mode = sourceArtifact
      ? (sourceArtifact.type === 'novel' ? 'novel' : 'article')
      : currentWritingMode();
    const labels = { article: '图文文章', novel: '原创小说', inspiration: '主题创作', ai: 'AI 写作' };
    const prompt = customPrompt || currentWritingPrompt(mode) || '请根据当前创作页面继续写作。';
    showModal('Workbuddy 创作衔接', 'WORKBUDDY BRIDGE',
      '<div class="workbuddy-bridge">' +
        '<div class="post-browse-source"><strong>当前页面：' + labels[mode] + '</strong><small>点击顶部按钮即可复制提示词并直接打开 Workbuddy 客户端或 Edge</small></div>' +
        '<label>创作提示词<textarea id="workbuddyPrompt">' + escapeHtml(prompt) + '</textarea></label>' +
        '<div class="article-source-tools"><button type="button" id="openWorkbuddyApp">复制提示词并打开 Workbuddy</button>' +
        '<button type="button" id="importWorkbuddyClipboard">从剪贴板导回</button></div>' +
        '<label>或直接粘贴 Workbuddy 结果<textarea id="workbuddyManualResult" placeholder="把 Workbuddy 生成的文章或小说粘贴到这里"></textarea></label>' +
        '<div class="workbuddy-launch-status" id="workbuddyLaunchStatus">准备打开 Workbuddy，提示词会自动复制。</div>' +
        '<p class="import-hint">Workbuddy 本身生成的内容仍需要你确认事实、原创性和图片授权。</p>' +
      '</div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>' +
      '<button class="btn btn-primary" type="button" id="importWorkbuddyManual">导入结果</button>');
    $('#openWorkbuddyApp').addEventListener('click', async () => {
      const text = $('#workbuddyPrompt').value.trim();
      try { await navigator.clipboard.writeText(text); } catch (error) {}
      try {
        $('#workbuddyLaunchStatus').textContent = '正在检测并打开 Workbuddy 客户端…';
        const result = await api('/api/open-platform', {
          method: 'POST',
          body: JSON.stringify({ platform: 'workbuddy', url: WORKBUDDY_URL })
        });
        const desktop = !['web', 'web-fallback', 'default-browser'].includes(result.method);
        $('#workbuddyLaunchStatus').textContent = desktop
          ? 'Workbuddy 客户端已打开，提示词已复制，可直接粘贴生成。'
          : '已在 Edge 打开 Workbuddy 网页，提示词已复制，可直接粘贴生成。';
        showToast(desktop ? 'Workbuddy 客户端已打开' : 'Workbuddy 已在 Edge 打开',
          '提示词已复制。生成完成后点击“从剪贴板导回”。', 'success');
      } catch (error) {
        $('#workbuddyLaunchStatus').textContent = '客户端未能打开，正在改用系统浏览器。';
        try {
          await api('/api/open', {
            method: 'POST',
            body: JSON.stringify({ url: WORKBUDDY_URL, browserId: 'edge' })
          });
          showToast('已在 Edge 打开 Workbuddy', '提示词已复制，可直接粘贴生成。', 'info');
        } catch (fallbackError) {
          showToast('打开 Workbuddy 失败', fallbackError.message, 'error');
        }
      }
    });
    const importResult = (text) => {
      const clean = String(text || '').trim();
      if (clean.length < 20) {
        showToast('没有可导入的内容', '请先在 Workbuddy 生成内容并复制。', 'info');
        return;
      }
      if (sourceArtifact && importMode === 'finished-revision') {
        closeModal();
        const type = sourceArtifact.type === 'novel' ? 'novel' : 'article';
        const taskId = beginGeneration(type, 'Workbuddy 修改 · ' + (sourceArtifact.title || '成品'),
          '正在把 Workbuddy 修改结果保存为新版本');
        try {
          if (type === 'article') {
            const parsed = aiTextToHtml(clean);
            const titleMatch = clean.match(/^标题[：:]\s*(.+)$/m);
            const title = truncate(parsed.title || (titleMatch && titleMatch[1].trim()) ||
              sourceArtifact.payload.title || 'Workbuddy 修改版', 30);
            const originalHtml = sourceArtifact.payload.html || '';
            const merged = preserveArticleFigures(originalHtml, parsed.html);
            state.article = Object.assign({}, JSON.parse(JSON.stringify(sourceArtifact.payload)), {
              id: 'article_workbuddy_revision_' + Date.now(),
              title,
              html: merged,
              sourceWorkId: sourceArtifact.id,
              revisionInstruction: $('#workbuddyPrefixInstruction') ? $('#workbuddyPrefixInstruction').value.trim() : '',
              status: 'editing',
              updatedAt: new Date().toISOString()
            });
            state.article.html = applyArticleTemplateHtml(
              state.article.html, state.article.template || state.articleTemplate);
            saveJson(KEYS.article, state.article);
            renderArticle();
            showView('article');
            finishGeneration(taskId, 'article', state.article);
          } else {
            const parsed = parseNovelAiOutput(clean, sourceArtifact.payload.title || 'Workbuddy 修改版');
            state.novel = Object.assign({}, JSON.parse(JSON.stringify(sourceArtifact.payload)), {
              id: 'novel_workbuddy_revision_' + Date.now(),
              title: parsed.title || sourceArtifact.payload.title || 'Workbuddy 修改版',
              html: novelTextToHtml(parsed.body || clean),
              storyBible: parsed.storyBible || sourceArtifact.payload.storyBible || {},
              sourceWorkId: sourceArtifact.id,
              updatedAt: new Date().toISOString()
            });
            saveJson(KEYS.novel, state.novel);
            renderNovel();
            showView('novel');
            finishGeneration(taskId, 'novel', state.novel);
          }
        } catch (error) {
          failGeneration(taskId, error.message);
          showToast('Workbuddy 修改结果导入失败', error.message, 'error');
        }
        return;
      }
      closeModal();
      if (mode === 'article') {
        const taskId = beginGeneration('article', state.article && state.article.title || 'Workbuddy 图文', '正在导入 Workbuddy 成品');
        const parsed = aiTextToHtml(clean);
        if (state.article) {
          state.article.html += '<hr>' + applyArticleTemplateHtml(parsed.html, state.articleTemplate);
          state.article.updatedAt = new Date().toISOString();
        } else {
          state.article = {
            id: 'article_workbuddy_' + Date.now(), title: parsed.title || 'Workbuddy 原创图文',
            html: applyArticleTemplateHtml(parsed.html, state.articleTemplate), cover: '', sourceIds: [],
            tags: ['Workbuddy'], articleMode: 'feature', articleScope: 'single', status: 'editing',
            createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
          };
        }
        saveJson(KEYS.article, state.article);
        renderArticle();
        showView('article');
        finishGeneration(taskId, 'article', state.article);
        return;
      }
      if (mode === 'novel') {
        const taskId = beginGeneration('novel', state.novel && state.novel.title || 'Workbuddy 原创小说', '正在导入 Workbuddy 成品');
        const parsed = parseNovelAiOutput(clean, 'Workbuddy 原创小说');
        state.novel = state.novel || {
          id: 'novel_workbuddy_' + Date.now(), lengthType: state.novelLength,
          genre: $('#novelGenre') ? $('#novelGenre').value : '现实题材',
          narrativeStyle: state.novelNarrativeStyle, createdAt: new Date().toISOString()
        };
        state.novel.title = parsed.title || state.novel.title || 'Workbuddy 原创小说';
        state.novel.html = (state.novel.html ? state.novel.html + '<hr>' : '') + novelTextToHtml(parsed.body || clean);
        state.novel.storyBible = parsed.storyBible || state.novel.storyBible || {};
        state.novel.updatedAt = new Date().toISOString();
        saveJson(KEYS.novel, state.novel);
        renderNovel();
        showView('novel');
        finishGeneration(taskId, 'novel', state.novel);
        return;
      }
      if (mode === 'inspiration') {
        $('#inspirationPrompt').value = clean;
        showToast('Workbuddy 内容已导入主题创作');
      } else {
        $('#aiInstructions').value = clean;
        showToast('Workbuddy 内容已导入 AI 写作');
      }
    };
    $('#importWorkbuddyClipboard').addEventListener('click', async () => {
      try {
        importResult(await navigator.clipboard.readText());
      } catch (error) {
        showToast('无法读取剪贴板', '请把结果粘贴到下方文本框后导入。', 'info');
      }
    });
    $('#importWorkbuddyManual').addEventListener('click', () =>
      importResult($('#workbuddyManualResult').value));
    if (launchImmediately) setTimeout(() => $('#openWorkbuddyApp').click(), 120);
  }

  function openSettings() {
    $('#settingsBackdrop').hidden = false;
    $('#settingsDrawer').hidden = false;
    renderSettings();
  }

  function closeSettings() {
    $('#settingsBackdrop').hidden = true;
    $('#settingsDrawer').hidden = true;
  }

  const AI_PROVIDERS = {
    deepseek: { baseUrl: 'https://api.deepseek.com/v1', model: 'deepseek-chat' },
    qwen: { baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1', model: 'qwen-plus' },
    moonshot: { baseUrl: 'https://api.moonshot.cn/v1', model: 'moonshot-v1-8k' },
    openai: { baseUrl: 'https://api.openai.com/v1', model: 'gpt-4.1-mini' },
    workbuddy: { baseUrl: 'https://api.workbuddy.ai/v1', model: 'workbuddy' },
    custom: { baseUrl: '', model: '' }
  };
  const IMAGE_AI_PROVIDERS = {
    openai: { baseUrl: 'https://api.openai.com/v1', model: 'gpt-image-1' },
    siliconflow: { baseUrl: 'https://api.siliconflow.cn/v1', model: 'Kwai-Kolors/Kolors' },
    custom: { baseUrl: '', model: '' }
  };

  function detectProvider(baseUrl) {
    const value = String(baseUrl || '').toLowerCase();
    if (value.includes('deepseek')) return 'deepseek';
    if (value.includes('dashscope') || value.includes('aliyun')) return 'qwen';
    if (value.includes('moonshot') || value.includes('kimi')) return 'moonshot';
    if (value.includes('openai.com')) return 'openai';
    if (value.includes('workbuddy')) return 'workbuddy';
    return 'custom';
  }

  function applyAiProvider(provider) {
    const preset = AI_PROVIDERS[provider];
    if (!preset || provider === 'custom') return;
    $('#aiBaseUrl').value = preset.baseUrl;
    $('#aiModel').value = preset.model;
  }

  function applyImageAiProvider(provider) {
    const preset = IMAGE_AI_PROVIDERS[provider];
    if (!preset || provider === 'custom') return;
    $('#imageAiBaseUrl').value = preset.baseUrl;
    $('#imageAiModel').value = preset.model;
  }

  function renderSettings() {
    $('#refreshMinutes').value = state.config.refreshMinutes || 20;
    $('#maxItems').value = state.config.maxItemsPerSection || 20;
    $('#sectionSwitches').innerHTML = state.config.sections.map((section) =>
      '<label><input type="checkbox" data-setting-section="' + escapeHtml(section.id) + '"' + (section.enabled ? ' checked' : '') + '>' + escapeHtml(section.name) + '</label>'
    ).join('');
    $('#aiEnabled').checked = Boolean(state.config.ai.enabled);
    $('#aiBaseUrl').value = state.config.ai.baseUrl || '';
    $('#aiModel').value = state.config.ai.model || '';
    $('#aiProvider').value = detectProvider(state.config.ai.baseUrl);
    $('#aiKey').value = '';
    $('#aiKey').placeholder = state.config.ai.hasKey ? '已保存，留空保持不变' : '输入 API Key';
    const aiState = $('#aiConfigState');
    aiState.textContent = state.config.ai.enabled && state.config.ai.hasKey ? '已启用' :
      state.config.ai.hasKey ? 'Key 已保存' : '未配置';
    aiState.classList.toggle('ready', Boolean(state.config.ai.enabled && state.config.ai.hasKey));
    aiState.classList.remove('error');
    $('#aiTestResult').textContent = state.config.ai.hasKey ? 'Key 已保存在本机，可测试连接' : 'Key 仅保存在本机';
    $('#imageAiEnabled').checked = Boolean(state.config.imageAi && state.config.imageAi.enabled);
    $('#imageAiProvider').value = state.config.imageAi && String(state.config.imageAi.baseUrl).includes('siliconflow') ? 'siliconflow' :
      (state.config.imageAi && String(state.config.imageAi.baseUrl).includes('openai.com') ? 'openai' : 'custom');
    $('#imageAiBaseUrl').value = state.config.imageAi && state.config.imageAi.baseUrl || '';
    $('#imageAiModel').value = state.config.imageAi && state.config.imageAi.model || '';
    $('#imageAiKey').value = '';
    $('#imageAiKey').placeholder = state.config.imageAi && state.config.imageAi.hasKey ? '已保存，留空保持不变' : '输入图像 API Key';
    const imageModelReady = Boolean(state.config.imageAi && state.config.imageAi.enabled && state.config.imageAi.hasKey);
    const textAiReady = Boolean(state.config.ai && state.config.ai.enabled && state.config.ai.hasKey);
    $('#imageAiState').textContent = imageModelReady ? '专业图像模型已启用' :
      textAiReady ? '文字 AI 插画可用' : '未配置';
    $('#imageAiState').classList.toggle('ready', imageModelReady || textAiReady);
    if (state.health && state.health.dataDirectory) $('#dataPath').textContent = state.health.dataDirectory;
    if (state.apps) renderAppOptions();
    else loadApps();
  }

  function collectSettings() {
    state.config.refreshMinutes = Math.max(5, Math.min(240, Number($('#refreshMinutes').value) || 20));
    state.config.maxItemsPerSection = Math.max(4, Math.min(30, Number($('#maxItems').value) || 20));
    $$('[data-setting-section]').forEach((input) => {
      const section = state.config.sections.find((item) => item.id === input.dataset.settingSection);
      if (section) section.enabled = input.checked;
    });
    state.config.ai.enabled = $('#aiEnabled').checked;
    state.config.ai.baseUrl = $('#aiBaseUrl').value.trim();
    state.config.ai.model = $('#aiModel').value.trim();
    state.config.ai.apiKey = $('#aiKey').value.trim();
    state.config.imageAi.enabled = $('#imageAiEnabled').checked;
    state.config.imageAi.baseUrl = $('#imageAiBaseUrl').value.trim();
    state.config.imageAi.model = $('#imageAiModel').value.trim();
    state.config.imageAi.apiKey = $('#imageAiKey').value.trim();
    state.config.preferredBrowserId = $('#preferredBrowser') ? $('#preferredBrowser').value : state.config.preferredBrowserId;
    state.config.preferredVideoPlayerId = $('#preferredVideoPlayer') ? $('#preferredVideoPlayer').value : state.config.preferredVideoPlayerId;
    return JSON.parse(JSON.stringify(state.config));
  }

  async function persistCurrentSettings(showResult, closeAfter) {
    const payload = collectSettings();
    try {
      const result = await api('/api/config', { method: 'POST', body: JSON.stringify(payload) });
      state.config = Object.assign({}, state.config, result.config);
      if (closeAfter) closeSettings();
      renderAll();
      if (showResult) showToast('设置已保存');
      return true;
    } catch (error) {
      if (showResult) showToast('保存失败', error.message, 'error');
      return false;
    }
  }

  async function saveSettings() {
    if ($('#aiEnabled').checked && !$('#aiKey').value.trim() && !state.config.ai.hasKey) {
      showToast('AI 已启用但还没有 Key', '请填写 API Key 后点击“测试连接”。', 'info');
      $('#aiKey').focus();
      return;
    }
    if ($('#imageAiEnabled').checked && !$('#imageAiKey').value.trim() && !state.config.imageAi.hasKey) {
      showToast('写实图片 AI 尚未填写 Key', '请填写图像 API Key，或关闭“启用写实配图”。', 'info');
      $('#imageAiKey').focus();
      return;
    }
    await persistCurrentSettings(true, true);
  }

  async function testAiConnection() {
    const button = $('#testAiBtn');
    const stateBadge = $('#aiConfigState');
    const resultLabel = $('#aiTestResult');
    const key = $('#aiKey').value.trim();
    if (!key && !state.config.ai.hasKey) {
      showToast('请先填写 API Key', 'Key 只会保存在你电脑本机。', 'info');
      $('#aiKey').focus();
      return;
    }
    button.disabled = true;
    stateBadge.textContent = '测试中';
    stateBadge.classList.remove('ready', 'error');
    resultLabel.textContent = '正在连接模型服务…';
    const previousEnabled = state.config.ai.enabled;
    $('#aiEnabled').checked = true;
    const saved = await persistCurrentSettings(false, false);
    if (!saved) {
      button.disabled = false;
      stateBadge.textContent = '保存失败';
      stateBadge.classList.add('error');
      resultLabel.textContent = '请检查设置后重试';
      return;
    }
    try {
      const response = await api('/api/ai', {
        method: 'POST',
        body: JSON.stringify({
          system: '你是连接测试助手。',
          prompt: '只回复四个字：连接成功',
          temperature: 0
        })
      });
      if (!response.ok || !response.text) throw new Error(response.error || '接口没有返回内容');
      stateBadge.textContent = '连接成功';
      stateBadge.classList.add('ready');
      resultLabel.textContent = '已连接 ' + ($('#aiModel').value.trim() || 'AI 模型');
      showToast('AI 连接成功', '以后生成图文时会自动进行单事件深度写作。');
    } catch (error) {
      state.config.ai.enabled = previousEnabled;
      await api('/api/config', { method: 'POST', body: JSON.stringify(state.config) }).catch(() => null);
      stateBadge.textContent = '连接失败';
      stateBadge.classList.add('error');
      resultLabel.textContent = '请检查 Key、模型名称或网络';
      showToast('AI 连接失败', error.message, 'error');
    } finally {
      button.disabled = false;
    }
  }

  async function addFeed() {
    const name = $('#feedName').value.trim();
    const url = $('#feedUrl').value.trim();
    if (!name || !/^https?:\/\//i.test(url)) {
      showToast('请填写名称和完整 RSS 地址', null, 'info');
      return;
    }
    state.config.customFeeds.push({ name, url, section: 'general', enabled: true });
    await persistCurrentSettings(false, false);
    $('#feedName').value = '';
    $('#feedUrl').value = '';
    showToast('RSS 已添加', '下次刷新时会读取该数据源。');
  }

  function bindEvents() {
    const sectionRail = $('#sectionRailList');
    let draggedRailItem = null;
    let railDragMoved = false;
    let railDropAt = 0;
    const saveRailOrder = () => {
      const ids = $$('.section-rail-item', sectionRail)
        .map((item) => item.dataset.railId)
        .filter(Boolean);
      if (!ids.length) return;
      state.railOrder = ids;
      saveJson(KEYS.railOrder, ids);
      railDropAt = Date.now();
      renderSectionRail();
      showToast('板块顺序已保存', '以后打开小程序会保持这个顺序。');
    };
    sectionRail.addEventListener('dragstart', (event) => {
      const item = event.target.closest('.section-rail-item');
      if (!item) return;
      draggedRailItem = item;
      railDragMoved = false;
      item.classList.add('dragging');
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', item.dataset.railId || '');
    });
    sectionRail.addEventListener('dragover', (event) => {
      if (!draggedRailItem) return;
      const target = event.target.closest('.section-rail-item');
      if (!target || target === draggedRailItem) return;
      event.preventDefault();
      const rect = target.getBoundingClientRect();
      const insertAfter = event.clientY > rect.top + rect.height / 2;
      if (insertAfter) target.after(draggedRailItem);
      else target.before(draggedRailItem);
      railDragMoved = true;
    });
    sectionRail.addEventListener('drop', (event) => {
      if (!draggedRailItem) return;
      event.preventDefault();
      if (railDragMoved) saveRailOrder();
    });
    sectionRail.addEventListener('dragend', () => {
      if (draggedRailItem) draggedRailItem.classList.remove('dragging');
      if (railDragMoved && Date.now() - railDropAt > 300) saveRailOrder();
      railDropAt = Date.now();
      draggedRailItem = null;
      railDragMoved = false;
    });
    sectionRail.addEventListener('click', (event) => {
      if (Date.now() - railDropAt < 300) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }, true);

    document.addEventListener('click', async (event) => {
      const viewButton = event.target.closest('[data-view]');
      if (viewButton) {
        if (viewButton.dataset.view === 'novel') seedNovelPromptFromLatest();
        showView(viewButton.dataset.view);
      }
      const platformButton = event.target.closest('[data-open-platform]');
      if (platformButton) {
        const url = platformButton.dataset.openPlatform;
        try {
          if (url.includes('music.163.com')) {
            await openNeteaseWatch();
          } else {
            await api('/api/open', {
              method: 'POST',
              body: JSON.stringify({ url, browserId: state.config.preferredBrowserId || 'edge' })
            });
            showToast('平台已打开', url.includes('weibo.com') ? '微博热搜会通过 Edge 采集器自动读取。' :
              url.includes('163.com') ? '网易新闻页面会通过 Edge 采集器自动读取。' : '腾讯新闻页面会通过 Edge 采集器自动读取。', 'info');
          }
        } catch (error) {
          showToast('打开平台失败', error.message, 'error');
        }
      }
      const programButton = event.target.closest('[data-open-program]');
      if (programButton) openProgram(programButton.dataset.openProgram);
      const section = event.target.closest('[data-section]');
      if (section) {
        const sourceUrl = section.dataset.platformSource || '';
        const fromVideoView = $('#view-video').classList.contains('active');
        selectSection(section.dataset.section, sourceUrl);
        if (sourceUrl) {
          if (fromVideoView || section.dataset.section === 'tencent') {
            state.pendingVideoSource = section.textContent.trim();
            state.pendingVideoSourceAt = Date.now();
            scheduleVideoReturnFlow(section.dataset.section);
            launchBrowseSource(section.dataset.section, section.textContent.trim(), 'video', 'video');
          } else {
            scheduleWritingReturnFlow('article', section.textContent.trim(), section.dataset.section);
            launchBrowseSource(section.dataset.section, section.textContent.trim(), 'writing', 'article');
          }
        }
      }
      const selectOnly = event.target.closest('[data-select-only]');
      if (selectOnly) {
        event.stopPropagation();
        toggleSelection(selectOnly.dataset.selectOnly);
      } else {
        const quickVideo = event.target.closest('[data-quick-video]');
        const discuss = event.target.closest('[data-open-topic]');
        if (quickVideo) {
          event.stopPropagation();
          generateVideoFromTopic(quickVideo.dataset.quickVideo);
        } else if (discuss) {
          event.stopPropagation();
          openTopic(discuss.dataset.openTopic);
        } else {
          const news = event.target.closest('[data-news-id]');
          if (news) openTopic(news.dataset.newsId);
        }
      }
      const hot = event.target.closest('[data-hot-id]');
      if (hot) {
        const item = state.news.find((entry) => entry.id === hot.dataset.hotId);
        if (item) openTopic(item.id);
      }
      const workTab = event.target.closest('[data-work-filter]');
      if (workTab) {
        state.workFilter = workTab.dataset.workFilter;
        renderDrafts();
      }
      const workbuddyFinished = event.target.closest('[data-workbuddy-finished]');
      if (workbuddyFinished) {
        event.stopPropagation();
        const source = workbuddyFinished.dataset.workbuddySource;
        const list = source === 'completed' ? state.completed : state.drafts;
        const item = list.find((entry) => entry.id === workbuddyFinished.dataset.workbuddyFinished);
        if (item) openWorkbuddyFinishedDialog(item);
        return;
      }
      const deleteGeneration = event.target.closest('[data-delete-generation]');
      if (deleteGeneration) {
        event.stopPropagation();
        deleteGenerationTask(deleteGeneration.dataset.deleteGeneration);
      }
      const deleteWork = event.target.closest('[data-delete-work]');
      if (deleteWork) {
        event.stopPropagation();
        deleteWorkItem(deleteWork.dataset.workSource, deleteWork.dataset.deleteWork);
      } else {
        const workItem = event.target.closest('[data-work-id]');
        if (workItem) openWorkItem(workItem.dataset.workSource, workItem.dataset.workId);
      }
      const del = event.target.closest('[data-delete-draft]');
      if (del) {
        event.stopPropagation();
        state.drafts = state.drafts.filter((item) => item.id !== del.dataset.deleteDraft);
        saveJson(KEYS.drafts, state.drafts);
        renderDrafts();
        showToast('草稿已删除');
      }
      const draft = event.target.closest('[data-draft-id]');
      if (draft && !event.target.closest('[data-delete-draft]')) openDraft(draft.dataset.draftId);
      if (event.target.closest('[data-refresh]')) fetchNews(true);
      if (event.target.closest('[data-modal-close]') || event.target.id === 'modalBackdrop') closeModal();
      if (event.target.closest('[data-cmd]')) {
        const button = event.target.closest('[data-cmd]');
        document.execCommand(button.dataset.cmd, false, button.dataset.value || null);
        $('#articleBody').focus();
        persistArticle();
      }
      if (event.target.id === 'changeCoverBtn') {
        const withImages = state.news.filter((item) => item.image);
        if (withImages.length) {
          const current = withImages.findIndex((item) => item.image === state.article.cover);
          state.article.cover = withImages[(current + 1) % withImages.length].image;
          saveJson(KEYS.article, state.article);
          renderArticle();
        }
      }
    });

    $('#refreshBtn').addEventListener('click', () => fetchNews(true));
    $('#inlineRefreshBtn').addEventListener('click', () => fetchNews(true));
    $('#sectionRefreshBtn').addEventListener('click', () => fetchNews(true));
    $('#openWorkCenterBtn').addEventListener('click', openWorkCenter);
    $('#loadingTaskCenterBtn').addEventListener('click', openWorkCenter);
    $('#workSort').addEventListener('change', (event) => {
      state.workSort = event.target.value;
      renderDrafts();
    });
    $('#creationSaveDraft').addEventListener('click', () => saveCurrentCreative('draft'));
    $('#creationSaveCompleted').addEventListener('click', () => saveCurrentCreative('completed'));
    $('#sectionOpenClientBtn').addEventListener('click', (event) => {
      event.preventDefault();
      state.pendingVideoSource = $('#sectionOpenClientBtn').textContent.trim() || '腾讯视频';
      state.pendingVideoSourceAt = Date.now();
      scheduleVideoReturnFlow('qqlive');
      launchBrowseSource('qqlive', state.pendingVideoSource, 'video', 'video');
    });
    $('#sectionOpenSourceBtn').addEventListener('click', async () => {
      await openPlatformContent(state.activeSection);
    });
    $('#settingsBtn').addEventListener('click', openSettings);
    $('#manageSectionsBtn').addEventListener('click', openSettings);
    $('#railImportBtn').addEventListener('click', () => openImportHot());
    $('#edgeAutoSetupBtn').addEventListener('click', async () => {
      if (state.edgeExtensionVersion && state.edgeExtensionVersion !== '1.9.6') {
        try {
          await api('/api/open-edge-extensions', { method: 'POST', body: '{}' });
          showToast('扩展管理页已打开', '找到“热点工坊 Edge 采集器”，点击“重新加载”，版本应变为 1.9.6。', 'info');
        } catch (error) {
          openEdgeCaptureSetup();
        }
      } else {
        openEdgeCaptureSetup();
      }
    });
    $('#materialLibraryBtn').addEventListener('click', openMaterialLibrary);
    $('#aiConfigureBtn').addEventListener('click', openSettings);
    $('#aiQuickSettings').addEventListener('click', openSettings);
    $('#codexWriteBtn').addEventListener('click', runCodexOneShot);
    $('#articleStylePreset').addEventListener('change', (event) => {
      state.articleStyle = event.target.value;
    });
    $('#articleContentMode').addEventListener('change', (event) => {
      state.articleContentMode = ARTICLE_CONTENT_MODES[event.target.value] ? event.target.value : 'fact';
      showToast('内容模式已切换', ARTICLE_CONTENT_MODE_LABELS[state.articleContentMode]);
    });
    $('#articleAngleGrid').addEventListener('click', (event) => {
      const button = event.target.closest('[data-article-angle]');
      if (!button) return;
      const mode = button.dataset.articleAngle;
      const selected = new Set(state.articleAngleModes);
      if (selected.has(mode)) selected.delete(mode);
      else if (selected.size < 4) selected.add(mode);
      else {
        showToast('最多选择 4 个模板', '先取消一个已选模板，再选择新的阐述角度。', 'info');
        return;
      }
      state.articleAngleModes = Array.from(selected);
      renderArticleAnglePicker();
    });
    $('#generateAngleVariantsBtn').addEventListener('click', runArticleAngleVariants);
    $('#articleLayoutPreset').addEventListener('change', (event) => {
      selectArticleTemplate(event.target.value);
      showToast('图文版式已切换');
    });
    $('#articleTemplateStrip').addEventListener('click', (event) => {
      const button = event.target.closest('[data-article-template-preset]');
      if (!button) return;
      selectArticleTemplate(button.dataset.articleTemplatePreset);
      showToast('已切换为' + ARTICLE_TEMPLATE_LABELS[state.articleTemplate] + '模板');
    });
    $('#articleQuickWriteBtn').addEventListener('click', () =>
      runArticleQuickWrite(state.articleMode || 'feature'));
    $('#articleSources').addEventListener('change', (event) => {
      const checkbox = event.target.closest('[data-article-source-select]');
      if (!checkbox) return;
      const id = checkbox.dataset.articleSourceSelect;
      const selected = new Set(state.articleSourceSelected);
      if (checkbox.checked) selected.add(id);
      else selected.delete(id);
      state.articleSourceSelected = Array.from(selected);
    });
    $('#articleSources').addEventListener('click', (event) => {
      const button = event.target.closest('[data-open-source-software]');
      if (button) {
        event.preventDefault();
        openSourceInSoftware(button.dataset.openSourceSoftware);
      }
    });
    $('#openArticleByTitleBtn').addEventListener('click', async () => {
      const title = $('#articleDirectTitleInput').value.trim();
      if (!title) {
        showToast('请输入文章或事件名称', '填写后会打开对应软件搜索。', 'info');
        $('#articleDirectTitleInput').focus();
        return;
      }
      await searchWritingTitle('article', $('#articleDirectPlatform').value, title);
    });
    $('#articleDirectTitleInput').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        $('#openArticleByTitleBtn').click();
      }
    });
    $('#selectAllArticleSourcesBtn').addEventListener('click', () => {
      const ids = articleSourceItems().map((item) => item.id);
      const allSelected = ids.length && ids.every((id) => state.articleSourceSelected.includes(id));
      state.articleSourceSelected = allSelected ? [] : ids;
      renderArticleSources();
    });
    $('#deleteSelectedArticleSourcesBtn').addEventListener('click', () => {
      if (!state.articleSourceSelected.length) {
        showToast('没有选择来源', '请先勾选要移除的图文来源。', 'info');
        return;
      }
      const removeIds = new Set(state.articleSourceSelected);
      if (state.article) {
        state.article.sourceIds = (state.article.sourceIds || []).filter((id) => !removeIds.has(id));
        state.article.sources = (state.article.sources || []).filter((id) => !removeIds.has(id));
        saveJson(KEYS.article, state.article);
      }
      state.selected = state.selected.filter((id) => !removeIds.has(id));
      saveJson(KEYS.selected, state.selected);
      state.articleSourceSelected = [];
      renderArticleSources();
      showToast('所选来源已移除', '只会从当前图文素材中移除，不会删除热点原文。');
    });
    $('#articleChooseSourceBtn').addEventListener('click', () => openWritingSourcePicker('article'));
    $('#articleReadSourceBtn').addEventListener('click', () => readWritingSource('article', false));
    $('#articleSoftwareTextSourceBtn').addEventListener('click', () => openSoftwareTextSourceDialog('article'));
    $('#articleLocalDataSourceBtn').addEventListener('click', () => $('#articleLocalDataSourceFile').click());
    $('#articleLocalDataSourceFile').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      event.target.value = '';
      await importLocalWritingDataSource('article', file);
    });
    $('#novelNarrativeStyle').addEventListener('change', (event) => {
      state.novelNarrativeStyle = event.target.value;
    });
    $('#novelQuickWriteBtn').addEventListener('click', runNovelQuickWrite);
    $('#novelChooseSourceBtn').addEventListener('click', () => openWritingSourcePicker('novel'));
    $('#novelReadSourceBtn').addEventListener('click', () => readWritingSource('novel', false));
    $('#novelSoftwareTextSourceBtn').addEventListener('click', () => openSoftwareTextSourceDialog('novel'));
    $('#novelLocalDataSourceBtn').addEventListener('click', () => $('#novelLocalDataSourceFile').click());
    $('#novelLocalDataSourceFile').addEventListener('change', async (event) => {
      const files = Array.from(event.target.files || []);
      event.target.value = '';
      await importLocalWritingDataSource('novel', files);
    });
    $('#novelToVideoBtn').addEventListener('click', adaptNovelToVideo);
    $('#aiChangeTopics').addEventListener('click', () => showView('home'));
    $('#aiScopeChoices').addEventListener('click', (event) => {
      const button = event.target.closest('[data-ai-scope]');
      if (!button) return;
      state.aiScope = button.dataset.aiScope;
      renderAiView();
    });
    $('#aiKindChoices').addEventListener('click', (event) => {
      const button = event.target.closest('[data-ai-kind]');
      if (!button) return;
      state.aiKind = button.dataset.aiKind;
      renderAiView();
      showToast('创作形式已切换', button.textContent.trim());
    });
    $('#aiModeChoices').addEventListener('click', (event) => {
      const button = event.target.closest('[data-ai-mode]');
      if (!button) return;
      state.aiArticleType = button.dataset.aiMode;
      state.aiMode = state.aiArticleType;
      renderAiView();
    });
    $('#aiNovelLengthChoices').addEventListener('click', (event) => {
      const button = event.target.closest('[data-ai-novel-length]');
      if (!button) return;
      state.aiNovelLength = button.dataset.aiNovelLength;
      renderAiView();
      showToast('小说篇幅已切换', button.textContent.trim());
    });
    $('#aiArticleStyle').addEventListener('change', (event) => {
      state.aiArticleStyle = event.target.value;
      showToast('参考平台文风已切换', event.target.options[event.target.selectedIndex].text);
    });
    $('.ai-quick-prompts').addEventListener('click', (event) => {
      const button = event.target.closest('[data-ai-prompt]');
      if (!button) return;
      $('#aiInstructions').value = button.dataset.aiPrompt;
      if (button.dataset.aiPrompt.includes('多事件')) state.aiScope = 'multi';
      renderAiView();
      $('#aiInstructions').focus();
    });
    $('#aiRunBtn').addEventListener('click', runAiWriting);
    $('#researchOnlyBtn').addEventListener('click', () => runResearch(true));
    $('#researchCreateBtn').addEventListener('click', createFromInspiration);
    $('#inspirationQuickPrompts').addEventListener('click', (event) => {
      const button = event.target.closest('[data-inspiration-prompt]');
      if (!button) return;
      $('#inspirationPrompt').value = button.dataset.inspirationPrompt;
      if (!$('#inspirationTitle').value.trim()) {
        const hot = leadItem();
        if (hot) $('#inspirationTitle').value = truncate(hot.title, 36);
      }
      $('#inspirationPrompt').focus();
      showToast('已填入提示词模板', button.textContent.trim());
    });
    $('#aiImageInput').addEventListener('change', async (event) => {
      await addAiImageFiles(event.target.files);
      event.target.value = '';
    });
    $('#aiVideoInput').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      event.target.value = '';
      if (!file) return;
      showLoading('正在读取视频画面', '正在从视频中提取多个画面作为图文素材。');
      try {
        addAiAttachments(await captureVideoFrames(file, 4));
        showToast('视频画面已加入素材', 'AI 会结合这些画面和你的提示词生成图文。');
      } catch (error) {
        showToast('读取视频失败', error.message, 'error');
      } finally {
        hideLoading();
      }
    });
    $('#aiPasteImageBtn').addEventListener('click', async () => {
      try {
        const clipboardItems = await navigator.clipboard.read();
        const files = [];
        for (const item of clipboardItems) {
          for (const type of item.types.filter((value) => value.startsWith('image/'))) {
            const blob = await item.getType(type);
            files.push(new File([blob], '剪贴板截图-' + Date.now() + '.png', { type }));
          }
        }
        if (!files.length) throw new Error('剪贴板里没有图片');
        await addAiImageFiles(files);
      } catch (error) {
        showToast('无法读取截图', '请点击“上传图片”，或直接复制截图后在页面按 Ctrl+V。', 'info');
      }
    });
    $('#aiGrabArticleBtn').addEventListener('click', grabArticleForAi);
    $('#aiAttachments').addEventListener('click', (event) => {
      const button = event.target.closest('[data-remove-ai-attachment]');
      if (!button) return;
      state.aiAttachments = state.aiAttachments.filter((item) => item.id !== button.dataset.removeAiAttachment);
      renderAiAttachments();
    });
    document.addEventListener('paste', async (event) => {
      if (!$('#view-ai').classList.contains('active')) return;
      const files = Array.from(event.clipboardData && event.clipboardData.files || [])
        .filter((file) => /^image\//i.test(file.type));
      if (files.length) {
        event.preventDefault();
        await addAiImageFiles(files);
      }
    });
    $('#closeSettings').addEventListener('click', closeSettings);
    $('#settingsBackdrop').addEventListener('click', closeSettings);
    $('#saveSettingsBtn').addEventListener('click', saveSettings);
    $('#refreshAppsBtn').addEventListener('click', async () => {
      state.apps = null;
      await loadApps();
      showToast('应用检测已更新');
    });
    $('#preferredBrowser').addEventListener('change', async () => {
      state.config.preferredBrowserId = $('#preferredBrowser').value;
      await persistCurrentSettings(false, false);
      showToast('默认浏览器已更新');
    });
    $('#preferredVideoPlayer').addEventListener('change', async () => {
      state.config.preferredVideoPlayerId = $('#preferredVideoPlayer').value;
      await persistCurrentSettings(false, false);
      showToast('默认视频播放器已更新');
    });
    $('#testPreferredBrowserBtn').addEventListener('click', async () => {
      try {
        const result = await api('/api/open', {
          method: 'POST',
          body: JSON.stringify({ url: location.href, browserId: $('#preferredBrowser').value })
        });
        showToast(result.browser === 'default-browser' ? '已用系统默认浏览器打开' : '工作台已在新窗口打开');
      } catch (error) {
        showToast('打开失败', error.message, 'error');
      }
    });
    $('#openGenericUrlBtn').addEventListener('click', async () => {
      const url = $('#genericOpenUrl').value.trim();
      if (!/^https?:\/\//i.test(url)) {
        showToast('请输入完整的 http 或 https 链接', null, 'info');
        return;
      }
      try {
        await api('/api/open', {
          method: 'POST',
          body: JSON.stringify({ url, browserId: $('#preferredBrowser').value })
        });
        showToast('网页已打开');
      } catch (error) {
        showToast('打开失败', error.message, 'error');
      }
    });
    $('#openLocalVideoBtn').addEventListener('click', async () => {
      const path = $('#localVideoPath').value.trim();
      if (!path) {
        showToast('请粘贴本地视频完整路径', null, 'info');
        return;
      }
      try {
        await api('/api/open-local-file', {
          method: 'POST',
          body: JSON.stringify({ path, playerId: $('#preferredVideoPlayer').value })
        });
        showToast('视频已交给所选播放器');
      } catch (error) {
        showToast('播放失败', error.message, 'error');
      }
    });
    $('#testAiBtn').addEventListener('click', testAiConnection);
    $('#aiProvider').addEventListener('change', (event) => applyAiProvider(event.target.value));
    $('#imageAiProvider').addEventListener('change', (event) => applyImageAiProvider(event.target.value));
    $('#addFeedBtn').addEventListener('click', addFeed);
    $('#closeModal').addEventListener('click', closeModal);
    $('#modalBackdrop').addEventListener('pointerdown', (event) => {
      if (event.button !== 0 || event.target.closest('button, a, input, select, textarea')) return;
      const head = event.target.closest('.modal-head');
      if (!head) return;
      const modal = head.closest('.modal');
      if (!modal) return;
      state.modalDrag = {
        modal,
        startX: event.clientX,
        startY: event.clientY,
        baseX: Number(modal.dataset.dragX) || 0,
        baseY: Number(modal.dataset.dragY) || 0
      };
      modal.classList.add('dragging');
      event.preventDefault();
      try { head.setPointerCapture(event.pointerId); } catch (error) {}
    });
    document.addEventListener('pointermove', (event) => {
      if (!state.modalDrag) return;
      const drag = state.modalDrag;
      const rect = drag.modal.getBoundingClientRect();
      const maxX = Math.max(0, (window.innerWidth - rect.width) / 2 - 12);
      const maxY = Math.max(0, (window.innerHeight - Math.min(rect.height, window.innerHeight)) / 2 - 18);
      const x = Math.max(-maxX, Math.min(maxX, drag.baseX + event.clientX - drag.startX));
      const y = Math.max(-maxY, Math.min(maxY, drag.baseY + event.clientY - drag.startY));
      drag.modal.dataset.dragX = String(x);
      drag.modal.dataset.dragY = String(y);
      drag.modal.style.transform = 'translate(' + x + 'px,' + y + 'px)';
    });
    document.addEventListener('pointerup', () => {
      if (!state.modalDrag) return;
      state.modalDrag.modal.classList.remove('dragging');
      state.modalDrag = null;
    });
    document.addEventListener('pointercancel', () => {
      if (!state.modalDrag) return;
      state.modalDrag.modal.classList.remove('dragging');
      state.modalDrag = null;
    });
    $('#importHotBtn').addEventListener('click', openImportHot);
    $('#captureLibraryBtn').addEventListener('click', captureEverythingNow);
    $('#workbuddyBtn').addEventListener('click', () => openWorkbuddyBridge(true));
    $('#headerPublishBtn').addEventListener('click', showPublishMenu);
    $('#programTabs').addEventListener('click', (event) => {
      const button = event.target.closest('[data-program-mode]');
      if (!button) return;
      saveProgramEpisode(false);
      state.programMode = button.dataset.programMode;
      const episodes = state.episodes.filter((episode) => episode.type === state.programMode);
      state.currentEpisodeId = episodes.length ? episodes[0].id : '';
      renderPrograms();
    });
    $('#programEpisodeList').addEventListener('click', (event) => {
      const card = event.target.closest('[data-episode-id]');
      if (!card) return;
      saveProgramEpisode(false);
      state.currentEpisodeId = card.dataset.episodeId;
      renderPrograms();
    });
    $('#newProgramEpisodeBtn').addEventListener('click', createProgramEpisode);
    $('#saveProgramEpisodeBtn').addEventListener('click', () => saveProgramEpisode(true));
    $('#previewProgramAudioBtn').addEventListener('click', previewProgramAudio);
    $('#programToVideoBtn').addEventListener('click', programToVideo);
    $('#novelLength').addEventListener('click', (event) => {
      const button = event.target.closest('[data-novel-length]');
      if (!button) return;
      state.novelLength = button.dataset.novelLength;
      $$('#novelLength button').forEach((item) => item.classList.toggle('active', item === button));
      $('#novelModeLabel').textContent = novelLengthLabel(state.novelLength);
    });
    $('#inspirationKindSwitch').addEventListener('click', (event) => {
      const button = event.target.closest('[data-output-kind]');
      if (!button) return;
      state.inspirationMode = button.dataset.outputKind;
      renderInspiration();
      showToast('作品类型已切换', button.textContent.trim());
    });
    $('#inspirationOutputMode').addEventListener('click', (event) => {
      const button = event.target.closest('[data-output-mode]');
      if (!button) return;
      state.inspirationArticleType = button.dataset.outputMode;
      renderInspiration();
      showToast('图文类型已切换', button.textContent.trim());
    });
    $('#inspirationNovelLength').addEventListener('click', (event) => {
      const button = event.target.closest('[data-inspiration-novel-length]');
      if (!button) return;
      state.inspirationNovelLength = button.dataset.inspirationNovelLength;
      renderInspiration();
      showToast('小说篇幅已切换', button.textContent.trim());
    });
    $('#inspirationArticleStyle').addEventListener('change', (event) => {
      state.articleStyle = event.target.value;
      showToast('参考平台文风已切换', event.target.options[event.target.selectedIndex].text);
    });
    $('#inspirationLayoutPreset').addEventListener('change', (event) => {
      state.articleTemplate = ARTICLE_TEMPLATE_PROMPTS[event.target.value] ? event.target.value : 'news';
      renderArticleTemplateStrip();
    });
    $('#novelPromptChips').addEventListener('click', (event) => {
      const button = event.target.closest('[data-novel-prompt]');
      if (!button) return;
      const input = $('#novelInspiration');
      const value = button.dataset.novelPrompt;
      if (!input.value.includes(value)) input.value = [input.value.trim(), value].filter(Boolean).join('；');
      input.focus();
    });
    $('#novelFromTopicsBtn').addEventListener('click', () => {
      const items = ensureSources(1);
      if (!items.length) {
        showToast('当前没有热点素材', '请先从首页选择或导入内容。', 'info');
        return;
      }
      $('#novelInspiration').value = items.map((item) =>
        item.title + '。' + item.summary
      ).join('\n\n');
      showToast('已加入故事背景', '可以继续添加人物、冲突和想要的结局。');
    });
    $('#generateNovelBtn').addEventListener('click', () => generateOriginalNovel(false));
    $('#previewNovelBtn').addEventListener('click', () => previewCurrentWork('novel'));
    $('#novelPrePublishBtn').addEventListener('click', () => openTextPrePublishEditor('novel'));
    $('#downloadNovelOriginalBtn').addEventListener('click', downloadNovelOriginal);
    $('#openNovelByTitleBtn').addEventListener('click', async () => {
      const title = $('#novelDirectTitleInput').value.trim();
      if (!title) {
        showToast('请输入小说名', '填写名称后会打开对应软件搜索。', 'info');
        $('#novelDirectTitleInput').focus();
        return;
      }
      await searchWritingTitle('novel', $('#novelDirectPlatform').value, title);
    });
    $('#novelDirectTitleInput').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        $('#openNovelByTitleBtn').click();
      }
    });
    $('#novelCodexLoginBtn').addEventListener('click', async () => {
      const button = $('#novelCodexLoginBtn');
      button.disabled = true;
      try {
        const result = await api('/api/codex-login', { method: 'POST', body: '{}' });
        if (result.alreadyLoggedIn) {
          await loadHealth();
          renderNovel();
          showToast('Codex 已连接', '可以使用本机 Codex 生成小说。');
          return;
        }
        showToast('已打开 Codex 登录窗口', '按窗口提示完成登录，这里会自动检测。');
        let attempts = 0;
        const timer = setInterval(async () => {
          attempts += 1;
          await loadHealth();
          renderNovel();
          if (state.codexReady || attempts >= 24) {
            clearInterval(timer);
            if (state.codexReady) showToast('Codex 登录成功', '现在可以直接生成原创小说。');
          }
        }, 2500);
      } catch (error) {
        showToast('无法启动 Codex 登录', error.message, 'error');
      } finally {
        button.disabled = false;
      }
    });
    $('#continueNovelBtn').addEventListener('click', () => {
      if (!state.novel || state.novelLength !== 'long') {
        showToast('请先生成长篇小说', '续写下一章仅用于长篇小说。', 'info');
        return;
      }
      generateOriginalNovel(true);
    });
    $('#novelTitle').addEventListener('input', persistNovel);
    $('#novelContent').addEventListener('input', () => {
      clearTimeout(window.__novelTimer);
      window.__novelTimer = setTimeout(persistNovel, 350);
      if (state.novel) {
        $('#novelWordCount').textContent = stripHtml($('#novelContent').innerHTML).replace(/\s/g, '').length + ' 字';
      }
    });
    $('#saveNovelBtn').addEventListener('click', () => {
      persistNovel();
      if (state.novel) {
        saveWorkToLibrary(buildWorkArtifact('novel', state.novel, 'manual_novel_' + Date.now()), 'completed');
      }
      showToast('小说已保存');
    });
    $('#copyNovelBtn').addEventListener('click', copyNovelText);
    $('#novelCompanionArticleBtn').addEventListener('click', createCompanionArticleFromNovel);
    document.addEventListener('click', (event) => {
      const publish = event.target.closest('[data-publish-novel]');
      if (publish) copyNovelAndOpen(publish.dataset.publishNovel);
    });
    $('#novelFreeImagesBtn').addEventListener('click', openFreeImageSearch);
    $('#importNovelMaterialBtn').addEventListener('click', openNovelMaterialImport);
    $('#novelMaterialList').addEventListener('click', (event) => {
      if (event.target.closest('input[type="checkbox"]')) return;
      const button = event.target.closest('[data-remove-novel-material]');
      if (button) {
        event.stopPropagation();
        state.novelMaterials = state.novelMaterials.filter((material) =>
          material.id !== button.dataset.removeNovelMaterial);
        saveJson(KEYS.novelMaterials, state.novelMaterials);
        renderNovelMaterials();
        showToast('参考素材已从列表移除');
        return;
      }
      const item = event.target.closest('[data-novel-material-id]');
      if (item) openNovelMaterialPreview(item.dataset.novelMaterialId);
    });
    $('#novelMaterialList').addEventListener('change', (event) => {
      const checkbox = event.target.closest('[data-novel-material-select]');
      if (!checkbox) return;
      const id = checkbox.dataset.novelMaterialSelect;
      const selected = new Set(state.novelMaterialSelected);
      if (checkbox.checked) {
        if ($('#novelMaterialUseMode') && $('#novelMaterialUseMode').value === 'single') {
          selected.clear();
        }
        selected.add(id);
      }
      else selected.delete(id);
      state.novelMaterialSelected = Array.from(selected);
    });
    $('#novelMaterialUseMode').addEventListener('change', (event) => {
      if (event.target.value === 'single' && state.novelMaterialSelected.length > 1) {
        state.novelMaterialSelected = state.novelMaterialSelected.slice(0, 1);
        renderNovelMaterials();
      }
      showToast(event.target.value === 'single' ? '已切换为单素材创作' : '已切换为多素材综合创作');
    });
    $('#novelChapterList').addEventListener('click', (event) => {
      const button = event.target.closest('[data-novel-chapter]');
      if (button) scrollToNovelChapter(Number(button.dataset.novelChapter));
    });
    $('#selectAllNovelMaterialsBtn').addEventListener('click', () => {
      const ids = state.novelMaterials.map((item) => item.id);
      const allSelected = ids.length && ids.every((id) => state.novelMaterialSelected.includes(id));
      state.novelMaterialSelected = allSelected ? [] : ids;
      renderNovelMaterials();
    });
    $('#deleteSelectedNovelMaterialsBtn').addEventListener('click', () => {
      if (!state.novelMaterialSelected.length) {
        showToast('没有选择素材', '请先勾选小说参考素材。', 'info');
        return;
      }
      const removeIds = new Set(state.novelMaterialSelected);
      state.novelMaterials = state.novelMaterials.filter((item) => !removeIds.has(item.id));
      state.novelMaterialSelected = [];
      saveJson(KEYS.novelMaterials, state.novelMaterials);
      renderNovelMaterials();
      showToast('所选小说素材已移除');
    });
    $('#refreshGithubBtn').addEventListener('click', loadGitHubStatus);
    $('#saveGithubPathBtn').addEventListener('click', async () => {
      state.config.githubRepoPath = $('#githubRepoPath').value.trim();
      try {
        const result = await api('/api/config', { method: 'POST', body: JSON.stringify(state.config) });
        state.config = Object.assign({}, state.config, result.config);
        await loadGitHubStatus();
        showToast('GitHub 仓库路径已保存');
      } catch (error) {
        showToast('保存路径失败', error.message, 'error');
      }
    });
    $('#openLocalRepoBtn').addEventListener('click', async () => {
      try { await api('/api/open-local-repository', { method: 'POST', body: '{}' }); }
      catch (error) { showToast('打开失败', error.message, 'error'); }
    });
    $('#openGithubDesktopBtn').addEventListener('click', async () => {
      try { await api('/api/open-github-desktop', { method: 'POST', body: '{}' }); }
      catch (error) { showToast('打开 GitHub Desktop 失败', error.message, 'error'); }
    });
    $('#openGithubRepoBtn').addEventListener('click', () => {
      const url = state.githubStatus && state.githubStatus.remote || 'https://github.com/HFq-ml/HotspotStudio';
      openToutiao(url);
    });
    $('#exportArticleGithubBtn').addEventListener('click', () => exportToGitHub('article'));
    $('#exportNovelGithubBtn').addEventListener('click', () => exportToGitHub('novel'));
    $('#creatorAvatar').addEventListener('click', () => {
      showView('home');
      setTimeout(() => $('.recent-panel').scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
    });
    $('#heroArticleBtn').addEventListener('click', () => {
      state.article = null;
      makeArticle(true, { scope: 'single', focusId: leadItem()?.id || '' });
    });
    $('#quickArticleBtn').addEventListener('click', () => {
      state.article = null;
      makeArticle(true, { scope: 'single', focusId: leadItem()?.id || '' });
    });
    $('#heroMultiBtn').addEventListener('click', () => {
      state.article = null;
      makeArticle(true, { scope: 'multi', mode: 'feature' });
    });
    $('#quickMultiBtn').addEventListener('click', () => {
      state.article = null;
      makeArticle(true, { scope: 'multi', mode: 'feature' });
    });
    $('#heroVideoBtn').addEventListener('click', startVideoFromHome);
    $('#quickVideoBtn').addEventListener('click', startVideoFromHome);
    $('#heroPrevBtn').addEventListener('click', (event) => {
      event.stopPropagation();
      advanceHero(-1);
    });
    $('#heroNextBtn').addEventListener('click', (event) => {
      event.stopPropagation();
      advanceHero(1);
    });
    $('#heroDots').addEventListener('click', (event) => {
      const dot = event.target.closest('[data-hero-index]');
      if (!dot) return;
      event.stopPropagation();
      state.heroIndex = Number(dot.dataset.heroIndex) || 0;
      renderHero(true);
    });
    const heroPlayer = $('#heroPlayer');
    let heroPointer = null;
    let lastHeroWheel = 0;
    heroPlayer.addEventListener('wheel', (event) => {
      if (Math.abs(event.deltaY) < 18) return;
      event.preventDefault();
      const now = Date.now();
      if (now - lastHeroWheel < 700) return;
      lastHeroWheel = now;
      advanceHero(event.deltaY > 0 ? 1 : -1);
    }, { passive: false });
    heroPlayer.addEventListener('pointerdown', (event) => {
      if (event.target.closest('button')) return;
      heroPointer = { x: event.clientX, y: event.clientY };
      state.heroPaused = true;
    });
    heroPlayer.addEventListener('pointerup', (event) => {
      if (!heroPointer) return;
      const deltaX = event.clientX - heroPointer.x;
      const deltaY = event.clientY - heroPointer.y;
      heroPointer = null;
      state.heroPaused = false;
      if (Math.abs(deltaY) >= 32 && Math.abs(deltaY) > Math.abs(deltaX)) {
        state.heroSwiped = true;
        advanceHero(deltaY < 0 ? 1 : -1);
      }
    });
    heroPlayer.addEventListener('pointercancel', () => {
      heroPointer = null;
      state.heroPaused = false;
    });
    heroPlayer.addEventListener('mouseenter', () => { state.heroPaused = true; });
    heroPlayer.addEventListener('mouseleave', () => { state.heroPaused = false; });
    heroPlayer.addEventListener('keydown', (event) => {
      if (event.key === 'ArrowDown' || event.key === 'ArrowRight') {
        event.preventDefault();
        advanceHero(1);
      } else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') {
        event.preventDefault();
        advanceHero(-1);
      }
    });
    heroPlayer.addEventListener('click', (event) => {
      if (event.target.closest('button') || event.target.closest('#heroDots')) return;
      if (state.heroSwiped) {
        state.heroSwiped = false;
        return;
      }
      const item = leadItem();
      if (item) openTopic(item.id);
    });
    $('#autoSelectBtn').addEventListener('click', () => autoRecommend(true));
    $('#hotMoreBtn').addEventListener('click', () => {
      state.activeSection = 'all';
      renderFilters();
      renderSectionRail();
      renderNews();
    });
    $('#moreBtn').addEventListener('click', () => {
      state.limit += 6;
      renderNews();
    });
    $('#searchInput').addEventListener('input', (event) => {
      state.search = event.currentTarget.value;
      renderNews();
    });
    $('#feedSortControls').addEventListener('click', (event) => {
      const button = event.target.closest('[data-feed-sort]');
      if (!button) return;
      state.feedSort = button.dataset.feedSort;
      state.limit = 9;
      renderNews();
      renderHero();
      autoGrabVisibleImages();
    });
    $('#headerSearch').addEventListener('input', (event) => {
      state.search = event.currentTarget.value;
      state.activeSection = 'all';
      renderFilters();
      renderSectionRail();
      renderNews();
    });
    $('#searchInput').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        state.search = event.currentTarget.value;
        renderNews();
      }
    });

    $('#articleTitle').addEventListener('input', persistArticle);
    $('#articleBody').addEventListener('input', () => {
      clearTimeout(window.__saveArticleTimer);
      window.__saveArticleTimer = setTimeout(persistArticle, 350);
      updateArticleMetrics();
    });
    $('#articleBody').addEventListener('pointerup', (event) => {
      const clickedFigure = event.target.closest('figure');
      if (clickedFigure) {
        state.articleReplaceImageNode = clickedFigure;
        hideArticleCaretTools();
        return;
      }
      const selection = window.getSelection();
      if (!selection || !selection.rangeCount) return;
      const range = selection.getRangeAt(0);
      if (!$('#articleBody').contains(range.commonAncestorContainer)) return;
      state.articleInsertRange = range.cloneRange();
      state.articleReplaceImageNode = event.target.closest('figure');
      positionArticleCaretTools(event.clientX, event.clientY, range);
    });
    $('#articleBody').addEventListener('click', (event) => {
      if (event.target.closest('figure')) {
        hideArticleCaretTools();
        return;
      }
      setTimeout(() => {
        const selection = window.getSelection();
        if (!selection || !selection.rangeCount) return;
        const range = selection.getRangeAt(0);
        if (!$('#articleBody').contains(range.commonAncestorContainer)) return;
        if (range.commonAncestorContainer.parentElement?.closest('figure')) {
          hideArticleCaretTools();
          return;
        }
        state.articleInsertRange = range.cloneRange();
        state.articleReplaceImageNode = event.target.closest('figure');
        positionArticleCaretTools(event.clientX, event.clientY, range);
      }, 0);
    });
    $('#articleBody').addEventListener('contextmenu', (event) => {
      event.preventDefault();
      let range = null;
      const replacementFigure = event.target.closest('figure');
      state.articleReplaceImageNode = replacementFigure || null;
      $('#articleContextReplaceImageBtn').hidden = !replacementFigure;
      const targetBlock = event.target.closest('p, h2, h3, blockquote, figure');
      if (targetBlock && $('#articleBody').contains(targetBlock)) {
        range = document.createRange();
        range.selectNodeContents(targetBlock);
        range.collapse(false);
      } else if (document.caretRangeFromPoint) {
        range = document.caretRangeFromPoint(event.clientX, event.clientY);
      }
      if (!range) {
        const selection = window.getSelection();
        if (selection && selection.rangeCount &&
            $('#articleBody').contains(selection.anchorNode)) {
          range = selection.getRangeAt(0).cloneRange();
        }
      }
      if (!range || !$('#articleBody').contains(range.commonAncestorContainer)) {
        range = document.createRange();
        range.selectNodeContents($('#articleBody'));
        range.collapse(false);
      }
      state.articleInsertRange = range.cloneRange();
      const menu = $('#articleContextMenu');
      menu.hidden = false;
      menu.style.left = Math.max(8, Math.min(window.innerWidth - 185, event.clientX)) + 'px';
      menu.style.top = Math.max(8, Math.min(window.innerHeight - 100, event.clientY)) + 'px';
      hideArticleCaretTools();
    });
    $('#articleBody').addEventListener('keyup', () => {
      const selection = window.getSelection();
      if (!selection || !selection.rangeCount) return;
      const range = selection.getRangeAt(0);
      if (!$('#articleBody').contains(range.commonAncestorContainer)) return;
      state.articleInsertRange = range.cloneRange();
      positionArticleCaretTools(null, null, range);
    });
    document.addEventListener('selectionchange', () => {
      clearTimeout(window.__articleCaretTimer);
      window.__articleCaretTimer = setTimeout(() => {
        if (!state.article || !$('#view-article').classList.contains('active') ||
            !$('#modalBackdrop').hidden) return;
        const selection = window.getSelection();
        if (!selection || !selection.rangeCount) return;
        const range = selection.getRangeAt(0);
        if (!$('#articleBody').contains(range.commonAncestorContainer)) return;
        state.articleInsertRange = range.cloneRange();
        positionArticleCaretTools(null, null, range);
      }, 60);
    });
    $('#articleCaretInsertImageBtn').addEventListener('click', () => {
      hideArticleCaretTools();
      openMediaStudio();
    });
    $('#articleCaretAutoImageBtn').addEventListener('click', generateArticleImageAtCaret);
    $('#articleContextInsertImageBtn').addEventListener('click', () => {
      $('#articleContextMenu').hidden = true;
      openMediaStudio();
    });
    $('#articleContextReplaceImageBtn').addEventListener('click', () => {
      $('#articleContextMenu').hidden = true;
      openMediaStudio();
    });
    $('#articleContextGenerateImageBtn').addEventListener('click', () => {
      $('#articleContextMenu').hidden = true;
      generateArticleImageAtCaret();
    });
    document.addEventListener('pointerdown', (event) => {
      if (event.target.closest('#articleCaretTools, #articleContextMenu, #articleBody, #modalBackdrop')) return;
      hideArticleCaretTools();
      $('#articleContextMenu').hidden = true;
    });
    window.addEventListener('scroll', () => {
      hideArticleCaretTools();
      $('#articleContextMenu').hidden = true;
    }, { passive: true });
    $('#regenerateArticleBtn').addEventListener('click', () => makeArticle(false));
    $('#articleModeSwitch').addEventListener('click', (event) => {
      const button = event.target.closest('[data-article-mode]');
      if (!button || button.dataset.articleMode === state.articleMode) return;
      state.articleMode = button.dataset.articleMode;
      makeArticle(false);
      showToast('已生成' + articleModeLabel(state.articleMode), '可以继续修改标题、正文和图片。');
    });
    $('#articleScopeSwitch').addEventListener('click', (event) => {
      const button = event.target.closest('[data-article-scope]');
      if (!button || button.dataset.articleScope === state.articleScope) return;
      const mode = state.articleMode;
      const focusId = state.articleFocusId || articleSourceItems()[0]?.id || '';
      state.article = null;
      makeArticle(false, { scope: button.dataset.articleScope, mode, focusId });
      showToast(button.dataset.articleScope === 'multi' ? '已切换为多事件讨论' : '已切换为单事件讨论',
        button.dataset.articleScope === 'multi' ? '将使用当前勾选的多条热点。' : '只围绕当前主事件写作。');
    });
    $('#saveArticleBtn').addEventListener('click', () => saveArticleToServer(true));
    $('#previewArticleBtn').addEventListener('click', () => previewCurrentWork('article'));
    $('#articlePrePublishBtn').addEventListener('click', () => openTextPrePublishEditor('article'));
    $('#downloadArticleOriginalBtn').addEventListener('click', downloadArticleOriginal);
    $('#publishArticleBtn').addEventListener('click', publishArticle);
    $('#articleToVideoBtn').addEventListener('click', articleToVideo);
    $('#mediaStudioBtn').addEventListener('click', openMediaStudio);
    $('#openToutiaoArticle').addEventListener('click', () => openToutiao(state.config.toutiaoUrl));
    $('#insertRuleBtn').addEventListener('click', () => {
      document.execCommand('insertHorizontalRule');
      persistArticle();
    });
    $('#factCheck').addEventListener('change', () => {
      if ($('#factCheck').checked) showToast('已标记为人工核验', '你仍需在发布前再次确认关键事实。');
    });

    $('#presenterOptions').addEventListener('click', (event) => {
      const button = event.target.closest('[data-presenter]');
      if (!button) return;
      state.presenter = button.dataset.presenter;
      $$('#presenterOptions button').forEach((item) => item.classList.toggle('active', item === button));
      setCanvasRatio();
    });
    $('#videoComposition').addEventListener('click', (event) => {
      const button = event.target.closest('[data-composition]');
      if (!button) return;
      state.videoComposition = button.dataset.composition;
      $$('#videoComposition button').forEach((item) => item.classList.toggle('active', item === button));
      state.videoBlob = null;
      $('#downloadVideoBtn').disabled = false;
      $('#downloadVideoBtn').hidden = true;
      $('#videoResult').hidden = true;
      $('#videoCanvas').hidden = false;
      $('#emptyVideo').hidden = false;
      hideVideoTextEditor();
      $('#generateVideoBtn span').textContent = state.videoComposition === 'precise' ? '原片顺序剪辑' : '原片高光快切';
      $('#videoState').textContent = state.videoComposition === 'precise' ? '已选择：原片顺序剪辑' : '已选择：高光快切';
      renderVideoSources();
      setCanvasRatio();
      showToast('剪辑方式已选择', state.videoComposition === 'precise' ? '按原片顺序剪辑' : '自动选取高光片段');
    });
    $('#videoOutputMode').addEventListener('click', (event) => {
      const button = event.target.closest('[data-output-mode]');
      if (!button) return;
      state.videoOutputMode = button.dataset.outputMode;
      saveJson(KEYS.videoOutputMode, state.videoOutputMode);
      if (state.videoOutputMode === 'clean') state.clipAudioMode = 'original';
      renderVideoControlState();
      setCanvasRatio();
      showToast(state.videoOutputMode === 'clean' ? '已选择原视频直出' : '已选择图文包装版',
        state.videoOutputMode === 'clean'
          ? '将去除程序添加的标题、字幕、人物和导演文字。'
          : '保留标题、字幕和导演风格包装。');
    });
    $('#originalSubtitleText').addEventListener('input', (event) => {
      state.originalSubtitleText = event.target.value;
      saveJson(KEYS.originalSubtitleText, state.originalSubtitleText);
    });
    $('#chineseSubtitleText').addEventListener('input', (event) => {
      state.chineseSubtitleText = event.target.value;
      saveJson(KEYS.chineseSubtitleText, state.chineseSubtitleText);
    });
    $('#fillSourceSubtitleBtn').addEventListener('click', () => {
      const text = currentSourceSubtitleText(false);
      state.originalSubtitleText = text;
      $('#originalSubtitleText').value = text;
      saveJson(KEYS.originalSubtitleText, text);
      showToast('已填入当前素材字幕', '可以直接修改，或继续翻译为中文。');
    });
    $('#subtitleSourceLanguage').addEventListener('change', (event) => {
      state.subtitleSourceLanguage = event.target.value;
      saveJson(KEYS.subtitleSourceLanguage, state.subtitleSourceLanguage);
    });
    $('#recognizeSpeechSubtitlesBtn').addEventListener('click', async () => {
      const button = $('#recognizeSpeechSubtitlesBtn');
      button.disabled = true;
      $('#speechRecognitionStatus').textContent = '正在读取视频音轨并识别人物说话…';
      try {
        const transcript = await recognizeSpeechSubtitles();
        state.originalSubtitleText = transcript;
        $('#originalSubtitleText').value = transcript;
        saveJson(KEYS.originalSubtitleText, transcript);
        if (state.clipAudioMode === 'original-cn') {
          if ((state.subtitleSourceLanguage || '').startsWith('zh')) {
            state.chineseSubtitleText = transcript;
            $('#chineseSubtitleText').value = transcript;
            saveJson(KEYS.chineseSubtitleText, transcript);
            $('#subtitleTranslateStatus').textContent = '已识别人物中文对白，并写入中文字幕。';
          } else {
            $('#subtitleTranslateStatus').textContent = '原字幕识别完成，正在翻译为中文…';
            try {
              const translated = await translateSubtitleText(transcript);
              state.chineseSubtitleText = translated;
              $('#chineseSubtitleText').value = translated;
              saveJson(KEYS.chineseSubtitleText, translated);
              $('#subtitleTranslateStatus').textContent = '人物对白识别和中文翻译均已完成。';
            } catch (error) {
              $('#subtitleTranslateStatus').textContent =
                '原字幕已识别，但中文翻译未完成：' + error.message;
            }
          }
        }
        $('#speechRecognitionStatus').textContent =
          '识别完成，共 ' + splitSubtitleLines(transcript).length + ' 句。';
        showToast('人物说话字幕已识别',
          state.clipAudioMode === 'original-cn'
            ? '可检查原字幕和中文翻译。'
            : '原字幕已写入，可直接剪辑。');
      } catch (error) {
        $('#speechRecognitionStatus').textContent = error.message;
        showToast('人物说话识别失败', error.message, 'error');
      } finally {
        button.disabled = false;
      }
    });
    $('#translateSubtitleBtn').addEventListener('click', async () => {
      let source = $('#originalSubtitleText').value.trim();
      if (!source) {
        source = currentSourceSubtitleText(false);
        state.originalSubtitleText = source;
        $('#originalSubtitleText').value = source;
        saveJson(KEYS.originalSubtitleText, source);
      }
      showLoading('正在翻译字幕', '正在把原字幕转换为自然通顺的中文字幕。');
      try {
        const translated = await translateSubtitleText(source);
        state.chineseSubtitleText = translated;
        $('#chineseSubtitleText').value = translated;
        saveJson(KEYS.chineseSubtitleText, translated);
        $('#subtitleTranslateStatus').textContent = '中文翻译已生成，可以继续手动修改。';
        showToast('字幕翻译完成', '生成视频时会显示中文翻译字幕。');
      } catch (error) {
        $('#subtitleTranslateStatus').textContent = error.message;
        showToast('字幕翻译失败', error.message, 'error');
      } finally {
        hideLoading();
      }
    });
    $('#clipAudioOptions').addEventListener('click', (event) => {
      const button = event.target.closest('[data-clip-audio]');
      if (!button) return;
      state.clipAudioMode = button.dataset.clipAudio;
      const audioLabels = {
        original: '原声 · 无字幕',
        'original-subs': '原声 + 原字幕',
        'original-cn': '原声 + 中文翻译字幕',
        voiceover: 'AI 声音',
        person: '人物口播',
        mute: '仅字幕'
      };
      $('#videoState').textContent = '已选择声音：' + (audioLabels[state.clipAudioMode] || state.clipAudioMode);
      renderVideoControlState();
      showToast('声音与人物方式已选择', audioLabels[state.clipAudioMode] || state.clipAudioMode);
    });
    $('#videoVisualStyle').addEventListener('click', (event) => {
      const button = event.target.closest('[data-visual-style]');
      if (!button) return;
      state.videoVisualStyle = button.dataset.visualStyle;
      $$('#videoVisualStyle button').forEach((item) => item.classList.toggle('active', item === button));
      setCanvasRatio();
      $('#videoState').textContent = '已选择画面风格：' + button.querySelector('strong').textContent;
      showToast('画面风格已选择', button.querySelector('strong').textContent);
    });
    $('#directorStyle').addEventListener('change', (event) => {
      state.directorStyle = event.target.value;
      saveJson(KEYS.directorStyle, state.directorStyle);
      const style = DIRECTOR_STYLES[state.directorStyle] || DIRECTOR_STYLES.zhang;
      $('#directorStyleHint').textContent = style.note;
      showToast('已切换导演风格', style.name + '。仅作为色彩、构图和节奏的创作参考。', 'info');
      setCanvasRatio();
    });
    $('#openDirectorStylesBtn').addEventListener('click', openDirectorStylePicker);
    $('#videoDurationOptions').addEventListener('click', (event) => {
      const button = event.target.closest('[data-video-duration]');
      if (!button) return;
      setVideoDurationValue(Number(button.dataset.videoDuration));
    });
    $('#applyCustomVideoDurationBtn').addEventListener('click', () => {
      const value = Number($('#customVideoDuration').value);
      if (!Number.isFinite(value) || value <= 0) {
        showToast('请输入有效时长', '可以输入任意秒数或分钟数。', 'info');
        $('#customVideoDuration').focus();
        return;
      }
      const unit = $('#customVideoDurationUnit').value;
      setVideoDurationValue(Math.round(value * (unit === 'minutes' ? 60 : 1)));
    });
    $('#videoMaterialSources').addEventListener('click', (event) => {
      const button = event.target.closest('[data-material-source]');
      if (!button) return;
      if (button.dataset.materialSource === 'anime' ||
          button.dataset.materialSource === 'variety') {
        openArchiveVideoLibrary(button.dataset.materialSource);
        return;
      }
      openVideoMaterialSearch(button.dataset.materialSource);
    });
    $('#openVideoDownloadSourcesBtn').addEventListener('click', () => {
      state.autoStartAfterClipImport = false;
      openVideoSourcePicker();
    });
    $('#openArchiveLibraryBtn').addEventListener('click', () => openArchiveVideoLibrary('all'));
    $('#capturePlayingVideoBtn').addEventListener('click', capturePlayingVideo);
    $('#videoNextCaptureBtn').addEventListener('click', capturePlayingVideo);
    $('#readDirectVideoSourceBtn').addEventListener('click', readDirectVideoSource);
    $('#captureFromDirectSourceBtn').addEventListener('click', capturePlayingVideo);
    $('#directSourceMode').addEventListener('click', (event) => {
      const button = event.target.closest('[data-direct-source-mode]');
      if (!button) return;
      $$('#directSourceMode button').forEach((item) =>
        item.classList.toggle('active', item === button));
      const sourceMode = button.dataset.directSourceMode === 'source';
      $('.direct-video-source-row').hidden = sourceMode;
      $('#directVideoSourceTextWrap').hidden = !sourceMode;
    });
    $('#directVideoSourceUrl').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        readDirectVideoSource();
      }
    });
    $('#refreshVideoDownloadQueueBtn').addEventListener('click', refreshVideoDownloadTasks);
    $('#videoDownloadModeSwitch').addEventListener('click', async (event) => {
      const button = event.target.closest('[data-download-mode]');
      if (!button) return;
      const sequential = button.dataset.downloadMode === 'sequential';
      try {
        await api('/api/video-download-mode', {
          method: 'POST',
          body: JSON.stringify({ sequential })
        });
        state.videoDownloadMode = sequential ? 'sequential' : 'parallel';
        saveJson(KEYS.videoDownloadMode, state.videoDownloadMode);
        await refreshVideoDownloadTasks();
        showToast(sequential ? '已切换为依次下载' : '已切换为同时下载',
          sequential ? '完成当前视频后，会自动开始队列中的下一个。' : '多个视频将同时下载。');
      } catch (error) {
        showToast('下载模式切换失败', error.message, 'error');
      }
    });
    $('#videoDownloadQueueList').addEventListener('click', async (event) => {
      const resume = event.target.closest('[data-download-resume]');
      if (resume) {
        const task = state.videoDownloadTasks.find((item) => item.taskId === resume.dataset.downloadResume);
        if (task) showVideoDownloadTask(task.taskId, task.title);
        return;
      }
      const preview = event.target.closest('[data-download-preview]');
      if (preview) {
        await previewQueuedDownload(preview.dataset.downloadPreview);
        return;
      }
      const folder = event.target.closest('[data-download-folder]');
      if (folder) {
        try { await api('/api/open-originals', { method: 'POST', body: '{}' }); }
        catch (error) { showToast('无法打开文件夹', error.message, 'error'); }
        return;
      }
      const library = event.target.closest('[data-download-library]');
      if (library) {
        $('#originalLibraryList').scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }
      const prioritize = event.target.closest('[data-download-prioritize]');
      if (prioritize) {
        prioritize.disabled = true;
        try {
          const result = await api('/api/video-import-prioritize', {
            method: 'POST',
            body: JSON.stringify({ id: prioritize.dataset.downloadPrioritize })
          });
          await refreshVideoDownloadTasks();
          showToast('已调整下载顺序', result.message || '该任务将作为下一个下载。');
        } catch (error) {
          prioritize.disabled = false;
          showToast('调整顺序失败', error.message, 'error');
        }
        return;
      }
      const remove = event.target.closest('[data-download-remove]');
      if (remove) {
        state.videoDownloadTasks = state.videoDownloadTasks.filter(
          (task) => task.taskId !== remove.dataset.downloadRemove);
        saveVideoDownloadTasks();
      }
    });
    $('#downloadOriginalVideoBtn').addEventListener('click', () => {
      state.autoStartAfterClipImport = false;
      openVideoSourcePicker();
    });
    $('#importDownloadedVideoBtn').addEventListener('click', () => {
      state.autoStartAfterClipImport = false;
      $('#localClipInput').click();
    });
    $('#openOriginalsFolderBtn').addEventListener('click', async () => {
      try {
        const result = await api('/api/open-originals', { method: 'POST', body: '{}' });
        if (result.folder && $('#originalLibraryPath')) {
          $('#originalLibraryPath').textContent = '保存位置：' + result.folder;
        }
      } catch (error) {
        showToast('打开原片文件夹失败', error.message, 'error');
      }
    });
    ['#videoSources', '#originalLibraryList', '#capturedVideoLibraryList'].forEach((selector) => {
      $(selector).addEventListener('change', (event) => {
        const checkbox = event.target.closest('.video-material-check, [data-video-library-select]');
        if (!checkbox) return;
        const id = checkbox.dataset.videoLibrarySelect || checkbox.dataset.videoMaterialSelect;
        if (!id) return;
        const selected = new Set(state.videoLibrarySelected);
        if (checkbox.checked) selected.add(id);
        else selected.delete(id);
        state.videoLibrarySelected = Array.from(selected);
        renderVideoSources();
        renderVideoLibraries();
      });
    });
    $('#selectAllVideoMaterialsBtn').addEventListener('click', () =>
      toggleVideoSelectionScope(state.localVideoClips));
    $('#selectAllOriginalVideosBtn').addEventListener('click', () =>
      toggleVideoSelectionScope(state.localVideoClips.filter((clip) => clip.originType !== 'captured')));
    $('#selectAllCapturedVideosBtn').addEventListener('click', () =>
      toggleVideoSelectionScope(state.localVideoClips.filter((clip) => clip.originType === 'captured')));
    ['#deleteSelectedVideoMaterialsBtn', '#deleteSelectedOriginalVideosBtn',
      '#deleteSelectedCapturedVideosBtn'].forEach((selector) => {
      $(selector).addEventListener('click', deleteSelectedVideoMaterials);
    });
    $('#videoPlatformGrid').addEventListener('click', (event) => {
      const button = event.target.closest('[data-video-platform]');
      if (!button) return;
      $$('#videoPlatformGrid [data-video-platform]').forEach((item) =>
        item.classList.toggle('active', item === button));
      state.platformOpenGuard[button.dataset.videoPlatform] = 0;
      state.pendingVideoSource = button.textContent.trim();
      state.pendingVideoSourceAt = Date.now();
      showVideoNextStep(button.textContent.trim(),
        '正在切换到对应软件或网站。选择电影、电视剧或其他视频后，使用官方下载；完成后返回并导入原片。');
      scheduleVideoReturnFlow(button.dataset.videoPlatform);
      showToast('正在唤起 ' + button.textContent.trim(), '系统会打开或切换到已安装的客户端。', 'info');
      launchBrowseSource(button.dataset.videoPlatform, button.textContent.trim(), 'video', 'video');
    });
    $('#readMediaWindowBtn').addEventListener('click', readCurrentMediaWindow);
    $('#readBreakdownMediaBtn').addEventListener('click', readCurrentMediaWindow);
    $('#videoNextImportBtn').addEventListener('click', () => {
      state.autoStartAfterClipImport = true;
      $('#localClipInput').click();
    });
    $('#videoNextStartEditBtn').addEventListener('click', () => {
      const clip = state.localVideoClips[0];
      if (clip) openOriginalEditing(clip.libraryId || clip.id);
    });
    $('#videoNextReadBtn').addEventListener('click', readCurrentMediaWindow);
    $('#videoNextCloseBtn').addEventListener('click', () => {
      $('#videoNextStepPanel').hidden = true;
    });
    $('#videoSources').addEventListener('click', async (event) => {
      const localDelete = event.target.closest('[data-video-local-delete]');
      if (localDelete) {
        event.stopPropagation();
        if (!window.confirm('确定删除这段原片吗？本机文件也会一起删除。')) return;
        try {
          await deleteLibraryVideo('original', localDelete.dataset.videoLocalDelete);
        } catch (error) {
          showToast('原片删除失败', error.message, 'error');
        }
        return;
      }
      const localButton = event.target.closest('[data-video-local-index]');
      if (localButton) {
        const clip = state.localVideoClips[Number(localButton.dataset.videoLocalIndex)];
        if (clip && clip.url) {
          showModal('原片预览', 'LOCAL VIDEO LIBRARY',
            '<div class="library-preview"><video controls playsinline src="' + escapeHtml(clip.url) + '"></video><strong>' +
            escapeHtml(clip.name) + '</strong><small>这是已导入本机的授权原片。</small></div>',
            '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>');
        }
        return;
      }
      const newsButton = event.target.closest('[data-video-news-id]');
      if (newsButton) {
        openTopic(newsButton.dataset.videoNewsId);
      }
    });
    $('#runVideoBreakdownBtn').addEventListener('click', runVideoBreakdown);
    $('#applyVideoBreakdownBtn').addEventListener('click', applyVideoBreakdown);
    $('#chooseLocalClipBtn').addEventListener('click', () => {
      state.autoStartAfterClipImport = false;
      openVideoSourcePicker();
    });
    $('#localClipInput').addEventListener('change', (event) => addLocalClipFiles(event.target.files));
    $('#generateClipMontageBtn').addEventListener('click', renderLocalClipMontage);
    $('#extractVoiceoverBtn').addEventListener('click', extractVoiceoverText);
    $('#generateVoiceoverBtn').addEventListener('click', () => generateVoiceover(true));
    $('#downloadVoiceoverBtn').addEventListener('click', downloadVoiceoverAudio);
    $('#voiceoverToVideoBtn').addEventListener('click', voiceoverToVideo);
    $('#voiceoverVoice').addEventListener('change', (event) => {
      state.voiceoverVoice = event.target.value;
      state.voiceoverBlob = null;
      if (state.voiceoverUrl) URL.revokeObjectURL(state.voiceoverUrl);
      state.voiceoverUrl = '';
      renderVoiceoverPanel();
      showToast('配音角色已切换', '请重新生成试听。');
    });
    $('#voiceoverText').addEventListener('input', (event) => {
      state.voiceoverText = event.target.value;
      if (state.voiceoverBlob) {
        state.voiceoverBlob = null;
        if (state.voiceoverUrl) URL.revokeObjectURL(state.voiceoverUrl);
        state.voiceoverUrl = '';
        $('#downloadVoiceoverBtn').disabled = false;
        $('#voiceoverAudio').hidden = true;
        $('#voiceoverStatus').textContent = '文字已修改 · 请重新生成配音';
      }
    });
    ['#originalLibraryList', '#capturedVideoLibraryList', '#finishedLibraryList'].forEach((selector) => {
      $(selector).addEventListener('click', async (event) => {
        const playButton = event.target.closest('[data-library-play]');
        if (playButton) {
          openLibraryVideo(playButton.dataset.libraryPlay, playButton.dataset.libraryId);
          return;
        }
        const editButton = event.target.closest('[data-library-edit]');
        if (editButton) {
          openOriginalEditing(editButton.dataset.libraryId);
          return;
        }
        const downloadButton = event.target.closest('[data-library-download]');
        if (downloadButton) {
          downloadLibraryVideo(downloadButton.dataset.libraryDownload);
          return;
        }
        const deleteButton = event.target.closest('[data-library-delete]');
        if (deleteButton) {
          try {
            await deleteLibraryVideo(deleteButton.dataset.libraryDelete, deleteButton.dataset.libraryId);
          } catch (error) {
            showToast('删除失败', error.message, 'error');
          }
        }
      });
    });
    $('#openNeteaseMusicBtn').addEventListener('click', async () => {
      await openNeteaseWatch();
    });
    $('#captureNeteaseAudioBtn').addEventListener('click', captureNeteaseAudio);
    $('#musicFileInput').addEventListener('change', (event) => {
      const file = event.target.files && event.target.files[0];
      state.musicFile = file || null;
      state.musicName = file ? file.name : '';
      $('#musicFileName').textContent = file ? file.name : '未添加';
      if (file) showToast('背景音乐已添加', '生成视频时会自动混入并循环播放。');
    });
    $('#generatePresenterImage').addEventListener('click', generateRealisticPresenter);
    $('#presenterPhotoInput').addEventListener('change', async (event) => {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      try {
        state.presenterImage = await readImageFile(file);
        saveJson(KEYS.presenterImage, state.presenterImage);
        updatePresenterImageStatus();
        setCanvasRatio();
        showToast('真人照片主播已启用', '请确认你拥有该人物肖像的使用授权。');
      } catch (error) {
        showToast('照片读取失败', error.message, 'error');
      }
    });
    $('#ratioOptions').addEventListener('click', (event) => {
      const button = event.target.closest('[data-ratio]');
      if (!button) return;
      state.ratio = button.dataset.ratio;
      $$('#ratioOptions button').forEach((item) => item.classList.toggle('active', item === button));
      setCanvasRatio();
    });
    $('#qualityOptions').addEventListener('click', (event) => {
      const button = event.target.closest('[data-video-quality]');
      if (!button) return;
      state.videoQuality = button.dataset.videoQuality;
      saveJson(KEYS.videoQuality, state.videoQuality);
      $$('#qualityOptions button').forEach((item) => item.classList.toggle('active', item === button));
      renderVideoControlState();
      setCanvasRatio();
      showToast('视频清晰度已切换', videoQualitySpec().label);
    });
    $('#applyVideoTextBtn').addEventListener('click', () => applyVideoTextEdit(false));
    $('#clearVideoTextBtn').addEventListener('click', () => applyVideoTextEdit(true));
    $('#generateCoreVideoTitleBtn').addEventListener('click', generateCoreVideoTitle);
    $('#speedOptions').addEventListener('click', (event) => {
      const button = event.target.closest('[data-speed]');
      if (!button) return;
      state.speed = button.dataset.speed;
      $$('#speedOptions button').forEach((item) => item.classList.toggle('active', item === button));
    });
    $('#generateVideoBtn').addEventListener('click', startAutoVideoEditing);
    $('#emptyGenerateVideo').addEventListener('click', startAutoVideoEditing);
    $('#downloadVideoBtn').addEventListener('click', downloadVideo);
    $('#prePublishEditBtn').addEventListener('click', openPrePublishEditor);
    $('#openVideoSourceReaderBtn').addEventListener('click', openVideoSourceReaderDialog);
    $('#openVideoPublishBtn').addEventListener('click', openPrePublishEditor);
    $('#originalPublishList').addEventListener('change', (event) => {
      const checkbox = event.target.closest('[data-publish-original-id]');
      if (!checkbox) return;
      state.originalPublishSelectionTouched = true;
      const id = checkbox.dataset.publishOriginalId;
      const selected = new Set(state.originalPublishSelected);
      if (checkbox.checked) selected.add(id);
      else selected.delete(id);
      state.originalPublishSelected = Array.from(selected);
    });
    $('#selectAllPublishOriginalsBtn').addEventListener('click', () => {
      state.originalPublishSelectionTouched = true;
      const allIds = state.localVideoClips.filter((clip) => clip && clip.url).map(originalClipKey);
      const allSelected = allIds.length && allIds.every((id) =>
        state.originalPublishSelected.includes(id));
      state.originalPublishSelected = allSelected ? [] : allIds;
      renderOriginalPublishBoard();
    });
    $('#downloadSelectedOriginalsBtn').addEventListener('click', downloadSelectedOriginals);
    $('#mergeSelectedOriginalsBtn').addEventListener('click', mergeSelectedOriginalsForPublish);
    $('#openOriginalToutiaoBtn').addEventListener('click', openPrePublishEditor);
    $('#playPreviewBtn').addEventListener('click', previewVideo);
    $('#resetVideoBtn').addEventListener('click', () => {
      if (state.videoUrl) URL.revokeObjectURL(state.videoUrl);
      if (state.neteaseAudioStream) {
        state.neteaseAudioStream.getTracks().forEach((track) => track.stop());
        state.neteaseAudioStream = null;
        $('#musicCaptureStatus').textContent = '接入时请选择正在播放的网易云窗口，并勾选“共享音频”。';
        $('#musicFileName').textContent = state.musicFile ? state.musicName || '已添加本地音频' : '未添加';
      }
      state.videoBlob = null;
      state.videoUrl = '';
      $('#videoResult').hidden = true;
      $('#videoCanvas').hidden = false;
      $('#emptyVideo').hidden = false;
      $('#downloadVideoBtn').hidden = true;
      $('#downloadVideoBtn').disabled = false;
      $('#videoState').textContent = '准备就绪';
      setCanvasRatio();
    });
    $('#changeVideoSources').addEventListener('click', () => showView('home'));
    $('#openDataBtn').addEventListener('click', async () => {
      try { await api('/api/open-data', { method: 'POST', body: '{}' }); }
      catch (error) { showToast('打开失败', error.message, 'error'); }
    });
    $('#openExtensionFolderBtn').addEventListener('click', async () => {
      try {
        await api('/api/open-extension', { method: 'POST', body: '{}' });
        showToast('已打开扩展目录', '在 Edge 打开 edge://extensions，开启开发人员模式并选择“加载解压缩的扩展”。', 'info');
      } catch (error) {
        showToast('打开失败', error.message, 'error');
      }
    });
    $('#openEdgeBtn').addEventListener('click', async () => {
      try {
        const result = await api('/api/open', { method: 'POST', body: JSON.stringify({ url: location.href }) });
        showToast(result.browser === 'edge-direct' || result.browser === 'microsoft-edge-protocol'
          ? '已在 Microsoft Edge 打开'
          : 'Edge 启动失败，已改用系统浏览器',
        result.browser === 'default-browser' ? '请检查 Edge 安装或系统安全软件。' : '将使用 Edge 当前登录配置。',
        result.browser === 'default-browser' ? 'info' : 'success');
      } catch (error) {
        showToast('打开 Edge 失败', error.message, 'error');
      }
    });
    $('#videoResult').addEventListener('timeupdate', () => {
      setProgress($('#videoResult').currentTime, state.generatedVideoSeconds || $('#videoResult').duration || 30);
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        closeModal();
        closeSettings();
      }
    });
  }

  function bindCriticalActions() {
    document.addEventListener('click', (event) => {
      const button = event.target.closest('button');
      if (!button) return;
      const actions = {
        downloadNovelOriginalBtn: () => downloadNovelOriginal(),
        downloadArticleOriginalBtn: () => downloadArticleOriginal(),
        articleMultiTemplateBtn: openArticleMultiTemplateDialog,
        aiMultiTemplateBtn: openAiMultiTemplateDialog,
        articleInsertImageBtn: openMediaStudio,
        articleAutoImageBtn: generateArticleImagesOneClick,
        articleAiModifyBtn: openCurrentArticleAiModifyDialog,
        articleInlineInsertImageBtn: openMediaStudio,
        articleInlineAutoImageBtn: generateArticleImagesOneClick,
        novelPrePublishBtn: () => openTextPrePublishEditor('novel'),
        articlePrePublishBtn: () => openTextPrePublishEditor('article'),
        openNovelByTitleBtn: () => {
          const title = $('#novelDirectTitleInput')?.value.trim();
          if (title) searchWritingTitle('novel', $('#novelDirectPlatform').value, title);
          else showToast('请输入小说名', '填写后会打开对应软件搜索。', 'info');
        },
        openArticleByTitleBtn: () => {
          const title = $('#articleDirectTitleInput')?.value.trim();
          if (title) searchWritingTitle('article', $('#articleDirectPlatform').value, title);
          else showToast('请输入文章名', '填写后会打开对应软件搜索。', 'info');
        },
        openVideoSourceReaderBtn: openVideoSourceReaderDialog,
        prePublishEditBtn: openPrePublishEditor,
        loadingTaskCenterBtn: openWorkCenter
      };
      const action = actions[button.id];
      if (!action) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      action();
    }, true);
  }

  async function init() {
    bindCriticalActions();
    bindEvents();
    try {
      if (localStorage.getItem('hotspot_app_build') !== APP_BUILD) {
        const pending = loadJson(KEYS.pendingBrowse, null);
        if (!pending || Date.now() - Number(pending.startedAt || 0) > 30000) {
          localStorage.removeItem(KEYS.pendingBrowse);
        }
        localStorage.setItem('hotspot_app_build', APP_BUILD);
      }
    } catch (error) {}
    window.addEventListener('focus', () => {
      pollEdgeInbox();
      pollNeteaseSnapshot();
      triggerBrowseResume(650);
    });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (state.recording) {
          showToast('视频正在生成，请保持小程序页面可见',
            '切到其他标签页可能降低录制帧率或造成卡顿。', 'info');
        }
        return;
      }
      if (state.recording) acquireVideoWakeLock();
      pollEdgeInbox();
      triggerBrowseResume(900);
    });
    reportClientLog('boot', 'studio v2 initialized');
    const cached = loadJson(KEYS.news, null);
    if (cached && cached.items && cached.items.length) {
      state.news = mergeImported(cached.items.map(normalizeItem));
      state.mode = cached.mode || 'cache';
    } else if (state.imported.length) {
      state.news = mergeImported([]);
    }
    drawAvatarPreview();
    updatePresenterImageStatus();
    await Promise.all([loadConfig(), loadHealth(), loadEdgeStatus()]);
    normalizeWorkLibraries();
    restoreBrowseFlow();
    const startParams = new URLSearchParams(location.search);
    const requestedSection = startParams.get('section') || '';
    if (/^[a-z0-9_-]+$/i.test(requestedSection)) state.activeSection = requestedSection;
    renderAll();
    await loadMediaLibraries();
    renderVideoDownloadQueue();
    await api('/api/video-download-mode', {
      method: 'POST',
      body: JSON.stringify({ sequential: state.videoDownloadMode === 'sequential' })
    }).catch(() => null);
    refreshVideoDownloadTasks();
    const downloadTask = startParams.get('videoDownloadTask');
    if (downloadTask) {
      showVideoDownloadTask(downloadTask, startParams.get('title') || '视频原片');
    } else if (startParams.has('videoLibrary')) {
      await loadServerOriginals(false);
      showView('video');
      const requestedFile = startParams.get('videoLibrary') || '';
      let clip = requestedFile
        ? state.localVideoClips.find((item) => item.serverFile === requestedFile)
        : null;
      if (!clip) clip = state.localVideoClips[0] || null;
      if (clip) {
        openLibraryVideo('original', clip.libraryId || clip.id);
      } else {
        try {
          const latest = await api('/api/video-import-latest');
          if (latest && latest.ok && latest.taskId) {
            showVideoDownloadTask(latest.taskId, latest.title || '视频原片');
          } else {
            showVideoNextStep('原片栏', '尚未发现新的原片，请重新下载，或点击“导入已下载原片”。');
          }
        } catch (error) {
          showVideoNextStep('原片栏', '尚未发现新的原片，请点击“导入已下载原片”。');
        }
      }
    }
    if (state.article) renderArticle();
    const captureParams = startParams;
    if (captureParams.get('edgeCapture') === '1') {
      const captureUrl = captureParams.get('url') || '';
      openImportHot({
        url: captureUrl,
        title: captureParams.get('title') || '',
        selected: captureParams.get('selected') || '',
        autoRead: Boolean(captureUrl)
      });
      history.replaceState(null, '', location.pathname);
    }
    await fetchNews(false);
    setCanvasRatio();
    await pollEdgeInbox();
    if (state.browseFlow.active) triggerBrowseResume(1100);
    setInterval(pollEdgeInbox, 5000);
    setInterval(pollNeteaseSnapshot, 3000);
    setInterval(refreshVideoDownloadTasks, 2500);
    setInterval(tickWorkElapsed, 1000);
    if (state.heroTimer) clearInterval(state.heroTimer);
    state.heroTimer = setInterval(() => {
      if (document.hidden || state.heroPaused || !$('#view-home').classList.contains('active') ||
          !$('#modalBackdrop').hidden) return;
      advanceHero(1);
    }, 6500);
    setInterval(() => {
      if (!document.hidden && $('#modalBackdrop').hidden && state.mode !== 'loading') fetchNews(false);
    }, 5 * 60 * 1000);
  }

  init();
})();
