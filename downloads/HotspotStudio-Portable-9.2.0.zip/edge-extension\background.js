const APP_ENDPOINT = 'http://127.0.0.1:18766/api/edge-capture';
const CURRENT_ENDPOINT = 'http://127.0.0.1:18766/api/edge-current';
const PUBLIC_NEWS_ENDPOINT = 'http://127.0.0.1:18766/api/public-news-ingest';
const VIDEO_IMPORT_ENDPOINT = 'http://127.0.0.1:18766/api/video-import';
const CAPTURE_DELAY = 1600;
const CURRENT_CAPTURE_DELAY = 700;
const PUBLIC_NEWS_REFRESH_MS = 8 * 60 * 1000;
const NEWS_DOMAINS = [
  'news.cn', 'xinhuanet.com', 'people.com.cn', 'cctv.com', 'chinanews.com.cn',
  'thepaper.cn', 'qq.com', 'news.qq.com', 'toutiao.com', 'weibo.com',
  '163.com', 'sina.com.cn', 'ifeng.com', '36kr.com', 'jiemian.com',
  'caixin.com', 'yicai.com', 'guancha.cn', 'xhby.net', 'cnstock.com'
  , 'jjwxc.net', 'fanqienovel.com', 'zhihu.com'
];
const pending = new Map();
const currentPending = new Map();
let publicNewsLoading = false;

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.sync.get(['autoCapture', 'newsOnly']);
  await chrome.storage.sync.set({
    autoCapture: current.autoCapture !== false,
    newsOnly: current.newsOnly !== false
  });
  if (chrome.action.setBadgeBackgroundColor) chrome.action.setBadgeBackgroundColor({ color: '#2d8b64' });
  chrome.alarms.create('hotspot-heartbeat', { periodInMinutes: 1 });
  chrome.alarms.create('hotspot-public-news', { delayInMinutes: 1, periodInMinutes: 8 });
  createCaptureMenus();
  sendHeartbeat();
  refreshPublicNewsIfNeeded();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('hotspot-heartbeat', { periodInMinutes: 1 });
  chrome.alarms.create('hotspot-public-news', { delayInMinutes: 1, periodInMinutes: 8 });
  createCaptureMenus();
  sendHeartbeat();
  refreshPublicNewsIfNeeded();
});

function createCaptureMenus() {
  if (!chrome.contextMenus) return;
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'hotspot-capture-page',
      title: '抓取当前页面到热点工坊',
      contexts: ['page', 'selection', 'image', 'video']
    });
    chrome.contextMenus.create({
      id: 'hotspot-download-video',
      title: '下载原片到热点工坊（限授权或公开视频）',
      contexts: ['video', 'page', 'link']
    });
  });
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;
  if (info.menuItemId === 'hotspot-download-video') {
    downloadOriginalVideo(tab, info).catch(async (error) => {
      await notifyVideoPage(tab.id, error && error.message || '下载原片失败', true);
      if (chrome.action.setBadgeText) {
        chrome.action.setBadgeText({ text: '!' });
        setTimeout(() => chrome.action.setBadgeText({ text: '' }), 2600);
      }
    });
    return;
  }
  captureTab(tab.id, true, {
    mode: 'manual',
    selectionText: info && info.selectionText || ''
  }).catch(() => {});
});

async function downloadOriginalVideo(tab, info) {
  let frames = [];
  try {
    frames = await chrome.scripting.executeScript({
      target: Object.assign({ tabId: tab.id },
        info && Number.isInteger(info.frameId) ? { frameIds: [info.frameId] } : { allFrames: true }),
      func: extractVideoSource
    });
  } catch (error) {}
  const fromPage = frames.map((entry) => entry && entry.result).find((entry) =>
    entry && (entry.videoUrl || entry.videoCandidates.length));
  const infoSource = info && /^https?:/i.test(info.srcUrl || '') ? info.srcUrl : '';
  const linkSource = info && /^https?:/i.test(info.linkUrl || '') &&
    /\.(mp4|webm|mov|m4v|ogv|ogg)(?:[?#]|$)/i.test(info.linkUrl) ? info.linkUrl : '';
  const videoUrl = infoSource || linkSource || (fromPage && fromPage.videoUrl) || '';
  if (!videoUrl || !/^https?:/i.test(videoUrl)) {
    throw new Error('当前画面没有公开视频直链。请使用平台官方下载，再回到热点工坊导入原片。');
  }
  const payload = {
    title: fromPage && fromPage.title || tab.title || '授权原片',
    pageUrl: tab.url || fromPage && fromPage.pageUrl || '',
    videoUrl,
    poster: fromPage && fromPage.poster || '',
    site: fromPage && fromPage.site || ''
  };
  const response = await fetch(VIDEO_IMPORT_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok || !result.taskId) {
    throw new Error(result.error || '原片下载失败，请使用平台官方下载后导入');
  }
  await chrome.storage.local.set({
    lastVideoDownload: {
      title: result.title || payload.title,
      taskId: result.taskId,
      status: 'downloading',
      time: new Date().toISOString()
    }
  });
  await notifyVideoPage(tab.id, '已开始下载原片，正在打开热点工坊下载界面：' + (result.title || payload.title), false);
  const focused = await focusStudioTab(result.taskId || '', result.title || payload.title);
  if (!focused) {
    try {
      const focusUrl = 'http://127.0.0.1:18766/api/show-download?id=' +
        encodeURIComponent(result.taskId || '') + '&title=' + encodeURIComponent(result.title || payload.title);
      await fetch(focusUrl, { cache: 'no-store' });
    } catch (error) {}
  }
  return result;
}

async function focusStudioTab(taskId, title) {
  const url = 'http://127.0.0.1:18766/?videoDownloadTask=' + encodeURIComponent(taskId || '') +
    '&title=' + encodeURIComponent(title || '原片') +
    '&run=' + Date.now();
  try {
    const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1:18766/*' });
    if (tabs.length) {
      const tab = tabs
        .filter((item) => Number.isInteger(item.id))
        .sort((a, b) => (Number(b.active) - Number(a.active)) ||
          (Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0)))[0];
      if (!tab) return false;
      await chrome.tabs.update(tab.id, { active: true, url });
      if (Number.isInteger(tab.windowId)) {
        await chrome.windows.update(tab.windowId, { focused: true, state: 'normal' });
        await chrome.tabs.highlight({ windowId: tab.windowId, tabs: [tab.index] });
      }
      return true;
    }
  } catch (error) {}
  try {
    await chrome.windows.create({ url, focused: true, width: 1240, height: 900 });
    return true;
  } catch (error) {
    try {
      await chrome.tabs.create({ url, active: true });
      return true;
    } catch (fallbackError) {
      return false;
    }
  }
}

async function notifyVideoPage(tabId, text, isError) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (message, error) => {
        const old = document.getElementById('hotspot-video-toast');
        if (old) old.remove();
        const node = document.createElement('div');
        node.id = 'hotspot-video-toast';
        node.textContent = message;
        Object.assign(node.style, {
          position: 'fixed', zIndex: '2147483647', right: '24px', bottom: '24px',
          maxWidth: '420px', padding: '13px 16px', borderRadius: '10px',
          background: error ? '#8f2d36' : '#235f49', color: '#fff',
          font: '14px/1.6 Microsoft YaHei UI, sans-serif',
          boxShadow: '0 10px 30px rgba(0,0,0,.28)'
        });
        document.documentElement.appendChild(node);
        setTimeout(() => node.remove(), 5200);
      },
      args: [text, Boolean(isError)]
    });
  } catch (error) {}
}

function extractVideoSource() {
  const absolute = (value) => {
    try { return new URL(value, location.href).href; } catch (error) { return ''; }
  };
  const videos = Array.from(document.querySelectorAll('video')).map((video) => {
    const sources = [video.currentSrc, video.src].concat(
      Array.from(video.querySelectorAll('source')).map((source) => source.src)
    ).map(absolute).filter(Boolean);
    return {
      sources,
      poster: absolute(video.poster || ''),
      duration: Number(video.duration) || 0,
      area: Math.max(1, video.clientWidth * video.clientHeight)
    };
  }).sort((first, second) => second.area - first.area);
  const meta = (selector) => {
    const node = document.querySelector(selector);
    return node && node.content || '';
  };
  const candidates = [];
  videos.forEach((video) => video.sources.forEach((source) => candidates.push(source)));
  [meta('meta[property="og:video:url"]'), meta('meta[property="og:video"]'), meta('meta[name="twitter:player:stream"]')]
    .map(absolute).filter(Boolean).forEach((source) => candidates.push(source));
  const downloadable = candidates.find((source) =>
    /^https?:/i.test(source) && !/\.(m3u8|mpd)(?:[?#]|$)/i.test(source)) || '';
  return {
    title: (document.querySelector('h1') && document.querySelector('h1').innerText || document.title || '').trim().slice(0, 180),
    pageUrl: location.href,
    videoUrl: downloadable,
    videoCandidates: candidates.slice(0, 12),
    poster: videos[0] && videos[0].poster || meta('meta[property="og:image"]'),
    duration: videos[0] && videos[0].duration || 0,
    site: location.hostname.replace(/^www\./, '')
  };
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'hotspot-heartbeat') sendHeartbeat();
  if (alarm.name === 'hotspot-public-news') refreshPublicNewsIfNeeded(true);
});

async function sendHeartbeat() {
  try {
    await fetch('http://127.0.0.1:18766/api/edge-heartbeat', {
      method: 'POST',
      body: JSON.stringify({ version: chrome.runtime.getManifest().version })
    });
    refreshPublicNewsIfNeeded();
  } catch (error) {
    // Hotspot Studio may not be running yet.
  }
}

async function refreshPublicNewsIfNeeded(force) {
  if (publicNewsLoading) return;
  try {
    const stored = await chrome.storage.local.get(['lastPublicNewsFetch']);
    if (!force && stored.lastPublicNewsFetch &&
        Date.now() - Number(stored.lastPublicNewsFetch) < PUBLIC_NEWS_REFRESH_MS) return;
    publicNewsLoading = true;
    const configResponse = await fetch('http://127.0.0.1:18766/api/config', { cache: 'no-store' });
    if (!configResponse.ok) throw new Error('无法读取小程序配置');
    const config = await configResponse.json();
    const sections = (config.sections || config.Sections || [])
      .filter((section) => section.enabled !== false && section.Enabled !== false)
      .slice(0, 24);
    const collected = [];
    for (let index = 0; index < sections.length; index += 4) {
      const batch = sections.slice(index, index + 4);
      const lists = await Promise.all(batch.map(fetchPublicSection));
      lists.forEach((items) => collected.push(...items));
    }
    if (!collected.length) throw new Error('没有获取到公共新闻 RSS');
    const response = await fetch(PUBLIC_NEWS_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: collected.slice(0, 320) })
    });
    if (!response.ok) throw new Error('热点工坊拒绝了公共新闻导入');
    await chrome.storage.local.set({
      lastPublicNewsFetch: Date.now(),
      lastPublicNewsCount: collected.length,
      lastPublicNewsError: ''
    });
    if (chrome.action.setBadgeText) {
      chrome.action.setBadgeText({ text: '新' });
      setTimeout(() => chrome.action.setBadgeText({ text: '' }), 1800);
    }
  } catch (error) {
    // The public-news bridge retries with the next heartbeat.
    await chrome.storage.local.set({
      lastPublicNewsError: error && error.message || '公共新闻同步失败'
    });
  } finally {
    publicNewsLoading = false;
  }
}

async function fetchPublicSection(section) {
  const id = section.id || section.Id || 'general';
  const name = section.name || section.Name || '要闻';
  const query = section.query || section.Query || '今日热点';
  const url = 'https://www.bing.com/news/search?q=' + encodeURIComponent(query) +
    '&format=rss&setlang=zh-cn&cc=cn';
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(url, { cache: 'no-store', signal: controller.signal });
    if (!response.ok) return [];
    const xml = await response.text();
    return parsePublicRss(xml, id, name);
  } catch (error) {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

function parsePublicRss(xml, section, sectionName) {
  const itemBlocks = String(xml || '').match(/<item\b[\s\S]*?<\/item>/gi) || [];
  return itemBlocks.slice(0, 12).map((block, index) => {
    const title = cleanXmlText(xmlTag(block, 'title'));
    const link = cleanXmlText(xmlTag(block, 'link'));
    if (!title || !/^https?:\/\//i.test(link)) return null;
    const description = cleanXmlText(xmlTag(block, 'description'));
    const pubDate = cleanXmlText(xmlTag(block, 'pubDate'));
    const imageMatch = block.match(/<media:content[^>]+url=["']([^"']+)["']/i) ||
      block.match(/<enclosure[^>]+url=["']([^"']+)["']/i) ||
      block.match(/<img[^>]+src=["']([^"']+)["']/i);
    let source = '公共新闻';
    try { source = new URL(link).hostname.replace(/^www\./, ''); } catch (error) {}
    return {
      title,
      url: link,
      summary: description || (sectionName + '最新公开新闻。'),
      image: imageMatch ? imageMatch[1] : '',
      images: imageMatch ? [imageMatch[1]] : [],
      source,
      section,
      sectionName,
      publishedAt: pubDate ? new Date(pubDate).toISOString() : new Date().toISOString(),
      publishedLabel: '实时',
      score: Math.max(72, 96 - index * 2),
      tag: '公共新闻',
      demo: false
    };
  }).filter(Boolean);
}

function xmlTag(block, tag) {
  const match = String(block || '').match(new RegExp('<' + tag + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + tag + '>', 'i'));
  return match ? match[1] : '';
}

function cleanXmlText(value) {
  return String(value || '')
    .replace(/^<!\[CDATA\[|\]\]>$/g, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'refresh-public-news') {
    refreshPublicNewsIfNeeded(true).then(async () => {
      const stored = await chrome.storage.local.get([
        'lastPublicNewsCount', 'lastPublicNewsError', 'lastPublicNewsFetch'
      ]);
      sendResponse({
        ok: !stored.lastPublicNewsError,
        count: stored.lastPublicNewsCount || 0,
        error: stored.lastPublicNewsError || '',
        time: stored.lastPublicNewsFetch || 0
      });
    }).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message && message.type === 'capture-now') {
    captureActiveTab(true).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message && message.type === 'download-video-now') {
    chrome.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      if (!tabs.length || !tabs[0].id) throw new Error('没有找到当前标签页');
      return downloadOriginalVideo(tabs[0], {});
    }).then((result) => sendResponse({ ok: true, title: result && result.title || '当前页面视频' }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  return false;
});

chrome.commands.onCommand.addListener((command) => {
  if (command === 'capture-current') captureActiveTab(true).catch(() => {});
  if (command === 'download-current-video') {
    chrome.tabs.query({ active: true, currentWindow: true }).then(async (tabs) => {
      if (!tabs.length || !tabs[0].id) throw new Error('没有找到当前标签页');
      try {
        await downloadOriginalVideo(tabs[0], {});
      } catch (error) {
        await notifyVideoPage(tabs[0].id, error.message, true);
      }
    }).catch(() => {});
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url) return;
  const settings = await chrome.storage.sync.get(['autoCapture', 'newsOnly']);
  if (settings.autoCapture === false) return;
  scheduleCurrentCapture(tabId);
  if (!isAllowedPage(tab.url, settings.newsOnly !== false)) return;
  clearTimeout(pending.get(tabId));
  pending.set(tabId, setTimeout(() => {
    pending.delete(tabId);
    captureTab(tabId, false).catch(() => {});
  }, CAPTURE_DELAY));
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const settings = await chrome.storage.sync.get(['autoCapture']);
  if (settings.autoCapture === false) return;
  scheduleCurrentCapture(activeInfo.tabId);
});

function scheduleCurrentCapture(tabId) {
  clearTimeout(currentPending.get(tabId));
  currentPending.set(tabId, setTimeout(() => {
    currentPending.delete(tabId);
    captureReferenceTab(tabId).catch(() => {});
  }, CURRENT_CAPTURE_DELAY));
}

async function captureReferenceTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (!tab.url || !/^https?:/i.test(tab.url)) return;
  const parsed = new URL(tab.url);
  if (parsed.hostname === '127.0.0.1' || parsed.hostname === 'localhost') return;
  const result = await chrome.scripting.executeScript({
    target: { tabId },
    func: extractCurrentPage
  });
  const payload = result && result[0] && result[0].result;
  if (!payload || !payload.title || !payload.text || payload.text.replace(/\s/g, '').length < 30) return;
  await fetch(CURRENT_ENDPOINT, {
    method: 'POST',
    body: JSON.stringify(Object.assign(payload, { capturedAt: new Date().toISOString() }))
  });
}

function isAllowedPage(url, newsOnly) {
  try {
    const parsed = new URL(url);
    if (!/^https?:$/.test(parsed.protocol)) return false;
    if (parsed.hostname === '127.0.0.1' || parsed.hostname === 'localhost') return false;
    if (!newsOnly) return true;
    const host = parsed.hostname.replace(/^www\./, '');
    if (/^news\.qq\.com$/i.test(host) || /^new\.qq\.com$/i.test(host)) {
      return /\/(rain\/a|a|article|detail)\//i.test(parsed.pathname);
    }
    if (/(^|\.)weibo\.com$/i.test(host)) {
      return /\/detail\/|\/status\/|\/weibo\?/i.test(parsed.pathname + parsed.search);
    }
    if (NEWS_DOMAINS.some((domain) => host === domain || host.endsWith('.' + domain))) return true;
    return /\/(news|article|detail|content|story|hot|topic)\//i.test(parsed.pathname);
  } catch (error) {
    return false;
  }
}

async function captureActiveTab(force) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tabs.length || !tabs[0].id) throw new Error('没有找到当前标签页');
  const settings = await chrome.storage.sync.get(['newsOnly']);
  if (!force && !isAllowedPage(tabs[0].url || '', settings.newsOnly !== false)) {
    return { ok: false, error: '当前页面不是受支持的新闻页面' };
  }
  return captureTab(tabs[0].id, force);
}

async function captureTab(tabId, force, options) {
  const tab = await chrome.tabs.get(tabId);
  if (!tab.url || !/^https?:/i.test(tab.url)) throw new Error('当前标签页不是网页');
  const tabUrl = new URL(tab.url);
  if (tabUrl.hostname === '127.0.0.1' || tabUrl.hostname === 'localhost') {
    throw new Error('不采集热点工坊自身的本地页面');
  }
  const result = await chrome.scripting.executeScript({
    target: { tabId },
    func: extractCurrentPage
  });
  const payload = Object.assign({}, result && result[0] && result[0].result);
  if (!payload) throw new Error('页面内容读取失败');
  const captureOptions = options || {};
  payload.captureMode = captureOptions.mode || 'auto';
  if (captureOptions.linkUrl) payload.url = captureOptions.linkUrl;
  if (captureOptions.selectionText) payload.selected = captureOptions.selectionText.slice(0, 4000);
  if (!force && !payload.isArticle) throw new Error('当前页面不是可识别的新闻正文');
  const response = await fetch(APP_ENDPOINT, {
    method: 'POST',
    body: JSON.stringify(Object.assign(payload, { capturedAt: new Date().toISOString() }))
  });
  if (!response.ok) throw new Error('热点工坊未运行，或本地接口拒绝连接');
  await chrome.storage.local.set({
    lastCapture: { title: payload.title, url: payload.url, time: new Date().toISOString(), mode: payload.captureMode }
  });
  sendHeartbeat();
  if (chrome.action.setBadgeText) {
    chrome.action.setBadgeText({ text: '✓' });
    setTimeout(() => chrome.action.setBadgeText({ text: '' }), 2200);
  }
  return { ok: true, title: payload.title };
}

function extractCurrentPage() {
  const absolute = (value) => {
    try { return new URL(value, location.href).href; } catch (error) { return ''; }
  };
  const meta = (selectors) => {
    for (const selector of selectors) {
      const node = document.querySelector(selector);
      if (node && node.content) return node.content;
    }
    return '';
  };
  const article = document.querySelector('article, main, [class*="article-content"], [class*="article-body"], [class*="content-body"]') || document.body;
  const text = (article && article.innerText || document.body.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 14000);
  const images = [];
  const addImage = (value) => {
    const url = absolute(value || '');
    if (/^https?:/i.test(url) && !images.includes(url) && images.length < 10) images.push(url);
  };
  addImage(meta(['meta[property="og:image"]', 'meta[name="twitter:image"]']));
  if (article) {
    article.querySelectorAll('img[src]').forEach((image) => addImage(image.currentSrc || image.src || image.getAttribute('data-src')));
  }
  return {
    title: (document.querySelector('h1') && document.querySelector('h1').innerText || document.title || '').trim().slice(0, 180),
    url: location.href,
    description: meta(['meta[name="description"]', 'meta[property="og:description"]']) || text.slice(0, 260),
    text,
    image: images[0] || '',
    images,
    site: location.hostname.replace(/^www\./, ''),
    isArticle: Boolean(article && text.length >= 350)
  };
}
