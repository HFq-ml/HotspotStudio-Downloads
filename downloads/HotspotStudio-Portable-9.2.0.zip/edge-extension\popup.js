const autoInput = document.getElementById('autoCapture');
const newsInput = document.getElementById('newsOnly');
const status = document.getElementById('status');
const last = document.getElementById('last');
const capture = document.getElementById('captureNow');
const downloadCurrentVideo = document.getElementById('downloadCurrentVideo');
const syncPublicNews = document.getElementById('syncPublicNews');

async function init() {
  const settings = await chrome.storage.sync.get(['autoCapture', 'newsOnly']);
  autoInput.checked = settings.autoCapture !== false;
  newsInput.checked = settings.newsOnly !== false;
  const local = await chrome.storage.local.get(['lastCapture']);
  if (local.lastCapture) {
    last.textContent = '最近采集：' + local.lastCapture.title + ' · ' + new Date(local.lastCapture.time).toLocaleTimeString('zh-CN');
  }
  const videoState = await chrome.storage.local.get(['lastVideoDownload']);
  if (videoState.lastVideoDownload) {
    status.textContent = '最近原片：' + videoState.lastVideoDownload.title +
      ' · ' + new Date(videoState.lastVideoDownload.time).toLocaleTimeString('zh-CN');
  }
  const publicState = await chrome.storage.local.get([
    'lastPublicNewsCount', 'lastPublicNewsError', 'lastPublicNewsFetch'
  ]);
  if (publicState.lastPublicNewsError) {
    last.textContent = '公共新闻同步失败：' + publicState.lastPublicNewsError;
  } else if (publicState.lastPublicNewsCount) {
    last.textContent = '公共新闻：已同步 ' + publicState.lastPublicNewsCount + ' 条';
  }
  status.textContent = '修改设置后立即生效。热点工坊需要保持运行。';
}

autoInput.addEventListener('change', async () => {
  await chrome.storage.sync.set({ autoCapture: autoInput.checked });
  status.textContent = autoInput.checked ? '自动采集已开启。' : '自动采集已关闭。';
});
newsInput.addEventListener('change', async () => {
  await chrome.storage.sync.set({ newsOnly: newsInput.checked });
  status.textContent = newsInput.checked ? '只读取新闻站点或文章路径。' : '注意：将尝试读取所有普通网页。';
});
capture.addEventListener('click', async () => {
  capture.disabled = true;
  status.textContent = '正在读取当前网页…';
  try {
    const result = await chrome.runtime.sendMessage({ type: 'capture-now' });
    if (!result || !result.ok) throw new Error(result && result.error || '采集失败');
    status.textContent = '已发送到热点工坊：' + result.title;
    const local = await chrome.storage.local.get(['lastCapture']);
    if (local.lastCapture) last.textContent = '最近采集：' + local.lastCapture.title;
  } catch (error) {
    status.textContent = error.message;
  } finally {
    capture.disabled = false;
  }
});
syncPublicNews.addEventListener('click', async () => {
  syncPublicNews.disabled = true;
  status.textContent = '正在同步国内外公共新闻…';
  try {
    const result = await chrome.runtime.sendMessage({ type: 'refresh-public-news' });
    if (!result || !result.ok) throw new Error(result && result.error || '同步失败');
    status.textContent = '公共新闻已同步 ' + result.count + ' 条';
    last.textContent = '打开热点工坊后点击“刷新最新”即可显示。';
  } catch (error) {
    status.textContent = '同步失败：' + error.message;
  } finally {
    syncPublicNews.disabled = false;
  }
});
downloadCurrentVideo.addEventListener('click', async () => {
  downloadCurrentVideo.disabled = true;
  status.textContent = '正在读取当前页面的视频地址…';
  try {
    const result = await chrome.runtime.sendMessage({ type: 'download-video-now' });
    if (!result || !result.ok) throw new Error(result && result.error || '没有找到可下载的视频');
    status.textContent = '已开始下载原片，正在打开热点工坊：' + (result.title || '');
  } catch (error) {
    status.textContent = error.message;
  } finally {
    downloadCurrentVideo.disabled = false;
  }
});
document.getElementById('openApp').addEventListener('click', () => {
  chrome.tabs.create({ url: 'http://127.0.0.1:18766/' });
});
init();
