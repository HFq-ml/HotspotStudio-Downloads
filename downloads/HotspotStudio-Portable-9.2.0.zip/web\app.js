(function () {
  'use strict';

  const $ = (selector, root) => (root || document).querySelector(selector);
  const $$ = (selector, root) => Array.from((root || document).querySelectorAll(selector));
  const icon = (name) => '<svg aria-hidden="true"><use href="#i-' + name + '"></use></svg>';
  const STORE = {
    news: 'hotspot_news_v1',
    selection: 'hotspot_selection_v1',
    article: 'hotspot_article_v1',
    drafts: 'hotspot_drafts_v1'
  };

  const DEFAULT_CONFIG = {
    refreshMinutes: 20,
    maxItemsPerSection: 12,
    sections: [
      { id: 'general', name: '综合热点', color: '#ff694b', enabled: true },
      { id: 'society', name: '社会', color: '#f49a32', enabled: true },
      { id: 'finance', name: '财经', color: '#39a56e', enabled: true },
      { id: 'tech', name: '科技', color: '#4a7df0', enabled: true },
      { id: 'world', name: '国际', color: '#8a67e8', enabled: true },
      { id: 'sports', name: '体育', color: '#1ca6a6', enabled: true },
      { id: 'entertainment', name: '文娱', color: '#df5b9c', enabled: true },
      { id: 'auto', name: '汽车', color: '#6b7d93', enabled: true }
    ],
    customFeeds: [],
    ai: { enabled: false, baseUrl: 'https://api.openai.com/v1', model: 'gpt-4.1-mini', hasKey: false },
    toutiaoUrl: 'https://mp.toutiao.com/profile_v4/graphic/publish',
    videoUrl: 'https://mp.toutiao.com/profile_v4/xigua/upload-video'
  };

  const state = {
    config: DEFAULT_CONFIG,
    news: [],
    mode: 'loading',
    updatedAt: '',
    message: '',
    activeSection: 'all',
    activeView: 'dashboard',
    selected: loadJson(STORE.selection, []),
    drafts: loadJson(STORE.drafts, []),
    article: loadJson(STORE.article, null),
    template: 'brief',
    search: '',
    health: null,
    videoRatio: '9:16',
    videoStyle: 'editorial',
    videoRecording: false,
    videoPreviewing: false,
    videoBlob: null,
    videoUrl: '',
    videoCleanup: null,
    tags: []
  };

  const VIEW_TITLES = {
    dashboard: ['每日资讯', '今日热点'],
    news: ['STORY LIBRARY', '选题库'],
    compose: ['CONTENT STUDIO', '图文创作'],
    video: ['VIDEO LAB', '微视频'],
    queue: ['PUBLISH QUEUE', '发布队列'],
    sources: ['NEWS SOURCES', '数据源'],
    settings: ['PREFERENCES', '设置']
  };

  function reportClientLog(kind, message, extra) {
    try {
      const payload = JSON.stringify({
        kind: kind,
        message: String(message || ''),
        extra: extra || '',
        url: location.href,
        time: new Date().toISOString()
      });
      if (navigator.sendBeacon) navigator.sendBeacon('/api/client-log', payload);
      else fetch('/api/client-log', { method: 'POST', body: payload, keepalive: true });
    } catch (error) {
      console.warn('Client log failed', error);
    }
  }

  window.addEventListener('error', (event) => {
    reportClientLog('error', event.message, (event.filename || '') + ':' + (event.lineno || 0) + ':' + (event.colno || 0));
  });
  window.addEventListener('unhandledrejection', (event) => {
    reportClientLog('promise', event.reason && (event.reason.stack || event.reason.message) || String(event.reason || ''));
  });

  function loadJson(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function saveJson(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.warn('Local storage failed', error);
    }
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/`/g, '&#096;');
  }

  function stripHtml(value) {
    const box = document.createElement('div');
    box.innerHTML = value || '';
    return (box.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function truncate(value, length) {
    const text = String(value || '').trim();
    return text.length > length ? text.slice(0, length).replace(/[，。；、\s]+$/, '') + '…' : text;
  }

  function formatDate() {
    const now = new Date();
    const weekday = new Intl.DateTimeFormat('zh-CN', { weekday: 'long' }).format(now);
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return { weekday, month, day, full: now.getFullYear() + '年' + month + '月' + day + '日' };
  }

  function setDates() {
    const date = formatDate();
    $('#pageEyebrow').textContent = date.weekday + ' · 每日资讯';
    $('#heroDate').textContent = date.full + ' · ' + date.weekday;
  }

  function sectionConfig(sectionId) {
    return (state.config.sections || []).find((section) => section.id === sectionId) || {
      id: sectionId,
      name: '资讯',
      color: '#ff694b'
    };
  }

  function normalizeNewsItem(item) {
    const section = sectionConfig(item.section);
    return Object.assign({}, item, {
      sectionName: item.sectionName || section.name,
      color: item.color || section.color,
      summary: item.summary || '打开来源可查看更完整的信息。'
    });
  }

  function getFilteredNews(options) {
    const settings = options || {};
    const query = (settings.search == null ? state.search : settings.search).trim().toLowerCase();
    const section = settings.section || state.activeSection;
    return state.news.filter((item) => {
      const sectionMatch = section === 'all' || item.section === section;
      const haystack = [item.title, item.summary, item.source, item.sectionName].join(' ').toLowerCase();
      return sectionMatch && (!query || haystack.includes(query));
    });
  }

  function getSelectedItems() {
    return state.selected
      .map((id) => state.news.find((item) => item.id === id))
      .filter(Boolean);
  }

  function setModeUi() {
    const pill = $('#livePill');
    const label = $('span', pill);
    pill.classList.remove('is-live', 'is-error');
    if (state.mode === 'live') {
      pill.classList.add('is-live');
      label.textContent = '实时数据';
      $('#statLiveBadge').textContent = '实时更新';
    } else if (state.mode === 'loading') {
      label.textContent = '正在采集';
      $('#statLiveBadge').textContent = '正在采集';
    } else if (state.mode === 'demo') {
      pill.classList.add('is-error');
      label.textContent = '演示数据';
      $('#statLiveBadge').textContent = '等待联网';
    } else {
      pill.classList.add('is-error');
      label.textContent = state.mode === 'stale' ? '上次缓存' : '当前离线';
      $('#statLiveBadge').textContent = '本地缓存';
    }
    $('#sourceLiveCount').textContent = state.mode === 'live' ? '实时采集' : state.mode === 'loading' ? '准备中' : '待连接';
    $('#sourceLiveCount').classList.toggle('live', state.mode === 'live');
  }

  function showView(view) {
    if (!VIEW_TITLES[view]) return;
    state.activeView = view;
    $$('.view').forEach((node) => node.classList.toggle('active', node.id === 'view-' + view));
    $$('.nav-item').forEach((node) => node.classList.toggle('active', node.dataset.view === view));
    const title = VIEW_TITLES[view];
    $('#pageEyebrow').textContent = title[0];
    $('#pageTitle').textContent = title[1];
    closeMobileMenu();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (view === 'compose') renderComposer();
    if (view === 'video') ensureVideoStoryboard();
    if (view === 'queue') renderDrafts();
    if (view === 'sources') renderSources();
    if (view === 'settings') renderSettings();
  }

  function closeMobileMenu() {
    $('#sidebar').classList.remove('open');
    $('#mobileBackdrop').classList.remove('open');
  }

  function showToast(title, message, type) {
    const kind = type || 'success';
    const toast = document.createElement('div');
    toast.className = 'toast ' + kind;
    toast.innerHTML =
      '<span class="toast-icon">' + icon(kind === 'error' ? 'close' : kind === 'info' ? 'spark' : 'check') + '</span>' +
      '<div><strong>' + escapeHtml(title) + '</strong>' +
      (message ? '<p>' + escapeHtml(message) + '</p>' : '') + '</div>';
    $('#toastStack').appendChild(toast);
    setTimeout(() => {
      toast.classList.add('leaving');
      setTimeout(() => toast.remove(), 240);
    }, 4200);
  }

  function showLoading(title, text) {
    $('#loadingTitle').textContent = title || '正在处理';
    $('#loadingText').textContent = text || '请稍候…';
    $('#loadingLayer').hidden = false;
  }

  function hideLoading() {
    $('#loadingLayer').hidden = true;
  }

  function showModal(title, eyebrow, bodyHtml, footHtml) {
    $('#modalTitle').textContent = title;
    $('#modalEyebrow').textContent = eyebrow || 'HOTSPOT STUDIO';
    $('#modalBody').innerHTML = bodyHtml;
    $('#modalFoot').innerHTML = footHtml || '<button class="btn btn-secondary" type="button" data-modal-close>关闭</button>';
    $('#modalBackdrop').hidden = false;
  }

  function closeModal() {
    $('#modalBackdrop').hidden = true;
  }

  function camelizeKeys(value) {
    if (Array.isArray(value)) return value.map(camelizeKeys);
    if (!value || typeof value !== 'object') return value;
    const result = {};
    Object.keys(value).forEach((key) => {
      const normalized = key.charAt(0).toLowerCase() + key.slice(1);
      result[normalized] = camelizeKeys(value[key]);
    });
    return result;
  }

  async function api(path, options) {
    const settings = Object.assign({ headers: { 'Content-Type': 'application/json' } }, options || {});
    const response = await fetch(path, settings);
    let data = null;
    try {
      data = await response.json();
    } catch (error) {
      throw new Error('本地服务返回了无法解析的内容。');
    }
    if (!response.ok) {
      throw new Error((data && data.error) || '请求失败（' + response.status + '）');
    }
    return camelizeKeys(data);
  }

  async function loadConfig() {
    try {
      const config = await api('/api/config');
      state.config = Object.assign({}, DEFAULT_CONFIG, config);
      if (!state.config.sections || !state.config.sections.length) state.config.sections = DEFAULT_CONFIG.sections;
      if (!state.config.customFeeds) state.config.customFeeds = [];
      if (!state.config.ai) state.config.ai = DEFAULT_CONFIG.ai;
    } catch (error) {
      state.config = DEFAULT_CONFIG;
      showToast('配置读取失败', error.message, 'error');
    }
    updateAiStatus();
  }

  async function loadHealth() {
    try {
      state.health = await api('/api/health');
      const path = $('#dataPath');
      if (path && state.health.dataDirectory) path.textContent = state.health.dataDirectory;
    } catch (error) {
      console.warn('Health check failed', error);
    }
  }

  async function fetchNews(force) {
    state.mode = 'loading';
    setModeUi();
    if (!state.news.length) renderSkeletons();
    const button = $('#fetchNowBtn');
    if (button) button.disabled = true;
    if (force) showLoading('正在采集今日热点', '正在从公开 RSS 数据源获取内容、图片与时间信息。');
    try {
      const demo = new URLSearchParams(location.search).get('demo') === '1';
      const response = await api('/api/news?section=all&force=' + (force ? '1' : '0') + (demo ? '&demo=1' : ''));
      if (!response || !Array.isArray(response.items)) throw new Error('数据格式不完整');
      state.news = response.items.map(normalizeNewsItem);
      state.mode = response.mode || (response.demo ? 'demo' : 'live');
      state.updatedAt = response.updatedAt || '';
      state.message = response.message || '';
      state.selected = state.selected.filter((id) => state.news.some((item) => item.id === id));
      saveJson(STORE.news, {
        items: state.news,
        mode: state.mode,
        updatedAt: state.updatedAt,
        message: state.message
      });
      saveJson(STORE.selection, state.selected);
      renderAll();
      if (state.mode === 'live') {
        showToast('热点已更新', '已收录 ' + state.news.length + ' 条资讯，所有内容均保存在本机。');
      } else if (state.mode === 'demo') {
        showToast('当前为演示内容', response.message || '网络数据源暂未连通，可稍后重试。', 'info');
      } else {
        showToast('正在使用缓存', response.message || '网络暂不可用。', 'info');
      }
    } catch (error) {
      state.mode = 'error';
      if (!state.news.length) renderNewsError(error.message);
      showToast('采集失败', error.message, 'error');
    } finally {
      setModeUi();
      hideLoading();
      if (button) button.disabled = false;
    }
  }

  function renderSkeletons() {
    const grid = $('#trendGrid');
    if (grid) grid.innerHTML = Array.from({ length: 5 }, () => '<div class="skeleton-card"></div>').join('');
    const feed = $('#newsFeed');
    if (feed) feed.innerHTML = '<div class="feed-loading">正在读取资讯…</div>';
  }

  function renderNewsError(message) {
    const html =
      '<div class="fatal-empty"><span>!</span><h3>暂时没有读到内容</h3>' +
      '<p>' + escapeHtml(message || '请检查网络后重试') + '</p>' +
      '<button class="btn btn-secondary" type="button" data-action="refresh">重新采集</button></div>';
    $('#trendGrid').innerHTML = html;
    $('#newsFeed').innerHTML = html;
  }

  function renderAll() {
    updateCounts();
    renderCategories();
    renderTrends();
    renderRadar();
    renderNewsFeed();
    renderSelection();
    renderSources();
    renderDrafts();
    renderComposer();
    renderStoryboard();
  }

  function updateCounts() {
    const activeSections = new Set(state.news.map((item) => item.section));
    $('#navNewsCount').textContent = state.news.length;
    $('#navDraftCount').textContent = state.drafts.length;
    $('#statNews').innerHTML = state.news.length + '<small> 条</small>';
    $('#statSections').innerHTML = activeSections.size + '<small> 个</small>';
    $('#statDrafts').innerHTML = state.drafts.length + '<small> 篇</small>';
    $('#selectionCount').textContent = state.selected.length;
    $('#flowSelected').textContent = state.selected.length ? '已选 ' + state.selected.length + ' 条素材' : '尚未选择';
    const steps = $$('.flow-step');
    const completed = state.news.length ? 1 : 0;
    const selected = state.selected.length ? 1 : 0;
    const composed = state.article && stripHtml(state.article.html).length > 120 ? 1 : 0;
    const drafted = state.drafts.length ? 1 : 0;
    const progress = Math.round((completed + selected + composed + drafted) / 4 * 100);
    $('#flowProgress').textContent = progress + '%';
    steps.forEach((step, index) => {
      step.classList.toggle('done', [completed, selected, composed, drafted][index] === 1);
      step.classList.toggle('current', [completed, selected, composed, drafted][index] === 0 && (index === 0 || [completed, selected, composed, drafted].slice(0, index).every(Boolean)));
    });
  }

  function renderCategories() {
    const container = $('#categoryScroller');
    if (!container) return;
    const sections = state.config.sections.filter((section) => section.enabled);
    container.innerHTML =
      '<button class="category-chip' + (state.activeSection === 'all' ? ' active' : '') + '" data-section="all" style="--chip-color:#ff6c51">全部热点</button>' +
      sections.map((section) =>
        '<button class="category-chip' + (state.activeSection === section.id ? ' active' : '') + '" data-section="' + escapeAttr(section.id) + '" style="--chip-color:' + escapeAttr(section.color) + '">' +
        escapeHtml(section.name) + '</button>'
      ).join('');
  }

  function newsCard(item, index, variant) {
    const selected = state.selected.includes(item.id);
    const image = item.image
      ? '<img src="' + escapeAttr(item.image) + '" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display=\'none\';this.parentElement.classList.add(\'no-image\')">'
      : '';
    const soft = hexToRgba(item.color || '#ff694b', 0.1);
    if (variant === 'news') {
      return '<article class="news-card' + (selected ? ' selected' : '') + '" data-id="' + escapeAttr(item.id) + '" style="--card-color:' + escapeAttr(item.color) + '">' +
        '<div class="news-card-copy">' +
          '<div class="news-card-top"><span class="news-card-section">' + escapeHtml(item.sectionName) + '</span><span class="news-card-time">' + escapeHtml(item.publishedLabel) + '</span>' +
          (item.demo ? '<span class="demo-tag">示例</span>' : '') + '</div>' +
          '<h4>' + escapeHtml(item.title) + '</h4>' +
          '<p>' + escapeHtml(item.summary) + '</p>' +
          '<div class="news-card-bottom"><button class="check-control" type="button" aria-label="选择">' + icon('check') + '</button><span class="source-name">' + escapeHtml(item.source) + '</span><span class="heat">' + Math.round(item.score || 70) + ' 热度</span></div>' +
        '</div>' +
        '<div class="news-thumb' + (item.image ? '' : ' no-image') + '">' + image + '</div>' +
      '</article>';
    }
    return '<article class="trend-card" data-id="' + escapeAttr(item.id) + '" style="--section-color:' + escapeAttr(item.color) + ';--section-soft:' + soft + '">' +
      '<button class="quick-select' + (selected ? ' selected' : '') + '" type="button" aria-label="选择素材">' + icon(selected ? 'check' : 'plus') + '</button>' +
      '<div class="trend-card-copy">' +
        '<div class="trend-card-meta"><span class="trend-rank">' + String(index + 1).padStart(2, '0') + ' · ' + escapeHtml(item.sectionName) + '</span><span>' + escapeHtml(item.publishedLabel) + '</span></div>' +
        '<h4>' + escapeHtml(item.title) + '</h4>' +
        '<p>' + escapeHtml(item.summary) + '</p>' +
        '<div class="trend-card-footer"><span>' + escapeHtml(item.source) + '</span><span class="heat">' + Math.round(item.score || 70) + '</span></div>' +
      '</div>' +
      '<div class="trend-image' + (item.image ? '' : ' no-image') + '">' + image + '<span class="image-source">' + escapeHtml(item.source) + '</span></div>' +
    '</article>';
  }

  function renderTrends() {
    const container = $('#trendGrid');
    if (!container) return;
    const items = getFilteredNews().slice(0, 5);
    if (!items.length) {
      container.innerHTML = '<div class="fatal-empty"><span>∅</span><h3>这个板块暂时没有内容</h3><p>可以切换其他板块或刷新数据源。</p></div>';
      return;
    }
    container.innerHTML = items.map((item, index) => newsCard(item, index, 'trend')).join('');
    $('#heroSignal').textContent = items[0].title;
  }

  function renderRadar() {
    const container = $('#radarList');
    if (!container) return;
    const sections = state.config.sections.map((section) => {
      const items = state.news.filter((item) => item.section === section.id);
      const score = items.length ? items.reduce((sum, item) => sum + (item.score || 70), 0) / items.length : 0;
      return Object.assign({}, section, { count: items.length, score });
    }).sort((a, b) => b.score - a.score).slice(0, 5);
    const max = Math.max(1, ...sections.map((section) => section.score));
    container.innerHTML = sections.map((section) =>
      '<div class="radar-row"><span>' + escapeHtml(section.name) + '</span><div class="radar-track"><i style="width:' +
      Math.max(4, Math.round(section.score / max * 100)) + '%;--row-color:' + escapeAttr(section.color) + '"></i></div><b>' +
      (section.count ? Math.round(section.score) : '—') + '</b></div>'
    ).join('');
    if (sections[0] && sections[0].count) {
      $('#tipTitle').textContent = sections[0].name + '板块值得关注';
      $('#tipText').textContent = '今天该板块有 ' + sections[0].count + ' 条新素材。建议选择“有清晰来源 + 有图片 + 可补充背景”的选题，再做事实核验。';
    }
  }

  function renderNewsFeed() {
    const container = $('#newsFeed');
    if (!container) return;
    const items = getFilteredNews();
    if (!items.length) {
      container.innerHTML = '<div class="fatal-empty"><span>∅</span><h3>没有匹配的素材</h3><p>试试清空搜索或切换资讯板块。</p></div>';
    } else {
      container.innerHTML = items.map((item, index) => newsCard(item, index, 'news')).join('');
    }
    const tabs = $('#filterTabs');
    const sections = state.config.sections.filter((section) => section.enabled);
    tabs.innerHTML =
      '<button class="filter-tab' + (state.activeSection === 'all' ? ' active' : '') + '" data-section="all">全部</button>' +
      sections.map((section) => '<button class="filter-tab' + (state.activeSection === section.id ? ' active' : '') + '" data-section="' + escapeAttr(section.id) + '">' + escapeHtml(section.name) + '</button>').join('');
  }

  function renderSelection() {
    const selected = getSelectedItems();
    $('#selectionCount').textContent = selected.length;
    const container = $('#selectionList');
    if (!selected.length) {
      container.innerHTML = '<div class="empty-mini"><span>' + icon('plus') + '</span><p>从左侧选择 1–5 条<br>开始创作</p></div>';
    } else {
      container.innerHTML = selected.map((item, index) =>
        '<div class="selected-mini"><span class="selected-index">' + String(index + 1).padStart(2, '0') + '</span><div><strong>' +
        escapeHtml(item.title) + '</strong><small>' + escapeHtml(item.source) + ' · ' + escapeHtml(item.sectionName) + '</small></div>' +
        '<button type="button" data-remove-selection="' + escapeAttr(item.id) + '" aria-label="移除">' + icon('close') + '</button></div>'
      ).join('');
    }
    updateCounts();
  }

  function toggleSelection(id) {
    const index = state.selected.indexOf(id);
    if (index >= 0) {
      state.selected.splice(index, 1);
    } else {
      if (state.selected.length >= 5) {
        showToast('最多选择 5 条', '更多素材会让短文失焦，建议保留最相关的几条。', 'info');
        return;
      }
      state.selected.push(id);
    }
    saveJson(STORE.selection, state.selected);
    renderTrends();
    renderNewsFeed();
    renderSelection();
    renderStoryboard();
    updateCounts();
  }

  function hexToRgba(hex, alpha) {
    const match = String(hex).replace('#', '').match(/^([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i);
    if (!match) return 'rgba(255,105,75,' + alpha + ')';
    return 'rgba(' + parseInt(match[1], 16) + ',' + parseInt(match[2], 16) + ',' + parseInt(match[3], 16) + ',' + alpha + ')';
  }

  function firstSentence(value) {
    const text = String(value || '').replace(/\s+/g, ' ').trim();
    const parts = text.match(/^.*?[。！？!?](?:\s|$)/);
    return truncate(parts ? parts[0] : text, 135);
  }

  function analysisFor(item, index) {
    const analyses = {
      general: ['从传播热度看，信息正在快速扩散，但不同渠道的表述仍有差异。', '这条消息与日常生活联系紧密，后续进展和官方回应值得继续关注。', '事件背后既有短期关注，也有长期结构性因素，需要把新闻放回具体语境中理解。'],
      society: ['公共议题的价值，不只在事件本身，也在于它如何影响普通人的日常选择。', '讨论社会治理，需要同时看效率、公平与执行成本，避免只凭单一细节下结论。', '后续值得关注的是服务能否真正落地，以及不同群体是否都能获得便利。'],
      finance: ['市场信息变化很快，单一指标不足以说明全部趋势，仍要结合后续数据观察。', '对普通读者而言，更重要的是理解变化会怎样传导到就业、消费与企业预期。', '判断经济信号时，应区分短期波动与中长期结构变化，避免把局部现象放大成整体结论。'],
      tech: ['技术进展值得关注，但最终价值仍取决于真实场景中的稳定性、成本与可用性。', '从产业发展看，技术、数据、算力与人才正在形成相互支撑的生态。', '面对快速迭代的新技术，既要看到效率提升，也要关注安全、隐私与使用门槛。'],
      world: ['国际议题往往牵动多个利益相关方，单一看法很难覆盖全部影响。', '观察后续变化时，需要同时留意政策表态、市场反应与区域合作动向。', '全球信息具有传导性，但不同市场与地区的实际影响可能并不相同。'],
      sports: ['竞技热点之外，赛事也在带动城市消费、公共空间与全民健身的讨论。', '成绩只是一面，训练体系、产业基础与大众参与度同样决定长期发展。', '体育内容的传播既要保留现场感，也应尊重规则、运动员与赛事组织。'],
      entertainment: ['文化内容的热度来自作品，也来自观众对现实议题的情感投射。', '评价文化消费，需要兼顾创作表达、用户体验与产业可持续性。', '好内容往往能跨越单一平台，让更多人愿意讨论、体验和分享。'],
      auto: ['汽车行业竞争正在从单一参数转向产品体验、补能网络与售后服务。', '消费者决策越来越重视长期使用成本，而不只是发布时的配置表。', '新能源与智能化仍在演进，企业需要把安全、质量和真实体验放在前面。']
    };
    const list = analyses[item.section] || analyses.general;
    return list[index % list.length];
  }

  function buildLocalArticle(template) {
    let items = getSelectedItems();
    if (!items.length) {
      items = state.news.filter((item) => item.image).slice(0, 3);
      if (!items.length) items = state.news.slice(0, 3);
    }
    if (!items.length) {
      showToast('还没有可用素材', '请先刷新资讯或从选题库选择内容。', 'info');
      return null;
    }
    const maxItems = template === 'brief' ? 3 : template === 'insight' ? 4 : 3;
    items = items.slice(0, maxItems);
    const date = formatDate();
    const first = items[0];
    const titles = {
      brief: '今日速览｜' + truncate(first.title, 20),
      insight: truncate(first.title, 20) + '：热点背后的三个观察',
      opinion: '从“' + truncate(first.title, 16) + '”说起'
    };
    let title = titles[template] || titles.brief;
    title = truncate(title.replace(/[｜：]+$/, ''), 30);

    const opening = template === 'opinion'
      ? '今天的热点很多，真正值得停下来想一想的是：这些消息与我们的日常究竟有什么关系。围绕“' + first.title + '”，可以从事实、影响和后续三个方面继续观察。'
      : '今天是' + date.full + '。从最新公开资讯中，我们梳理了几个值得关注的方向。以下内容基于媒体摘要整理，发布前仍需回到原始来源核验事实与图片授权。';

    let html = '<p>' + escapeHtml(opening) + '</p>';
    items.forEach((item, index) => {
      const heading = String(index + 1).padStart(2, '0') + '｜' + (index === 0 ? '今天发生了什么' : item.sectionName + '的新动向');
      html += '<h2>' + escapeHtml(heading) + '</h2>';
      html += '<p><strong>' + escapeHtml(truncate(item.title, 45)) + '</strong>。据' + escapeHtml(item.source || '公开报道') + '，' + escapeHtml(firstSentence(item.summary)) + '</p>';
      if (item.image) {
        html += '<figure><img src="' + escapeAttr(item.image) + '" alt="' + escapeAttr(item.title) + '"><figcaption>图片素材：' +
          escapeHtml(item.source || '新闻来源') + '（发布前请确认使用授权）</figcaption></figure>';
      }
      html += '<p>' + escapeHtml(analysisFor(item, index)) + '</p>';
      html += '<p><a href="' + escapeAttr(item.url) + '" target="_blank" rel="noreferrer">查看原文 · ' + escapeHtml(item.source || '来源') + '</a></p>';
    });

    const closing = template === 'opinion'
      ? '热点总会过去，但问题会留下。与其被标题推着走，不如多问一句：信息是否完整？影响落到谁身上？接下来值得观察什么？欢迎在评论区说说你的看法。'
      : template === 'insight'
        ? '把这些消息放在一起看，可以发现一个共同点：变化正在发生，但答案还没有完全展开。接下来，真实数据、执行细节与普通人感受到的变化，会比一时的情绪更重要。'
        : '以上就是今天的简要梳理。后续若有权威信息或重要进展，我们也会继续关注。你最关心哪一个话题？';
    html += '<hr><p>' + escapeHtml(closing) + '</p>';
    html += '<p><small>信息来源：' + items.map((item) => escapeHtml(item.source || '公开资讯')).join('、') +
      '。本文为资讯摘要与编辑整理，不代表原媒体观点；图片与事实请发布前再次核验。</small></p>';

    return {
      id: 'article_' + Date.now(),
      title,
      html,
      sources: items.map((item) => item.id),
      template,
      tags: unique([first.sectionName, '今日热点', template === 'opinion' ? '观点' : '资讯']).slice(0, 4),
      cover: first.image || '',
      status: 'editing',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  function generateArticle(useSelection) {
    const article = buildLocalArticle(state.template);
    if (!article) return null;
    state.article = article;
    state.tags = article.tags.slice();
    persistArticle();
    renderComposer();
    if (useSelection) showView('compose');
    showToast('短文已生成', '已用所选素材生成图文初稿，可在编辑器中继续完善。');
    return article;
  }

  function persistArticle() {
    if (!state.article) return;
    state.article.title = $('#articleTitle') ? $('#articleTitle').value.trim() : state.article.title;
    state.article.html = $('#articleContent') ? $('#articleContent').innerHTML : state.article.html;
    state.article.updatedAt = new Date().toISOString();
    state.article.tags = state.tags.slice();
    saveJson(STORE.article, state.article);
    updateComposerMetrics();
  }

  function renderComposer() {
    const title = $('#articleTitle');
    const content = $('#articleContent');
    if (!title || !content) return;
    if (state.article) {
      if (document.activeElement !== title) title.value = state.article.title || '';
      if (document.activeElement !== content) content.innerHTML = state.article.html || '';
      if (!state.tags.length) state.tags = (state.article.tags || []).slice();
    } else if (!content.innerHTML.trim() || content.textContent.includes('点击左侧选题库')) {
      content.innerHTML = '<p class="placeholder-line">点击选题库中的素材，或从右上角生成一篇短文。</p>';
    }
    resizeTitle();
    renderComposeSources();
    renderTags();
    updateComposerMetrics();
  }

  function renderComposeSources() {
    const container = $('#composeSources');
    if (!container) return;
    let items = state.selected.length ? getSelectedItems() : (state.article && state.article.sources || []).map((id) => state.news.find((item) => item.id === id)).filter(Boolean);
    if (!items.length) items = state.news.slice(0, 3);
    container.innerHTML = items.length ? items.map((item) =>
      '<div class="source-item"><span class="source-favicon">' + escapeHtml((item.source || '来').slice(0, 1)) + '</span>' +
      '<div><strong>' + escapeHtml(item.title) + '</strong><small>' + escapeHtml(item.source) + ' · ' + escapeHtml(item.publishedLabel) + '</small></div></div>'
    ).join('') : '<div class="empty-custom">' + icon('news') + '尚未选择素材</div>';
  }

  function updateComposerMetrics() {
    if (!$('#articleContent')) return;
    const title = $('#articleTitle').value;
    const text = $('#articleContent').innerText || '';
    const chars = text.replace(/\s/g, '').length;
    $('#titleCount').textContent = title.length + ' / 30';
    $('#charCount').textContent = chars;
    const sources = state.article && state.article.sources ? state.article.sources.length : state.selected.length;
    $('#sourceCount').textContent = sources + ' 个信息来源';
    $('#saveState').textContent = state.article ? '已自动保存' : '内容自动保存在本机';
    const cover = state.article && state.article.cover ? state.article.cover : getSelectedItems().find((item) => item.image)?.image;
    const strip = $('#coverStrip');
    if (cover) {
      const coverItem = state.news.find((item) => item.image === cover);
      strip.classList.add('has-cover');
      strip.innerHTML = '<img src="' + escapeAttr(cover) + '" alt="封面">' +
        '<div><strong>文章封面候选</strong><small>' + escapeHtml(coverItem ? coverItem.source : '素材图片') + '</small></div>' +
        '<button type="button" data-action="replace-cover">更换</button>';
    } else {
      strip.classList.remove('has-cover');
      strip.innerHTML = '';
    }
    const titleOk = title.length >= 6 && title.length <= 30;
    const imageOk = Boolean(cover);
    $('#checkTitle').checked = titleOk;
    $('#checkImage').checked = imageOk;
    $('#checkSource').checked = Boolean(sources);
    const checks = $$('.check-list input');
    const score = Math.round(checks.filter((input) => input.checked).length / Math.max(1, checks.length) * 100);
    const badge = $('#readyScore');
    badge.textContent = score === 100 ? '可以发布' : score + '% 完成';
    badge.classList.toggle('good', score >= 75);
  }

  function renderTags() {
    const list = $('#tagList');
    if (!list) return;
    if (!state.tags.length) {
      list.innerHTML = '<span>今日热点 <button type="button" data-remove-tag="今日热点">×</button></span>';
      state.tags = ['今日热点'];
    }
    list.innerHTML = state.tags.map((tag) =>
      '<span>' + escapeHtml(tag) + ' <button type="button" data-remove-tag="' + escapeAttr(tag) + '">×</button></span>'
    ).join('');
  }

  function resizeTitle() {
    const element = $('#articleTitle');
    if (!element) return;
    element.style.height = 'auto';
    element.style.height = Math.max(71, element.scrollHeight) + 'px';
  }

  function unique(values) {
    return Array.from(new Set(values.filter(Boolean)));
  }

  function syncDraft(status) {
    persistArticle();
    if (!state.article) return null;
    const existing = state.drafts.find((draft) => draft.id === state.article.id);
    const draft = Object.assign({}, state.article, {
      status: status || state.article.status || 'editing',
      plainText: stripHtml(state.article.html),
      updatedAt: new Date().toISOString()
    });
    state.article.status = draft.status;
    if (existing) Object.assign(existing, draft);
    else state.drafts.unshift(draft);
    state.drafts = state.drafts.slice(0, 50);
    saveJson(STORE.drafts, state.drafts);
    saveJson(STORE.article, state.article);
    renderDrafts();
    updateCounts();
    return draft;
  }

  async function saveDraftToServer(silent) {
    const draft = syncDraft(state.article ? state.article.status : 'editing');
    if (!draft) {
      showToast('还没有草稿内容', '请先刷新热点并生成一篇短文。', 'info');
      return null;
    }
    try {
      const result = await api('/api/draft', {
        method: 'POST',
        body: JSON.stringify({
          title: draft.title,
          html: $('#articleContent').innerHTML,
          text: stripHtml($('#articleContent').innerHTML),
          tags: state.tags,
          cover: draft.cover,
          kind: 'article',
          sources: draft.sources
        })
      });
      if (!silent) showToast('草稿已保存', result.htmlPath || '已保存到本机数据目录。');
      return result;
    } catch (error) {
      if (!silent) showToast('保存失败', error.message, 'error');
      return null;
    }
  }

  async function callAi(prompt, system) {
    return api('/api/ai', {
      method: 'POST',
      body: JSON.stringify({ prompt, system: system, temperature: 0.55 })
    });
  }

  async function refineWithAi() {
    if (!state.config.ai.enabled || !state.config.ai.hasKey) {
      showToast('还没有配置 AI', '可在“设置”中填写兼容 OpenAI 的服务地址、模型与 API Key。', 'info');
      showView('settings');
      return;
    }
    persistArticle();
    if (!state.article) {
      showToast('请先生成初稿', '选择素材后生成短文，再使用 AI 润色。', 'info');
      return;
    }
    showLoading('正在润色文章', state.config.ai.model + ' 正在调整结构、标题和信息密度。');
    const items = state.article.sources.map((id) => state.news.find((item) => item.id === id)).filter(Boolean);
    const facts = items.map((item, index) =>
      (index + 1) + '. 标题：' + item.title + '\n来源：' + item.source + '\n摘要：' + item.summary + '\n链接：' + item.url
    ).join('\n\n');
    const prompt = [
      '把下面的新闻素材整理成一篇可直接进入人工审核的中文短文。',
      '要求：不编造事实和数字；保留来源署名；标题不超过30个汉字；正文800-1100字；语言清楚、克制、有信息增量；可以给出观察，但必须与来源摘要一致。',
      '输出格式：第一行是“标题：...”，空一行，接下来是正文；使用小标题分段。',
      '原始事实：\n' + facts.slice(0, 12000)
    ].join('\n\n');
    try {
      const result = await callAi(prompt, '你是一名严谨的中文新闻编辑，擅长把公开资讯改写成有结构但不煽动情绪的短文。');
      if (!result.ok || !result.text) throw new Error(result.error || 'AI 未返回内容');
      const lines = result.text.trim().split(/\r?\n/);
      let title = state.article.title;
      if (lines[0] && /^[#标题：:\s]+/.test(lines[0])) {
        title = lines[0].replace(/^[#\s]*标题[：:\s]*/, '').replace(/^#+\s*/, '').trim();
        lines.shift();
      }
      const plain = lines.join('\n').trim();
      const paragraphs = plain.split(/\n{2,}/).map((part) => {
        const text = part.trim();
        if (!text) return '';
        if (/^[一二三四五六七八九十\d]+[、.．]/.test(text) || text.length < 26) {
          return '<h2>' + escapeHtml(text.replace(/^[一二三四五六七八九十\d]+[、.．]\s*/, '')) + '</h2>';
        }
        return '<p>' + escapeHtml(text).replace(/\n/g, '<br>') + '</p>';
      }).join('');
      state.article.title = truncate(title, 30);
      state.article.html = paragraphs || '<p>' + escapeHtml(plain) + '</p>';
      state.article.status = 'editing';
      saveJson(STORE.article, state.article);
      renderComposer();
      showToast('AI 润色完成', '请继续人工核验事实、来源和图片授权。');
    } catch (error) {
      showToast('AI 润色失败', error.message, 'error');
    } finally {
      hideLoading();
    }
  }

  async function copyArticle() {
    persistArticle();
    if (!state.article) {
      showToast('还没有文章', '请先生成短文。', 'info');
      return false;
    }
    const title = $('#articleTitle').value.trim();
    const content = $('#articleContent').innerHTML;
    const text = title + '\n\n' + stripHtml(content);
    return copyRich(title, content, text);
  }

  async function copyRich(title, html, plainText) {
    const fullHtml = '<h1>' + escapeHtml(title) + '</h1>' + html;
    try {
      if (navigator.clipboard && window.ClipboardItem) {
        await navigator.clipboard.write([new ClipboardItem({
          'text/html': new Blob([fullHtml], { type: 'text/html' }),
          'text/plain': new Blob([plainText], { type: 'text/plain' })
        })]);
        return true;
      }
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(plainText);
        return true;
      }
      throw new Error('Clipboard API unavailable');
    } catch (error) {
      const area = document.createElement('textarea');
      area.value = plainText;
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand('copy');
      area.remove();
      if (!ok) {
        showToast('复制失败', '请选中编辑器内容后手动复制。', 'error');
        return false;
      }
      return true;
    }
  }

  async function prepareToutiao() {
    if (!state.article) {
      showToast('请先生成文章', '选中素材并生成短文后，再准备今日头条草稿。', 'info');
      return;
    }
    await saveDraftToServer(true);
    const copied = await copyArticle();
    showPublishModal(copied);
  }

  function showPublishModal(copied) {
    showModal('准备发送到今日头条', "TODAY'S TOUTIAO",
      '<div class="publish-step"><span class="step-no">01</span><div><strong>' + (copied ? '图文已复制到剪贴板' : '请在编辑器内手动复制') + '</strong><p>热点工坊已保存本机草稿，并准备好纯文本与富文本。</p></div></div>' +
      '<div class="publish-step"><span class="step-no">02</span><div><strong>在头条创作页按 Ctrl + V</strong><p>把内容粘贴到标题和正文编辑器。图片较多时请逐张确认是否成功导入。</p></div></div>' +
      '<div class="publish-step"><span class="step-no">03</span><div><strong>补充封面并人工审核</strong><p>检查标题长度、段落格式、图片版权、来源署名和平台规则，再由你确认发布。</p></div></div>' +
      '<div class="modal-note">' + icon('check') + '<p>程序不会绕过今日头条登录或平台风控，也不会替你点击最终发布。这样能保留账号安全与内容审核环节。</p></div>',
      '<button class="btn btn-secondary" type="button" data-modal-close>返回编辑器</button>' +
      '<button class="btn btn-secondary" type="button" id="modalCopyAgain">' + icon('copy') + '再复制一次</button>' +
      '<button class="btn btn-primary" type="button" id="modalOpenToutiao">' + icon('external') + '打开今日头条</button>');
    $('#modalCopyAgain').addEventListener('click', async () => {
      const ok = await copyArticle();
      showToast(ok ? '内容已复制' : '复制失败', ok ? '打开创作页后直接按 Ctrl + V。' : '请回到编辑器手动复制。', ok ? 'success' : 'error');
    });
    $('#modalOpenToutiao').addEventListener('click', () => openToutiao(state.config.toutiaoUrl));
  }

  async function openToutiao(url) {
    closeModal();
    try {
      await api('/api/open', { method: 'POST', body: JSON.stringify({ url: url || state.config.toutiaoUrl }) });
      showToast('已打开今日头条', '若浏览器尚未登录，请先扫码登录，再按 Ctrl + V 粘贴已复制内容。', 'info');
    } catch (error) {
      showToast('打开失败', error.message, 'error');
    }
  }

  function renderDrafts() {
    const container = $('#draftList');
    if (!container) return;
    const pending = state.drafts.filter((draft) => draft.status !== 'ready').length;
    const ready = state.drafts.filter((draft) => draft.status === 'ready').length;
    $('#queuePending').textContent = pending;
    $('#queueReady').textContent = ready;
    $('#queueWeek').textContent = state.drafts.filter((draft) => {
      return Date.now() - new Date(draft.updatedAt || 0).getTime() < 7 * 86400000;
    }).length;
    if (!state.drafts.length) {
      container.innerHTML = '<div class="empty-state"><span>' + icon('pen') + '</span><h3>还没有保存的草稿</h3><p>从热点中选出素材，生成你的第一篇短文。</p><button class="btn btn-primary" type="button" data-view="compose">开始创作</button></div>';
      return;
    }
    container.innerHTML = state.drafts.map((draft) =>
      '<article class="draft-item" data-draft-id="' + escapeAttr(draft.id) + '">' +
        '<div class="draft-thumb">' + (draft.cover ? '<img src="' + escapeAttr(draft.cover) + '" alt="">' : '文') + '</div>' +
        '<div class="draft-copy"><h4>' + escapeHtml(draft.title || '未命名草稿') + '</h4><p><span>' + new Date(draft.updatedAt || Date.now()).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) +
        '</span><span>' + (draft.plainText || '').replace(/\s/g, '').length + ' 字</span><span class="draft-status ' + (draft.status === 'ready' ? 'ready' : '') + '">' + (draft.status === 'ready' ? '已准备' : '编辑中') + '</span></p></div>' +
        '<div class="draft-actions"><button class="btn btn-secondary btn-sm" type="button" data-edit-draft="' + escapeAttr(draft.id) + '">继续编辑</button><button class="icon-btn" type="button" data-delete-draft="' + escapeAttr(draft.id) + '" title="删除">' + icon('trash') + '</button></div>' +
      '</article>'
    ).join('');
  }

  function openDraft(id) {
    const draft = state.drafts.find((item) => item.id === id);
    if (!draft) return;
    state.article = Object.assign({}, draft);
    state.tags = (draft.tags || []).slice();
    saveJson(STORE.article, state.article);
    showView('compose');
    renderComposer();
  }

  function renderSources() {
    const grid = $('#sourceGrid');
    if (!grid) return;
    const allEnabled = state.config.sections.every((section) => section.enabled);
    $('#allSectionsToggle').checked = allEnabled;
    grid.innerHTML = state.config.sections.map((section) =>
      '<article class="source-card" style="--source-color:' + escapeAttr(section.color) + ';--source-soft:' + hexToRgba(section.color, .09) + '">' +
        '<div class="source-card-top"><span class="source-card-icon">' + escapeHtml(section.name.slice(0, 1)) + '</span><div><strong>' + escapeHtml(section.name) + '</strong><small>' + escapeHtml(section.query || '公开资讯检索') + '</small></div>' +
        '<label class="switch-label"><input type="checkbox" data-section-toggle="' + escapeAttr(section.id) + '"' + (section.enabled ? ' checked' : '') + '><i></i></label></div>' +
      '</article>'
    ).join('');
    const custom = $('#customFeedList');
    if (!state.config.customFeeds.length) {
      custom.innerHTML = '<div class="empty-custom">' + icon('rss') + '还没有自定义 RSS。支持 RSS 2.0 与 Atom 地址。</div>';
    } else {
      custom.innerHTML = state.config.customFeeds.map((feed) =>
        '<div class="custom-feed"><span>' + icon('rss') + '</span><div><strong>' + escapeHtml(feed.name) + '</strong><small>' + escapeHtml(feed.url) + '</small></div>' +
        '<label class="switch-label"><input type="checkbox" data-feed-toggle="' + escapeAttr(feed.url) + '"' + (feed.enabled ? ' checked' : '') + '><i></i></label>' +
        '<button class="icon-btn" type="button" data-remove-feed="' + escapeAttr(feed.url) + '" title="删除">' + icon('trash') + '</button></div>'
      ).join('');
    }
  }

  function renderSettings() {
    if (!$('#refreshMinutes')) return;
    $('#refreshMinutes').value = state.config.refreshMinutes || 20;
    $('#maxItems').value = state.config.maxItemsPerSection || 12;
    $('#aiEnabled').checked = Boolean(state.config.ai.enabled);
    $('#aiEnabledLabel').textContent = state.config.ai.enabled ? '已启用' : '未启用';
    $('#aiBaseUrl').value = state.config.ai.baseUrl || '';
    $('#aiModel').value = state.config.ai.model || '';
    $('#aiApiKey').value = '';
    $('#aiApiKey').placeholder = state.config.ai.hasKey ? '已保存 Key，留空保持不变' : '输入 API Key';
    $('#toutiaoUrl').value = state.config.toutiaoUrl || '';
    $('#videoUrl').value = state.config.videoUrl || '';
  }

  function updateAiStatus() {
    const active = state.config.ai && state.config.ai.enabled && state.config.ai.hasKey;
    $('#sidebarAiName').textContent = active ? (state.config.ai.model || 'AI 编辑') : '本地智能编辑';
    $('#sidebarAiStatus').textContent = active ? '已连接' : '就绪';
    $('#sidebarAiHint').textContent = active ? 'AI 润色已启用，可继续本地成稿' : '摘要与成稿均可离线完成';
  }

  async function saveConfig(showResult) {
    try {
      const payload = JSON.parse(JSON.stringify(state.config));
      payload.ai.apiKey = $('#aiApiKey') && $('#aiApiKey').value ? $('#aiApiKey').value.trim() : '';
      const result = await api('/api/config', { method: 'POST', body: JSON.stringify(payload) });
      state.config = Object.assign({}, DEFAULT_CONFIG, result.config);
      updateAiStatus();
      renderAll();
      if (showResult) showToast('设置已保存', '配置已写入本机数据目录。');
    } catch (error) {
      if (showResult) showToast('设置保存失败', error.message, 'error');
    }
  }

  async function saveSettings() {
    state.config.refreshMinutes = Number($('#refreshMinutes').value) || 20;
    state.config.maxItemsPerSection = Number($('#maxItems').value) || 12;
    state.config.ai.enabled = $('#aiEnabled').checked;
    state.config.ai.baseUrl = $('#aiBaseUrl').value.trim();
    state.config.ai.model = $('#aiModel').value.trim();
    state.config.toutiaoUrl = $('#toutiaoUrl').value.trim();
    state.config.videoUrl = $('#videoUrl').value.trim();
    await saveConfig(true);
    renderSettings();
  }

  function showAddFeedModal() {
    showModal('添加自定义 RSS', 'NEW DATA SOURCE',
      '<form id="addFeedForm" class="add-feed-form">' +
        '<label>名称<input name="name" required placeholder="例如：我的行业资讯"></label>' +
        '<label>RSS 地址<input name="url" type="url" required placeholder="https://example.com/feed.xml"></label>' +
        '<label>归入板块<select name="section">' + state.config.sections.map((section) => '<option value="' + escapeAttr(section.id) + '">' + escapeHtml(section.name) + '</option>').join('') + '</select></label>' +
      '</form>',
      '<button class="btn btn-secondary" type="button" data-modal-close>取消</button><button class="btn btn-primary" type="button" id="confirmAddFeed">' + icon('plus') + '添加数据源</button>');
    $('#confirmAddFeed').addEventListener('click', async () => {
      const form = $('#addFeedForm');
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      state.config.customFeeds.push({
        name: String(data.get('name')).trim(),
        url: String(data.get('url')).trim(),
        section: String(data.get('section')),
        enabled: true
      });
      await saveConfig(false);
      closeModal();
      showToast('数据源已添加', '下次刷新时会开始抓取该 RSS。');
    });
  }

  function ensureVideoStoryboard() {
    if (!state.selected.length && state.news.length) {
      state.selected = state.news.filter((item) => item.image).slice(0, 4).map((item) => item.id);
      if (!state.selected.length) state.selected = state.news.slice(0, 4).map((item) => item.id);
      saveJson(STORE.selection, state.selected);
      renderNewsFeed();
      renderSelection();
      renderTrends();
    }
    renderStoryboard();
    setupCanvas();
  }

  function renderStoryboard() {
    const container = $('#storyboardList');
    if (!container) return;
    const items = getSelectedItems();
    $('#storyboardCount').textContent = items.length + ' 镜';
    if (!items.length) {
      container.innerHTML = '<div class="empty-custom">' + icon('video') + '选择 3–5 条新闻素材开始</div>';
      return;
    }
    container.innerHTML = items.map((item, index) =>
      '<div class="storyboard-item"><span class="shot-no">' + String(index + 1).padStart(2, '0') + '</span><div><strong>' + escapeHtml(item.title) + '</strong><small>' +
      escapeHtml(item.sectionName) + ' · ' + (index === 0 ? '开场' : index === items.length - 1 ? '收尾' : '展开') + '</small></div>' +
      '<button type="button" data-remove-selection="' + escapeAttr(item.id) + '" aria-label="移除">' + icon('close') + '</button></div>'
    ).join('');
  }

  function setupCanvas() {
    const canvas = $('#videoCanvas');
    if (!canvas || state.videoRecording) return;
    const portrait = state.videoRatio === '9:16';
    canvas.width = portrait ? 1080 : 1280;
    canvas.height = portrait ? 1920 : 720;
    drawVideoFrame(itemsForVideo(), 0, 0, 0, true);
  }

  function itemsForVideo() {
    return getSelectedItems().slice(0, 5);
  }

  function canvasGradient(ctx, width, height, style, seed) {
    const palettes = [
      ['#18243b', '#273755', '#ff6b52'],
      ['#102b2a', '#18413e', '#5dd3a0'],
      ['#24203e', '#3b315b', '#a384ff'],
      ['#352126', '#58343b', '#ff8a69']
    ];
    const palette = palettes[seed % palettes.length];
    if (style === 'minimal') {
      ctx.fillStyle = '#f6f4ee';
      ctx.fillRect(0, 0, width, height);
      return;
    }
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, palette[0]);
    gradient.addColorStop(.65, palette[1]);
    gradient.addColorStop(1, palette[2]);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
  }

  function roundRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
  }

  function wrapCanvasText(ctx, text, maxWidth, maxLines) {
    const chars = Array.from(String(text || ''));
    const lines = [];
    let line = '';
    for (const char of chars) {
      const test = line + char;
      if (ctx.measureText(test).width > maxWidth && line) {
        lines.push(line);
        line = char;
        if (lines.length >= maxLines - 1) break;
      } else {
        line = test;
      }
    }
    if (line && lines.length < maxLines) lines.push(line);
    if (Array.from(String(text || '')).join('') !== lines.join('') && lines.length) {
      lines[lines.length - 1] = lines[lines.length - 1].replace(/[，。；、\s]+$/, '') + '…';
    }
    return lines;
  }

  const imageCache = new Map();
  function loadCanvasImage(url) {
    if (!url) return Promise.resolve(null);
    if (imageCache.has(url)) return imageCache.get(url);
    const promise = new Promise((resolve) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => resolve(null);
      image.src = '/api/image?url=' + encodeURIComponent(url);
    });
    imageCache.set(url, promise);
    return promise;
  }

  function drawImageCover(ctx, image, x, y, width, height, zoom) {
    if (!image) return false;
    const ratio = Math.max(width / image.width, height / image.height) * (zoom || 1);
    const sourceWidth = width / ratio;
    const sourceHeight = height / ratio;
    const sourceX = Math.max(0, (image.width - sourceWidth) / 2);
    const sourceY = Math.max(0, (image.height - sourceHeight) / 2);
    ctx.drawImage(image, sourceX, sourceY, sourceWidth, sourceHeight, x, y, width, height);
    return true;
  }

  async function drawVideoFrame(items, stage, stageProgress, globalProgress, forceIntro) {
    const canvas = $('#videoCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const portrait = height > width;
    const intro = forceIntro || stage < 0;
    const outro = stage >= items.length;
    const style = state.videoStyle;
    canvasGradient(ctx, width, height, style, stage < 0 ? 0 : stage + 1);
    ctx.save();
    ctx.globalAlpha = style === 'minimal' ? .06 : .09;
    ctx.strokeStyle = style === 'minimal' ? '#18243b' : '#ffffff';
    ctx.lineWidth = 2;
    const step = portrait ? 92 : 78;
    for (let x = 0; x < width; x += step) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
    }
    for (let y = 0; y < height; y += step) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
    }
    ctx.restore();

    const darkText = style === 'minimal';
    const textColor = darkText ? '#172033' : '#ffffff';
    const mutedColor = darkText ? '#7f8795' : '#a9b4c6';
    const accent = '#ff6c52';
    const margin = portrait ? 72 : 70;

    ctx.fillStyle = accent;
    ctx.fillRect(margin, portrait ? 74 : 44, portrait ? 64 : 48, 8);
    ctx.fillStyle = textColor;
    ctx.font = '700 ' + (portrait ? 30 : 22) + 'px "Microsoft YaHei UI"';
    ctx.fillText('热点工坊 · NEWS BRIEF', margin, portrait ? 130 : 96);
    ctx.textAlign = 'right';
    ctx.fillStyle = mutedColor;
    ctx.font = '500 ' + (portrait ? 24 : 18) + 'px "Microsoft YaHei UI"';
    ctx.fillText(formatDate().month + ' / ' + formatDate().day, width - margin, portrait ? 130 : 96);
    ctx.textAlign = 'left';

    if (intro) {
      ctx.fillStyle = mutedColor;
      ctx.font = '600 ' + (portrait ? 29 : 22) + 'px "Microsoft YaHei UI"';
      ctx.fillText('TODAY’S BRIEF  ·  今日资讯速览', margin, portrait ? 330 : 190);
      ctx.fillStyle = textColor;
      ctx.font = '800 ' + (portrait ? 102 : 66) + 'px "Microsoft YaHei UI"';
      const introLines = ['今天，值得', '关注的几件事'];
      introLines.forEach((line, index) => ctx.fillText(line, margin, (portrait ? 500 : 286) + index * (portrait ? 122 : 82)));
      ctx.fillStyle = accent;
      ctx.fillRect(margin, portrait ? 805 : 452, portrait ? 116 : 80, 10);
      ctx.fillStyle = mutedColor;
      ctx.font = '500 ' + (portrait ? 28 : 20) + 'px "Microsoft YaHei UI"';
      ctx.fillText(formatDate().full + ' · ' + items.length + ' 条热点', margin, portrait ? 862 : 494);
      drawIntroOrbit(ctx, width, height, portrait);
    } else if (outro) {
      ctx.fillStyle = mutedColor;
      ctx.font = '600 ' + (portrait ? 29 : 22) + 'px "Microsoft YaHei UI"';
      ctx.fillText('END OF BRIEF  ·  信息仍在更新', margin, portrait ? 350 : 205);
      ctx.fillStyle = textColor;
      ctx.font = '800 ' + (portrait ? 84 : 58) + 'px "Microsoft YaHei UI"';
      ['先核验，', '再表达。'].forEach((line, index) => ctx.fillText(line, margin, (portrait ? 500 : 300) + index * (portrait ? 110 : 75)));
      ctx.fillStyle = mutedColor;
      ctx.font = '500 ' + (portrait ? 28 : 20) + 'px "Microsoft YaHei UI"';
      ctx.fillText('关注热点工坊，明天继续为你梳理。', margin, portrait ? 785 : 452);
      ctx.fillStyle = accent;
      roundRect(ctx, margin, portrait ? 870 : 500, portrait ? 280 : 210, portrait ? 64 : 48, 14);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = '700 ' + (portrait ? 25 : 19) + 'px "Microsoft YaHei UI"';
      ctx.fillText('收藏 · 关注 · 讨论', margin + 35, portrait ? 912 : 532);
    } else {
      const item = items[Math.min(stage, items.length - 1)];
      const image = await loadCanvasImage(item && item.image);
      const imageTop = portrait ? 250 : 158;
      const imageHeight = portrait ? 790 : 340;
      const imageWidth = width - margin * 2;
      ctx.save();
      roundRect(ctx, margin, imageTop, imageWidth, imageHeight, portrait ? 24 : 18);
      ctx.clip();
      if (image && style !== 'minimal') {
        const zoom = 1 + Math.min(.06, stageProgress * .06);
        drawImageCover(ctx, image, margin, imageTop, imageWidth, imageHeight, zoom);
      } else {
        const fallback = ctx.createLinearGradient(margin, imageTop, width - margin, imageTop + imageHeight);
        fallback.addColorStop(0, darkText ? '#e8e4da' : '#334462');
        fallback.addColorStop(1, darkText ? '#d5cec0' : '#9c594e');
        ctx.fillStyle = fallback;
        ctx.fillRect(margin, imageTop, imageWidth, imageHeight);
        ctx.fillStyle = darkText ? 'rgba(25,33,49,.09)' : 'rgba(255,255,255,.08)';
        ctx.font = '900 ' + (portrait ? 150 : 96) + 'px "Microsoft YaHei UI"';
        ctx.fillText(item ? item.sectionName.slice(0, 1) : '热', margin + imageWidth / 2 - (portrait ? 75 : 50), imageTop + imageHeight / 2 + 50);
      }
      ctx.restore();

      ctx.fillStyle = 'rgba(10,18,31,.76)';
      roundRect(ctx, margin + 22, imageTop + imageHeight - 68, portrait ? 154 : 124, 42, 9);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = '700 ' + (portrait ? 21 : 16) + 'px "Microsoft YaHei UI"';
      ctx.fillText(item ? item.sectionName : '资讯', margin + 42, imageTop + imageHeight - 39);

      const titleTop = portrait ? 1110 : 535;
      ctx.fillStyle = accent;
      ctx.font = '800 ' + (portrait ? 24 : 18) + 'px "Microsoft YaHei UI"';
      ctx.fillText(String(stage + 1).padStart(2, '0') + '  /  ' + String(items.length).padStart(2, '0'), margin, titleTop);
      ctx.fillStyle = textColor;
      ctx.font = '800 ' + (portrait ? 60 : 39) + 'px "Microsoft YaHei UI"';
      const titleLines = wrapCanvasText(ctx, item ? item.title : '', width - margin * 2, portrait ? 4 : 2);
      titleLines.forEach((line, index) => ctx.fillText(line, margin, titleTop + (portrait ? 78 : 58) + index * (portrait ? 76 : 51)));
      const summaryTop = titleTop + (portrait ? 414 : 200);
      ctx.fillStyle = mutedColor;
      ctx.font = '500 ' + (portrait ? 29 : 21) + 'px "Microsoft YaHei UI"';
      const summaryLines = wrapCanvasText(ctx, item ? item.summary : '', width - margin * 2, portrait ? 3 : 2);
      summaryLines.forEach((line, index) => ctx.fillText(line, margin, summaryTop + index * (portrait ? 51 : 34)));
      ctx.fillStyle = darkText ? '#747c89' : '#8e9aad';
      ctx.font = '500 ' + (portrait ? 23 : 17) + 'px "Microsoft YaHei UI"';
      ctx.fillText('来源 · ' + (item ? item.source : '公开资讯'), margin, portrait ? 1770 : 680);
    }

    const lineY = height - (portrait ? 92 : 34);
    ctx.fillStyle = darkText ? 'rgba(23,32,51,.1)' : 'rgba(255,255,255,.12)';
    ctx.fillRect(margin, lineY, width - margin * 2, 4);
    ctx.fillStyle = accent;
    ctx.fillRect(margin, lineY, (width - margin * 2) * Math.max(.02, globalProgress || 0), 4);
    ctx.fillStyle = darkText ? '#626b79' : '#7a879b';
    ctx.font = '600 ' + (portrait ? 20 : 15) + 'px "Microsoft YaHei UI"';
    if (portrait) {
      ctx.fillText('热点工坊 · LOCAL NEWS STUDIO', margin, height - 45);
      ctx.textAlign = 'right';
      ctx.fillText('人工核验后发布', width - margin, height - 45);
      ctx.textAlign = 'left';
    }
  }

  function drawIntroOrbit(ctx, width, height, portrait) {
    ctx.save();
    ctx.strokeStyle = 'rgba(255,255,255,.09)';
    ctx.lineWidth = 2;
    const cx = portrait ? width * .78 : width * .8;
    const cy = portrait ? 1510 : height * .63;
    [110, 190, 270].forEach((radius) => {
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();
    });
    ctx.fillStyle = '#ff7258';
    ctx.beginPath();
    ctx.arc(cx + 160, cy - 60, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#6f93ed';
    ctx.beginPath();
    ctx.arc(cx - 205, cy + 95, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function videoSegments() {
    const items = itemsForVideo();
    const intro = 2.7;
    const outro = 2.6;
    const content = items.length ? Math.max(3.7, 24 / items.length) : 0;
    const total = intro + content * items.length + outro;
    return { items, intro, content, outro, total };
  }

  function frameAt(elapsed, animated) {
    const timeline = videoSegments();
    let stage;
    let stageProgress;
    if (elapsed < timeline.intro) {
      stage = -1;
      stageProgress = elapsed / timeline.intro;
    } else if (elapsed < timeline.intro + timeline.content * timeline.items.length) {
      const contentElapsed = elapsed - timeline.intro;
      stage = Math.floor(contentElapsed / timeline.content);
      stageProgress = (contentElapsed % timeline.content) / timeline.content;
    } else {
      stage = timeline.items.length;
      stageProgress = Math.min(1, (elapsed - timeline.intro - timeline.content * timeline.items.length) / timeline.outro);
    }
    drawVideoFrame(timeline.items, stage, stageProgress, elapsed / timeline.total, false);
    if (animated) {
      $('#timelineFill').style.width = Math.min(100, elapsed / timeline.total * 100) + '%';
      $('#videoDuration').textContent = '00:' + String(Math.floor(elapsed)).padStart(2, '0') + ' / 00:' + String(Math.ceil(timeline.total)).padStart(2, '0');
    }
  }

  function stopPreview() {
    if (state.videoCleanup) state.videoCleanup();
    state.videoCleanup = null;
    state.videoPreviewing = false;
  }

  function previewVideo() {
    if (state.videoBlob) {
      const video = $('#videoResult');
      if (video.paused) video.play();
      else video.pause();
      return;
    }
    if (state.videoPreviewing) {
      stopPreview();
      $('#previewVideoBtn').innerHTML = icon('play');
      return;
    }
    const items = itemsForVideo();
    if (!items.length) {
      showToast('没有视频素材', '请先从选题库选择新闻。', 'info');
      return;
    }
    $('#videoEmpty').hidden = true;
    $('#videoCanvas').hidden = false;
    state.videoPreviewing = true;
    $('#previewVideoBtn').innerHTML = icon('pause');
    const start = performance.now();
    let frameId;
    const loop = (now) => {
      const elapsed = ((now - start) / 1000) % videoSegments().total;
      frameAt(elapsed, true);
      if (state.videoPreviewing) frameId = requestAnimationFrame(loop);
    };
    frameId = requestAnimationFrame(loop);
    state.videoCleanup = () => {
      cancelAnimationFrame(frameId);
      $('#previewVideoBtn').innerHTML = icon('play');
    };
  }

  function videoNarration(items) {
    if (!items.length) return '今天有哪些值得关注的新闻？打开热点工坊，查看最新资讯。';
    const parts = ['你好，这里是热点工坊的今日资讯速览。'];
    items.forEach((item) => {
      parts.push(item.title + '。' + firstSentence(item.summary));
    });
    parts.push('以上就是今天的新闻。热点变化很快，发布前请核验来源、事实和图片授权。关注热点工坊，明天继续为你梳理。');
    return parts.join(' ');
  }

  function synthesizeEdgeTts(text, voice) {
    return new Promise((resolve, reject) => {
      if (!voice) {
        resolve(null);
        return;
      }
      const token = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
      const requestId = crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '') : String(Date.now()) + Math.random().toString(16).slice(2);
      const ws = new WebSocket('wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=' + token);
      const chunks = [];
      let settled = false;
      const timeout = setTimeout(() => finish(new Error('在线语音连接超时')), 28000);
      function finish(error, blob) {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        try { ws.close(); } catch (ignore) {}
        if (error) reject(error);
        else resolve(blob);
      }
      ws.binaryType = 'arraybuffer';
      ws.onopen = () => {
        try {
          const config = 'X-Timestamp:' + new Date().toString() + '\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n' +
            JSON.stringify({ context: { synthesis: { audio: { metadataoptions: { sentenceBoundaryEnabled: false, wordBoundaryEnabled: false }, outputFormat: 'audio-24khz-48kbitrate-mono-mp3' } } } });
          ws.send(config);
          const safeText = String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
          const ssml = 'X-RequestId:' + requestId + '\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:' + new Date().toString() +
            '\r\nPath:ssml\r\n\r\n<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="zh-CN"><voice name="' +
            voice + '"><prosody rate="+5%" pitch="+0Hz">' + safeText + '</prosody></voice></speak>';
          ws.send(ssml);
        } catch (error) {
          finish(error);
        }
      };
      ws.onmessage = (event) => {
        if (typeof event.data === 'string') {
          if (event.data.includes('Path:turn.end')) {
            if (!chunks.length) finish(new Error('在线语音没有返回音频'));
            else finish(null, new Blob(chunks, { type: 'audio/mpeg' }));
          }
          return;
        }
        const buffer = event.data;
        const view = new DataView(buffer);
        if (buffer.byteLength < 2) return;
        const headerSize = view.getUint16(0);
        if (buffer.byteLength < 2 + headerSize) return;
        const header = new TextDecoder().decode(new Uint8Array(buffer, 2, Math.min(headerSize, 300)));
        if (header.includes('Path:audio')) chunks.push(new Uint8Array(buffer, 2 + headerSize));
      };
      ws.onerror = () => finish(new Error('在线语音服务暂不可用'));
      ws.onclose = () => {
        if (!settled) {
          if (chunks.length) finish(null, new Blob(chunks, { type: 'audio/mpeg' }));
          else finish(new Error('在线语音连接已关闭'));
        }
      };
    });
  }

  function selectRecorderMime() {
    const formats = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    return formats.find((type) => window.MediaRecorder && MediaRecorder.isTypeSupported(type)) || '';
  }

  async function renderVideo() {
    if (state.videoRecording) return;
    const items = itemsForVideo();
    if (!items.length) {
      showToast('请先选择素材', '微视频需要 1–5 条新闻素材。', 'info');
      return;
    }
    if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) {
      showToast('当前浏览器不支持视频录制', '请使用最新版 Edge 或 Chrome。', 'error');
      return;
    }
    stopPreview();
    state.videoRecording = true;
    state.videoPreviewing = false;
    $('#renderVideoBtn').disabled = true;
    $('#videoResult').hidden = true;
    $('#videoCanvas').hidden = false;
    $('#videoEmpty').hidden = true;
    $('#videoState').textContent = '正在合成…';
    showLoading('正在生成微视频', '正在预加载新闻图片、生成旁白并录制画面。');
    try {
      await Promise.all(items.map((item) => loadCanvasImage(item.image)));
      const voice = $('#voiceSelect').value;
      let narrationAudio = null;
      let audioContext = null;
      let sourceNode = null;
      if (voice) {
        try {
          showLoading('正在生成旁白', '首次使用需要连接在线语音服务，请稍候。');
          const audioBlob = await synthesizeEdgeTts(videoNarration(items), voice);
          if (audioBlob && audioBlob.size > 1000) {
            narrationAudio = new Audio(URL.createObjectURL(audioBlob));
            narrationAudio.preload = 'auto';
            await new Promise((resolve, reject) => {
              narrationAudio.onloadedmetadata = resolve;
              narrationAudio.onerror = () => reject(new Error('旁白音频载入失败'));
              setTimeout(resolve, 7000);
            });
          }
        } catch (error) {
          showToast('旁白生成失败', '将改为生成带字幕的静音视频：' + error.message, 'info');
          narrationAudio = null;
        }
      }

      const canvas = $('#videoCanvas');
      setupCanvas();
      const canvasStream = canvas.captureStream(30);
      const tracks = canvasStream.getVideoTracks().slice();
      if (narrationAudio && narrationAudio.duration && isFinite(narrationAudio.duration)) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        await audioContext.resume();
        sourceNode = audioContext.createMediaElementSource(narrationAudio);
        const destination = audioContext.createMediaStreamDestination();
        sourceNode.connect(destination);
        sourceNode.connect(audioContext.destination);
        destination.stream.getAudioTracks().forEach((track) => tracks.push(track));
      }
      const stream = new MediaStream(tracks);
      const mimeType = selectRecorderMime();
      const recorder = new MediaRecorder(stream, Object.assign({ videoBitsPerSecond: 5500000, audioBitsPerSecond: 128000 }, mimeType ? { mimeType: mimeType } : {}));
      const chunks = [];
      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size) chunks.push(event.data);
      };
      const stopped = new Promise((resolve) => {
        recorder.onstop = () => resolve(new Blob(chunks, { type: mimeType || 'video/webm' }));
      });

      const baseTimeline = videoSegments();
      const targetDuration = narrationAudio && isFinite(narrationAudio.duration) && narrationAudio.duration > 6
        ? Math.max(baseTimeline.total, narrationAudio.duration + .8)
        : baseTimeline.total;
      recorder.start(1000);
      if (narrationAudio) {
        try { await narrationAudio.play(); } catch (error) { console.warn('Audio play failed', error); }
      }
      const started = performance.now();
      await new Promise((resolve) => {
        let frameId;
        const draw = (now) => {
          const elapsed = (now - started) / 1000;
          const ratio = elapsed / targetDuration;
          const adjusted = Math.min(targetDuration, ratio * videoSegments().total);
          frameAt(adjusted, true);
          if (elapsed < targetDuration) frameId = requestAnimationFrame(draw);
          else {
            cancelAnimationFrame(frameId);
            resolve();
          }
        };
        frameId = requestAnimationFrame(draw);
      });
      if (recorder.state !== 'inactive') recorder.stop();
      if (narrationAudio) narrationAudio.pause();
      const blob = await stopped;
      if (state.videoUrl) URL.revokeObjectURL(state.videoUrl);
      state.videoBlob = blob;
      state.videoUrl = URL.createObjectURL(blob);
      const video = $('#videoResult');
      video.src = state.videoUrl;
      video.hidden = false;
      canvas.hidden = true;
      $('#downloadVideoBtn').disabled = false;
      $('#videoState').textContent = '生成完成 · ' + Math.round(targetDuration) + ' 秒';
      $('#videoDuration').textContent = '00:00 / 00:' + String(Math.round(targetDuration)).padStart(2, '0');
      $('#timelineFill').style.width = '100%';
      showToast('微视频已生成', '请预览并检查画面、字幕、旁白与素材授权，再下载发布。');
      if (sourceNode) sourceNode.disconnect();
      if (audioContext) audioContext.close();
    } catch (error) {
      console.error(error);
      showToast('视频生成失败', error.message, 'error');
      $('#videoState').textContent = '生成失败';
      setupCanvas();
    } finally {
      state.videoRecording = false;
      $('#renderVideoBtn').disabled = false;
      hideLoading();
    }
  }

  function downloadVideo() {
    if (!state.videoBlob || !state.videoUrl) {
      showToast('还没有成片', '请先生成微视频。', 'info');
      return;
    }
    const link = document.createElement('a');
    link.href = state.videoUrl;
    link.download = '热点工坊_新闻微视频_' + new Date().toISOString().slice(0, 10) + '.webm';
    document.body.appendChild(link);
    link.click();
    link.remove();
    showToast('已开始下载', '成片为 WebM 格式，可直接上传到支持该格式的视频平台。');
  }

  function fullscreenVideo() {
    const target = state.videoBlob ? $('#videoResult') : $('#videoCanvas');
    if (target.requestFullscreen) {
      target.requestFullscreen().catch(() => {
        showToast('无法进入全屏', '请使用浏览器的全屏功能。', 'info');
      });
    }
  }

  function bindEvents() {
    document.addEventListener('click', async (event) => {
      const viewTarget = event.target.closest('[data-view]');
      if (viewTarget) {
        const view = viewTarget.getAttribute('data-view');
        if (view === 'compose' && !state.article) generateArticle(false);
        showView(view);
      }

      const sectionTarget = event.target.closest('[data-section]');
      if (sectionTarget) {
        state.activeSection = sectionTarget.getAttribute('data-section');
        renderCategories();
        renderTrends();
        renderNewsFeed();
      }

      const trendCard = event.target.closest('.trend-card');
      if (trendCard) toggleSelection(trendCard.getAttribute('data-id'));
      const newsCardNode = event.target.closest('.news-card');
      if (newsCardNode && !event.target.closest('a')) toggleSelection(newsCardNode.getAttribute('data-id'));

      const removeSelection = event.target.closest('[data-remove-selection]');
      if (removeSelection) {
        event.stopPropagation();
        toggleSelection(removeSelection.getAttribute('data-remove-selection'));
      }
      const removeTag = event.target.closest('[data-remove-tag]');
      if (removeTag) {
        state.tags = state.tags.filter((tag) => tag !== removeTag.getAttribute('data-remove-tag'));
        renderTags();
      }
      const editDraft = event.target.closest('[data-edit-draft]');
      if (editDraft) openDraft(editDraft.getAttribute('data-edit-draft'));
      const deleteDraft = event.target.closest('[data-delete-draft]');
      if (deleteDraft) {
        const id = deleteDraft.getAttribute('data-delete-draft');
        const draft = state.drafts.find((item) => item.id === id);
        if (draft && confirm('确定删除草稿“' + draft.title + '”吗？')) {
          state.drafts = state.drafts.filter((item) => item.id !== id);
          if (state.article && state.article.id === id) state.article = null;
          saveJson(STORE.drafts, state.drafts);
          if (!state.article) localStorage.removeItem(STORE.article);
          renderDrafts();
          updateCounts();
          showToast('草稿已删除');
        }
      }
      const removeFeed = event.target.closest('[data-remove-feed]');
      if (removeFeed) {
        const url = removeFeed.getAttribute('data-remove-feed');
        state.config.customFeeds = state.config.customFeeds.filter((feed) => feed.url !== url);
        await saveConfig(false);
        showToast('数据源已移除');
      }
      if (event.target.closest('[data-action="refresh"]')) fetchNews(true);
      if (event.target.closest('[data-action="replace-cover"]')) {
        const withImages = state.news.filter((item) => item.image);
        if (withImages.length > 1 && state.article) {
          const current = state.article.cover;
          const currentIndex = withImages.findIndex((item) => item.image === current);
          state.article.cover = withImages[(currentIndex + 1) % withImages.length].image;
          saveJson(STORE.article, state.article);
          renderComposer();
          showToast('封面候选已更换');
        }
      }
      if (event.target.closest('[data-modal-close]') || event.target.id === 'modalBackdrop') closeModal();
    });

    $$('.nav-item').forEach((node) => node.addEventListener('click', () => showView(node.dataset.view)));
    $('#menuBtn').addEventListener('click', () => {
      $('#sidebar').classList.add('open');
      $('#mobileBackdrop').classList.add('open');
    });
    $('#mobileBackdrop').addEventListener('click', closeMobileMenu);
    $('#topCreateBtn').addEventListener('click', () => {
      if (!state.article) generateArticle(false);
      showView('compose');
    });
    $('#fetchNowBtn').addEventListener('click', () => fetchNews(true));
    $('#refreshFeedBtn').addEventListener('click', () => fetchNews(true));
    $('#clearSelection').addEventListener('click', () => {
      state.selected = [];
      saveJson(STORE.selection, state.selected);
      renderAll();
    });
    $('#buildFromNewsBtn').addEventListener('click', () => generateArticle(true));
    $('#selectionCompose').addEventListener('click', () => generateArticle(true));
    $('#selectionVideo').addEventListener('click', () => {
      ensureVideoStoryboard();
      showView('video');
    });
    $('#templateSwitch').addEventListener('click', (event) => {
      const button = event.target.closest('[data-template]');
      if (!button) return;
      state.template = button.dataset.template;
      $$('#templateSwitch button').forEach((node) => node.classList.toggle('active', node === button));
      if (state.article || state.selected.length) generateArticle(false);
    });
    $('#articleTitle').addEventListener('input', () => {
      resizeTitle();
      persistArticle();
    });
    $('#articleContent').addEventListener('input', () => {
      persistArticle();
      clearTimeout(window.__articleSaveTimer);
      window.__articleSaveTimer = setTimeout(() => persistArticle(), 400);
    });
    $('#tagInput').addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ',') return;
      event.preventDefault();
      const value = event.currentTarget.value.trim().replace(/,$/, '');
      if (!value) return;
      state.tags = unique(state.tags.concat(value)).slice(0, 6);
      event.currentTarget.value = '';
      renderTags();
      persistArticle();
    });
    $('#saveDraftBtn').addEventListener('click', () => saveDraftToServer(false));
    $('#publishPrepBtn').addEventListener('click', prepareToutiao);
    $('#aiRefineBtn').addEventListener('click', refineWithAi);
    $('#openToutiaoOnly').addEventListener('click', () => openToutiao(state.config.toutiaoUrl));
    $('#openToutiaoSettings').addEventListener('click', () => openToutiao(state.config.toutiaoUrl));
    $('#downloadVideoBtn').addEventListener('click', downloadVideo);
    $('#renderVideoBtn').addEventListener('click', renderVideo);
    $('#previewVideoBtn').addEventListener('click', previewVideo);
    $('#videoFullscreen').addEventListener('click', fullscreenVideo);
    $('#openVideoPublish').addEventListener('click', () => {
      if (state.videoBlob) downloadVideo();
      openToutiao(state.config.videoUrl);
    });
    $('#ratioSwitch').addEventListener('click', (event) => {
      const button = event.target.closest('[data-ratio]');
      if (!button) return;
      state.videoRatio = button.dataset.ratio;
      $$('#ratioSwitch button').forEach((node) => node.classList.toggle('active', node === button));
      state.videoBlob = null;
      $('#downloadVideoBtn').disabled = true;
      $('#videoResult').hidden = true;
      $('#videoCanvas').hidden = false;
      $('#videoEmpty').hidden = false;
      setupCanvas();
    });
    $('#videoStyle').addEventListener('change', (event) => {
      state.videoStyle = event.target.value;
      setupCanvas();
    });
    $('#addSourceBtn').addEventListener('click', showAddFeedModal);
    $('#allSectionsToggle').addEventListener('change', async (event) => {
      state.config.sections.forEach((section) => { section.enabled = event.target.checked; });
      await saveConfig(false);
      renderSources();
    });
    document.addEventListener('change', async (event) => {
      if (event.target.matches('[data-section-toggle]')) {
        const section = state.config.sections.find((item) => item.id === event.target.dataset.sectionToggle);
        if (section) section.enabled = event.target.checked;
        await saveConfig(false);
      }
      if (event.target.matches('[data-feed-toggle]')) {
        const feed = state.config.customFeeds.find((item) => item.url === event.target.dataset.feedToggle);
        if (feed) feed.enabled = event.target.checked;
        await saveConfig(false);
      }
      if (event.target.id === 'aiEnabled') {
        $('#aiEnabledLabel').textContent = event.target.checked ? '已启用' : '未启用';
      }
    });
    $('#saveSettingsBtn').addEventListener('click', saveSettings);
    $('#openDataBtn').addEventListener('click', async () => {
      try {
        await api('/api/open-data', { method: 'POST', body: '{}' });
      } catch (error) {
        showToast('打开失败', error.message, 'error');
      }
    });
    $('#globalSearch').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        state.search = event.currentTarget.value.trim();
        $('#newsSearch').value = state.search;
        showView('news');
        renderNewsFeed();
      }
    });
    $('#newsSearch').addEventListener('input', (event) => {
      state.search = event.currentTarget.value;
      renderNewsFeed();
    });
    document.addEventListener('keydown', (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        $('#globalSearch').focus();
      }
      if (event.key === 'Escape') {
        closeModal();
        closeMobileMenu();
      }
    });
    $$('.check-list input').forEach((input) => input.addEventListener('change', updateComposerMetrics));
    $('#videoResult').addEventListener('timeupdate', () => {
      const video = $('#videoResult');
      if (video.duration && isFinite(video.duration)) {
        $('#timelineFill').style.width = video.currentTime / video.duration * 100 + '%';
        $('#videoDuration').textContent = '00:' + String(Math.floor(video.currentTime)).padStart(2, '0') + ' / 00:' + String(Math.floor(video.duration)).padStart(2, '0');
      }
    });
  }

  async function init() {
    setDates();
    bindEvents();
    reportClientLog('boot', 'app initialized');
    const cached = loadJson(STORE.news, null);
    if (cached && Array.isArray(cached.items) && cached.items.length) {
      state.news = cached.items.map(normalizeNewsItem);
      state.mode = cached.mode || 'cache';
      state.updatedAt = cached.updatedAt || '';
      state.selected = state.selected.filter((id) => state.news.some((item) => item.id === id));
      renderAll();
    } else {
      renderSkeletons();
    }
    await Promise.all([loadConfig(), loadHealth()]);
    renderAll();
    const force = new URLSearchParams(location.search).get('refresh') === '1';
    await fetchNews(force);
    if (force) history.replaceState(null, '', location.pathname);
  }

  init();
})();
