(() => {
  if (document.getElementById('hotspot-video-download-host')) return;

  const host = document.createElement('div');
  host.id = 'hotspot-video-download-host';
  host.style.cssText = 'position:fixed!important;left:24px!important;top:96px!important;z-index:2147483647!important;pointer-events:auto!important;';
  const shadow = host.attachShadow({ mode: 'open' });
  const style = document.createElement('style');
  style.textContent = `
    button {
      display: flex; align-items: center; gap: 7px; min-height: 38px; padding: 0 14px;
      border: 1px solid rgba(255,255,255,.34); border-radius: 19px;
      background: linear-gradient(135deg, #2e7f5c, #1f6047); color: #fff;
      box-shadow: 0 8px 24px rgba(15,54,39,.28); cursor: pointer;
      font: 700 12px/1 "Microsoft YaHei UI", sans-serif;
    }
    button:hover { background: linear-gradient(135deg, #37966c, #266f52); }
    button[disabled] { opacity: .7; cursor: wait; }
    svg { width: 15px; height: 15px; }
  `;
  const button = document.createElement('button');
  button.type = 'button';
  button.title = '支持公开或已授权的视频直链；会员 DRM 内容请使用官方下载';
  button.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12M7 10l5 5 5-5M4 20h16"/></svg><span>下载原片到热点工坊</span>';
  shadow.append(style, button);
  const mountHost = () => {
    const fullscreenElement = document.fullscreenElement;
    const target = fullscreenElement && fullscreenElement.tagName !== 'VIDEO'
      ? fullscreenElement : document.documentElement;
    if (host.parentNode !== target) target.appendChild(host);
  };
  mountHost();
  document.addEventListener('fullscreenchange', () => {
    mountHost();
    setTimeout(() => {
      host.style.display = 'block';
    }, 60);
  });

  button.addEventListener('click', async () => {
    button.disabled = true;
    button.querySelector('span').textContent = '正在读取视频…';
    try {
      const result = await chrome.runtime.sendMessage({ type: 'download-video-now' });
      if (!result || !result.ok) throw new Error(result && result.error || '下载失败');
      button.querySelector('span').textContent = '正在下载到热点工坊';
    } catch (error) {
      button.querySelector('span').textContent = '未找到可下载原片';
    } finally {
      setTimeout(() => {
        button.disabled = false;
        button.querySelector('span').textContent = '下载原片到热点工坊';
      }, 3200);
    }
  });

  const updateVisibility = () => {
    const videos = Array.from(document.querySelectorAll('video'));
    const hasPlayingVideo = videos.some((video) =>
      (video.clientWidth > 120 && video.clientHeight > 80) ||
      Boolean(video.currentSrc) || video.readyState > 0
    );
    const supportedHost = /(^|\.)(youku\.com|v\.qq\.com|mgtv\.com|iqiyi\.com|bilibili\.com|youtube\.com|ted\.com|archive\.org|baidu\.com|sohu\.com)$/i
      .test(location.hostname);
    const topFrame = window.top === window;
    host.style.display = (hasPlayingVideo || (topFrame && supportedHost)) ? 'block' : 'none';
  };
  updateVisibility();
  new MutationObserver(updateVisibility).observe(document.documentElement, { childList: true, subtree: true });
  setInterval(updateVisibility, 2500);
})();
